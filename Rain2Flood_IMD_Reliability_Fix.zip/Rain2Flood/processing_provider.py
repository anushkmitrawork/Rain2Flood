from qgis.core import QgsProcessingProvider
from .dem_slope_processing    import DemSlopeProcessing
from .flash_flood_analysis    import FlashFloodAnalysis
from .standard_flood_analysis import StandardFloodAnalysis
from .rainfall_data_downloader import RainfallDataDownloader

class Rain2FloodProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(DemSlopeProcessing())
        self.addAlgorithm(FlashFloodAnalysis())
        self.addAlgorithm(StandardFloodAnalysis())
        self.addAlgorithm(RainfallDataDownloader())

    def id(self):           return 'rain2flood'
    def name(self):         return 'Rain2Flood'
    def longName(self):     return 'Rain2Flood Hydrological Toolkit v3.0'
    def versionInfo(self):  return '2.0.0'
