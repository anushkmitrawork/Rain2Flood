"""
Extent Picker
=============
A small widget for choosing a rectangular area of interest three ways:

  * the full extent of any loaded layer
  * the current map canvas extent
  * a rectangle drawn on the canvas

Why this replaced "Catchment layer" on the CN / LULC tab
---------------------------------------------------------
That tab downloads land cover and derives CN and Manning's rasters. None
of that needs a catchment — it needs to know WHICH AREA to fetch and
process. Demanding a polygon there was the same circularity as elsewhere
in the plugin: the catchment is delineated later, from a pour point, so
at CN-generation time the user frequently does not have one yet and had
to go and invent a boundary just to get past the field.

A bounding box is also what the underlying operations actually consume.
The ESA WorldCover download takes a lat/lon bbox. The LULC derivation
clips to geometries, and a rectangle is a perfectly good geometry. Only
the uniform-CN generator wanted a real polygon, and for a uniform raster
the shape is irrelevant.

Generating CN over a slightly larger rectangle is harmless: the flood
tabs clip to the delineated catchment when they run, so the surplus is
discarded at the point it would otherwise matter. Generating it over too
SMALL an area is the failure that hurts, which is why the padding option
exists and defaults to on.
"""

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QLabel,
    QDoubleSpinBox, QCheckBox,
)
from qgis.PyQt.QtCore import pyqtSignal

from qgis.core import (
    QgsProject, QgsCoordinateTransform, QgsCoordinateReferenceSystem,
    QgsRectangle, QgsGeometry, QgsPointXY,
)


# ── Draw-on-canvas tool ──────────────────────────────────────────────────
class _ExtentDrawTool:
    """
    Thin wrapper over QgsMapToolExtent.

    Wrapped rather than used directly so the widget keeps working if the
    class is unavailable: QgsMapToolExtent has moved between qgis.gui
    namespaces across releases, and an ImportError at module scope would
    take the whole CN tab down rather than just disabling one button.
    """

    def __init__(self, canvas, on_done):
        from qgis.gui import QgsMapToolExtent
        self._canvas = canvas
        self._prev = canvas.mapTool()
        self._tool = QgsMapToolExtent(canvas)
        self._on_done = on_done
        self._tool.extentChanged.connect(self._done)

    def start(self):
        self._canvas.setMapTool(self._tool)

    def _done(self, rect):
        try:
            self._on_done(rect)
        finally:
            # Always hand the canvas back. Leaving a rubber-band tool
            # active after the user has drawn makes the map feel broken.
            self._canvas.unsetMapTool(self._tool)
            if self._prev is not None:
                self._canvas.setMapTool(self._prev)


# ── Widget ───────────────────────────────────────────────────────────────
class ExtentPicker(QWidget):
    """
    Emits `extentChanged` whenever the chosen area changes.

    Read the result with extent_4326() / geoms_4326() / as_temp_gpkg().
    """

    extentChanged = pyqtSignal()

    MODE_LAYER = 0
    MODE_CANVAS = 1
    MODE_DRAWN = 2

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self._iface = iface
        self._drawn = None            # QgsRectangle in canvas CRS
        self._drawn_crs = None
        self._tool = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        self.mode = QComboBox()
        self.mode.addItems([
            'Full extent of a layer',
            'Current map canvas extent',
            'Rectangle drawn on the canvas',
        ])
        self.mode.setToolTip(
            'Which area to download land cover for and derive CN / '
            "Manning's rasters over. A catchment polygon is not needed — "
            'the flood tabs clip to the delineated catchment when they run.')
        self.layer = QComboBox()
        self.layer.setToolTip(
            'Any loaded layer. Its full extent (bounding box) is used, '
            'not its shape.')
        row1.addWidget(self.mode, 1)
        row1.addWidget(self.layer, 1)
        root.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        self.btn_draw = QPushButton('Draw on Canvas')
        self.btn_draw.setToolTip(
            'Click and drag a rectangle on the map. The canvas returns to '
            'your previous tool afterwards.')
        self.btn_refresh = QPushButton('Refresh')
        self.btn_refresh.setToolTip(
            'Re-read the canvas extent or the layer list after panning, '
            'zooming, or adding layers.')
        self.pad_on = QCheckBox('Pad by')
        self.pad_on.setChecked(True)
        self.pad_on.setToolTip(
            'Enlarge the area slightly. Land cover that stops short of the '
            'catchment edge leaves holes in the CN raster, and a hole is a '
            'much worse problem than a little surplus.')
        self.pad = QDoubleSpinBox()
        self.pad.setRange(0.0, 50.0)
        self.pad.setValue(5.0)
        self.pad.setSuffix(' %')
        self.pad.setDecimals(1)
        self.pad.setFixedWidth(84)
        row2.addWidget(self.btn_draw)
        row2.addWidget(self.btn_refresh)
        row2.addStretch()
        row2.addWidget(self.pad_on)
        row2.addWidget(self.pad)
        root.addLayout(row2)

        self.summary = QLabel('—')
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)

        self.mode.currentIndexChanged.connect(self._mode_changed)
        self.layer.currentIndexChanged.connect(self._emit)
        self.pad_on.toggled.connect(self._emit)
        self.pad.valueChanged.connect(self._emit)
        self.btn_draw.clicked.connect(self._start_draw)
        self.btn_refresh.clicked.connect(self.refresh)

        self.refresh()
        self._mode_changed(self.mode.currentIndex())

    # ── population ───────────────────────────────────────────────────────
    def refresh(self):
        """Re-read the layer list, keeping the current selection if it survives."""
        current = self.layer.currentData()
        self.layer.blockSignals(True)
        self.layer.clear()
        try:
            for lyr in QgsProject.instance().mapLayers().values():
                try:
                    if lyr.extent().isEmpty():
                        continue
                except Exception:
                    continue
                self.layer.addItem(lyr.name(), lyr.id())
        except Exception:
            pass
        if current is not None:
            i = self.layer.findData(current)
            if i >= 0:
                self.layer.setCurrentIndex(i)
        self.layer.blockSignals(False)
        self._emit()

    def _mode_changed(self, idx):
        self.layer.setVisible(idx == self.MODE_LAYER)
        self.btn_draw.setVisible(idx == self.MODE_DRAWN)
        self._emit()

    # ── drawing ──────────────────────────────────────────────────────────
    def _start_draw(self):
        canvas = self._iface.mapCanvas() if self._iface else None
        if canvas is None:
            self.summary.setText('No map canvas available.')
            return
        try:
            self._tool = _ExtentDrawTool(canvas, self._drawn_done)
            self._tool.start()
            self.summary.setText(
                'Drag a rectangle on the map canvas…')
        except Exception as e:
            self.summary.setText(
                f'Drawing is not available in this QGIS build ({e}). '
                f'Use "Current map canvas extent" instead — zoom the map '
                f'to the area you want first.')

    def _drawn_done(self, rect):
        if rect is None or rect.isEmpty():
            return
        self._drawn = QgsRectangle(rect)
        canvas = self._iface.mapCanvas()
        self._drawn_crs = canvas.mapSettings().destinationCrs()
        self._emit()

    # ── results ──────────────────────────────────────────────────────────
    def _raw_extent(self):
        """(QgsRectangle, QgsCoordinateReferenceSystem) or (None, None)."""
        idx = self.mode.currentIndex()
        try:
            if idx == self.MODE_LAYER:
                lid = self.layer.currentData()
                if not lid:
                    return None, None
                lyr = QgsProject.instance().mapLayer(lid)
                if lyr is None:
                    return None, None
                return QgsRectangle(lyr.extent()), lyr.crs()
            if idx == self.MODE_CANVAS:
                canvas = self._iface.mapCanvas()
                return (QgsRectangle(canvas.extent()),
                        canvas.mapSettings().destinationCrs())
            if idx == self.MODE_DRAWN and self._drawn is not None:
                return QgsRectangle(self._drawn), self._drawn_crs
        except Exception:
            return None, None
        return None, None

    def extent_4326(self):
        """(minx, miny, maxx, maxy) in WGS84, padded, or None."""
        rect, crs = self._raw_extent()
        if rect is None or rect.isEmpty():
            return None
        try:
            wgs = QgsCoordinateReferenceSystem('EPSG:4326')
            if crs is not None and crs.isValid() and crs != wgs:
                tr = QgsCoordinateTransform(crs, wgs, QgsProject.instance())
                rect = tr.transformBoundingBox(rect)
        except Exception:
            return None

        minx, miny = rect.xMinimum(), rect.yMinimum()
        maxx, maxy = rect.xMaximum(), rect.yMaximum()
        if self.pad_on.isChecked() and self.pad.value() > 0:
            f = self.pad.value() / 100.0
            dx, dy = (maxx - minx) * f, (maxy - miny) * f
            minx, maxx = minx - dx, maxx + dx
            miny, maxy = miny - dy, maxy + dy
        # Clamp to the valid WGS84 domain; padding near a pole or the
        # antimeridian can otherwise produce coordinates that no tile
        # server will accept.
        minx, maxx = max(minx, -180.0), min(maxx, 180.0)
        miny, maxy = max(miny, -90.0), min(maxy, 90.0)
        if not (maxx > minx and maxy > miny):
            return None
        return (minx, miny, maxx, maxy)

    def geoms_4326(self):
        """[shapely box] for clipping, or None."""
        e = self.extent_4326()
        if e is None:
            return None
        try:
            from shapely.geometry import box
            return [box(e[0], e[1], e[2], e[3])]
        except Exception:
            return None

    def as_temp_gpkg(self):
        """
        Write the extent as a single-polygon GeoPackage in WGS84 and
        return its path. For the uniform-CN generator, which takes a
        vector path rather than geometries.
        """
        e = self.extent_4326()
        if e is None:
            return None
        import os
        import tempfile
        try:
            import geopandas as gpd
            from shapely.geometry import box
            d = tempfile.mkdtemp(prefix='r2f_extent_')
            p = os.path.join(d, 'lulc_extent.gpkg')
            gpd.GeoDataFrame(
                {'Name': ['LULC extent']},
                geometry=[box(e[0], e[1], e[2], e[3])],
                crs='EPSG:4326').to_file(p, driver='GPKG')
            return p
        except Exception:
            return None

    def is_set(self):
        return self.extent_4326() is not None

    # ── summary line ─────────────────────────────────────────────────────
    def _emit(self):
        e = self.extent_4326()
        if e is None:
            if self.mode.currentIndex() == self.MODE_DRAWN:
                self.summary.setText(
                    'No rectangle drawn yet — click "Draw on Canvas".')
            elif self.mode.currentIndex() == self.MODE_LAYER:
                self.summary.setText(
                    'No layer selected, or the selected layer has no extent.')
            else:
                self.summary.setText('Extent unavailable.')
        else:
            minx, miny, maxx, maxy = e
            # Rough ground size, for a sanity read before downloading
            # several hundred megabytes of 10 m land cover.
            import math
            km_x = (maxx - minx) * 111.32 * math.cos(math.radians((miny + maxy) / 2))
            km_y = (maxy - miny) * 110.57
            area = abs(km_x * km_y)
            warn = ''
            if area > 250000:
                warn = ('  — that is very large for 10 m land cover; '
                        'expect a long download.')
            self.summary.setText(
                f'{minx:.4f}, {miny:.4f}  →  {maxx:.4f}, {maxy:.4f}  '
                f'(about {km_x:.0f} × {km_y:.0f} km, {area:,.0f} km²){warn}')
        self.extentChanged.emit()
