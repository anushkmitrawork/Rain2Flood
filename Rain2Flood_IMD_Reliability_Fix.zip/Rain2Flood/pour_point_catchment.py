"""
Pour-Point Catchment Delineation
=================================
Given a DEM and a single pour point (outlet / point of interest), derive:

  - the snapped pour point, moved onto the stream network
  - the UPSTREAM CATCHMENT draining to that point, as a polygon
  - the LONGEST FLOW PATH from the catchment divide to that point, as a
    polyline
  - catchment area, flow path length, and the S1085 main-stem slope

Why this exists
---------------
The previous workflow asked the user to supply a catchment polygon and
then delineated streams *inside* it, which is circular: you need the
catchment to get the catchment. It is also hydrologically wrong at the
edges. Flow accumulation on a clipped raster truncates upstream
contributing area at the clip boundary, so cells near the edge report an
accumulation that is too low and the derived stream network is wrong
there. A catchment delineated from a pour point on the full DEM is a true
watershed divide by construction — no flow crosses it — which makes every
downstream clip exact rather than approximate.

Self-contained: uses only numpy/scipy/rasterio/geopandas/shapely, and the
D8 stack in flood_mapping.py. No GRASS dependency, so this works even
where the Processing GRASS Provider isn't available.

IMPORTANT: the DEM must be in a PROJECTED CRS (metres). Cell size is used
directly as a distance, so a geographic DEM (degrees) produces nonsense
areas and slopes. This is checked and raises.
"""

import os
import numpy as np

try:
    from .flood_mapping import (_fill_sinks, _flow_accumulation_d8,
                                 _main_stem_slope)
except ImportError:
    from flood_mapping import (_fill_sinks, _flow_accumulation_d8,
                                _main_stem_slope)


# ──────────────────────────────────────────────────────────────────────────
def snap_pour_point(accumulation, valid_mask, row, col,
                     stream_mask=None, search_radius=10, feedback=None):
    """
    Move a user-clicked pour point onto the stream network.

    This is the single most common way a pour-point tool produces
    nonsense: a point one cell off the channel sits on a hillslope, and
    the "catchment" delineated from it is the handful of cells draining
    that hillslope facet rather than the river basin the user meant. A
    user clicking on a basemap, or typing a lat/lon from a report, will
    essentially never land exactly on the modelled channel — the DEM's
    channel is where the *DEM* says it is, which is typically one to a few
    cells from where the real river appears on imagery.

    Snapping rule: take the NEAREST stream cell within the search radius,
    breaking ties toward higher accumulation. Note this is deliberately
    not the plain "highest accumulation in the window" rule that some
    tools use — on a confluence that rule jumps the point onto whichever
    river is bigger, which silently changes the catchment to one the user
    did not ask for. Nearest-stream respects which channel was clicked;
    accumulation only breaks ties.

    Falls back to highest accumulation in the window if no stream cell is
    in range, and says so.

    Returns (row, col, moved_cells, note).
    """
    rows, cols = accumulation.shape
    row, col = int(row), int(col)

    if not (0 <= row < rows and 0 <= col < cols):
        raise ValueError(
            f"Pour point falls outside the DEM (row={row}, col={col}, "
            f"DEM is {rows}x{cols}). Check that the point and the DEM "
            f"cover the same area.")

    candidates = None
    note = ""
    used_radius = search_radius
    if stream_mask is not None:
        # Progressive expansion. The old behaviour — give up at the
        # nominal radius and take the highest-accumulation cell in that
        # window — is worse than useless: on a meandering channel the
        # point can easily sit 15-20 cells from the thalweg, the window
        # then contains nothing but hillslope, and the "highest
        # accumulation" cell in it drains a handful of cells. That
        # produced a 0.02 km² catchment from a 1.4 million-cell DEM in
        # testing, with only a warning. Expanding the search and reporting
        # how far it had to go is far more useful than a confident wrong
        # answer.
        for mult in (1, 2, 3, 5):
            rad = search_radius * mult
            r0, r1 = max(0, row - rad), min(rows, row + rad + 1)
            c0, c1 = max(0, col - rad), min(cols, col + rad + 1)
            win_stream = stream_mask[r0:r1, c0:c1] & valid_mask[r0:r1, c0:c1]
            if np.any(win_stream):
                candidates = win_stream
                used_radius = rad
                if mult > 1:
                    note = (f"no stream cell within {search_radius} cells, so "
                            f"the search was widened to {rad}")
                break

    r0, r1 = max(0, row - used_radius), min(rows, row + used_radius + 1)
    c0, c1 = max(0, col - used_radius), min(cols, col + used_radius + 1)
    win_acc = accumulation[r0:r1, c0:c1]
    win_valid = valid_mask[r0:r1, c0:c1]
    rr, cc = np.mgrid[r0:r1, c0:c1]
    dist2 = (rr - row) ** 2 + (cc - col) ** 2

    if candidates is None:
        if stream_mask is not None:
            raise ValueError(
                f"No stream cell found within {search_radius * 5} cells of the "
                f"pour point. Either the point is nowhere near a modelled "
                f"channel, or the stream threshold is too high for this "
                f"catchment. Check the point against the stream network from "
                f"Tab 2, or lower the stream threshold.")
        if not np.any(win_valid):
            raise ValueError(
                "No valid DEM cells within the snap radius of the pour "
                "point. The point is probably outside the DEM's data area.")
        candidates = win_valid

    # Nearest candidate; ties broken by higher accumulation.
    d2 = np.where(candidates, dist2, np.inf)
    min_d2 = d2.min()
    tied = candidates & (dist2 == min_d2)
    acc_tied = np.where(tied, win_acc, -np.inf)
    k = np.unravel_index(int(np.argmax(acc_tied)), win_acc.shape)
    new_r, new_c = r0 + int(k[0]), c0 + int(k[1])

    moved = float(np.hypot(new_r - row, new_c - col))

    if feedback:
        acc_before = (float(accumulation[row, col])
                      if valid_mask[row, col] else 0.0)
        acc_after = float(accumulation[new_r, new_c])
        feedback.pushInfo(
            f"  Pour point snapped {moved:.1f} cell(s): "
            f"({row}, {col}) -> ({new_r}, {new_c}). "
            f"Upstream cells {acc_before:.0f} -> {acc_after:.0f}.")
        if note:
            feedback.pushWarning(f"  Snap: {note}.")
        if moved > 0.75 * used_radius:
            feedback.pushWarning(
                f"  The pour point moved {moved:.1f} cells, close to the "
                f"{used_radius}-cell search limit. That usually means the "
                f"point was some way off the modelled channel — check the "
                f"snapped location before trusting the catchment, and "
                f"consider whether the DEM's channel is where you expect.")
        if acc_before > 0 and acc_after > 5 * max(acc_before, 1):
            feedback.pushWarning(
                f"  Snapping increased upstream area by a factor of "
                f"{acc_after / max(acc_before, 1):.0f}. The point has most "
                f"likely landed on a larger river than the one clicked. "
                f"Reduce the snap radius if that is not what you wanted.")

    return new_r, new_c, moved, note


# ──────────────────────────────────────────────────────────────────────────
def _downstream_index(flow_dr, flow_dc, has_target, valid_mask, cell_size):
    """
    Build the flat 'drains to' pointer array and the per-cell step length.

    Cells with no downstream target (the DEM edge, an unresolved pit)
    point at themselves, making them fixed points of the mapping.
    """
    rows, cols = flow_dr.shape
    idx = np.arange(rows * cols, dtype=np.int64).reshape(rows, cols)

    tr = np.arange(rows, dtype=np.int64)[:, None] + flow_dr.astype(np.int64)
    tc = np.arange(cols, dtype=np.int64)[None, :] + flow_dc.astype(np.int64)
    in_bounds = (tr >= 0) & (tr < rows) & (tc >= 0) & (tc < cols)

    tr_c = np.clip(tr, 0, rows - 1)
    tc_c = np.clip(tc, 0, cols - 1)
    target = tr_c * cols + tc_c

    routes = has_target & valid_mask & in_bounds & valid_mask[tr_c, tc_c]
    nxt = np.where(routes, target, idx).astype(np.int64)

    diag = (flow_dr != 0) & (flow_dc != 0)
    step = np.where(routes,
                    cell_size * np.where(diag, np.sqrt(2.0), 1.0),
                    0.0).astype(np.float64)

    return nxt.reshape(-1), step.reshape(-1)


def delineate_upstream(flow_dr, flow_dc, has_target, valid_mask,
                        outlet_rc, cell_size, feedback=None):
    """
    Find every cell draining to `outlet_rc`, and each cell's flow distance
    to it, by POINTER JUMPING (path doubling) over the D8 flow graph.

    The obvious implementation — walk upstream from the outlet with a
    stack — is a Python loop over every cell in the catchment, which on a
    2577 km² catchment at 30 m is ~2.9 million iterations. Pointer jumping
    does the same work in ~log2(longest path) vectorised passes, each one
    a single fancy-index over the array: about 15-20 passes, well under a
    second, versus tens of seconds for the loop.

    The trick: make the outlet a fixed point of the 'drains to' mapping,
    then repeatedly square the mapping (root = root[root]). Every cell
    upstream of the outlet converges to the outlet; every other cell
    converges to its own terminal cell (a different outlet, or the grid
    edge). So membership is just `root == outlet`. Carrying the
    accumulated step length alongside (d = d + d[root]) gives the flow
    distance to the outlet for free, which is what the longest flow path
    needs.

    Returns (catchment_mask, flow_distance_m, nxt_flat, outlet_flat_index).
    """
    rows, cols = flow_dr.shape
    nxt, step = _downstream_index(flow_dr, flow_dc, has_target,
                                   valid_mask, cell_size)

    outlet_flat = int(outlet_rc[0]) * cols + int(outlet_rc[1])
    nxt_routing = nxt.copy()
    nxt_routing[outlet_flat] = outlet_flat        # absorbing state
    step_routing = step.copy()
    step_routing[outlet_flat] = 0.0

    root = nxt_routing.copy()
    dist = step_routing.copy()

    for n_pass in range(1, 65):
        new_root = root[root]
        new_dist = dist + dist[root]
        if np.array_equal(new_root, root):
            break
        root, dist = new_root, new_dist
    else:
        if feedback:
            feedback.pushWarning(
                "  Flow-path resolution hit its 64-pass limit. This implies "
                "a flow path longer than 2^64 cells, which should be "
                "impossible — treat the catchment boundary with suspicion.")

    catchment = (root == outlet_flat).reshape(rows, cols) & valid_mask
    catchment[int(outlet_rc[0]), int(outlet_rc[1])] = True
    flow_dist = dist.reshape(rows, cols)

    if feedback:
        feedback.pushInfo(
            f"  Upstream catchment resolved in {n_pass} doubling pass(es): "
            f"{int(catchment.sum())} cells.")

    return catchment, flow_dist, nxt, outlet_flat


# ──────────────────────────────────────────────────────────────────────────
def longest_flow_path(catchment_mask, flow_dist, nxt_flat, outlet_flat,
                       transform, feedback=None):
    """
    Trace the longest flow path: from the catchment cell with the greatest
    flow distance to the outlet, down the D8 path to the outlet.

    This is the real traced path, not a straight line and not a
    basin-shape approximation. It matters because time of concentration
    and every lag equation take the longest flow path length as an input —
    your log showed L=180386 m driving SCS lag, so an error here
    propagates straight into the hydrograph timing.

    Returns (list_of_xy, length_m, flat_cell_indices, reached_outlet).
    `reached_outlet` is False when the trace stopped early — the line
    is still continuous, but it is short, so it must not be reported
    as the full flow path.
    """
    rows, cols = catchment_mask.shape
    d_in = np.where(catchment_mask, flow_dist, -1.0)
    head_flat = int(np.argmax(d_in))
    length_m = float(d_in.flat[head_flat])

    if length_m <= 0:
        if feedback:
            feedback.pushWarning(
                "  Longest flow path has zero length — the pour point "
                "appears to have no upstream area. Check the snap result.")
        return [], 0.0, [], False

    path = [head_flat]
    seen = {head_flat}
    cur = head_flat
    reached_outlet = (head_flat == outlet_flat)
    stop_reason = None
    for _ in range(rows * cols):
        if cur == outlet_flat:
            reached_outlet = True
            break
        nxt_i = int(nxt_flat[cur])
        if nxt_i == cur:
            stop_reason = ('the path reached a cell with no downstream '
                           'neighbour (an unresolved pit) before the outlet')
            break
        if nxt_i in seen:
            stop_reason = ('the path revisited a cell it had already '
                           'passed through (a routing loop)')
            break
        cur = nxt_i
        seen.add(cur)
        path.append(cur)
    else:
        stop_reason = 'the trace hit its step limit'

    # A truncated trace must not be presented as "the longest flow path".
    # It is a single continuous line either way, so it looks entirely
    # plausible on the map — but it is short, and the length feeds SCS
    # lag and every time-of-concentration estimate downstream.
    if not reached_outlet and feedback:
        feedback.pushWarning(
            f"  The longest flow path stopped before reaching the pour "
            f"point: {stop_reason}. The line is continuous but INCOMPLETE, "
            f"so its length ({length_m / 1000.0:.2f} km) understates the "
            f"true flow path and any lag derived from it will be too "
            f"short. This usually indicates flat or noisy valley floors "
            f"that depression filling could not fully resolve.")

    a, b, c_, d_, e, f_ = (transform.a, transform.b, transform.c,
                           transform.d, transform.e, transform.f)
    coords = []
    for flat in path:
        r, c = divmod(flat, cols)
        # cell centre
        x = c_ + a * (c + 0.5) + b * (r + 0.5)
        y = f_ + d_ * (c + 0.5) + e * (r + 0.5)
        coords.append((x, y))

    if feedback:
        feedback.pushInfo(
            f"  Longest flow path: {len(coords)} cells, "
            f"{length_m / 1000.0:.2f} km.")

    return coords, length_m, path, reached_outlet


# ──────────────────────────────────────────────────────────────────────────
def _polygonize_catchment(catchment_mask, transform, crs, feedback=None):
    """
    Vectorise the catchment mask to a single polygon.

    Interior holes are removed unconditionally: a D8 catchment is the set
    of cells draining to one point, so it cannot contain a hole. Any hole
    is a rasterisation artefact of 8-connected diagonal links, and leaving
    them in produces a boundary with pinholes that looks broken in QGIS
    and breaks later clipping.
    """
    from rasterio import features as rio_features
    from shapely.geometry import shape, Polygon
    from shapely.ops import unary_union
    import geopandas as gpd

    shapes = list(rio_features.shapes(
        catchment_mask.astype(np.uint8), mask=catchment_mask,
        transform=transform))
    if not shapes:
        return None

    polys = [shape(geom) for geom, val in shapes if val == 1]
    if not polys:
        return None

    merged = unary_union(polys)
    if merged.geom_type == 'MultiPolygon':
        parts = sorted(merged.geoms, key=lambda p: p.area, reverse=True)
        main = parts[0]
        dropped = sum(p.area for p in parts[1:])
        if feedback and dropped > 0:
            feedback.pushInfo(
                f"  Catchment vectorised as {len(parts)} part(s); kept the "
                f"largest ({main.area / 1e6:.2f} km²), dropped "
                f"{dropped / 1e6:.4f} km² of diagonal-link slivers.")
    else:
        main = merged

    if main.interiors:
        n_holes = len(main.interiors)
        main = Polygon(main.exterior)
        if feedback:
            feedback.pushInfo(
                f"  Removed {n_holes} interior hole(s) — a catchment "
                f"draining to one point cannot have holes; these are "
                f"8-connectivity rasterisation artefacts.")

    return gpd.GeoDataFrame(
        {'Area_km2': [round(main.area / 1e6, 4)]},
        geometry=[main], crs=crs)


# ──────────────────────────────────────────────────────────────────────────
def delineate_from_pour_point(dem_path, pour_x, pour_y, output_dir,
                               stream_threshold_cells=None,
                               snap_radius_cells=10,
                               feedback=None):
    """
    Full pour-point workflow on a PROJECTED DEM.

    `pour_x`, `pour_y` are in the DEM's own CRS (use
    pour_point_xy_in_raster_crs() to convert from lat/lon first).

    Returns a dict with output paths and derived catchment properties, or
    raises ValueError with an actionable message.
    """
    import rasterio
    from shapely.geometry import LineString, Point
    import geopandas as gpd

    os.makedirs(output_dir, exist_ok=True)

    with rasterio.open(dem_path) as src:
        if src.crs is None:
            raise ValueError(
                "The DEM has no CRS. Reproject it to a projected CRS "
                "(a UTM zone covering your area) in Tab 1 first.")
        if src.crs.is_geographic:
            raise ValueError(
                f"The DEM is in a geographic CRS ({src.crs.to_string()}), "
                f"so its cell size is in degrees. Catchment area, flow path "
                f"length and slope would all be meaningless. Reproject to a "
                f"projected CRS (UTM) in Tab 1 first.")
        dem_raw = src.read(1).astype(np.float64)
        transform = src.transform
        crs = src.crs
        nodata = src.nodata
        cell_size = abs(transform.a)

    if nodata is not None:
        dem_raw[dem_raw == nodata] = np.nan
    dem_raw[dem_raw < -1e4] = np.nan
    valid_mask = np.isfinite(dem_raw)
    if not valid_mask.any():
        raise ValueError("The DEM contains no valid elevation data.")

    rows, cols = dem_raw.shape
    inv = ~transform
    fcol, frow = inv * (pour_x, pour_y)
    col0, row0 = int(np.floor(fcol)), int(np.floor(frow))

    if feedback:
        feedback.pushInfo(
            f"Pour-point delineation on {rows}x{cols} DEM @ "
            f"{cell_size:.1f} m ({crs.to_string()}).")
        feedback.pushInfo("  Filling depressions (catchment-masked) …")

    dem_filled = _fill_sinks(np.where(valid_mask, dem_raw, np.nan),
                              valid_mask=valid_mask)
    acc, fdr, fdc, ht = _flow_accumulation_d8(
        dem_filled, valid_mask, return_dirs=True)

    cell_area_km2 = (cell_size ** 2) / 1e6
    if stream_threshold_cells is None:
        # Same size-scaled rule the flood mapper uses, so the network the
        # point snaps to is the same one the flood map references.
        total_km2 = float(valid_mask.sum()) * cell_area_km2
        thresh_km2 = float(np.clip(0.005 * total_km2, 0.25, 25.0))
        stream_threshold_cells = max(1, int(thresh_km2 / cell_area_km2))
    stream_mask = (acc >= stream_threshold_cells) & valid_mask

    if feedback:
        feedback.pushInfo(
            f"  Stream network for snapping: {int(stream_mask.sum())} cells "
            f"(>= {stream_threshold_cells} cells = "
            f"{stream_threshold_cells * cell_area_km2:.2f} km²).")

    snap_r, snap_c, moved, snap_note = snap_pour_point(
        acc, valid_mask, row0, col0, stream_mask=stream_mask,
        search_radius=snap_radius_cells, feedback=feedback)

    catchment, flow_dist, nxt, outlet_flat = delineate_upstream(
        fdr, fdc, ht, valid_mask, (snap_r, snap_c), cell_size,
        feedback=feedback)

    n_cells = int(catchment.sum())
    area_km2 = n_cells * cell_area_km2
    if n_cells < 10:
        raise ValueError(
            f"The delineated catchment is only {n_cells} cell(s) "
            f"({area_km2:.4f} km²). The pour point has almost certainly "
            f"snapped onto a hillslope rather than a channel. Increase the "
            f"snap radius, lower the stream threshold, or move the point "
            f"onto the mapped stream network.")

    coords, path_len_m, _, reached_outlet = longest_flow_path(
        catchment, flow_dist, nxt, outlet_flat, transform, feedback=feedback)

    # ── S1085 along the MAIN STREAM ───────────────────────────────────────
    # Deliberately NOT along the longest flow path. The longest flow path
    # correctly starts at the catchment divide and so includes the
    # hillslope reach above the channel head — that is what time of
    # concentration wants, but it is far steeper than any channel. On a
    # test catchment whose channel slope was 1.5% by construction, taking
    # S1085 along the longest flow path returned 0.0605, four times too
    # high, because the 85% point sat on the valley wall. Slope for the
    # hydraulic calculations has to come from the channel.
    s1085 = _main_stem_slope(
        dem_filled, dem_raw, catchment, acc, fdr, fdc, ht, cell_size,
        stream_mask=(stream_mask & catchment), feedback=feedback)

    # ── Write outputs ─────────────────────────────────────────────────────
    catch_gpkg = os.path.join(output_dir, 'upstream_catchment.gpkg')
    path_gpkg = os.path.join(output_dir, 'longest_flow_path.gpkg')
    point_gpkg = os.path.join(output_dir, 'pour_point_snapped.gpkg')

    catch_gdf = _polygonize_catchment(catchment, transform, crs, feedback)
    if catch_gdf is None:
        raise ValueError("Could not vectorise the delineated catchment.")
    catch_gdf['FlowPath_m'] = round(path_len_m, 1)
    if s1085 is not None:
        catch_gdf['S1085'] = round(s1085, 6)
    catch_gdf.to_file(catch_gpkg, driver='GPKG')

    if len(coords) >= 2:
        line = LineString(coords)

        # Contiguity guarantee. Every vertex is a D8 step from the last,
        # so no gap can exceed one diagonal cell. Checking it here means a
        # future routing change cannot quietly start emitting a line with
        # jumps in it — which would still load as one feature and still
        # look like a river.
        _c = np.asarray(line.coords)
        _steps = np.hypot(np.diff(_c[:, 0]), np.diff(_c[:, 1]))
        _max_step = cell_size * np.sqrt(2.0) * 1.01
        _gaps = int(np.sum(_steps > _max_step))
        if _gaps and feedback:
            feedback.pushWarning(
                f"  The flow path contains {_gaps} vertex gap(s) larger than "
                f"one diagonal cell (worst {_steps.max():.0f} m). It is "
                f"written as a single feature but is not geometrically "
                f"continuous — this is a bug, please report it.")
        elif feedback:
            feedback.pushInfo(
                f"  Flow path written as a single continuous LineString: "
                f"{len(_c)} vertices, no gaps "
                f"(max step {_steps.max():.1f} m).")

        gpd.GeoDataFrame(
            {'Length_m': [round(path_len_m, 1)],
             'Length_km': [round(path_len_m / 1000.0, 3)],
             'Vertices': [len(_c)],
             'Complete': ['yes' if reached_outlet else 'NO - truncated']},
            geometry=[line], crs=crs
        ).to_file(path_gpkg, driver='GPKG')
    else:
        path_gpkg = None

    snap_x = transform.c + transform.a * (snap_c + 0.5) + transform.b * (snap_r + 0.5)
    snap_y = transform.f + transform.d * (snap_c + 0.5) + transform.e * (snap_r + 0.5)
    gpd.GeoDataFrame(
        {'Moved_cells': [round(moved, 2)],
         'Moved_m': [round(moved * cell_size, 1)],
         'Area_km2': [round(area_km2, 4)],
         'Note': [snap_note or 'snapped to nearest stream cell']},
        geometry=[Point(snap_x, snap_y)], crs=crs
    ).to_file(point_gpkg, driver='GPKG')

    # ── Cross-check: vector area vs cell count ────────────────────────────
    vec_area = float(catch_gdf.geometry.area.iloc[0]) / 1e6
    if abs(vec_area - area_km2) / max(area_km2, 1e-9) > 0.02:
        if feedback:
            feedback.pushWarning(
                f"  Vectorised area ({vec_area:.2f} km²) differs from the "
                f"cell count ({area_km2:.2f} km²) by more than 2%. The "
                f"polygon may have lost detail; the cell-count area is the "
                f"reliable one.")

    if feedback:
        feedback.pushInfo(
            f"  Catchment: {area_km2:.2f} km², longest flow path "
            f"{path_len_m / 1000.0:.2f} km"
            + (f", S1085 = {s1085:.5f}" if s1085 else ", S1085 unavailable"))

    return {
        'catchment_gpkg': catch_gpkg,
        'flow_path_gpkg': path_gpkg,
        'snapped_point_gpkg': point_gpkg,
        'catchment_mask': catchment,
        'area_km2': area_km2,
        'flow_path_m': path_len_m,
        's1085': s1085,
        'snapped_rc': (snap_r, snap_c),
        'snapped_xy': (snap_x, snap_y),
        'snap_moved_cells': moved,
        'snap_moved_m': moved * cell_size,
        'cell_size': cell_size,
        'crs': crs.to_string(),
    }


# ──────────────────────────────────────────────────────────────────────────
def pour_point_xy_in_raster_crs(lat, lon, raster_path, feedback=None):
    """
    Convert a WGS84 lat/lon pour point into the raster's own CRS.

    Uses rasterio/pyproj rather than QGIS classes so this is testable
    outside a QGIS session.
    """
    import rasterio
    from rasterio.warp import transform as warp_transform

    with rasterio.open(raster_path) as src:
        dst_crs = src.crs
    if dst_crs is None:
        raise ValueError("Raster has no CRS.")
    xs, ys = warp_transform('EPSG:4326', dst_crs, [float(lon)], [float(lat)])
    if feedback:
        feedback.pushInfo(
            f"  Pour point lat={lat:.5f}, lon={lon:.5f} -> "
            f"({xs[0]:.1f}, {ys[0]:.1f}) in {dst_crs.to_string()}.")
    return float(xs[0]), float(ys[0])


# ──────────────────────────────────────────────────────────────────────────
# QGIS loading / symbology
#
# Imported lazily inside the functions so this module stays importable
# (and testable) outside a QGIS session.
# ──────────────────────────────────────────────────────────────────────────
def load_pour_point_outputs(result, feedback=None, load_flow_path=True,
                             load_snapped_point=True):
    """
    Load the delineation outputs into QGIS with sensible symbology.

    The catchment is drawn as a HOLLOW boundary (no fill). A filled
    catchment covers the DEM, hillshade, flood depth rasters and basemap
    underneath it, which is exactly the set of things you want to see it
    against; every user then immediately opens layer properties to turn
    the fill off.

    Each layer is loaded separately rather than grouped, so they can be
    toggled independently.
    """
    out = {}
    if result.get('catchment_gpkg'):
        out['catchment'] = _load_styled(
            result['catchment_gpkg'], 'Upstream Catchment',
            _style_catchment_outline, feedback)
    if load_flow_path and result.get('flow_path_gpkg'):
        out['flow_path'] = _load_styled(
            result['flow_path_gpkg'], 'Longest Flow Path',
            _style_flow_path, feedback)
    if load_snapped_point and result.get('snapped_point_gpkg'):
        out['pour_point'] = _load_styled(
            result['snapped_point_gpkg'], 'Pour Point (snapped)',
            _style_pour_point, feedback)
    return out


def _load_styled(path, name, style_fn, feedback=None):
    if not path or not os.path.exists(path):
        return None
    try:
        from qgis.core import QgsProject, QgsVectorLayer
        proj = QgsProject.instance()
        stale = [lyr.id() for lyr in proj.mapLayers().values()
                 if lyr.name() == name]
        if stale:
            proj.removeMapLayers(stale)
            if feedback:
                feedback.pushInfo(
                    f"  Replaced {len(stale)} previous layer(s) named '{name}'.")
        layer = QgsVectorLayer(path, name, 'ogr')
        if not layer.isValid():
            if feedback:
                feedback.pushWarning(f"  Failed to load {name}.")
            return None
        try:
            style_fn(layer)
        except Exception as e:
            if feedback:
                feedback.pushWarning(f"  Could not style {name}: {e}")
        proj.addMapLayer(layer)
        if feedback:
            feedback.pushInfo(f"  Loaded: {name}")
        return layer
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"  Could not load {name}: {e}")
        return None


def _style_catchment_outline(layer):
    """Hollow polygon: thick dark outline, no fill."""
    from qgis.core import QgsFillSymbol
    sym = QgsFillSymbol.createSimple({
        'style': 'no',                     # no fill
        'color': '0,0,0,0',
        'outline_style': 'solid',
        'outline_color': '#D81B60',
        'outline_width': '0.9',
    })
    layer.renderer().setSymbol(sym)
    layer.setOpacity(1.0)
    layer.triggerRepaint()


def _style_flow_path(layer):
    """
    Longest flow path: SOLID line with a white casing underneath.

    It was dashed. On a 150 km path drawn at map scale the dash pattern
    reads as a broken line — the geometry is a single continuous
    LineString, but nobody can tell that by looking at it, and "it breaks
    at the junctions" is the obvious conclusion when a dash gap happens
    to land near a confluence. A solid line cannot be misread that way.

    The white casing (a wider white line drawn beneath a narrower
    coloured one) is how cartographers keep a line legible over a busy
    raster. It replaces the contrast the dash was there to provide.

    Render-time simplification is also switched off. QGIS simplifies
    dense geometries while drawing, and this path has one vertex per DEM
    cell — several thousand of them. Simplification can visibly drop
    vertices at tight bends, which on a meandering channel is exactly
    where confluences are.
    """
    from qgis.core import QgsLineSymbol, QgsSimpleLineSymbolLayer
    from qgis.PyQt.QtGui import QColor

    sym = QgsLineSymbol.createSimple({})
    sym.deleteSymbolLayer(0)

    casing = QgsSimpleLineSymbolLayer.create({
        'color': '255,255,255,220',
        'width': '1.6',
        'capstyle': 'round',
        'joinstyle': 'round',
    })
    core = QgsSimpleLineSymbolLayer.create({
        'color': '#E65100',
        'width': '0.7',
        'capstyle': 'round',
        'joinstyle': 'round',
    })
    sym.appendSymbolLayer(casing)
    sym.appendSymbolLayer(core)
    layer.renderer().setSymbol(sym)

    try:
        from qgis.core import QgsVectorSimplifyMethod
        m = QgsVectorSimplifyMethod()
        m.setSimplifyHints(QgsVectorSimplifyMethod.NoSimplification)
        layer.setSimplifyMethod(m)
    except Exception:
        pass

    layer.triggerRepaint()


def _style_pour_point(layer):
    """Snapped pour point: hollow star so the underlying channel stays visible."""
    from qgis.core import QgsMarkerSymbol
    sym = QgsMarkerSymbol.createSimple({
        'name': 'star',
        'color': '255,255,255,0',
        'outline_color': '#C62828',
        'outline_width': '0.6',
        'size': '4.5',
    })
    layer.renderer().setSymbol(sym)
    layer.triggerRepaint()


# ──────────────────────────────────────────────────────────────────────────
def resolve_catchment_from_pour_point(dem_path, lat, lon, output_dir,
                                       snap_radius_cells=10,
                                       load_in_qgis=True, feedback=None):
    """
    Convenience wrapper for the flood-analysis tabs: lat/lon in, delineated
    catchment out, loaded into QGIS.

    Returns the same dict as delineate_from_pour_point(), or raises
    ValueError with a message the tab can show directly.
    """
    if dem_path is None:
        raise ValueError(
            "Pour-point delineation needs a DEM. Select the reprojected DEM "
            "from Tab 1.")
    if lat is None or lon is None:
        raise ValueError(
            "Pour-point delineation needs a pour point. Set one at the top "
            "of this tab, either by typing coordinates or with the map "
            "picker.")

    x, y = pour_point_xy_in_raster_crs(lat, lon, dem_path, feedback=feedback)
    result = delineate_from_pour_point(
        dem_path, x, y, output_dir,
        snap_radius_cells=snap_radius_cells, feedback=feedback)

    if load_in_qgis:
        try:
            load_pour_point_outputs(result, feedback=feedback)
        except Exception as e:
            if feedback:
                feedback.pushWarning(
                    f"  Delineation succeeded but layers could not be loaded "
                    f"into QGIS: {e}. The files are still in {output_dir}.")
    return result
