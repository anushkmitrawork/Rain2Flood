"""
Standard Flood Analysis Algorithm (Daily / Long-Duration)
==========================================================
Supports:
  - SCS Triangular UH  (NRCS NEH-4)
  - NRCS Dimensionless UH
  - Snyder Synthetic UH
  - Clark IUH
  - UK FEH Parametric (FSR/FEH Vol 4)
  - Australia ARR2019 Probabilistic Rational Method
  - Canada / NZ Rational IDF approach
  - Rational Method (Modified)
  - Muskingum-Cunge routing
  - CN / LULC / Manning's raster integration
  - Multi-duration frequency analysis (6h, 12h, 24h, 48h, 72h)
  - SCS Type-II 24-hr design storm
  - HEC-HMS export
"""

import os, sys, gc, math, warnings, traceback
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
try:
    from . import plot_style as _ps
except ImportError:
    import plot_style as _ps
_ps.apply_style()
from datetime import datetime, timedelta

from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterString,
    QgsProcessingParameterEnum, QgsProcessingParameterFile,
    QgsProcessingParameterNumber, QgsProcessingParameterVectorLayer,
    QgsProcessingParameterRasterLayer, QgsProcessingParameterBoolean,
    QgsProcessingParameterFolderDestination, QgsProcessingException,
    QgsProcessing, QgsProject, QgsRasterLayer,
    QgsProcessingOutputFile, QgsProcessingOutputFolder,
    QgsProcessingParameterPoint, QgsProcessingParameterDateTime,
)
from qgis.PyQt.QtCore import QDateTime, QDate, QTime

try:
    from .rainfall_data_sources import (
        download_openmeteo_data, download_gpm_imerg_daily,
        download_noaa_ghcnd_nearest, load_chirps_data,
        load_excel_rainfall_data, quality_control_rainfall,
        generate_synthetic_rainfall,
    )
    from .hydrological_calculations import (
        frequency_analysis, frequency_analysis_with_uncertainty, select_best_distribution,
        calculate_scs_cn_runoff,
        calculate_time_to_peak, generate_scs_unit_hydrograph,
        generate_nrcs_dimensionless_uh, generate_flood_hydrograph,
        generate_snyder_unit_hydrograph, generate_clark_iuh,
        rational_method_peak_discharge, modified_rational_method,
        fit_idf_curves, generate_idf_table,
        scs_type_ii_distribution, alternating_block_hyetograph,
        feh_rainfall_runoff, arr_probabilistic_rational,
        canada_rational_peak, nz_probabilistic_rational,
        muskingum_cunge_routing, green_ampt_infiltration,
    )
    from .flood_mapping import generate_flood_map, generate_flood_map_2d, load_flood_rasters_to_qgis, load_hazard_rasters_to_qgis
    from .report_generator import generate_html_report
    from .cn_lulc_manager import adjust_cn_for_amc
    from .flash_flood_analysis import (
        _resolve_coordinates, _parse_first_number,
        _extract_catchment_params, _resolve_cn_manning_rasters,
        _short_duration_maxima, _plot_idf_curves,
    )
except ImportError:
    from rainfall_data_sources import (
        download_openmeteo_data, download_gpm_imerg_daily,
        download_noaa_ghcnd_nearest, load_chirps_data,
        load_excel_rainfall_data, quality_control_rainfall,
        generate_synthetic_rainfall,
    )
    from hydrological_calculations import (
        frequency_analysis, frequency_analysis_with_uncertainty, select_best_distribution,
        calculate_scs_cn_runoff,
        calculate_time_to_peak, generate_scs_unit_hydrograph,
        generate_nrcs_dimensionless_uh, generate_flood_hydrograph,
        generate_snyder_unit_hydrograph, generate_clark_iuh,
        rational_method_peak_discharge, modified_rational_method,
        fit_idf_curves, generate_idf_table,
        scs_type_ii_distribution, alternating_block_hyetograph,
        feh_rainfall_runoff, arr_probabilistic_rational,
        canada_rational_peak, nz_probabilistic_rational,
        muskingum_cunge_routing,
    )
    from flood_mapping import generate_flood_map, generate_flood_map_2d, load_flood_rasters_to_qgis, load_hazard_rasters_to_qgis
    from report_generator import generate_html_report
    from cn_lulc_manager import adjust_cn_for_amc
    from flash_flood_analysis import (
        _resolve_coordinates, _parse_first_number,
        _extract_catchment_params, _resolve_cn_manning_rasters,
        _short_duration_maxima, _plot_idf_curves,
    )


class StandardFloodAnalysis(QgsProcessingAlgorithm):
    # ── Parameter IDs ─────────────────────────────────────────────────────
    RAINFALL_SOURCE    = 'RAINFALL_SOURCE'
    RAINFALL_RASTER    = 'RAINFALL_RASTER'
    USE_SPATIAL_RAIN   = 'USE_SPATIAL_RAIN'
    COORDINATES_POINT  = 'COORDINATES_POINT'
    COORDINATES_MANUAL = 'COORDINATES_MANUAL'
    START_DATE         = 'START_DATE'
    END_DATE           = 'END_DATE'
    EXCEL_FILE         = 'EXCEL_FILE'
    DATE_COLUMN        = 'DATE_COLUMN'
    RAINFALL_COLUMN    = 'RAINFALL_COLUMN'
    CHIRPS_FOLDER      = 'CHIRPS_FOLDER'
    ANALYSIS_METHOD    = 'ANALYSIS_METHOD'
    REGIONAL_METHOD    = 'REGIONAL_METHOD'
    RETURN_PERIODS     = 'RETURN_PERIODS'
    FREQ_METHOD        = 'FREQ_METHOD'
    AMC_CONDITION      = 'AMC_CONDITION'
    CATCHMENT_INPUT    = 'CATCHMENT_INPUT'
    SNAP_RADIUS        = 'SNAP_RADIUS'
    CATCHMENT          = 'CATCHMENT'
    DEM                = 'DEM'
    SLOPE_RASTER       = 'SLOPE_RASTER'
    FLOW_PATH          = 'FLOW_PATH'
    CN_RASTER_SOURCE   = 'CN_RASTER_SOURCE'
    CN_RASTER          = 'CN_RASTER'
    LULC_RASTER        = 'LULC_RASTER'
    LULC_TYPE          = 'LULC_TYPE'
    MANNING_RASTER     = 'MANNING_RASTER'
    HSG                = 'HSG'
    AREA               = 'AREA'
    SLOPE              = 'SLOPE'
    CN                 = 'CN'
    RUNOFF_COEFF       = 'RUNOFF_COEFF'
    MANNING_N          = 'MANNING_N'
    SAAR               = 'SAAR'
    SOIL_CLASS         = 'SOIL_CLASS'
    URBEXT             = 'URBEXT'
    C10                = 'C10'
    IDF_A              = 'IDF_A'
    IDF_B              = 'IDF_B'
    IDF_C              = 'IDF_C'
    ENABLE_ROUTING     = 'ENABLE_ROUTING'
    MUSK_K             = 'MUSK_K'
    MUSK_X             = 'MUSK_X'
    DESIGN_STORM_TYPE  = 'DESIGN_STORM_TYPE'
    OUTPUT_DIR         = 'OUTPUT_DIR'
    GENERATE_MAPS      = 'GENERATE_MAPS'
    OBSERVED_HYDROGRAPH = 'OBSERVED_HYDROGRAPH'
    CWC_COEFFS          = 'CWC_COEFFS'
    POUR_POINT          = 'POUR_POINT'
    POUR_POINT_MANUAL   = 'POUR_POINT_MANUAL'
    SUBBASIN_LAYER      = 'SUBBASIN_LAYER'
    WAVE_CELERITY       = 'WAVE_CELERITY'
    RUN_SENSITIVITY     = 'RUN_SENSITIVITY'
    LOAD_RASTERS       = 'LOAD_RASTERS'
    USE_2D_ROUTING     = 'USE_2D_ROUTING'
    EXPORT_HEC_HMS     = 'EXPORT_HEC_HMS'

    OUTPUT_EXCEL       = 'OUTPUT_EXCEL'
    OUTPUT_FLOOD_MAPS  = 'OUTPUT_FLOOD_MAPS'
    OUTPUT_RASTERS     = 'OUTPUT_FLOOD_RASTERS'
    OUTPUT_HYDROGRAPHS = 'OUTPUT_HYDROGRAPHS'
    OUTPUT_HEC_HMS     = 'OUTPUT_HEC_HMS'

    ANALYSIS_METHODS = [
        'SCS Triangular UH (NRCS NEH-4)',
        'NRCS Dimensionless UH',
        'Snyder Synthetic UH',
        'Clark IUH',
        'UK FEH Parametric (planning-grade)',
        'Australia ARR2019 Probabilistic Rational',
        'Canada / NZ Rational IDF',
        'Rational Method (Modified)',
    ]
    REGIONAL_METHODS = [
        'None (standard SCS)',
        'UK FEH / FSR',
        'Australia ARR2019',
        'Canada MTO',
        'New Zealand NIWA',
        'Middle East Wadi',
    ]
    RAINFALL_SOURCES = [
        'Open-Meteo ERA5 (Daily, Free)',
        'NASA POWER (Daily, Free)',
        'NOAA GHCND (Nearest Station, Free)',
        'IMD Gridded 0.25° (India)',
        'CHIRPS NetCDF (Local Files)',
        'Excel / CSV File',
        'Synthetic (planning only)',
    ]
    FREQ_METHODS    = ['Gumbel (EV1)', 'Log-Pearson III', 'GEV (MLE)', 'GEV (L-moments)',
                        'Auto (best fit by AIC)']
    AMC_OPTIONS     = ['AMC I (Dry)', 'AMC II (Normal)', 'AMC III (Wet)']
    CN_SOURCES      = ['Manual Value', 'CN Raster (HEC-RAS)', 'LULC Raster → compute CN',
                       'Download ESA WorldCover → compute CN']
    LULC_TYPES      = ['ESA WorldCover 2021', 'NLCD 2019 (USA)', 'CORINE (Europe)', 'MODIS IGBP']
    HSG_OPTIONS     = ['A (Well-drained sand/gravel)', 'B (Moderate infiltration)',
                       'C (Slow infiltration)', 'D (Clay / high runoff)']
    DESIGN_STORMS   = ['SCS Type-II 24-hr', 'Alternating Block Method (ABM)',
                       'Uniform Distribution', 'Chicago Design Storm']
    SOIL_CLASSES    = ['1 (Permeable – chalk/limestone)', '2 (Moderate – loam)',
                       '3 (Mixed)', '4 (Clay)', '5 (Impermeable – heavy clay)']

    def initAlgorithm(self, config=None):
        # ── Rainfall source ────────────────────────────────────────────────
        self.addParameter(QgsProcessingParameterEnum(
            self.RAINFALL_SOURCE, 'Rainfall Data Source',
            options=self.RAINFALL_SOURCES, defaultValue=0))
        self.addParameter(QgsProcessingParameterPoint(
            self.COORDINATES_POINT, 'Select Location on Map', optional=True, defaultValue=''))
        self.addParameter(QgsProcessingParameterString(
            self.COORDINATES_MANUAL, 'Manual Coordinates (Lat, Lon)',
            defaultValue='20.0, 77.0', optional=True))
        self.addParameter(QgsProcessingParameterDateTime(
            self.START_DATE, 'Start Date',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate().addDays(-3650), QTime(0,0,0))))
        self.addParameter(QgsProcessingParameterDateTime(
            self.END_DATE, 'End Date',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate(), QTime(0,0,0))))
        self.addParameter(QgsProcessingParameterFile(
            self.EXCEL_FILE, 'Excel/CSV File (Daily Rainfall)', optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.DATE_COLUMN, 'Date Column Name', defaultValue='Date', optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.RAINFALL_COLUMN, 'Rainfall Column Name', defaultValue='Rainfall_mm', optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_SPATIAL_RAIN,
            'Use Spatial Rainfall Raster instead of point rainfall',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RAINFALL_RASTER,
            'Spatial Rainfall Raster (mm depth, each pixel = 24-hr storm total)',
            optional=True))
        self.addParameter(QgsProcessingParameterFile(
            self.CHIRPS_FOLDER, 'CHIRPS Data Folder (.nc files)', optional=True,
            behavior=QgsProcessingParameterFile.Folder))

        # ── Analysis ───────────────────────────────────────────────────────
        self.addParameter(QgsProcessingParameterEnum(
            self.ANALYSIS_METHOD, 'Flood Analysis Method',
            options=self.ANALYSIS_METHODS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.REGIONAL_METHOD, 'Regional Standard (optional overlay)',
            options=self.REGIONAL_METHODS, defaultValue=0))
        self.addParameter(QgsProcessingParameterString(
            self.RETURN_PERIODS, 'Return Periods (years, comma-separated)',
            defaultValue='2,5,10,25,50,100,200'))
        self.addParameter(QgsProcessingParameterEnum(
            self.FREQ_METHOD, 'Frequency Analysis Method',
            options=self.FREQ_METHODS, defaultValue=1))  # LP3 default for daily
        self.addParameter(QgsProcessingParameterEnum(
            self.AMC_CONDITION, 'Antecedent Moisture Condition',
            options=self.AMC_OPTIONS, defaultValue=1))
        self.addParameter(QgsProcessingParameterEnum(
            self.DESIGN_STORM_TYPE, 'Design Storm Temporal Pattern',
            options=self.DESIGN_STORMS, defaultValue=0))

        # ── Catchment ──────────────────────────────────────────────────────
        self.addParameter(QgsProcessingParameterEnum(
            self.CATCHMENT_INPUT, 'Catchment Input Method',
            options=['Shapefile + DEM', 'Manual Parameters',
                     'Pour Point + DEM (auto-delineate upstream catchment)'],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP_RADIUS,
            'Pour-point snap radius (cells) — only used by the pour-point method',
            QgsProcessingParameterNumber.Integer, defaultValue=10, minValue=0))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CATCHMENT, 'Catchment Boundary (Polygon)',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DEM, 'DEM Raster', optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.SLOPE_RASTER, 'Slope Raster (%) – optional', optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.FLOW_PATH, 'Longest Flow Path (Line)',
            types=[QgsProcessing.TypeVectorLine], optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.AREA, 'Manual Catchment Area (km²)',
            QgsProcessingParameterNumber.Double, optional=True, minValue=0.01))
        self.addParameter(QgsProcessingParameterNumber(
            self.SLOPE, 'Manual Mean Slope (decimal, e.g. 0.02)',
            QgsProcessingParameterNumber.Double, optional=True, minValue=0.0001))

        # ── CN / LULC / Manning's ──────────────────────────────────────────
        self.addParameter(QgsProcessingParameterEnum(
            self.CN_RASTER_SOURCE, 'CN / LULC Data Source',
            options=self.CN_SOURCES, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CN_RASTER, 'CN Raster (HEC-RAS, pixel=CN value)', optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.LULC_RASTER, 'LULC Raster', optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.LULC_TYPE, 'LULC Dataset Type',
            options=self.LULC_TYPES, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.MANNING_RASTER, "Manning's n Raster (optional)", optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.HSG, 'Hydrologic Soil Group (default)',
            options=self.HSG_OPTIONS, defaultValue=1))
        self.addParameter(QgsProcessingParameterString(
            self.CN, 'Manual Curve Number',
            defaultValue='75'))
        self.addParameter(QgsProcessingParameterString(
            self.RUNOFF_COEFF, 'Runoff Coefficient C (Rational method)',
            defaultValue='0.60'))
        self.addParameter(QgsProcessingParameterString(
            self.MANNING_N, "Manual Manning's n",
            defaultValue='0.035'))

        # ── Regional parameters ───────────────────────────────────────────
        self.addParameter(QgsProcessingParameterNumber(
            self.SAAR, 'UK FEH – SAAR (Standard Average Annual Rainfall, mm)',
            QgsProcessingParameterNumber.Double, defaultValue=800.0, optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.SOIL_CLASS, 'UK FEH – HOST Soil Class (1=permeable, 5=impermeable)',
            options=self.SOIL_CLASSES, defaultValue=2, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.URBEXT, 'UK FEH – Urban Extent (URBEXT, 0–1)',
            QgsProcessingParameterNumber.Double, defaultValue=0.1, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.C10, 'ARR / NZ – 10-year Runoff Coefficient (C10)',
            QgsProcessingParameterNumber.Double, defaultValue=0.45, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.IDF_A, 'Canada IDF coefficient a (i = a/(Tc+b)^c)',
            QgsProcessingParameterNumber.Double, defaultValue=1200.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.IDF_B, 'Canada IDF coefficient b',
            QgsProcessingParameterNumber.Double, defaultValue=10.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.IDF_C, 'Canada IDF coefficient c',
            QgsProcessingParameterNumber.Double, defaultValue=0.75, optional=True))

        # ── Routing ────────────────────────────────────────────────────────
        self.addParameter(QgsProcessingParameterBoolean(
            self.ENABLE_ROUTING, 'Enable Muskingum-Cunge Channel Routing', defaultValue=False))
        self.addParameter(QgsProcessingParameterNumber(
            self.MUSK_K, 'Muskingum K – Travel Time (hr)',
            QgsProcessingParameterNumber.Double, defaultValue=2.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.MUSK_X, 'Muskingum X – Weighting Factor',
            QgsProcessingParameterNumber.Double, defaultValue=0.2, optional=True))

        # ── Output ────────────────────────────────────────────────────────
        self.addParameter(QgsProcessingParameterBoolean(
            self.GENERATE_MAPS, 'Generate Flood Inundation Maps', defaultValue=True))
        self.addParameter(QgsProcessingParameterFile(
            self.OBSERVED_HYDROGRAPH,
            'Observed Hydrograph CSV for calibration (optional) — columns: '
            'Time_hr, Discharge_m3s',
            optional=True))
        self.addParameter(QgsProcessingParameterPoint(
            self.POUR_POINT,
            'Pour point / outlet — click on the map. ALL results correspond '
            'to this location', optional=True, defaultValue=''))
        self.addParameter(QgsProcessingParameterString(
            self.POUR_POINT_MANUAL,
            'Pour point as "lat,lon" (used if nothing picked on the map)',
            defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.SUBBASIN_LAYER,
            'Sub-basins from Tab 2 (optional) — enables semi-distributed '
            'routing instead of treating the catchment as one lump',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.WAVE_CELERITY, 'Flood wave celerity for sub-basin routing (m/s)',
            QgsProcessingParameterNumber.Double, defaultValue=1.0, optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.CWC_COEFFS,
            'CWC subzone coefficients (unused by Standard Flood methods; kept '
            'for settings compatibility)', defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.RUN_SENSITIVITY,
            'Run sensitivity analysis (not yet available for Standard Flood)',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_2D_ROUTING,
            'Also route the full hydrograph through 2D diffusive-wave '
            'physics (slower, more realistic — see Help)',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(
            self.LOAD_RASTERS, 'Load Flood Rasters in QGIS', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.EXPORT_HEC_HMS, 'Export HEC-HMS Compatible Files', defaultValue=True))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR, 'Output Directory'))

        self.addOutput(QgsProcessingOutputFile(self.OUTPUT_EXCEL, 'Results Excel'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_FLOOD_MAPS, 'Flood Maps (PNG)'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_RASTERS, 'Flood Rasters (GeoTIFF)'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_HYDROGRAPHS, 'Hydrographs'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_HEC_HMS, 'HEC-HMS Files'))

    def processAlgorithm(self, parameters, context, feedback):
        # ── Resolve parameters ────────────────────────────────────────────
        point  = self.parameterAsPoint(parameters, self.COORDINATES_POINT, context)
        manual = self.parameterAsString(parameters, self.COORDINATES_MANUAL, context)
        lat, lon = _resolve_coordinates(point, manual, feedback)

        start_dt = self.parameterAsDateTime(parameters, self.START_DATE, context)
        end_dt   = self.parameterAsDateTime(parameters, self.END_DATE, context)
        start_str = start_dt.toString('yyyy-MM-dd')
        end_str   = end_dt.toString('yyyy-MM-dd')
        start_yr  = int(start_str[:4])
        end_yr    = int(end_str[:4])

        rp_str    = self.parameterAsString(parameters, self.RETURN_PERIODS, context)
        return_periods = [int(x.strip()) for x in rp_str.split(',') if x.strip().isdigit()]
        if not return_periods:
            return_periods = [10, 25, 50, 100]

        rain_src  = self.parameterAsEnum(parameters, self.RAINFALL_SOURCE, context)
        use_spatial    = self.parameterAsBoolean(parameters, self.USE_SPATIAL_RAIN, context)
        rain_rast_lyr  = self.parameterAsRasterLayer(parameters, self.RAINFALL_RASTER, context)
        rain_rast_path = rain_rast_lyr.source() if rain_rast_lyr else None
        method    = self.parameterAsEnum(parameters, self.ANALYSIS_METHOD, context)
        reg_meth  = self.parameterAsEnum(parameters, self.REGIONAL_METHOD, context)
        freq_idx  = self.parameterAsEnum(parameters, self.FREQ_METHOD, context) + 1
        amc_idx   = self.parameterAsEnum(parameters, self.AMC_CONDITION, context)
        amc       = amc_idx + 1
        ds_type   = self.parameterAsEnum(parameters, self.DESIGN_STORM_TYPE, context)
        cat_input = self.parameterAsEnum(parameters, self.CATCHMENT_INPUT, context)
        cn_src    = self.parameterAsEnum(parameters, self.CN_RASTER_SOURCE, context)
        lulc_ti   = self.parameterAsEnum(parameters, self.LULC_TYPE, context)
        lulc_name = ['ESA', 'NLCD', 'CORINE', 'MODIS'][lulc_ti]
        hsg_idx   = self.parameterAsEnum(parameters, self.HSG, context)
        hsg       = ['A', 'B', 'C', 'D'][hsg_idx]
        enable_rt = self.parameterAsBoolean(parameters, self.ENABLE_ROUTING, context)
        gen_maps  = self.parameterAsBoolean(parameters, self.GENERATE_MAPS, context)
        pour_pt_raw = self.parameterAsPoint(parameters, self.POUR_POINT, context)
        pour_pt_manual = self.parameterAsString(parameters, self.POUR_POINT_MANUAL, context)
        subbasin_layer = self.parameterAsVectorLayer(parameters, self.SUBBASIN_LAYER, context)
        wave_celerity = self.parameterAsDouble(parameters, self.WAVE_CELERITY, context) or 1.0
        pour_lat, pour_lon = _resolve_coordinates(pour_pt_raw, pour_pt_manual, feedback)
        if pour_lat is not None and pour_lon is not None:
            feedback.pushInfo(
                f"Pour point (outlet) set to lat={pour_lat:.5f}, lon={pour_lon:.5f} — "
                f"all discharges correspond to THIS point."
            )
        else:
            feedback.pushInfo(
                "No pour point supplied — results correspond to the catchment's "
                "own lowest point, inferred from the DEM."
            )
        observed_hydrograph_path = self.parameterAsFile(
            parameters, self.OBSERVED_HYDROGRAPH, context)
        use_2d_routing = self.parameterAsBoolean(parameters, self.USE_2D_ROUTING, context)
        ld_rast   = self.parameterAsBoolean(parameters, self.LOAD_RASTERS, context)
        exp_hec   = self.parameterAsBoolean(parameters, self.EXPORT_HEC_HMS, context)
        output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        os.makedirs(output_dir, exist_ok=True)

        cn_manual  = _parse_first_number(self.parameterAsString(parameters, self.CN, context), 75.0)
        runoff_C   = _parse_first_number(self.parameterAsString(parameters, self.RUNOFF_COEFF, context), 0.60)
        manning_n  = _parse_first_number(self.parameterAsString(parameters, self.MANNING_N, context), 0.035)

        # Regional parameters
        saar       = self.parameterAsDouble(parameters, self.SAAR, context) or 800.0
        soil_cls   = self.parameterAsEnum(parameters, self.SOIL_CLASS, context) + 1
        urbext     = self.parameterAsDouble(parameters, self.URBEXT, context) or 0.1
        C10        = self.parameterAsDouble(parameters, self.C10, context) or 0.45
        idf_a      = self.parameterAsDouble(parameters, self.IDF_A, context) or 1200.0
        idf_b      = self.parameterAsDouble(parameters, self.IDF_B, context) or 10.0
        idf_c      = self.parameterAsDouble(parameters, self.IDF_C, context) or 0.75

        feedback.pushInfo(
            f"Standard Flood Analysis v3.0 | lat={lat:.4f}, lon={lon:.4f} | "
            f"method={self.ANALYSIS_METHODS[method]} | AMC={amc}"
        )

        # ── Layer paths ──────────────────────────────────────────────────
        cat_lyr  = self.parameterAsVectorLayer(parameters, self.CATCHMENT, context)
        dem_lyr  = self.parameterAsRasterLayer(parameters, self.DEM, context)
        slp_lyr  = self.parameterAsRasterLayer(parameters, self.SLOPE_RASTER, context)
        fp_lyr   = self.parameterAsVectorLayer(parameters, self.FLOW_PATH, context)
        cn_lyr   = self.parameterAsRasterLayer(parameters, self.CN_RASTER, context)
        lulc_lyr = self.parameterAsRasterLayer(parameters, self.LULC_RASTER, context)
        mn_lyr   = self.parameterAsRasterLayer(parameters, self.MANNING_RASTER, context)

        catchment_path = cat_lyr.source()  if cat_lyr  else None
        dem_path       = dem_lyr.source()  if dem_lyr  else None
        slope_path     = slp_lyr.source()  if slp_lyr  else None
        flow_path      = fp_lyr.source()   if fp_lyr   else None
        cn_path        = cn_lyr.source()   if cn_lyr   else None
        lulc_path      = lulc_lyr.source() if lulc_lyr else None
        mann_path      = mn_lyr.source()   if mn_lyr   else None

        chirps_folder = self.parameterAsString(parameters, self.CHIRPS_FOLDER, context)

        # ── A0. Pour-point delineation (if selected) ──────────────────────
        # See the matching block in flash_flood_analysis for why: it removes
        # the circularity of needing a catchment polygon to analyse a
        # catchment, and the delineated boundary is a true watershed divide
        # so later clips are exact. The point is snapped to the stream
        # network first.
        pp_result = None
        if cat_input == 2:
            feedback.setProgress(2)
            feedback.pushInfo("=== A0. Pour-Point Catchment Delineation ===")
            try:
                from .pour_point_catchment import (resolve_catchment_from_pour_point,
                                                    pour_point_xy_in_raster_crs)
            except ImportError:
                from pour_point_catchment import (resolve_catchment_from_pour_point,
                                                   pour_point_xy_in_raster_crs)
            snap_radius = self.parameterAsInt(parameters, self.SNAP_RADIUS, context)
            try:
                pp_result = resolve_catchment_from_pour_point(
                    dem_path, pour_lat, pour_lon, output_dir,
                    snap_radius_cells=max(1, snap_radius),
                    load_in_qgis=ld_rast, feedback=feedback)
            except ValueError as e:
                raise QgsProcessingException(str(e))
            catchment_path = pp_result['catchment_gpkg']
            cat_lyr = None
            feedback.pushInfo(
                f"Delineated upstream catchment: {pp_result['area_km2']:.2f} km², "
                f"longest flow path {pp_result['flow_path_m'] / 1000.0:.2f} km, "
                f"snapped {pp_result['snap_moved_m']:.0f} m from the point given.")

            # ── Is the rainfall point actually in this catchment? ────────
            # The rainfall lat/lon and the pour point are separate inputs
            # and nothing tied them together. A real run fetched ERA5 at
            # 16.7038, 74.1557 for a catchment whose outlet was at
            # 16.66184, 74.46644 — 33 km away, and outside the delineated
            # boundary. Every design rainfall depth, and therefore every
            # discharge, came from a grid cell that drains somewhere else.
            # Nothing in the output said so.
            try:
                from shapely.geometry import Point as _Pt
                import geopandas as _gpd
                _cat = _gpd.read_file(pp_result['catchment_gpkg'])
                _rx, _ry = pour_point_xy_in_raster_crs(lat, lon, dem_path)
                _pt = _Pt(_rx, _ry)
                _geom = _cat.geometry.union_all() if hasattr(
                    _cat.geometry, 'union_all') else _cat.geometry.unary_union
                if not _geom.contains(_pt):
                    _d_km = _geom.distance(_pt) / 1000.0
                    feedback.pushWarning(
                        f"  The rainfall point (lat={lat:.4f}, lon={lon:.4f}) "
                        f"lies OUTSIDE the delineated catchment, {_d_km:.1f} km "
                        f"beyond its boundary. Design rainfall — and so every "
                        f"discharge below — is being taken from a location that "
                        f"does not drain to this pour point. Set the rainfall "
                        f"coordinates inside the catchment, ideally near its "
                        f"centroid.")
                else:
                    _cx = _geom.centroid
                    _off = ((_cx.x - _rx) ** 2 + (_cx.y - _ry) ** 2) ** 0.5 / 1000.0
                    if _off > 25.0:
                        feedback.pushInfo(
                            f"  Rainfall point is inside the catchment but "
                            f"{_off:.0f} km from its centroid — check that it "
                            f"represents the catchment as a whole.")
            except Exception as _e:
                feedback.pushInfo(
                    f"  (Could not check the rainfall point against the "
                    f"catchment: {_e})")

        # ── A. Catchment parameters ───────────────────────────────────────
        feedback.setProgress(3); feedback.pushInfo("=== A. Catchment Parameters ===")
        area, slope_pct, L_m = _extract_catchment_params(
            0 if cat_input == 2 else cat_input,
            catchment_path, dem_path, slope_path, flow_path,
            self.parameterAsDouble(parameters, self.AREA, context),
            self.parameterAsDouble(parameters, self.SLOPE, context),
            feedback
        )

        if pp_result is not None:
            # Prefer the TRACED D8 flow path over the polygon's geometric
            # span — the diagonal of an outline ignores every meander and is
            # not a flow path. L_m drives the regional formulae and lag.
            if flow_path is None:
                if abs(pp_result['flow_path_m'] - L_m) > 0.05 * max(L_m, 1.0):
                    feedback.pushInfo(
                        f"  Longest flow path: using the traced D8 path "
                        f"({pp_result['flow_path_m'] / 1000.0:.2f} km) rather than "
                        f"the polygon's geometric span ({L_m / 1000.0:.2f} km).")
                L_m = pp_result['flow_path_m']
            area = pp_result['area_km2']

        # ── B. CN / LULC / Manning's ─────────────────────────────────────
        feedback.setProgress(8); feedback.pushInfo("=== B. CN / LULC / Manning's Rasters ===")
        d_cn_path, d_mann_path, w_cn, w_mann = _resolve_cn_manning_rasters(
            cn_src, cn_path, lulc_path, lulc_name, catchment_path,
            output_dir, lat, lon, cat_lyr, hsg, amc, cn_manual, manning_n, feedback
        )
        effective_cn   = np.clip(float(w_cn)   if w_cn   else adjust_cn_for_amc(cn_manual, amc), 30, 99)
        effective_mann = max(0.01, min(0.5, float(w_mann) if w_mann else manning_n))
        feedback.pushInfo(f"Effective CN={effective_cn:.1f}, Manning n={effective_mann:.4f}")

        # ── C. Download rainfall (daily) ──────────────────────────────────
        feedback.setProgress(15); feedback.pushInfo("=== C. Rainfall Data ===")
        spatial_rain_mm = None

        if use_spatial and rain_rast_path and catchment_path:
            feedback.pushInfo("Using SPATIAL rainfall raster for storm depth …")
            try:
                # numpy is already imported at module level as np — importing
                # it again HERE would make `np` a function-local name for the
                # whole of processAlgorithm, so every earlier use of np.*
                # (e.g. the np.clip on effective_cn above) would raise
                # UnboundLocalError before this line ever runs.
                import rasterio
                from rasterio.mask import mask as rasterio_mask
                import geopandas as gpd
                from shapely.geometry import mapping
                gdf_sp = gpd.read_file(catchment_path)
                with rasterio.open(rain_rast_path) as rsrc:
                    gdf_r  = gdf_sp.to_crs(rsrc.crs)
                    geoms  = [mapping(g) for g in gdf_r.geometry]
                    out, _ = rasterio_mask(rsrc, geoms, crop=True, nodata=rsrc.nodata or -9999.0)
                    arr    = out[0].astype(np.float32)
                    nd_v   = rsrc.nodata if rsrc.nodata is not None else -9999.0
                    arr[arr == nd_v] = np.nan; arr[arr < 0] = np.nan
                valid_px = arr[~np.isnan(arr)]
                if len(valid_px) > 0:
                    spatial_rain_mm = float(np.mean(valid_px))
                    feedback.pushInfo(
                        f"Spatial storm depth: mean={spatial_rain_mm:.2f} mm, "
                        f"max={float(np.max(valid_px)):.2f} mm  ({len(valid_px)} pixels)"
                    )
                else:
                    feedback.pushWarning("Spatial raster: no valid pixels in catchment – falling back to point.")
            except Exception as e:
                feedback.pushWarning(f"Spatial raster extraction failed ({e}) – using point rainfall.")

        if spatial_rain_mm is None:
            rainfall_df = _load_rainfall_daily(
                rain_src, lat, lon, start_str, end_str, start_yr, end_yr,
                self.parameterAsString(parameters, self.EXCEL_FILE, context),
                self.parameterAsString(parameters, self.DATE_COLUMN, context),
                self.parameterAsString(parameters, self.RAINFALL_COLUMN, context),
                chirps_folder, feedback
            )
            if rainfall_df is None or rainfall_df.empty:
                raise QgsProcessingException("Failed to load rainfall data.")
            rainfall_df, qc = quality_control_rainfall(rainfall_df, feedback=feedback)
        else:
            rainfall_df = None
            qc = {'source': 'spatial_raster', 'spatial_mean_mm': spatial_rain_mm}

        # ── D. Annual maxima and frequency analysis ───────────────────────
        feedback.setProgress(30); feedback.pushInfo("=== D. Frequency Analysis ===")
        import numpy as _np
        if spatial_rain_mm is not None:
            feedback.pushInfo(
                f"Spatial rainfall mode: storm depth={spatial_rain_mm:.2f} mm "
                f"applied uniformly across all return periods."
            )
            durations_hr   = [24]
            design_storms  = {24: _np.full(len(return_periods), spatial_rain_mm)}
            design_storms_ci_lower, design_storms_ci_upper = {}, {}
            design_storms_dist_name = {24: 'N/A (spatial raster mean)'}
            sdm            = {}
            idf_coeffs     = {}
            idf_func       = lambda d, r: spatial_rain_mm / max(d, 0.01)
            idf_table_df   = None
            freq_dist_name = 'Spatial raster (uniform across TPs)'
        else:
            durations_hr = [6, 12, 24, 48, 72]
            sdm = _short_duration_maxima(rainfall_df, durations_hr, feedback)
            design_storms = {}
            design_storms_ci_lower, design_storms_ci_upper = {}, {}
            design_storms_dist_name = {}
            freq_dist_name = None
            AUTO_METHOD_UI_CODE = 5  # 'Auto (best fit by AIC)' — see FREQ_METHODS
            for dur in durations_hr:
                if dur in sdm and len(sdm[dur]) >= 3:
                    actual_method = freq_idx
                    if freq_idx == AUTO_METHOD_UI_CODE:
                        auto_code, auto_name, _, _ = select_best_distribution(sdm[dur], feedback)
                        actual_method = auto_code
                    result = frequency_analysis_with_uncertainty(
                        sdm[dur], return_periods, actual_method, feedback, n_bootstrap=500)
                    design_storms[dur] = result['design']
                    design_storms_ci_lower[dur] = result['ci_lower']
                    design_storms_ci_upper[dur] = result['ci_upper']
                    design_storms_dist_name[dur] = result['dist_name']
                    freq_dist_name = result['dist_name']
            if not design_storms:
                raise QgsProcessingException("Insufficient data for frequency analysis.")
            idf_coeffs, idf_func = fit_idf_curves(design_storms, return_periods, feedback)
            idf_table_df         = generate_idf_table(idf_coeffs, durations_hr, return_periods)

        # ── E. Design storm (24-hr or user choice) ────────────────────────
        feedback.setProgress(42); feedback.pushInfo("=== E. Design Storm Temporal Distribution ===")
        storm_dur_hr = 24
        design24hr   = design_storms.get(24, design_storms.get(min(design_storms.keys())))

        # ── F. Runoff and hydrograph generation ──────────────────────────
        feedback.setProgress(52); feedback.pushInfo("=== F. Runoff & Hydrograph Generation ===")
        tp_hr = calculate_time_to_peak(L_m, slope_pct, effective_cn, feedback, duration_hr=storm_dur_hr)

        results, hyd_data, regional_results = [], {}, []
        for i, rp in enumerate(return_periods):
            rain_mm = float(design24hr[i]) if i < len(design24hr) else 50.0
            row, hyd = _run_standard_analysis(
                method, rp, rain_mm, storm_dur_hr, area,
                effective_cn, runoff_C, effective_mann,
                L_m, slope_pct, tp_hr, amc, ds_type, feedback,
                idf_func=idf_func
            )
            results.append(row)
            hyd_data[rp] = hyd

            # Regional overlay
            if reg_meth > 0:
                r_row = _apply_regional_method(
                    reg_meth, rp, rain_mm, area, effective_cn, slope_pct,
                    saar, soil_cls, urbext, C10, idf_func, tp_hr,
                    idf_a, idf_b, idf_c, i, feedback
                )
                if r_row:
                    regional_results.append(r_row)

        df_out     = pd.DataFrame(results)
        df_regional = pd.DataFrame(regional_results) if regional_results else None

        # ── G. Routing ────────────────────────────────────────────────────
        if enable_rt and hyd_data:
            K = self.parameterAsDouble(parameters, self.MUSK_K, context) or 2.0
            X = self.parameterAsDouble(parameters, self.MUSK_X, context) or 0.2
            feedback.pushInfo(f"=== G. Muskingum-Cunge Routing (K={K}hr, X={X}) ===")
            for rp, data in hyd_data.items():
                dt = float(data['time'][1] - data['time'][0]) if len(data['time']) > 1 else 0.5
                data['discharge_routed'] = muskingum_cunge_routing(
                    data['discharge'], dt, K, X, feedback)

        # ── H. Hydrograph plots ───────────────────────────────────────────
        feedback.setProgress(65); feedback.pushInfo("=== H. Hydrograph Visualisation ===")
        hydro_dir = os.path.join(output_dir, 'hydrographs')
        os.makedirs(hydro_dir, exist_ok=True)
        _plot_standard_hydrographs(hyd_data, return_periods, method,
                                    self.ANALYSIS_METHODS, hydro_dir, enable_rt, feedback)

        # ── I. Design storm hyetographs ───────────────────────────────────
        _plot_standard_design_storms(design24hr, return_periods, ds_type,
                                      self.DESIGN_STORMS, idf_func, hydro_dir, feedback)

        # ── J. IDF curves ─────────────────────────────────────────────────
        _plot_idf_curves(design_storms, return_periods, durations_hr, output_dir, feedback)

        # ── K. Annual maxima plot ─────────────────────────────────────────
        _plot_annual_maxima(sdm, durations_hr, output_dir, feedback)

        # ── K1b. Semi-distributed sub-basin routing (optional) ────────────
        if subbasin_layer is not None:
            feedback.pushInfo("=== K1b. Semi-Distributed Sub-Basin Routing ===")
            try:
                from .subbasin_routing import (
                    load_subbasins, route_subbasins_to_outlet, write_subbasin_summary)
                from .flash_flood_analysis import _pour_point_in_layer_crs
            except ImportError:
                from subbasin_routing import (
                    load_subbasins, route_subbasins_to_outlet, write_subbasin_summary)
                from flash_flood_analysis import _pour_point_in_layer_crs
            try:
                pour_xy = _pour_point_in_layer_crs(
                    pour_lat, pour_lon, subbasin_layer, feedback)
                subs = load_subbasins(subbasin_layer.source(), pour_xy,
                                       catchment_path=catchment_path,
                                       feedback=feedback)
                if subs:
                    sd_rows = []
                    for rp_i, rp in enumerate(return_periods):
                        rain_rp = float(design24hr[rp_i]) if rp_i < len(design24hr) else None
                        if rain_rp is None:
                            continue
                        feedback.pushInfo(f"  --- {rp}-yr ---")
                        sd = route_subbasins_to_outlet(
                            subs, rain_rp, 24, effective_cn, effective_mann,
                            slope_pct, cn_raster_path=(d_cn_path or cn_path),
                            feedback=feedback, wave_celerity_ms=wave_celerity)
                        if not sd:
                            continue
                        write_subbasin_summary(sd, output_dir, rp, feedback)
                        lumped_peak = next(
                            (float(r['Discharge (m³/s)']) for r in results
                             if int(r['Return Period (yr)']) == rp), None)
                        sd_rows.append({
                            'Return Period (yr)': rp,
                            'Lumped peak (m3/s)': round(lumped_peak, 2) if lumped_peak else None,
                            'Semi-distributed peak (m3/s)': round(sd['peak_m3s'], 2),
                            'Sub-basins': len(subs),
                        })
                        if lumped_peak:
                            diff = 100.0 * (sd['peak_m3s'] - lumped_peak) / lumped_peak
                            feedback.pushInfo(
                                f"    Lumped={lumped_peak:.1f} m³/s vs "
                                f"semi-distributed={sd['peak_m3s']:.1f} m³/s ({diff:+.1f}%)."
                            )
                    if sd_rows:
                        _sd_dir = os.path.join(output_dir, 'subbasins')
                        os.makedirs(_sd_dir, exist_ok=True)
                        pd.DataFrame(sd_rows).to_csv(
                            os.path.join(_sd_dir, 'lumped_vs_semidistributed.csv'), index=False)
                        feedback.pushInfo("  Comparison saved: lumped_vs_semidistributed.csv")
            except Exception as e:
                feedback.pushWarning(f"  Sub-basin routing failed: {e}")

        # ── K2. Calibration against observed data (optional) ──────────────
        if observed_hydrograph_path and os.path.exists(observed_hydrograph_path):
            feedback.setProgress(70); feedback.pushInfo("=== K2. Calibration vs Observed Hydrograph ===")
            try:
                from .flash_flood_analysis import _run_calibration
            except ImportError:
                from flash_flood_analysis import _run_calibration
            _run_calibration(observed_hydrograph_path, hyd_data, return_periods,
                             output_dir, feedback)

        # ── L. Flood mapping ──────────────────────────────────────────────
        flood_map_paths, flood_raster_paths = [], []
        flood_velocity_paths, flood_hazard_paths = [], []
        flood_2d_map_paths, flood_2d_raster_paths = [], []
        if gen_maps and dem_path and catchment_path:
            feedback.setProgress(78); feedback.pushInfo("=== L. Flood Inundation Mapping ===")
            for _, row in df_out.iterrows():
                rp      = int(row['Return Period (yr)'])
                Q       = float(row['Discharge (m³/s)'])
                Q_rd_mm = float(row.get('Runoff Depth (mm)', 0))
                fmap, frast, fvel, fhaz = generate_flood_map(
                    discharge=Q, dem_path=dem_path, catchment_path=catchment_path,
                    output_dir=output_dir, return_period=rp,
                    manning_n=effective_mann, feedback=feedback,
                    cn_raster_path=d_cn_path or cn_path,
                    manning_raster_path=d_mann_path or mann_path,
                    runoff_depth_mm=Q_rd_mm if Q_rd_mm > 0 else None
                )
                if fmap:  flood_map_paths.append(fmap)
                if frast: flood_raster_paths.append(frast)
                if fvel:  flood_velocity_paths.append(fvel)
                if fhaz:  flood_hazard_paths.append(fhaz)

                if use_2d_routing and rp in hyd_data:
                    hyd = hyd_data[rp]
                    t_s = np.asarray(hyd['time'], dtype=np.float64) * 3600.0
                    q_cms = np.asarray(hyd['discharge'], dtype=np.float64)
                    if len(t_s) >= 2 and np.max(q_cms) > 0:
                        feedback.pushInfo(
                            f"  2D routing for {rp}-yr (this is the slow, "
                            f"opt-in step — see Help for what it does "
                            f"differently) ..."
                        )
                        fmap2d, frast2d, _result2d = generate_flood_map_2d(
                            t_s, q_cms, dem_path, catchment_path, output_dir,
                            return_period=rp, manning_n=effective_mann,
                            feedback=feedback,
                            cn_raster_path=d_cn_path or cn_path,
                            manning_raster_path=d_mann_path or mann_path,
                        )
                        if fmap2d:  flood_2d_map_paths.append(fmap2d)
                        if frast2d: flood_2d_raster_paths.append(frast2d)

        if ld_rast and flood_raster_paths:
            load_flood_rasters_to_qgis(flood_raster_paths, feedback)
        if ld_rast and flood_velocity_paths:
            load_flood_rasters_to_qgis(flood_velocity_paths, feedback)
        if ld_rast and flood_hazard_paths:
            load_hazard_rasters_to_qgis(flood_hazard_paths, feedback)
        if ld_rast and flood_2d_raster_paths:
            load_flood_rasters_to_qgis(flood_2d_raster_paths, feedback)

        # ── M. HEC-HMS export ─────────────────────────────────────────────
        if exp_hec:
            feedback.setProgress(92); feedback.pushInfo("=== M. HEC-HMS Export ===")
            _export_standard_hec_hms(output_dir, df_out, hyd_data, design_storms,
                                      return_periods, durations_hr, area,
                                      effective_cn, effective_mann, slope_pct, L_m,
                                      method, self.ANALYSIS_METHODS, tp_hr, feedback)

        # ── N. Save Excel ─────────────────────────────────────────────────
        excel_path = os.path.join(output_dir, 'Standard_Flood_Analysis_Results.xlsx')
        _save_standard_excel(excel_path, df_out, df_regional, idf_table_df,
                              sdm, return_periods, durations_hr, design_storms,
                              qc, effective_cn, effective_mann, amc, 24,
                              self.ANALYSIS_METHODS[method],
                              self.REGIONAL_METHODS[reg_meth], freq_dist_name,
                              design_storms_ci_lower, design_storms_ci_upper,
                              design_storms_dist_name)

        # ── O. HTML report ────────────────────────────────────────────────
        feedback.setProgress(96); feedback.pushInfo("=== O. Report Generation ===")
        generate_html_report(
            output_dir, 'Standard Flood',
            {
                'Catchment area (km²)': f"{area:.2f}",
                'Mean slope (%)': f"{slope_pct:.2f}",
                'Longest flow path (m)': f"{L_m:.0f}",
                'Effective CN (AMC-adjusted)': f"{effective_cn:.1f}",
                "Effective Manning's n": f"{effective_mann:.4f}",
                'Analysis method': self.ANALYSIS_METHODS[method],
                'Regional standard': self.REGIONAL_METHODS[reg_meth],
                'Frequency distribution': freq_dist_name or 'N/A',
                'Return periods (yr)': ', '.join(str(r) for r in return_periods),
                'Antecedent moisture condition': amc,
                'Rainfall record length (yr)': qc.get('record_length_years', 'N/A'),
            },
            results_df=df_out, feedback=feedback)

        feedback.setProgress(100); feedback.pushInfo(f"=== Standard flood analysis complete. Results: {output_dir} ===")
        gc.collect()
        return {
            self.OUTPUT_EXCEL:       excel_path,
            self.OUTPUT_FLOOD_MAPS:  os.path.join(output_dir, 'flood_maps'),
            self.OUTPUT_RASTERS:     os.path.join(output_dir, 'flood_rasters'),
            self.OUTPUT_HYDROGRAPHS: os.path.join(output_dir, 'hydrographs'),
            self.OUTPUT_HEC_HMS:     os.path.join(output_dir, 'hec_hms'),
        }

    def name(self):           return 'standard_flood_analysis'
    def displayName(self):    return 'Standard Flood Analysis (Daily / Long-Duration)'
    def group(self):          return 'Hydrology'
    def groupId(self):        return 'hydrology'
    def createInstance(self): return StandardFloodAnalysis()


# ===========================================================================
# Private helpers
# ===========================================================================

def _load_rainfall_daily(rain_src, lat, lon, start_str, end_str,
                          start_yr, end_yr, excel_file, date_col, rain_col,
                          chirps_folder, feedback):
    if rain_src == 0:
        return download_openmeteo_data(lat, lon, start_str, end_str, feedback)
    elif rain_src == 1:
        return download_gpm_imerg_daily(lat, lon, start_str, end_str, feedback)
    elif rain_src == 2:
        return download_noaa_ghcnd_nearest(lat, lon, start_str, end_str, feedback=feedback)
    elif rain_src == 3:  # IMD
        try:
            from .rainfall_data_sources import download_imd_data
        except ImportError:
            from rainfall_data_sources import download_imd_data
        result = download_imd_data(lat, lon, start_yr, end_yr, None, feedback)
        if result is not None:
            return result
        feedback.pushWarning("IMD download failed – falling back to Open-Meteo.")
        return download_openmeteo_data(lat, lon, start_str, end_str, feedback)
    elif rain_src == 4:
        return load_chirps_data(chirps_folder, lat, lon, start_yr, end_yr, feedback)
    elif rain_src == 5:
        return load_excel_rainfall_data(excel_file, date_col, rain_col, feedback)
    else:
        return generate_synthetic_rainfall(100.0, cv=0.5, n_years=30, feedback=feedback)


def _run_standard_analysis(method, rp, rain_mm, storm_dur_hr, area,
                             cn, C, mann_n, L_m, slope_pct, tp_hr, amc,
                             ds_type, feedback, idf_func=None):
    """Return (result_row dict, hydrograph dict)."""
    row = {'Return Period (yr)': rp, '24hr Rainfall (mm)': rain_mm}

    # Design storm distribution
    if ds_type == 0:  # SCS Type-II
        t_h, cum_mm, incr_mm = scs_type_ii_distribution(rain_mm, 24, 97)
    elif ds_type == 1:  # ABM
        t_h, incr_mm = alternating_block_hyetograph(rain_mm, 24, 48, feedback=feedback)
        cum_mm = np.cumsum(incr_mm)
    elif ds_type == 2:  # Uniform
        incr_mm = np.full(48, rain_mm / 48)
        t_h     = np.linspace(0, 24, 49)[:-1]
        cum_mm  = np.cumsum(incr_mm)
    else:  # Chicago
        t_h, incr_mm = _chicago_design_storm(rain_mm, 24, 48, feedback)
        cum_mm = np.cumsum(incr_mm)

    Q_mm   = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
    row['Runoff Depth (mm)'] = Q_mm

    if method == 0:  # SCS Triangular
        t, disch = generate_scs_unit_hydrograph(area, tp_hr, feedback)
        _, disch_fh = generate_flood_hydrograph(t, disch, Q_mm, feedback)
        Qp = float(disch_fh.max())
        hyd = {'time': t, 'discharge': disch_fh}

    elif method == 1:  # NRCS Dimensionless
        t, disch = generate_nrcs_dimensionless_uh(area, tp_hr, feedback)
        _, disch_fh = generate_flood_hydrograph(t, disch, Q_mm, feedback)
        Qp = float(disch_fh.max())
        hyd = {'time': t, 'discharge': disch_fh}

    elif method == 2:  # Snyder
        Lca  = L_m * 0.4
        t, disch, _ = generate_snyder_unit_hydrograph(area, L_m, Lca, feedback=feedback)
        disch_fh = disch * (Q_mm / 10.0)
        Qp = float(disch_fh.max())
        hyd = {'time': t, 'discharge': disch_fh}

    elif method == 3:  # Clark IUH
        tc  = tp_hr * 1.7
        R   = tc * 0.8
        t, iuh = generate_clark_iuh(area, tc, R, feedback=feedback)
        disch_fh = iuh * Q_mm
        Qp = float(disch_fh.max())
        hyd = {'time': t, 'discharge': disch_fh}

    elif method in (4, 5, 6):  # Regional methods – use SCS as default UH
        t, disch = generate_nrcs_dimensionless_uh(area, tp_hr, feedback)
        _, disch_fh = generate_flood_hydrograph(t, disch, Q_mm, feedback)
        Qp = float(disch_fh.max())
        hyd = {'time': t, 'discharge': disch_fh}

    elif method == 7:  # Rational
        # Tc (time of concentration), not Tp (time to peak) — same
        # SCS convention (Tp = 0.6*Tc) used elsewhere in this codebase.
        tc_hr_actual = tp_hr / 0.6
        i_from_idf = idf_func(tc_hr_actual, rp) if idf_func else None
        # Textbook Rational Method: intensity from the IDF curve AT
        # duration=Tc, not the 24hr design depth divided by the analysis
        # duration — IDF curves are non-linear in duration so these
        # differ, and Tc is very often well under 24hr for the small-to-
        # medium catchments this method is normally used for.
        i_mm_hr = i_from_idf if i_from_idf is not None else rain_mm / storm_dur_hr
        Qp = rational_method_peak_discharge(C, i_mm_hr, area)
        tb = storm_dur_hr + 2 * tp_hr
        t  = np.array([0, tp_hr, tb])
        hyd = {'time': t, 'discharge': np.array([0, Qp, 0])}

    else:
        Qp = 0.0
        hyd = {'time': np.array([0, 1]), 'discharge': np.array([0, 0])}

    row['Discharge (m³/s)'] = Qp
    row['Time to Peak (hr)'] = tp_hr
    row["Manning's n"] = mann_n
    return row, hyd


def _apply_regional_method(reg_meth, rp, rain_mm, area, cn, slope_pct,
                             saar, soil_cls, urbext, C10, idf_func, tp_hr,
                             idf_a, idf_b, idf_c, i, feedback):
    row = {'Return Period (yr)': rp}
    try:
        if reg_meth == 1:  # UK FEH
            result = feh_rainfall_runoff(area, saar, soil_cls, urbext, slope_pct, rp,
                                          rain_mm, feedback)
            row['FEH Qp (m³/s)'] = result['Qp']
            row['FEH QMED (m³/s)'] = result['QMED']
            row['FEH Growth Factor'] = result['growth_factor']

        elif reg_meth == 2:  # ARR2019
            if idf_func:
                i_crit = idf_func(tp_hr, rp) or rain_mm / 24.0
            else:
                i_crit = rain_mm / 24.0
            Qp = arr_probabilistic_rational(area, i_crit, C10, rp, feedback=feedback)
            row['ARR PRM Qp (m³/s)'] = Qp

        elif reg_meth == 3:  # Canada
            Qp, i_val = canada_rational_peak(C10, area, idf_a, idf_b, idf_c, tp_hr, feedback)
            row['Canada Rational Qp (m³/s)'] = Qp
            row['Canada Design Intensity (mm/hr)'] = i_val

        elif reg_meth == 4:  # NZ
            i_crit = idf_func(tp_hr, rp) if idf_func else rain_mm / 24.0
            if i_crit is None:
                i_crit = rain_mm / 24.0
            Qp = nz_probabilistic_rational(C10, area, i_crit, rp, feedback)
            row['NZ PRM Qp (m³/s)'] = Qp

        elif reg_meth == 5:  # Middle East Wadi
            from .hydrological_calculations import wadi_flood_estimation
            Qp, Q_mm, Tc = wadi_flood_estimation(area, rain_mm, cn, slope_pct, feedback)
            row['Wadi Qp (m³/s)'] = Qp
            row['Wadi Runoff (mm)'] = Q_mm
            row['Wadi Tc (hr)'] = Tc

    except Exception as e:
        feedback.pushWarning(f"Regional method failed for T={rp}: {e}")
    return row if len(row) > 1 else None


def _chicago_design_storm(total_mm, dur_hr, n_intervals, feedback=None):
    """Chicago Design Storm (Keifer & Chu 1957)."""
    r = 0.35  # ratio of time to peak to total duration (typical)
    dt = dur_hr / n_intervals
    t  = np.arange(0, dur_hr, dt)
    tp = r * dur_hr
    # Parabolic approximation
    hyeto = np.where(
        t <= tp,
        total_mm * 2 * (t / dur_hr) / (r * n_intervals),
        total_mm * 2 * (dur_hr - t) / (dur_hr) / ((1 - r) * n_intervals)
    )
    hyeto = np.abs(hyeto)
    hyeto = hyeto / hyeto.sum() * total_mm
    return t, hyeto


def _plot_standard_hydrographs(hyd_data, return_periods, method_idx, method_names,
                                 hydro_dir, enable_routing, feedback):
    if not hyd_data:
        return
    colors = plt.cm.plasma(np.linspace(0.1, 0.85, len(return_periods)))
    fig, ax = plt.subplots(figsize=(13, 7))
    for rp, col in zip(return_periods, colors):
        if rp not in hyd_data:
            continue
        d = hyd_data[rp]
        ax.plot(d['time'], d['discharge'], color=col, lw=2.2, label=f'{rp}-yr')
        if enable_routing and 'discharge_routed' in d:
            ax.plot(d['time'], d['discharge_routed'],
                    color=col, lw=2, ls='--', alpha=0.7, label=f'{rp}-yr (routed)')
        ax.fill_between(d['time'], d['discharge'], alpha=0.07, color=col)
    ax.set_xlabel('Time (hr)', fontsize=12)
    ax.set_ylabel('Discharge (m³/s)', fontsize=12)
    ax.set_title(
        f'Standard Flood Hydrographs — 24-hr Design Storm\n'
        f'Method: {method_names[method_idx]}',
        fontsize=13, fontweight='bold'
    )
    ax.legend(fontsize=9, ncol=3, loc='upper right')
    ax.grid(True, ls='--', alpha=0.4)
    ax.set_xlim(left=0)
    ax.set_ylim(bottom=0)
    out = os.path.join(hydro_dir, 'standard_flood_hydrographs.png')
    fig.savefig(out, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    if feedback:
        feedback.pushInfo(f"Standard hydrograph plot: {out}")


def _plot_standard_design_storms(design24hr, return_periods, ds_type_idx,
                                   ds_type_names, idf_func, hydro_dir, feedback):
    funcs = {
        0: lambda r, mm: scs_type_ii_distribution(mm, 24, 97)[:2],
        1: lambda r, mm: alternating_block_hyetograph(mm, 24, 48, feedback=None),
        2: lambda r, mm: (np.linspace(0, 24, 48), np.full(48, mm / 48)),
        3: lambda r, mm: _chicago_design_storm(mm, 24, 48),
    }
    fn = funcs.get(ds_type_idx, funcs[0])
    fig, axes = plt.subplots(len(return_periods), 1,
                              figsize=(11, 3 * len(return_periods)), sharex=True)
    if len(return_periods) == 1:
        axes = [axes]
    colors = plt.cm.Blues(np.linspace(0.35, 0.85, len(return_periods)))
    for ax, rp, mm, col in zip(axes, return_periods, design24hr, colors):
        if i_mm := mm:
            t, h = fn(rp, float(i_mm))
            dw = 24 / len(h) * 0.9
            ax.bar(t[:len(h)], h, width=dw, color=col, edgecolor='steelblue', lw=0.5, align='edge')
            ax.set_title(f'{ds_type_names[ds_type_idx]} – {rp}-year ({float(i_mm):.0f} mm)',
                         fontsize=10)
            ax.set_ylabel('Rainfall (mm)', fontsize=9)
            ax.grid(True, axis='y', ls='--', alpha=0.4)
    axes[-1].set_xlabel('Time (hr)', fontsize=10)
    fig.suptitle('24-hr Design Storm Hyetographs', fontsize=12, fontweight='bold')
    fig.tight_layout()
    out = os.path.join(hydro_dir, 'design_storm_hyetographs.png')
    fig.savefig(out, dpi=180, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def _plot_annual_maxima(sdm, durations_hr, output_dir, feedback):
    fig, ax = plt.subplots(figsize=(11, 6))
    colors = plt.cm.tab10(np.linspace(0, 1, len(durations_hr)))
    for dur, col in zip(durations_hr, colors):
        if dur not in sdm:
            continue
        vals = sorted(sdm[dur])
        n    = len(vals)
        ranks = np.arange(1, n + 1)
        T     = (n + 1) / ranks  # Weibull
        ax.plot(T, vals[::-1], 'o-', color=col, lw=1.5, ms=4, label=f'{dur}-hr max')
    ax.set_xscale('log')
    ax.set_xlabel('Return Period (years)', fontsize=12)
    ax.set_ylabel('Rainfall (mm)', fontsize=12)
    ax.set_title('Annual Maximum Rainfall – Empirical Plotting Positions', fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, ls='--', alpha=0.4)
    out = os.path.join(output_dir, 'Annual_Maxima_Plot.png')
    fig.savefig(out, dpi=180, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    if feedback:
        feedback.pushInfo(f"Annual maxima plot: {out}")


def _export_standard_hec_hms(output_dir, df_out, hyd_data, design_storms,
                               return_periods, durations, area, cn, mann_n,
                               slope_pct, L_m, method_idx, method_names, tp_hr, feedback):
    hec_dir = os.path.join(output_dir, 'hec_hms')
    os.makedirs(hec_dir, exist_ok=True)
    for rp, data in hyd_data.items():
        path = os.path.join(hec_dir, f'hydrograph_{rp}yr.csv')
        pd.DataFrame({'Time_hr': data['time'], 'Discharge_m3s': data['discharge']}).to_csv(path, index=False)
    for dur in durations:
        if dur in design_storms:
            pd.DataFrame({'Return_Period_yr': return_periods,
                          'Rainfall_mm': design_storms[dur]}).to_csv(
                os.path.join(hec_dir, f'design_storm_{dur}hr.csv'), index=False)
    with open(os.path.join(hec_dir, 'catchment_parameters.txt'), 'w') as f:
        f.write("=== HEC-HMS Parameters – Rain2Flood v3.0 ===\n\n")
        f.write(f"Analysis_Method         {method_names[method_idx]}\n")
        f.write(f"Area_km2                {area:.4f}\n")
        f.write(f"Curve_Number            {cn:.1f}\n")
        f.write(f"Manning_n               {mann_n:.4f}\n")
        f.write(f"Slope_pct               {slope_pct:.3f}\n")
        f.write(f"Flow_Path_m             {L_m:.1f}\n")
        f.write(f"Time_to_Peak_hr         {tp_hr:.3f}\n")
    if feedback:
        feedback.pushInfo(f"HEC-HMS files saved: {hec_dir}")


def _save_standard_excel(path, df_out, df_regional, idf_df, sdm,
                          return_periods, durations, design_storms,
                          qc, cn, mann_n, amc, storm_dur_hr, method_name,
                          regional_name, freq_name,
                          design_storms_ci_lower=None, design_storms_ci_upper=None,
                          design_storms_dist_name=None):
    design_storms_ci_lower = design_storms_ci_lower or {}
    design_storms_ci_upper = design_storms_ci_upper or {}
    design_storms_dist_name = design_storms_dist_name or {}
    with pd.ExcelWriter(path, engine='openpyxl') as writer:
        df_out.to_excel(writer, sheet_name='Results', index=False)
        if df_regional is not None and not df_regional.empty:
            df_regional.to_excel(writer, sheet_name='Regional Methods', index=False)
        idf_df.to_excel(writer, sheet_name='IDF Table', index=False)

        rows = []
        for dur in durations:
            if dur in sdm:
                for yi, v in enumerate(sdm[dur]):
                    rows.append({'Duration (hr)': dur, 'Year': yi + 1, 'Annual Max (mm)': round(v, 2)})
        if rows:
            pd.DataFrame(rows).to_excel(writer, sheet_name='Annual Maxima', index=False)

        ds_rows = []
        for dur in durations:
            if dur in design_storms:
                for rp, v in zip(return_periods, design_storms[dur]):
                    ds_rows.append({'Duration (hr)': dur, 'Return Period (yr)': rp,
                                    'Rainfall (mm)': round(v, 2), 'Intensity (mm/hr)': round(v / dur, 2)})
        if ds_rows:
            pd.DataFrame(ds_rows).to_excel(writer, sheet_name='Design Storms', index=False)

        # Frequency analysis uncertainty sheet — 90% bootstrap confidence
        # intervals and the distribution actually used per duration, so
        # a short record's design values come with an honest sense of
        # how much to trust them instead of a bare point estimate.
        ci_rows = []
        for dur in durations:
            if dur in design_storms and dur in design_storms_ci_lower:
                dist_name = design_storms_dist_name.get(dur, 'N/A')
                for rp, v, lo, hi in zip(return_periods, design_storms[dur],
                                          design_storms_ci_lower[dur],
                                          design_storms_ci_upper[dur]):
                    ci_rows.append({
                        'Duration (hr)': dur, 'Return Period (yr)': rp,
                        'Distribution Used': dist_name,
                        'Design Rainfall (mm)': round(float(v), 2),
                        '90% CI Lower (mm)': round(float(lo), 2),
                        '90% CI Upper (mm)': round(float(hi), 2),
                    })
        if ci_rows:
            pd.DataFrame(ci_rows).to_excel(writer, sheet_name='Frequency Uncertainty', index=False)

        params = [
            ('Analysis Method', method_name), ('Regional Standard', regional_name),
            ('Frequency Distribution', freq_name), ('CN (effective)', cn),
            ("Manning's n", mann_n), ('AMC', amc), ('Storm Duration (hr)', storm_dur_hr),
            ('QC Negatives Removed', qc.get('negatives_removed', 0)),
            ('Record Length (yr)', qc.get('record_length_years', 'N/A')),
        ]
        pd.DataFrame(params, columns=['Parameter', 'Value']).to_excel(
            writer, sheet_name='Parameters', index=False)
