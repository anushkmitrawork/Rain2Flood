from qgis.core import QgsApplication
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os

from .processing_provider import Rain2FloodProvider
from .rain2flood_dialog import Rain2FloodDialog


class Rain2FloodPlugin:
    def __init__(self, iface):
        self.iface    = iface
        self.provider = None
        self.action   = None
        self.dlg      = None

    def initGui(self):
        self.provider = Rain2FloodProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(
            QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
            'Rain2Flood v3.0 – Hydrological Toolkit',
            self.iface.mainWindow()
        )
        self.action.setWhatsThis('Open Rain2Flood v3.0 – Professional Rainfall-Runoff & Flood Analysis')
        self.action.triggered.connect(self.show_dialog)
        self.iface.addPluginToMenu('&Rain2Flood', self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        if self.action:
            self.iface.removePluginMenu('&Rain2Flood', self.action)
            self.iface.removeToolBarIcon(self.action)

    def show_dialog(self):
        if self.dlg is None:
            self.dlg = Rain2FloodDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()


def classFactory(iface):
    return Rain2FloodPlugin(iface)
