"""
DEM and Slope Processing Algorithm  (v4 — robust reprojection/crop rewrite)
============================================================================
Reprojects, crops, and derives:
  - Slope (single unit chosen by the user: percent OR degrees)
  - Basic catchment statistics (area, relief, mean slope, Tc estimates)

v4 changes (this rewrite)
--------------------------
1. REPROJECT + CROP IN ONE PASS, via a WarpedVRT bounded to the catchment's
   own extent (padded slightly), instead of the old two-stage approach
   (reproject the ENTIRE DEM to a new grid, write it to disk, then
   separately mask/crop it to the catchment). WarpedVRT is the standard,
   GDAL-backed way to do a windowed reprojection: it only ever touches the
   pixels that matter, computes the destination transform directly from
   the catchment's bounds (not the whole source DEM's bounds), and handles
   nodata propagation through resampling correctly and in one place. This
   removes an entire class of subtle two-stage transform/rounding issues.

2. SLOPE IS NOW COMPUTED WITH A PROPER NODATA-AWARE HORN'S METHOD (the same
   3x3-kernel algorithm GDAL's `gdaldem slope` uses), instead of the old
   `np.gradient` on an array where NaN/nodata had been zero-filled first.
   Zero-filling nodata before differentiating manufactures a fake cliff —
   real elevation dropping straight to sea level — at every nodata
   boundary (the catchment's own edge, and any void inside it), which is
   an extreme, physically-fake slope spike that renders as a dark/black
   halo wherever it occurs. The new implementation instead marks any
   pixel whose 3x3 neighbourhood touches nodata as nodata in the output,
   which is what GDAL itself does and is the correct, standard behaviour.

3. NO MORE SINK-FILLING IN THIS TOOL. Pit/depression-filling is a
   hydrological-routing conditioning step (needed before flow direction/
   accumulation), which no longer happens here at all — that work now
   lives entirely in the Streams & Sub-basins tool. Computing "slope" on
   an artificially pit-filled surface isn't standard practice and isn't
   needed for this tool's actual output, so the step (and its associated
   risk of introducing its own artifacts) is removed rather than kept
   around unused.

4. Unflagged DEM voids/sentinels (common in DEMs with no declared nodata
   value — e.g. -32768, 32767, or 0-as-fill left over from the source
   data) are detected via a physically-plausible elevation range check
   and folded into nodata, in addition to whatever nodata value (if any)
   the file declares.

5. Diagnostics: a pre-check reports what fraction of the catchment has
   plausible DEM coverage in the DEM's own native CRS (before any
   reprojection), and after cropping, the DEM/catchment bounds and any
   offset between them are logged explicitly.
"""

import os
import gc
import math
import numpy as np
import warnings
warnings.filterwarnings('ignore')

from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorLayer, QgsProcessingParameterCrs,
    QgsProcessingParameterFolderDestination, QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum, QgsProcessingException,
    QgsProcessing, QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem
)

# Physically plausible land-surface elevation range (meters). Used to catch
# unflagged DEM voids/sentinels that a file without a declared nodata value
# would otherwise let straight through as "valid" data. -430 m (Dead Sea
# shore) to 8849 m (Everest) covers real terrain anywhere on Earth with
# comfortable margin.
_PLAUSIBLE_ELEV_MIN = -500.0
_PLAUSIBLE_ELEV_MAX = 9000.0

# Extra margin (in units of the DEM's own resolution) padded around the
# catchment's bounds before windowed-reprojecting, so resampling near the
# edges has real neighbouring data to draw on rather than starting right at
# the crop boundary.
_CROP_PAD_CELLS = 5


class DemSlopeProcessing(QgsProcessingAlgorithm):
    DEM           = 'DEM'
    CATCHMENT     = 'CATCHMENT'
    TARGET_CRS    = 'TARGET_CRS'
    SLOPE_UNIT    = 'SLOPE_UNIT'      # 0 = Percent, 1 = Degrees
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    LOAD_IN_QGIS  = 'LOAD_IN_QGIS'

    SLOPE_UNIT_OPTIONS = ['Percent', 'Degrees']

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.DEM, 'Input DEM Raster'))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CATCHMENT,
            'Catchment Boundary (OPTIONAL — leave empty to process the whole DEM)',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterCrs(
            self.TARGET_CRS, 'Target Projected CRS', defaultValue='EPSG:32643'))
        self.addParameter(QgsProcessingParameterEnum(
            self.SLOPE_UNIT, 'Slope output unit',
            options=self.SLOPE_UNIT_OPTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.LOAD_IN_QGIS, 'Load layers in QGIS after processing', defaultValue=True))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_FOLDER, 'Output Folder'))

    def processAlgorithm(self, parameters, context, feedback):
        try:
            import rasterio
            from rasterio.vrt import WarpedVRT
            from rasterio.mask import mask as rasterio_mask
            from rasterio.warp import (calculate_default_transform, transform_bounds,
                                        Resampling)
            from rasterio.crs import CRS as RioCRS
            from rasterio.windows import from_bounds as window_from_bounds
            import geopandas as gpd
            from shapely.geometry import mapping
        except ImportError as e:
            raise QgsProcessingException(f"Required packages not available: {e}")

        dem_layer       = self.parameterAsRasterLayer(parameters, self.DEM, context)
        catchment_layer = self.parameterAsVectorLayer(parameters, self.CATCHMENT, context)
        target_crs      = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        slope_unit_idx  = self.parameterAsEnum(parameters, self.SLOPE_UNIT, context)
        load_in_qgis    = self.parameterAsBoolean(parameters, self.LOAD_IN_QGIS, context)
        output_folder   = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        os.makedirs(output_folder, exist_ok=True)

        slope_unit_name = self.SLOPE_UNIT_OPTIONS[slope_unit_idx]

        dem_path       = dem_layer.source()
        utm_crs        = target_crs.authid()

        feedback.pushInfo("=== DEM & Slope Processing v4 ===")

        # ── Step 0: coverage pre-check (native CRS, no reprojection) ──────
        # The catchment boundary is OPTIONAL. Requiring it here was
        # circular in the wider workflow: Tab 2 delineates the catchment
        # from this tab's output, and Tabs 4/5 now delineate the upstream
        # catchment from a pour point, so nothing downstream needs a
        # polygon the user has to source separately. Leave it empty and
        # the whole DEM is reprojected — which is also what sub-basin
        # delineation wants, since flow accumulation on a clipped raster
        # truncates upstream area at the clip edge.
        catchment_gdf = None
        if catchment_layer is not None:
            try:
                _check_dem_covers_catchment(dem_layer, catchment_layer, feedback)
            except Exception as e:
                feedback.pushWarning(f"  (Coverage pre-check skipped: {e})")

            catchment_gdf = _read_vector_with_authoritative_crs(
                gpd, catchment_layer.source(), catchment_layer, feedback)
        else:
            feedback.pushInfo(
                "  No catchment boundary supplied — processing the FULL DEM "
                "extent. This is the recommended input for Tab 2 "
                "(delineation) and for the pour-point workflow in Tabs 4/5.")

        with rasterio.open(dem_path) as src:
            src_crs = src.crs
            if src_crs is None:
                qgis_dem_crs = dem_layer.crs().authid()
                if not qgis_dem_crs:
                    raise QgsProcessingException(
                        "The input DEM has no CRS defined and QGIS has no "
                        "assigned CRS either. Please assign a CRS to the "
                        "DEM layer before running.")
                feedback.pushWarning(
                    f"  DEM file has no embedded CRS — using the CRS "
                    f"assigned in QGIS ({qgis_dem_crs}) instead.")
                src_crs = RioCRS.from_user_input(qgis_dem_crs)

            src_nodata = src.nodata
            if src_nodata is None:
                feedback.pushWarning(
                    "  DEM has no nodata value defined — void/sentinel "
                    "values (if any) will be caught by the physical-"
                    "plausibility check below instead."
                )
            src_res = (abs(src.transform.a), abs(src.transform.e))

            # ── Step 2: Single-pass reproject + crop via WarpedVRT ────────
            feedback.pushInfo(
                f"Step 1-2: Reprojecting + cropping DEM to {utm_crs} "
                f"(single pass) …"
            )
            if catchment_gdf is not None:
                catch_crs_gdf = catchment_gdf.to_crs(utm_crs)
                cminx, cminy, cmaxx, cmaxy = catch_crs_gdf.total_bounds
            else:
                catch_crs_gdf = None
                cminx, cminy, cmaxx, cmaxy = transform_bounds(
                    src_crs, utm_crs, *src.bounds)

            # Resolution in target-CRS units: convert the DEM's native pixel
            # size using the same calculate_default_transform GDAL logic,
            # applied ONLY across the DEM's own bounds — this yields a
            # correct target resolution without ever materialising a
            # full-extent reprojected raster.
            t_full, w_full, h_full = calculate_default_transform(
                src_crs, utm_crs, src.width, src.height, *src.bounds)
            res_x, res_y = abs(t_full.a), abs(t_full.e)

            pad_x = res_x * _CROP_PAD_CELLS
            pad_y = res_y * _CROP_PAD_CELLS
            win_minx, win_miny = cminx - pad_x, cminy - pad_y
            win_maxx, win_maxy = cmaxx + pad_x, cmaxy + pad_y

            out_width  = max(1, int(math.ceil((win_maxx - win_minx) / res_x)))
            out_height = max(1, int(math.ceil((win_maxy - win_miny) / res_y)))
            dst_transform = rasterio.transform.from_origin(
                win_minx, win_maxy, res_x, res_y)

            with WarpedVRT(src, src_crs=src_crs, crs=utm_crs, transform=dst_transform,
                            width=out_width, height=out_height,
                            resampling=Resampling.bilinear,
                            src_nodata=src_nodata, nodata=-9999.0,
                            dtype='float32') as vrt:
                crop_arr = vrt.read(1).astype(np.float32)
                crop_transform = vrt.transform
                crop_crs = vrt.crs

        # ── Step 3: Keep the reprojected (padded / full) grid ─────────────
        # NOTE ON ORDER: slope is computed on THIS array, before any clip to
        # the catchment polygon. Horn's method needs all eight neighbours,
        # so a cell on a clip boundary has no data on one side and its
        # slope is an artefact of the clip rather than of the terrain. With
        # the pad retained (or the full DEM when no polygon is supplied),
        # every cell that survives the later clip had real terrain around
        # it when its slope was computed. Clipping first, as before, left a
        # ring of wrong slope values all the way around the catchment.
        transform = crop_transform
        meta = {
            'driver': 'GTiff', 'height': crop_arr.shape[0], 'width': crop_arr.shape[1],
            'count': 1, 'dtype': 'float32', 'crs': crop_crs,
            'transform': crop_transform, 'nodata': -9999.0, 'compress': 'lzw',
        }

        # ── Diagnostics: bounds comparison ────────────────────────────────
        h, w = crop_arr.shape
        dem_left, dem_top = transform.c, transform.f
        dem_right = dem_left + w * transform.a
        dem_bottom = dem_top + h * transform.e
        feedback.pushInfo(
            f"  [diag] Reprojected DEM bounds ({utm_crs}): "
            f"({dem_left:.0f}, {dem_bottom:.0f}) – ({dem_right:.0f}, {dem_top:.0f})"
        )
        if catch_crs_gdf is not None:
            cat_b = catch_crs_gdf.total_bounds
            dem_cx, dem_cy = (dem_left + dem_right) / 2, (dem_bottom + dem_top) / 2
            cat_cx, cat_cy = (cat_b[0] + cat_b[2]) / 2, (cat_b[1] + cat_b[3]) / 2
            offset_km = math.hypot(dem_cx - cat_cx, dem_cy - cat_cy) / 1000.0
            feedback.pushInfo(
                f"  [diag] Catchment bounds ({utm_crs}):   "
                f"({cat_b[0]:.0f}, {cat_b[1]:.0f}) – ({cat_b[2]:.0f}, {cat_b[3]:.0f})"
            )
            feedback.pushInfo(f"  [diag] Center-to-center offset: {offset_km:.3f} km")

        # ── Void/sentinel cleanup ──────────────────────────────────────────
        # See module docstring point 4. Anything outside the physically
        # plausible elevation range gets folded into nodata, in addition to
        # the -9999 already set by the crop above.
        already_nodata = (crop_arr == -9999.0)
        implausible = (~already_nodata) & (
            (crop_arr < _PLAUSIBLE_ELEV_MIN) | (crop_arr > _PLAUSIBLE_ELEV_MAX)
        )
        n_bad = int(np.sum(implausible))
        if n_bad > 0:
            feedback.pushWarning(
                f"  Found {n_bad:,} DEM cell(s) with physically implausible "
                f"elevation (outside {_PLAUSIBLE_ELEV_MIN:.0f} to "
                f"{_PLAUSIBLE_ELEV_MAX:.0f} m) — an unflagged void/sentinel "
                f"in the source DEM. Treating these as nodata."
            )
        crop_arr[implausible] = -9999.0

        cropped_dem_path = os.path.join(output_folder, "dem_cropped.tif")
        with rasterio.open(cropped_dem_path, 'w', **meta) as dst:
            dst.write(crop_arr, 1)
        feedback.pushInfo("  ✓ Crop done")

        # ── Step 4: Slope — nodata-aware Horn's method ────────────────────
        feedback.pushInfo(f"Step 4: Computing slope ({slope_unit_name}) …")
        dem = crop_arr.astype(np.float64)
        nodata_mask = (dem == -9999.0)
        dem_nan = np.where(nodata_mask, np.nan, dem)

        cell_res_x = abs(transform.a)
        cell_res_y = abs(transform.e)
        cell_sz    = (cell_res_x + cell_res_y) / 2.0

        slope_percent, slope_degrees, slope_valid = _slope_horn(
            dem_nan, cell_res_x, cell_res_y, nodata_mask)

        # ── Step 4b: NOW clip both DEM and slope to the polygon ───────────
        # Deferred until after Horn's method has run (see the note at
        # Step 3): clipping first leaves a ring of boundary cells whose
        # slope was computed against missing neighbours.
        if catch_crs_gdf is not None:
            feedback.pushInfo("Step 4b: Clipping DEM and slope to catchment polygon …")
            from rasterio.features import geometry_mask
            try:
                inside = geometry_mask(
                    [mapping(g) for g in catch_crs_gdf.geometry],
                    out_shape=crop_arr.shape, transform=transform, invert=True)
            except Exception as e:
                raise QgsProcessingException(
                    f"Could not rasterise the catchment boundary for clipping. "
                    f"This usually means the DEM and catchment have "
                    f"incompatible CRS assignments. Original error: {e}")
            if not inside.any():
                raise QgsProcessingException(
                    f"DEM and catchment boundary do not overlap after "
                    f"reprojection to {utm_crs}. The DEM and/or catchment "
                    f"layer most likely have an incorrect CRS assigned.")
            crop_arr = np.where(inside, crop_arr, -9999.0).astype(np.float32)
            nodata_mask = nodata_mask | (~inside)
            slope_valid = slope_valid & inside
            dem_nan = np.where(nodata_mask, np.nan, crop_arr.astype(np.float64))
            feedback.pushInfo(
                f"  Clipped to {int(inside.sum()):,} cell(s) inside the boundary.")

        slope_out_arr = slope_percent if slope_unit_idx == 0 else slope_degrees
        slope_path = os.path.join(output_folder, f"slope_{slope_unit_name.lower()}.tif")
        slope_meta = meta.copy()
        slope_meta.update({'dtype': 'float32', 'nodata': -9999.0, 'compress': 'lzw'})
        slope_write = np.where(slope_valid, slope_out_arr, -9999.0).astype(np.float32)
        with rasterio.open(slope_path, 'w', **slope_meta) as dst:
            dst.write(slope_write, 1)

        mean_slope_pct = float(np.nanmean(np.where(slope_valid, slope_percent, np.nan)))
        mean_slope_deg = float(np.nanmean(np.where(slope_valid, slope_degrees, np.nan)))
        max_slope_pct  = float(np.nanmax(np.where(slope_valid, slope_percent, np.nan)))
        feedback.pushInfo(f"  ✓ Slope: mean={mean_slope_pct:.2f}%, max={max_slope_pct:.2f}%")
        if max_slope_pct > 500:
            feedback.pushWarning(
                f"  Max slope ({max_slope_pct:.0f}%) is still very high for "
                f"natural terrain (rarely exceeds a few hundred percent "
                f"even in steep mountains). If this persists, there may be "
                f"additional bad values in the source DEM worth inspecting "
                f"directly in a GIS/raster viewer."
            )

        # ── Step 5: Catchment statistics ──────────────────────────────────
        feedback.pushInfo("Step 5: Computing catchment statistics …")
        valid_elev = dem_nan[~nodata_mask]
        min_elev  = float(np.nanmin(valid_elev)) if valid_elev.size else float('nan')
        max_elev  = float(np.nanmax(valid_elev)) if valid_elev.size else float('nan')
        relief_m  = max_elev - min_elev

        if catch_crs_gdf is not None:
            area_km2 = float(catch_crs_gdf.area.sum()) / 1e6
            longest_fp_m = _longest_geometric_span(catch_crs_gdf)
        else:
            # No polygon: report the DEM's own valid extent. These are
            # DEM-extent statistics, NOT catchment statistics — the
            # diagonal span of a rectangular DEM is not a flow path. They
            # are reported so the tab still produces something useful, but
            # the real catchment numbers come from the pour-point
            # delineation in Tabs 4/5, which traces the actual D8 path.
            area_km2 = float((~nodata_mask).sum()) * cell_res_x * cell_res_y / 1e6
            longest_fp_m = float(math.hypot(w * cell_res_x, h * cell_res_y))
            feedback.pushWarning(
                "  No catchment polygon supplied, so the statistics below "
                "describe the DEM EXTENT, not a catchment. In particular the "
                "'longest flow path' is the DEM's diagonal, which is not a "
                "flow path at all, and every time-of-concentration value "
                "derived from it is meaningless. Use the pour-point "
                "delineation in Tab 4/5 for real catchment statistics — it "
                "traces the actual D8 flow path.")
        Tc_kirpich_hr  = _kirpich_tc(longest_fp_m, mean_slope_pct / 100.0)
        Tc_bransby_hr  = _bransby_williams_tc(longest_fp_m, area_km2, mean_slope_pct)
        Tc_FAA_hr      = _faa_tc(longest_fp_m / 1000.0, mean_slope_pct / 100.0)

        stats_path = os.path.join(output_folder, "catchment_statistics.txt")
        with open(stats_path, 'w') as f:
            f.write("=== Catchment Statistics – Rain2Flood v3.0 ===\n\n")
            f.write(f"Area (km²):                    {area_km2:.3f}\n")
            f.write(f"Min Elevation (m):             {min_elev:.2f}\n")
            f.write(f"Max Elevation (m):             {max_elev:.2f}\n")
            f.write(f"Relief (m):                    {relief_m:.2f}\n")
            f.write(f"Mean Slope (%):                {mean_slope_pct:.2f}\n")
            f.write(f"Mean Slope (°):                {mean_slope_deg:.2f}\n")
            f.write(f"Est. Longest Flow Path (m):    {longest_fp_m:.0f}  "
                    f"(geometric estimate)\n")
            f.write(f"Tc Kirpich (hr):               {Tc_kirpich_hr:.3f}\n")
            f.write(f"Tc Bransby-Williams (hr):      {Tc_bransby_hr:.3f}\n")
            f.write(f"Tc FAA (hr):                   {Tc_FAA_hr:.3f}\n")
            f.write(f"DEM Cell Size (m):             {cell_sz:.2f}\n")
            f.write(f"Slope output unit:             {slope_unit_name}\n")

        feedback.pushInfo(
            f"Catchment stats: A={area_km2:.2f} km², "
            f"Slope={mean_slope_pct:.2f}%, Relief={relief_m:.0f} m, "
            f"Tc_Kirpich={Tc_kirpich_hr:.2f} hr"
        )

        # ── Step 6: Load in QGIS ──────────────────────────────────────────
        if load_in_qgis:
            _load_layers_to_qgis([
                (cropped_dem_path, "DEM (cropped)",              'terrain'),
                (slope_path,       f"Slope ({slope_unit_name})", 'RdYlGn_r'),
            ], feedback)

        gc.collect()
        return {'OUTPUT_FOLDER': output_folder}

    # ── Metadata ─────────────────────────────────────────────────────────
    def name(self):          return 'dem_slope_processing'
    def displayName(self):   return 'DEM & Slope Processing'
    def group(self):         return 'Hydrology'
    def groupId(self):       return 'hydrology'
    def createInstance(self): return DemSlopeProcessing()


# ===========================================================================
# Helper functions
# ===========================================================================

def _split_qgis_source(source_str):
    """
    QGIS's QgsVectorLayer.source() returns a plain file path for simple
    shapefiles, but for multi-layer containers (GeoPackage, FileGDB, etc.)
    it returns a decorated URI like
    '/path/to/file.gpkg|layername=catchment_boundary'. Passing that whole
    string to geopandas.read_file() is not reliable — it can silently open
    the wrong layer. Returns (path, layer_name_or_None).
    """
    if '|' not in source_str:
        return source_str, None
    path, _, rest = source_str.partition('|')
    layer_name = None
    for part in rest.split('|'):
        if part.startswith('layername='):
            layer_name = part.split('=', 1)[1]
    return path, layer_name


def _check_dem_covers_catchment(dem_layer, catchment_layer, feedback):
    """
    Check, in the DEM's OWN native CRS with no reprojection involved, what
    fraction of the catchment polygon falls on plausible (non-void)
    DEM data. Done before any reprojection so it can't be confused by
    anything later in the pipeline.
    """
    import rasterio
    from rasterio.mask import mask as rasterio_mask
    from rasterio.crs import CRS as RioCRS
    import geopandas as gpd
    from shapely.geometry import mapping

    dem_path = dem_layer.source()
    cat_path, cat_layer_name = _split_qgis_source(catchment_layer.source())
    cat_gdf = (gpd.read_file(cat_path, layer=cat_layer_name)
               if cat_layer_name else gpd.read_file(cat_path))
    if cat_gdf.crs is None:
        qgis_crs = catchment_layer.crs().authid()
        if qgis_crs:
            cat_gdf = cat_gdf.set_crs(qgis_crs, allow_override=True)

    with rasterio.open(dem_path) as src:
        dem_crs = src.crs
        if dem_crs is None:
            qgis_dem_crs = dem_layer.crs().authid()
            if not qgis_dem_crs:
                raise RuntimeError("neither DEM nor catchment has a usable CRS")
            dem_crs = RioCRS.from_user_input(qgis_dem_crs)

        cat_in_dem_crs = cat_gdf.to_crs(dem_crs) if cat_gdf.crs else cat_gdf
        geoms = [mapping(g) for g in cat_in_dem_crs.geometry]

        try:
            out, _ = rasterio_mask(src, geoms, crop=True, nodata=src.nodata)
        except ValueError:
            feedback.reportError(
                "  [diag] Coverage check: the catchment polygon does not "
                "overlap the DEM's extent AT ALL in the DEM's own native "
                "CRS. The DEM you selected does not cover this catchment.",
                fatalError=False)
            return

        nodata_val = src.nodata
        band = out[0].astype(np.float64)
        if nodata_val is not None:
            is_nodata = (band == nodata_val) if not np.isnan(nodata_val) else np.isnan(band)
        else:
            is_nodata = np.isnan(band)
        is_implausible = (~is_nodata) & (
            (band < _PLAUSIBLE_ELEV_MIN) | (band > _PLAUSIBLE_ELEV_MAX)
        )
        valid = np.sum(~is_nodata & ~is_implausible)
        total = band.size
        pct = 100.0 * valid / total if total else 0.0
        n_implausible = int(np.sum(is_implausible))

        feedback.pushInfo(
            f"  [diag] DEM coverage of catchment bbox (native CRS, no "
            f"reprojection): {pct:.1f}% of pixels have plausible valid "
            f"data ({int(valid):,}/{total:,})."
        )
        if n_implausible > 0:
            feedback.pushWarning(
                f"  [diag] {n_implausible:,} pixel(s) inside the catchment "
                f"bbox have physically implausible elevation values "
                f"(outside {_PLAUSIBLE_ELEV_MIN:.0f} to "
                f"{_PLAUSIBLE_ELEV_MAX:.0f} m) — likely an unflagged void "
                f"in the source DEM. These will be treated as nodata "
                f"during processing."
            )
        if pct < 98.0:
            feedback.reportError(
                f"  [diag] The source DEM only has plausible data over "
                f"{pct:.1f}% of the catchment's bounding box, BEFORE any "
                f"reprojection or cropping. This points to a DEM COVERAGE "
                f"GAP (the DEM tile/mosaic doesn't fully cover the "
                f"catchment) rather than a coordinate/shift bug.",
                fatalError=False
            )


def _read_vector_with_authoritative_crs(gpd, path, qgis_layer, feedback):
    """
    Read a vector file with geopandas. Only fall back to the QGIS-assigned
    CRS when the file has NO CRS at all — if the file's CRS merely differs
    from what QGIS shows, trust the file (a silent override on a guess is
    itself a way to introduce a shift) and just log both values.
    """
    gdf_path, gdf_layer = _split_qgis_source(path)
    if gdf_layer:
        feedback.pushInfo(f"  Reading catchment layer '{gdf_layer}' from {gdf_path}")
        gdf = gpd.read_file(gdf_path, layer=gdf_layer)
    else:
        gdf = gpd.read_file(gdf_path)
    qgis_crs_authid = qgis_layer.crs().authid() if qgis_layer.crs().isValid() else None

    if gdf.crs is None:
        if qgis_crs_authid:
            feedback.pushWarning(
                f"  Catchment file has no embedded CRS — using the CRS "
                f"assigned in QGIS ({qgis_crs_authid}) instead.")
            gdf = gdf.set_crs(qgis_crs_authid, allow_override=True)
        else:
            feedback.pushWarning(
                "  Catchment file has no embedded CRS and QGIS has none "
                "assigned either. Reprojection may be unreliable — please "
                "assign a CRS to this layer.")
    elif qgis_crs_authid:
        try:
            file_authid = gdf.crs.to_authority()
            file_authid_str = ':'.join(file_authid) if file_authid else str(gdf.crs)
        except Exception:
            file_authid_str = str(gdf.crs)
        if file_authid_str.upper() != qgis_crs_authid.upper():
            feedback.pushWarning(
                f"  Note: catchment file's embedded CRS ({file_authid_str}) "
                f"differs from the CRS QGIS shows for this layer "
                f"({qgis_crs_authid}). Using the file's own CRS "
                f"({file_authid_str})."
            )
    return gdf


def _slope_horn(dem_nan, res_x, res_y, nodata_mask):
    """
    Slope via Horn's method (Horn, 1981) — the same 3x3-kernel algorithm
    GDAL's `gdaldem slope` uses. NaN-safe: any output pixel whose 3x3
    neighbourhood touches a nodata cell is itself marked invalid, rather
    than treating missing neighbours as elevation=0 (which manufactures a
    fake cliff at every nodata boundary).

    Returns (slope_percent, slope_degrees, valid_mask).
    """
    # Pad with edge-replication so we always have a full 3x3 window, and
    # track which padded cells were originally nodata separately.
    dem_p = np.pad(dem_nan, 1, mode='edge')
    nod_p = np.pad(nodata_mask, 1, mode='constant', constant_values=True)
    dem_p = np.where(nod_p, 0.0, dem_p)  # value doesn't matter where nodata;
                                          # excluded via nod_p below

    a = dem_p[0:-2, 0:-2]; b = dem_p[0:-2, 1:-1]; c = dem_p[0:-2, 2:]
    d = dem_p[1:-1, 0:-2];                        f = dem_p[1:-1, 2:]
    g = dem_p[2:,   0:-2]; h = dem_p[2:,   1:-1]; i = dem_p[2:,   2:]

    dzdx = ((c + 2 * f + i) - (a + 2 * d + g)) / (8.0 * res_x)
    dzdy = ((g + 2 * h + i) - (a + 2 * b + c)) / (8.0 * res_y)
    slope_rad = np.arctan(np.sqrt(dzdx ** 2 + dzdy ** 2))
    slope_percent = np.tan(slope_rad) * 100.0
    slope_degrees = np.degrees(slope_rad)

    na = nod_p[0:-2, 0:-2]; nb = nod_p[0:-2, 1:-1]; nc = nod_p[0:-2, 2:]
    nd = nod_p[1:-1, 0:-2]; ne = nod_p[1:-1, 1:-1]; nf = nod_p[1:-1, 2:]
    ng = nod_p[2:,   0:-2]; nh = nod_p[2:,   1:-1]; ni = nod_p[2:,   2:]
    any_nodata_nbr = na | nb | nc | nd | ne | nf | ng | nh | ni
    valid = ~any_nodata_nbr

    return slope_percent, slope_degrees, valid


def _longest_geometric_span(gdf):
    """
    Approximate the catchment's longest flow path as the diameter (longest
    pairwise vertex distance) of the union of the catchment polygon(s)'
    convex hull — a coarse geometric substitute for a true flow-path
    length, used only for order-of-magnitude Tc estimates.
    """
    from shapely.ops import unary_union
    geom = unary_union(list(gdf.geometry))
    hull = geom.convex_hull
    coords = list(hull.exterior.coords) if hasattr(hull, 'exterior') and hull.exterior else []
    if len(coords) < 2:
        minx, miny, maxx, maxy = geom.bounds
        return float(math.hypot(maxx - minx, maxy - miny))
    best = 0.0
    for i in range(len(coords)):
        for j in range(i + 1, len(coords)):
            dd = math.hypot(coords[i][0] - coords[j][0], coords[i][1] - coords[j][1])
            if dd > best:
                best = dd
    return float(best)


def _kirpich_tc(L_m, slope_decimal):
    """Kirpich (1940) Tc in hours."""
    L_ft = L_m * 3.28084
    S    = max(slope_decimal, 1e-5)
    Tc_min = 0.0078 * (L_ft ** 0.77) * (S ** -0.385)
    return Tc_min / 60.0


def _bransby_williams_tc(L_m, area_km2, slope_pct):
    """Bransby-Williams (1942) Tc in hours."""
    L_km = L_m / 1000.0
    S    = max(slope_pct, 0.01)
    return (58.5 * L_km) / (S ** 0.2 * area_km2 ** 0.1)


def _faa_tc(L_km, slope_decimal):
    """FAA (Federal Aviation Administration) overland flow Tc in hours."""
    S = max(slope_decimal, 1e-5)
    return (1.8 * (1.1 - 0.0) * L_km ** 0.5) / (S ** 0.333)


def _load_layers_to_qgis(layers, feedback):
    """
    Load a list of (path, name, cmap_hint) into the current QGIS project,
    applying a proper colour ramp based on the actual data range (not
    QGIS's default flat-gray singleband renderer, which is what every
    layer got before — cmap_hint was accepted as a parameter here but
    never actually used anywhere).
    Removes any existing layer with the same display name first, so a
    stale layer from a previous run can never be mistaken for the fresh
    output when comparing against the canvas.
    """
    try:
        from qgis.core import (QgsRasterLayer, QgsProject, QgsRasterShader,
                                QgsColorRampShader, QgsSingleBandPseudoColorRenderer,
                                QgsRasterBandStats)
        from qgis.PyQt.QtGui import QColor
        proj = QgsProject.instance()
        for path, name, cmap_hint in layers:
            if not path or not os.path.exists(path):
                continue
            stale = [lyr.id() for lyr in proj.mapLayers().values() if lyr.name() == name]
            if stale:
                proj.removeMapLayers(stale)
                if feedback:
                    feedback.pushInfo(
                        f"  Removed {len(stale)} previous layer(s) named "
                        f"'{name}' before loading the new one.")
            layer = QgsRasterLayer(path, name)
            if not layer.isValid():
                if feedback:
                    feedback.pushWarning(f"  Failed to load: {name}")
                continue

            try:
                # DISCRETE classes with equal-count breaks, not an
                # interpolated stretch. Elevation and especially slope are
                # strongly skewed — most cells sit in a narrow band with a
                # long thin tail — so a linear stretch spent most of the
                # palette on ground that barely exists and only three or
                # four colours ever appeared. See
                # ui_palettes.quantile_breaks.
                try:
                    from .ui_palettes import DEM_RAMP, SLOPE_RAMP, apply_ramp
                except ImportError:
                    from ui_palettes import DEM_RAMP, SLOPE_RAMP, apply_ramp
                if cmap_hint == 'RdYlGn_r':
                    apply_ramp(layer, SLOPE_RAMP, fmt='{:.1f}%', feedback=feedback)
                elif cmap_hint == 'terrain':
                    apply_ramp(layer, DEM_RAMP, fmt='{:.0f}', feedback=feedback)
            except Exception as e:
                if feedback:
                    feedback.pushWarning(f"  Could not style {name}: {e}")

            proj.addMapLayer(layer)
            # See rain2flood_dialog.py's _load_lyr for why this matters:
            # setRenderer() alone doesn't reliably force the canvas/legend
            # to refresh — without this the layer can look unstyled until
            # the user manually reopens Properties > Symbology.
            layer.triggerRepaint()
            layer.emitStyleChanged()
            if feedback:
                feedback.pushInfo(f"  Loaded: {name}")
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"QGIS layer load error: {e}")


def _color_ramp_items(cmap_hint, vmin, vmax):
    """
    Build (value, hex_color, label) breakpoints for a small set of named
    ramps, scaled to the layer's actual min/max so the colours always
    span the real data range rather than an assumed one.
    """
    try:
        from .ui_palettes import DEM_RAMP, SLOPE_RAMP, ramp_items
    except ImportError:
        from ui_palettes import DEM_RAMP, SLOPE_RAMP, ramp_items

    if cmap_hint == 'RdYlGn_r':
        # Slope. The DEM palette reversed: on a slope raster the flat
        # ground is the low end and steep ground the alarming high end,
        # which is the opposite reading order from elevation.
        colours = SLOPE_RAMP
        fmt = '{:.1f}%'
    elif cmap_hint == 'terrain':
        colours = DEM_RAMP
        fmt = '{:.0f} m'
    else:
        return None

    items = ramp_items(vmin, vmax, colours, fmt=fmt)
    if not items:
        return None
    # Label only the ends; a ten-stop legend with every value spelled out
    # is unreadable in the QGIS layer panel.
    out = []
    for i, (v, c, lbl) in enumerate(items):
        keep = lbl if i in (0, len(items) - 1) else ''
        out.append((v, c, keep))
    return out
