"""
Rain2Flood – Main Dialog
Tab order: DEM & Slope → Streams & Sub-basins → CN/LULC → Rainfall Data → Flash Flood → Standard Flood → About
v3.9: Spatial Rainfall tab/module removed (didn't connect to the plugin's
      actual design-storm workflow — IDF/frequency analysis already covers
      that from real gauge/IDF data; the gridded-API retrieval was high
      maintenance cost for thin, redundant value). Flash/Standard Flood
      still accept an optional user-supplied gridded rainfall raster from
      any external source (CHIRPS/ERA5/interpolated gauge data/etc.).
"""

import os
from qgis.PyQt.QtWidgets import (
    QDialog, QTabWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QComboBox, QCheckBox, QPushButton, QFileDialog,
    QMessageBox, QGroupBox, QDateTimeEdit, QDoubleSpinBox, QSpinBox,
    QScrollArea, QWidget, QTextEdit, QProgressBar, QFrame, QToolButton,
    QApplication, QTableWidget, QTableWidgetItem, QAbstractItemView,
    QHeaderView,
)
from qgis.PyQt.QtCore import QDateTime, QDate, QTime, Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsProcessingFeedback,
    QgsProject, QgsProcessingContext, QgsMapLayerProxyModel,
    QgsRasterLayer, QgsVectorLayer,
)
from qgis.gui import QgsMapLayerComboBox, QgsProjectionSelectionWidget

try:
    from .dem_slope_processing     import DemSlopeProcessing
    from .standard_flood_analysis  import StandardFloodAnalysis
    from .flash_flood_analysis     import FlashFloodAnalysis
    from .rainfall_data_downloader import RainfallDataDownloader
    from .dependency_manager       import DependencyManager
    from .cn_lulc_manager import (
        CN_TABLE_TR55, ESA_WORLDCOVER_TO_PARAMS, NLCD_TO_PARAMS,
        CORINE_TO_PARAMS, MODIS_IGBP_TO_PARAMS, HECRAS_CN_CLASSES,
        MANNING_N_CHANNELS, MANNING_N_OVERLAND,
    )
    from .raster_downloader import (
        download_esa_worldcover_for_bbox,
        generate_cn_raster_from_lulc_file,
        generate_cn_raster_manual,
        merge_raster_tiles,
    )
    from .map_point_picker import PointPickerButton
    from .extent_picker import ExtentPicker
    from .subcatchment_delineation import SubcatchmentDelineation
except ImportError:
    from dem_slope_processing     import DemSlopeProcessing
    from standard_flood_analysis  import StandardFloodAnalysis
    from flash_flood_analysis     import FlashFloodAnalysis
    from rainfall_data_downloader import RainfallDataDownloader
    from dependency_manager       import DependencyManager
    from cn_lulc_manager import (
        CN_TABLE_TR55, ESA_WORLDCOVER_TO_PARAMS, NLCD_TO_PARAMS,
        CORINE_TO_PARAMS, MODIS_IGBP_TO_PARAMS, HECRAS_CN_CLASSES,
        MANNING_N_CHANNELS, MANNING_N_OVERLAND,
    )
    from raster_downloader import (
        download_esa_worldcover_for_bbox,
        generate_cn_raster_from_lulc_file,
        generate_cn_raster_manual,
        merge_raster_tiles,
    )
    from map_point_picker import PointPickerButton
    from extent_picker import ExtentPicker
    from subcatchment_delineation import SubcatchmentDelineation

_FA = FlashFloodAnalysis
_SA = StandardFloodAnalysis

# Qt6 / Qt5 enum compatibility
try:
    _Qt_RichText     = Qt.TextFormat.RichText
    _Qt_AlignCenter  = Qt.AlignmentFlag.AlignCenter
    _QHdr_Stretch    = QHeaderView.ResizeMode.Stretch
    _QHdr_ResizeCont = QHeaderView.ResizeMode.ResizeToContents
    _QAbs_NoEdit     = QAbstractItemView.EditTrigger.NoEditTriggers
    _Qt_Window       = Qt.WindowType.Window
    _Qt_WinMin       = Qt.WindowType.WindowMinimizeButtonHint
    _Qt_WinMax       = Qt.WindowType.WindowMaximizeButtonHint
    _Qt_WinClose     = Qt.WindowType.WindowCloseButtonHint
    _QFrame_NoFrame  = QFrame.Shape.NoFrame
    _Qt_Translucent  = Qt.WidgetAttribute.WA_TranslucentBackground
except AttributeError:
    _Qt_RichText     = Qt.RichText            # type: ignore
    _Qt_AlignCenter  = Qt.AlignCenter         # type: ignore
    _QHdr_Stretch    = QHeaderView.Stretch    # type: ignore
    _QHdr_ResizeCont = QHeaderView.ResizeToContents  # type: ignore
    _QAbs_NoEdit     = QAbstractItemView.NoEditTriggers  # type: ignore
    _Qt_Window       = Qt.Window              # type: ignore
    _Qt_WinMin       = Qt.WindowMinimizeButtonHint  # type: ignore
    _Qt_WinMax       = Qt.WindowMaximizeButtonHint  # type: ignore
    _Qt_WinClose     = Qt.WindowCloseButtonHint     # type: ignore
    _QFrame_NoFrame  = QFrame.NoFrame               # type: ignore
    _Qt_Translucent  = Qt.WA_TranslucentBackground  # type: ignore

# ══════════════════════════════════════════════════════════════════════════
#  THEME — light surface, indigo accent
#
#  Every colour pair below was checked with the WCAG relative-luminance
#  formula, not picked by eye, and the ratios are asserted in
#  test_theme_is_self_consistent. Contrast is the whole point of this
#  theme: the log in particular is long-running diagnostic output that
#  gets read carefully, so it needs body-text contrast, not decoration.
#
#  Measured (AA needs 4.5:1 for body text, 3:1 for UI/large):
#    #FFFFFF on ACCENT #3F51B5 ....... 6.87:1
#    TEXT   #1A1A1E on white ........ 17.35:1
#    TEXT_DIM #5A6270 on white ....... 6.15:1
#    LOG_ERROR #B3261E on white ...... 6.54:1
#    LOG_WARN  #8A5200 on white ...... 6.39:1
#    LOG_OK    #1B5E20 on white ...... 7.87:1
#
#  Indigo 500 rather than a deeper indigo on purpose. #1A237E would give
#  13:1 against white, but as a large filled area (selected tab, primary
#  button, progress bar) it reads almost black and stops looking like an
#  accent at all. 6.87:1 clears AA for the white label on it with room to
#  spare, and keeps the hue legible.
#
#  Surfaces are separated by lightness, as in the dark theme: the window
#  is a faint blue-grey and cards sit on pure white above it, so a card
#  edge is visible even where a border is not.
# ══════════════════════════════════════════════════════════════════════════

PLUGIN_VERSION = '3.0'
LINKEDIN_URL = 'https://in.linkedin.com/in/rahul-pandey-nitb'
GITHUB_URL   = 'https://github.com/rahulpandey696/Rain2Flood'

# Single source of truth for the changelog. metadata.txt and README.md
# carry the same text; keeping the wording here means the About tab can
# never drift from what the plugin manager shows.
CHANGELOG_ENTRIES = [
    ("Pour-point workflow",
     "Set one pour point and the upstream catchment, longest flow path and "
     "channel slope are all delineated from the DEM. No catchment polygon is "
     "required anywhere in the plugin. The point is snapped to the stream "
     "network first."),
    ("Flood extent corrected",
     "Depression filling was dammed by the nodata surround of a clipped "
     "catchment, flattening the lower basin and flooding ~66% of it "
     "regardless of discharge. Extents are now channel-scale and respond to "
     "discharge."),
    ("Volume budget",
     "Mapped flood water can no longer exceed the runoff the storm produced. "
     "The consistency check used to warn and be ignored."),
    ("Channel slope",
     "Measured longitudinally as S1085 along the traced main stem instead of "
     "from the DEM gradient magnitude, which measured the valley walls."),
    ("Sub-basin routing",
     "Sub-basins are clipped to the analysis catchment, so basins draining "
     "elsewhere are no longer summed into the hydrograph."),
    ("Method-range warnings",
     "The SCS lag equation now says when it is being extrapolated past its "
     "~8 km2 validity range, and when time to peak exceeds the storm "
     "duration."),
    ("Rainfall location check",
     "Warns when the rainfall point falls outside the delineated catchment."),
    ("CN / LULC extent",
     "The CN tab takes an area of interest — layer extent, canvas extent or a "
     "rectangle drawn on the map — instead of demanding a catchment polygon."),
    ("Interface",
     "Rebuilt with a contrast-checked light theme, new raster colour ramps "
     "for DEM, slope, CN, LULC and Manning's n, and QGIS 4 / PyQt6 "
     "compatibility."),
]

CHANGELOG_HTML = '<br>'.join(
    f'<b>{t}</b> — {d}' for t, d in CHANGELOG_ENTRIES)

TRANSLUCENT = False          # real window translucency; see note below

# Glyph assets for combo/spin arrows and the checkbox tick.
#
# These have to be real images. Qt's stylesheet box model will not build a
# CSS triangle from borders on a zero-sized subcontrol — it lays out a
# small filled square instead, which is what every "border-left: 4px solid
# transparent" dark-theme recipe actually renders here. And the moment a
# QSpinBox or QComboBox is styled at all, Qt stops drawing its NATIVE
# indicator from the palette, so leaving the subcontrol unstyled gets a
# stub in the wrong colour rather than nothing. An image is the only
# option that renders correctly in both cases.
_ICON_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')


def _icon_url(name):
    """Qt stylesheets want forward slashes on every platform."""
    return os.path.join(_ICON_DIR, name).replace('\\', '/')


_CHEV_DOWN    = _icon_url('r2f_chevron_down.png')
_CHEV_UP      = _icon_url('r2f_chevron_up.png')
_CHEV_DOWN_HI = _icon_url('r2f_chevron_down_hi.png')
_CHEV_UP_HI   = _icon_url('r2f_chevron_up_hi.png')
_CHECK        = _icon_url('r2f_check.png')

# Surfaces, in stacking order.
#
# BG is the requested #F2EFE7 — a warm cream. Cards sit on pure white
# ABOVE it, which is the right way round: a warm ground with cool white
# panels reads as depth, where cream-on-cream reads as washed out. That
# was the complaint about the previous theme, and it was a real one —
# everything sat within a few percent lightness of everything else, so
# nothing had edges.
#
# Structure now carries colour rather than being uniformly pale: the
# selected tab is a solid accent block, group-box titles sit on a pale
# teal chip, and the header is a teal band. Contrast comes from hue and
# value together instead of hairlines alone.
BG          = '#F2EFE7'      # window — warm cream (requested)
SURFACE     = '#FFFFFF'      # cards / group boxes
SURFACE_2   = '#FFFFFF'      # inputs
SURFACE_3   = '#E4F0ED'      # hover — pale teal wash
SUNKEN      = '#FFFFFF'      # log / code areas (unchanged: log stays white)

# Everything the user types into or picks from: browse bars, spin boxes,
# dropdowns (closed and open) and the processing log. Held as its own pair
# so a future theme change cannot tint an input field by accident — a
# half-tinted form reads as half-disabled.
INPUT_BG    = '#FFFFFF'
INPUT_FG    = '#000000'

# Text. Dark navy rather than neutral black, so it belongs to the blue
# family the accents come from.
TEXT        = '#14212E'      # 14.20:1 on BG, 16.32:1 on white
TEXT_DIM    = '#4A5A6A'      # 6.17:1  on BG, 7.09:1  on white
TEXT_FAINT  = '#5A6B7B'      # still AA on both

# Hairlines, tinted with the accent so they belong to the palette rather
# than sitting on it as neutral grey.
LINE        = 'rgba(51,104,160,0.16)'
LINE_STRONG = 'rgba(51,104,160,0.32)'

# Accent + semantic, from the supplied palette.
#   #3368A0  primary      white on it = 5.79:1
#   #66A3BF  secondary    FILL ONLY — as text it is 2.78:1, far below AA,
#                         so ACCENT2 (used for text and borders) is a
#                         darkened version of the same hue.
#   #C8DFDB  pale teal    chips, selected rows, header band
ACCENT      = '#3368A0'
ACCENT_DEEP = '#26507D'      # hover / pressed, and accent-coloured text
ACCENT_SOFT = '#C8DFDB'
ACCENT_FILL = '#66A3BF'      # decorative fills only, never text
ON_ACCENT   = '#FFFFFF'
ACCENT2     = '#357089'      # secondary action — 5.48:1 on white

# Tooltip: pale yellow ground with deep teal text. Kept as its own pair
# rather than reusing TEXT/SURFACE because a tooltip floats over arbitrary
# content and needs to be unmistakably NOT part of the panel beneath it.
TOOLTIP_BG  = '#FFF9AF'
TOOLTIP_FG  = '#154D71'
SUCCESS     = '#1B5E20'
WARN        = '#8A5200'
DANGER      = '#B3261E'

# Log tokens — deliberately UNCHANGED. The log is white-backed body text
# that was tuned for reading, and it was explicitly asked to stay as it
# is. Keeping it separate from the theme tokens is what makes that
# possible without special-casing.
LOG_BG      = '#FFFFFF'
LOG_TEXT    = '#1A1A1E'
LOG_DIM     = '#5A6270'
LOG_OK      = '#1B5E20'
LOG_WARN    = '#8A5200'
LOG_ERROR   = '#B3261E'
LOG_HEAD    = '#303F9F'

GLOBAL_STYLE = f"""
QWidget {{
    font-size: 12px;
    color: {TEXT};
    background: transparent;
}}
QDialog, QScrollArea, QScrollArea > QWidget > QWidget {{
    background: {BG};
}}

/* ── Text inputs ──────────────────────────────────────────────────── */
QLineEdit, QSpinBox, QDoubleSpinBox, QDateTimeEdit {{
    background: {INPUT_BG};
    border: 1px solid {LINE};
    border-bottom: 1px solid {LINE_STRONG};
    border-radius: 6px;
    padding: 6px 9px;
    color: {TEXT};
    selection-background-color: {ACCENT};
    selection-color: {ON_ACCENT};
}}
/* Inputs stay WHITE on hover. Tinting them on hover made a form of
   browse bars and dropdowns look half-disabled; the hover cue is the
   border instead, which is quieter and does not fight the text. */
QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QDateTimeEdit:hover {{
    background: {INPUT_BG};
    border-color: {ACCENT};
    border-bottom-color: {ACCENT};
}}
/* Fluent's focus cue is a thicker accent underline, not a full ring */
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateTimeEdit:focus {{
    background: {SURFACE_2};
    border: 1px solid {LINE};
    border-bottom: 2px solid {ACCENT};
    padding-bottom: 5px;
}}
QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{
    color: {TEXT_FAINT};
    background: rgba(0,0,0,0.03);
}}

QSpinBox::up-button, QDoubleSpinBox::up-button,
QSpinBox::down-button, QDoubleSpinBox::down-button,
QDateTimeEdit::up-button, QDateTimeEdit::down-button {{
    background: transparent; border: none; width: 16px;
}}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow, QDateTimeEdit::up-arrow {{
    image: url({_CHEV_UP}); width: 12px; height: 8px;
}}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow, QDateTimeEdit::down-arrow {{
    image: url({_CHEV_DOWN}); width: 12px; height: 8px;
}}
QSpinBox::up-arrow:hover, QDoubleSpinBox::up-arrow:hover {{ image: url({_CHEV_UP_HI}); }}
QSpinBox::down-arrow:hover, QDoubleSpinBox::down-arrow:hover {{ image: url({_CHEV_DOWN_HI}); }}
QSpinBox::up-arrow:disabled, QDoubleSpinBox::up-arrow:disabled,
QSpinBox::down-arrow:disabled, QDoubleSpinBox::down-arrow:disabled {{ image: none; }}

/* ── Combo boxes ──────────────────────────────────────────────────── */
QComboBox {{
    background: {INPUT_BG};
    color: {INPUT_FG};
    border: 1px solid {LINE};
    border-bottom: 1px solid {LINE_STRONG};
    border-radius: 6px;
    padding: 6px 9px;
    color: {TEXT};
    min-height: 16px;
}}
QComboBox:hover {{ background: {INPUT_BG}; border-color: {ACCENT};
                   border-bottom-color: {ACCENT}; }}
QComboBox:focus {{ border-bottom: 2px solid {ACCENT}; padding-bottom: 5px; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{
    image: url({_CHEV_DOWN}); width: 12px; height: 8px; margin-right: 8px;
}}
QComboBox::down-arrow:hover {{ image: url({_CHEV_DOWN_HI}); }}
QComboBox QAbstractItemView {{
    background: {INPUT_BG};
    border: 1px solid {LINE_STRONG};
    border-radius: 8px;
    padding: 4px;
    color: {INPUT_FG};
    outline: none;
    selection-background-color: {ACCENT};
    selection-color: {ON_ACCENT};
}}
QComboBox QAbstractItemView::item {{ color: {INPUT_FG}; }}
QComboBox QAbstractItemView::item:selected {{ color: {ON_ACCENT}; }}
QComboBox QAbstractItemView::item {{
    padding: 6px 8px; border-radius: 4px; min-height: 20px;
}}
QComboBox QAbstractItemView::item:hover {{ background: {ACCENT_SOFT}; color: {INPUT_FG}; }}

/* ── Checkboxes ───────────────────────────────────────────────────── */
QCheckBox {{ color: {TEXT}; spacing: 8px; padding: 2px 0; }}
QCheckBox::indicator {{
    width: 17px; height: 17px;
    border: 1.5px solid {TEXT_FAINT};
    border-radius: 4px;
    background: {SURFACE_2};
}}
QCheckBox::indicator:hover {{ border-color: {ACCENT}; background: {ACCENT_SOFT}; }}
QCheckBox::indicator:checked {{
    background: {ACCENT}; border-color: {ACCENT};
    image: url({_CHECK});
}}
QRadioButton {{ color: {TEXT}; spacing: 8px; }}
QRadioButton::indicator {{
    width: 17px; height: 17px; border-radius: 9px;
    border: 1.5px solid {TEXT_FAINT}; background: {SURFACE_2};
}}
QRadioButton::indicator:checked {{
    background: {ACCENT}; border: 5px solid {SURFACE_2};
}}

/* ── Group boxes = cards ──────────────────────────────────────────── */
QGroupBox {{
    font-weight: 600;
    background: {SURFACE};
    border: 1px solid {LINE};
    border-radius: 10px;
    margin-top: 16px;
    padding: 16px 14px 12px 14px;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px; top: 2px;
    padding: 3px 10px;
    color: {ACCENT_DEEP};
    background: {ACCENT_SOFT};
    border-radius: 6px;
    font-size: 12px;
}}

/* ── Tabs ─────────────────────────────────────────────────────────── */
QTabWidget::pane {{
    border: none; background: {BG}; top: -1px;
}}
QTabBar {{ qproperty-drawBase: 0; background: transparent; }}
QTabBar::tab {{
    min-width: 116px;
    padding: 9px 16px;
    margin: 4px 3px 6px 0;
    font-size: 12px;
    color: {TEXT_DIM};
    background: transparent;
    border: 1px solid transparent;
    border-radius: 7px;
}}
QTabBar::tab:hover {{ background: {ACCENT_SOFT}; color: {ACCENT_DEEP}; }}
QTabBar::tab:selected {{
    background: {ACCENT};
    color: {ON_ACCENT};
    border: 1px solid {ACCENT};
    font-weight: 600;
}}

/* ── Log / text areas ─────────────────────────────────────────────── */
QTextEdit, QPlainTextEdit {{
    border: 1px solid {LINE_STRONG};
    border-radius: 8px;
    background: {INPUT_BG};
    color: {LOG_TEXT};
    padding: 8px;
    selection-background-color: {ACCENT};
    selection-color: {ON_ACCENT};
}}

/* ── Progress ─────────────────────────────────────────────────────── */
QProgressBar {{
    border: none;
    border-radius: 3px;
    height: 6px;
    text-align: center;
    background: rgba(0,0,0,0.08);
    color: transparent;
}}
QProgressBar::chunk {{
    background: {ACCENT};
    border-radius: 3px;
}}

/* ── Scrollbars — thin, overlay-style ─────────────────────────────── */
QScrollBar:vertical {{
    width: 10px; background: transparent; margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: rgba(0,0,0,0.20);
    border-radius: 5px; min-height: 32px;
}}
QScrollBar::handle:vertical:hover {{ background: rgba(0,0,0,0.34); }}
QScrollBar:horizontal {{
    height: 10px; background: transparent; margin: 2px;
}}
QScrollBar::handle:horizontal {{
    background: rgba(0,0,0,0.20);
    border-radius: 5px; min-width: 32px;
}}
QScrollBar::handle:horizontal:hover {{ background: rgba(0,0,0,0.34); }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

/* ── Tables ───────────────────────────────────────────────────────── */
QTableWidget {{
    gridline-color: {LINE};
    background: {SURFACE};
    alternate-background-color: #F7F8FC;
    border: 1px solid {LINE};
    border-radius: 8px;
    color: {TEXT};
}}
QTableWidget::item {{ padding: 5px; border: none; }}
QTableWidget::item:selected {{ background: {ACCENT}; color: {ON_ACCENT}; }}
QHeaderView::section {{
    background: {ACCENT_SOFT};
    color: {ACCENT_DEEP};
    padding: 7px 5px;
    border: none;
    border-bottom: 1px solid {LINE_STRONG};
    font-weight: 600;
}}
QTableCornerButton::section {{ background: {ACCENT_SOFT}; border: none; }}

/* ── Misc ─────────────────────────────────────────────────────────── */
QToolButton {{
    background: {SURFACE_2};
    border: 1px solid {LINE_STRONG};
    border-radius: 6px;
    padding: 5px 9px;
    color: {TEXT};
}}
QToolButton:hover {{ background: {ACCENT_SOFT}; border-color: {ACCENT}; }}
/* QToolTip is a TOP-LEVEL window, not a child widget, and Qt resolves
   its text colour from the palette before the stylesheet gets a look in.
   The shorthand 'background' also does not reliably reach it. The result
   was a tooltip that took the dark background but kept dark palette text
   — invisible. Both halves are now spelled out explicitly here, and
   QToolTip.setPalette() is called as well (see _install_tooltip_palette),
   because on some platforms only the palette route works. */
QToolTip {{
    background-color: {TOOLTIP_BG};
    color: {TOOLTIP_FG};
    border: 1px solid {ACCENT};
    border-radius: 6px;
    padding: 6px 9px;
    opacity: 250;
}}
QLabel {{ background: transparent; }}
QMessageBox {{ background: {SURFACE}; }}
"""


def _install_tooltip_palette():
    """
    Force the tooltip colours through the PALETTE as well as the
    stylesheet.

    QToolTip is a top-level window. Qt resolves its foreground from
    QPalette.ToolTipText before any stylesheet 'color' is considered, so
    a stylesheet that sets only the background produces a tooltip with
    the new background and the OLD text colour. On a dark tooltip with
    dark inherited text that is invisible — which is exactly what was
    reported.

    Setting both roles here is belt and braces: whichever mechanism the
    platform honours, the pair is consistent.
    """
    try:
        from qgis.PyQt.QtWidgets import QToolTip
        from qgis.PyQt.QtGui import QPalette, QColor
        pal = QToolTip.palette()
        try:
            base_role = QPalette.ColorRole.ToolTipBase
            text_role = QPalette.ColorRole.ToolTipText
        except AttributeError:
            base_role = QPalette.ToolTipBase
            text_role = QPalette.ToolTipText
        pal.setColor(base_role, QColor(TOOLTIP_BG))
        pal.setColor(text_role, QColor(TOOLTIP_FG))
        QToolTip.setPalette(pal)
        return True
    except Exception:
        return False


# ── Themed callouts ───────────────────────────────────────────────────────
# The old code hand-wrote a pastel background on every note label
# (#E8F5E9, #FFF3E0, #E3F2FD …). Those were tuned for a light theme and
# turn into glare on a dark one, and being scattered inline they all had
# to be found and changed by hand. One helper, four intents.

# Edge colour, fill, and TEXT colour. Text is spelled out per intent
# rather than always TEXT_DIM: on a light tint the body of a callout can
# carry the semantic hue itself and still clear AA, which reads better
# than grey text next to a coloured bar.
_CALLOUT = {
    'info':    (ACCENT,  '#EEF0FA', '#2A3050'),
    'success': (SUCCESS, '#ECF5ED', '#14401A'),
    'warn':    (WARN,    '#FBF3E4', '#6B4100'),
    'muted':   (None,    'transparent', TEXT_DIM),
}


def _note_style(kind='info'):
    """Stylesheet for an inline explanatory label."""
    edge, fill, fg = _CALLOUT.get(kind, _CALLOUT['info'])
    if edge is None:
        return f'color:{fg};font-size:11px;background:transparent;'
    return (f'color:{fg};font-size:11px;background:{fill};'
            f'padding:8px 10px;border-radius:7px;'
            f'border-left:3px solid {edge};')


def _note(text, kind='info', rich=False):
    """A wrapped, themed explanatory label."""
    lbl = QLabel(text)
    lbl.setWordWrap(True)
    if rich:
        lbl.setTextFormat(_Qt_RichText)
    lbl.setStyleSheet(_note_style(kind))
    return lbl


# ── Helpers ───────────────────────────────────────────────────────────────

# hue -> (text/border, resting wash, hover wash)
_TINTED = {
    ACCENT2:   (ACCENT2, '#E4F0EE', '#D2E6E2'),
    SUCCESS:   (SUCCESS, '#ECF5ED', '#DBEBDD'),
    WARN:      (WARN,    '#FBF3E4', '#F4E6CB'),
    DANGER:    (DANGER,  '#FAEBEA', '#F3D7D5'),
    # Legacy call sites still pass these hex values directly.
    '#B71C1C': (DANGER,  '#FAEBEA', '#F3D7D5'),
    '#546E7A': (TEXT_DIM, 'rgba(0,0,0,0.05)', 'rgba(0,0,0,0.10)'),
}


def _sb(btn, color=ACCENT, tc=None, small=False):
    """
    Style a button.

    Two visual weights, as in Fluent: ACCENT gives a filled PRIMARY button
    (the one action that runs the tab), anything else gives a subtle
    surface button. The old version painted every button the same solid
    blue — Browse, Help, Close and Run all looked equally important, so
    none of them read as the primary action.

    The old hover/press states also appended 'CC'/'99' alpha suffixes to
    the colour, which silently produced an invalid colour string for any
    caller passing an rgba() or named colour, and Qt then dropped the
    whole rule. These are explicit colours instead.
    """
    pad = '6px 14px' if small else '9px 22px'
    primary = (color == ACCENT)

    if primary:
        fg = tc or ON_ACCENT
        btn.setStyleSheet(
            f'QPushButton{{background:{ACCENT};color:{fg};border:none;'
            f'border-radius:7px;padding:{pad};font-weight:600;}}'
            f'QPushButton:hover{{background:{ACCENT_DEEP};}}'
            f'QPushButton:pressed{{background:#283593;}}'
            f'QPushButton:disabled{{background:rgba(0,0,0,0.07);'
            f'color:{TEXT_FAINT};}}'
        )
    elif color in _TINTED:
        # Semantic buttons (destructive, confirm, secondary action) keep
        # their meaning but stay quieter than the primary: tinted text and
        # border over a translucent wash of the same hue, which is how
        # Fluent renders a semantic non-primary control on a dark surface.
        # A fully saturated fill here would read as a second primary.
        hue, wash, hover = _TINTED[color]
        fg = tc or hue
        btn.setStyleSheet(
            f'QPushButton{{background:{wash};color:{fg};'
            f'border:1px solid {hue};'
            f'border-radius:7px;padding:{pad};font-weight:600;}}'
            f'QPushButton:hover{{background:{hover};}}'
            f'QPushButton:pressed{{background:{wash};}}'
            f'QPushButton:disabled{{color:{TEXT_FAINT};'
            f'background:transparent;border-color:{LINE};}}'
        )
    else:
        fg = tc or TEXT
        btn.setStyleSheet(
            f'QPushButton{{background:{SURFACE_2};color:{fg};'
            f'border:1px solid {LINE_STRONG};'
            f'border-radius:7px;padding:{pad};font-weight:500;}}'
            f'QPushButton:hover{{background:{SURFACE_3};}}'
            f'QPushButton:pressed{{background:{SURFACE};}}'
            f'QPushButton:disabled{{color:{TEXT_FAINT};'
            f'border-color:{LINE};}}'
        )

def _grp(title, cls=QFormLayout):
    g = QGroupBox(title); l = cls(); g.setLayout(l); return g, l

def _lbl(t, bold=False, color=None):
    w = QLabel(t)
    if bold: f=w.font(); f.setBold(True); w.setFont(f)
    if color: w.setStyleSheet(f'color:{color};')
    return w

def _bf(le, par, cap='File', flt='All (*)'):
    p,_=QFileDialog.getOpenFileName(par, cap, '', flt)
    if p: le.setText(p)

def _bd(le, par, cap='Folder'):
    p=QFileDialog.getExistingDirectory(par, cap)
    if p: le.setText(p)

_RASTER_FILE_FILTER = (
    'Raster files (*.tif *.tiff *.img *.asc *.vrt);;'
    'GeoTIFF (*.tif *.tiff);;All files (*.*)'
)
_VECTOR_FILE_FILTER = (
    'Vector files (*.shp *.gpkg *.geojson *.json);;'
    'Shapefile (*.shp);;GeoPackage (*.gpkg);;All files (*.*)'
)


def _collect_config(tab):
    """
    Collect a tab's current settings by introspecting its own widgets.

    Deliberately generic rather than a hand-written per-tab field list:
    this plugin has 25+ inputs per flood tab and gains more over time, and
    a hardcoded list would silently go stale every time a field is added
    (saving a config that quietly omits the new setting is worse than not
    having the feature at all, because the user believes it was saved).

    Layer pickers store the LAYER NAME rather than the layer object, so a
    config saved in one QGIS session can be reapplied in another — the
    name is matched back against whatever layers are loaded at load time.
    """
    cfg = {}
    for name, w in vars(tab).items():
        if name.startswith('_') or w is None:
            continue
        try:
            if isinstance(w, _LC):
                lyr = w.currentLayer()
                cfg[name] = {'__type__': 'layer', 'value': lyr.name() if lyr else ''}
            elif isinstance(w, QComboBox):
                cfg[name] = {'__type__': 'combo', 'value': w.currentIndex()}
            elif isinstance(w, QCheckBox):
                cfg[name] = {'__type__': 'check', 'value': w.isChecked()}
            elif isinstance(w, (QDoubleSpinBox, QSpinBox)):
                cfg[name] = {'__type__': 'spin', 'value': w.value()}
            elif isinstance(w, QLineEdit):
                cfg[name] = {'__type__': 'text', 'value': w.text()}
            elif isinstance(w, QDateTimeEdit):
                cfg[name] = {'__type__': 'datetime',
                             'value': w.dateTime().toString('yyyy-MM-dd HH:mm:ss')}
        except Exception:
            continue
    return cfg


def _apply_config(tab, cfg):
    """
    Apply a saved config back onto a tab's widgets.

    Returns (n_applied, warnings). Each field is applied independently and
    failures are collected rather than raised, so one stale field (e.g. a
    layer that isn't loaded in this project, or a setting removed in a
    later plugin version) can't prevent the rest of the config loading.
    """
    applied, warnings_out = 0, []
    for name, entry in (cfg or {}).items():
        w = getattr(tab, name, None)
        if w is None or not isinstance(entry, dict):
            continue
        kind, val = entry.get('__type__'), entry.get('value')
        try:
            if kind == 'layer' and isinstance(w, _LC):
                if not val:
                    continue
                match = [l for l in QgsProject.instance().mapLayers().values()
                         if l.name() == val]
                if match:
                    w.c.setLayer(match[0])
                    applied += 1
                else:
                    warnings_out.append(
                        f"layer '{val}' (for {name}) is not loaded in this project")
            elif kind == 'combo' and isinstance(w, QComboBox):
                if 0 <= int(val) < w.count():
                    w.setCurrentIndex(int(val)); applied += 1
                else:
                    warnings_out.append(
                        f"{name}: saved option index {val} no longer exists "
                        f"(the option list has changed since this config was saved)")
            elif kind == 'check' and isinstance(w, QCheckBox):
                w.setChecked(bool(val)); applied += 1
            elif kind == 'spin' and isinstance(w, (QDoubleSpinBox, QSpinBox)):
                w.setValue(type(w.value())(val)); applied += 1
            elif kind == 'text' and isinstance(w, QLineEdit):
                w.setText(str(val)); applied += 1
            elif kind == 'datetime' and isinstance(w, QDateTimeEdit):
                dt = QDateTime.fromString(str(val), 'yyyy-MM-dd HH:mm:ss')
                if dt.isValid():
                    w.setDateTime(dt); applied += 1
        except Exception as e:
            warnings_out.append(f"{name}: {e}")
    return applied, warnings_out


def _save_config_dialog(tab, tab_name, parent):
    """Prompt for a path and write this tab's settings as JSON."""
    import json
    path, _ = QFileDialog.getSaveFileName(
        parent, f'Save {tab_name} Configuration', f'{tab_name.lower()}_config.json',
        'JSON files (*.json);;All files (*.*)')
    if not path:
        return
    if not path.lower().endswith('.json'):
        path += '.json'
    try:
        payload = {
            'rain2flood_config_version': 1,
            'tab': tab_name,
            'settings': _collect_config(tab),
        }
        with open(path, 'w') as f:
            json.dump(payload, f, indent=2)
        QMessageBox.information(parent, 'Saved',
                                f'Configuration saved:\n{path}')
    except Exception as e:
        QMessageBox.warning(parent, 'Save Failed', f'Could not save configuration:\n{e}')


def _load_config_dialog(tab, tab_name, parent):
    """Prompt for a JSON config and apply it to this tab."""
    import json
    path, _ = QFileDialog.getOpenFileName(
        parent, f'Load {tab_name} Configuration', '',
        'JSON files (*.json);;All files (*.*)')
    if not path:
        return
    try:
        with open(path) as f:
            payload = json.load(f)
        saved_tab = payload.get('tab')
        if saved_tab and saved_tab != tab_name:
            resp = QMessageBox.question(
                parent, 'Different Tab',
                f"This config was saved from the '{saved_tab}' tab, but you're "
                f"loading it into '{tab_name}'. Only matching fields will be "
                f"applied. Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if resp != QMessageBox.StandardButton.Yes:
                return
        applied, warns = _apply_config(tab, payload.get('settings', {}))
        msg = f'Applied {applied} setting(s) from:\n{path}'
        if warns:
            msg += ('\n\nNot applied:\n- ' + '\n- '.join(warns[:8]))
            if len(warns) > 8:
                msg += f'\n- ...and {len(warns)-8} more'
        QMessageBox.information(parent, 'Configuration Loaded', msg)
    except Exception as e:
        QMessageBox.warning(parent, 'Load Failed', f'Could not load configuration:\n{e}')


# ═══════════════════════════════════════════════════════════════════════════
#  Tooltips
# ═══════════════════════════════════════════════════════════════════════════
# Central tooltip registry keyed by widget attribute name, applied by
# introspection (see _apply_tooltips). Done this way rather than 90-odd
# inline setToolTip() calls so the help text lives in one reviewable
# place, stays consistent between the tabs that share widget names, and
# can't drift out of sync with the widgets themselves.
_TOOLTIPS = {
    # ── Catchment / terrain inputs ────────────────────────────────────
    'cat': 'Polygon layer defining the catchment boundary. Everything is '
           'clipped to this: DEM, CN, rainfall extraction and flood extent.',
    'dem': 'Digital Elevation Model raster. Drives slope, flow paths, '
           'sub-basins and flood depth. Use the finest reliable DEM you '
           'have — 30 m SRTM is workable for regional studies, finer LiDAR '
           'is much better for flood extent.',
    'slp': 'Optional pre-computed slope raster in PERCENT (from Tab 1). '
           'Leave empty to derive slope from the DEM automatically.',
    'fp': 'Optional line layer for the longest flow path. Leave empty and it '
          'is estimated from the DEM — supplying a real traced flow path '
          'gives a more reliable time of concentration.',
    'area': 'Catchment area used when "Manual Parameters" is selected '
            'instead of GIS layers.',
    'slope': 'Average catchment slope as a decimal (0.02 = 2%), used in '
             'Manual Parameters mode.',
    'method': 'GIS Layers derives area/slope/flow path from your rasters. '
              'Manual Parameters uses the numbers you type instead — useful '
              'when you already have surveyed catchment properties.',

    # ── Rainfall ──────────────────────────────────────────────────────
    'src': 'Where rainfall data comes from. Gridded reanalysis (ERA5, IMD) '
           'needs no files but can differ from local gauges, especially for '
           'short-duration extremes. Use Excel/CSV if you have real gauge data.',
    'lat': 'Latitude of the rainfall extraction point (decimal degrees). '
           'Use the map picker to set it by clicking the canvas.',
    'lon': 'Longitude of the rainfall extraction point (decimal degrees).',
    'xls': 'Excel or CSV file containing your own rainfall record.',
    'dcol': 'Name of the date/time column in your rainfall file.',
    'rcol': 'Name of the rainfall column (mm) in your rainfall file.',
    'chirps': 'CHIRPS satellite rainfall directory, if using that source.',
    'rps': 'Return periods to analyse, comma-separated (e.g. 10,25,50,100). '
           'These are the design events the whole analysis is run for.',
    'dur': 'Design storm duration. Shorter durations give higher intensities '
           'and suit small, fast-responding catchments; longer durations suit '
           'large catchments where the whole area contributes.',
    'freq': 'Probability distribution fitted to the annual maxima. '
            '"Auto (best fit by AIC)" tries Gumbel, Log-Pearson III, GEV and '
            'Log-Normal and picks the best fit for your record. Every option '
            'also reports 90% confidence intervals and runs trend/outlier checks.',

    # ── CN / LULC / roughness ─────────────────────────────────────────
    'cn': 'Curve Number raster (Tab 3). Controls how much rainfall becomes '
          'runoff — the single most influential input in most analyses.',
    'cn_v': 'Manual Curve Number (30-98) if you have no CN raster. Higher = '
            'more runoff. ~70 for mixed agricultural, ~90 for urban.',
    'mann': "Manning's n raster (Tab 3) for spatially-varying surface roughness.",
    'mn_v': "Manual Manning's n. ~0.03 clean channels, ~0.05 natural streams, "
            "~0.1+ heavy vegetation/floodplain.",
    'c_v': 'Rational Method runoff coefficient C (0-1). Fraction of rainfall '
           'that becomes direct runoff.',
    'amc': 'Antecedent Moisture Condition. I = dry, II = average (normal '
           'design assumption), III = saturated. AMC III gives noticeably '
           'higher runoff for the same rainfall.',
    'hsg': 'Hydrologic Soil Group raster (A = sandy/fast-draining through '
           'D = clay/slow-draining).',
    'lulc': 'Land use / land cover raster used to derive CN and roughness.',
    'ltype': 'Which LULC classification scheme your raster uses — this '
             'selects the correct class-to-CN lookup table.',
    'use': 'Use an external gridded storm-depth raster instead of the point '
           'rainfall source above.',
    'rast': 'Storm-depth raster in mm (e.g. a CHIRPS/ERA5 event total).',

    # ── Analysis options ──────────────────────────────────────────────
    'rout': 'Enable Muskingum-Cunge channel routing, which attenuates and '
            'delays the hydrograph as it travels downstream.',
    'mk': 'Muskingum K — approximate travel time through the reach (hours).',
    'mx': 'Muskingum X — weighting factor, 0 to 0.5. 0 = pure reservoir '
          'storage, 0.5 = pure translation. Around 0.2 is typical for rivers.',
    'reg': 'Regional flood estimation standard applied alongside the main '
           'method, for comparison against local practice.',
    'dst': 'Temporal pattern used to distribute the total design rainfall '
           'over the storm duration.',
    'saar': 'Standard Average Annual Rainfall (mm) — required by the UK FEH method.',
    'sc': 'HOST soil class 1-5 for FEH. 1 = permeable/high baseflow, '
          '5 = impermeable/flashy.',
    'ux': 'URBEXT urban extent index for FEH (0 = rural). Above 0.025, FEH '
          'expects a separate urban adjustment this tool does not apply.',
    'c10': 'ARR/NZ 10-year runoff coefficient for the regional method.',
    'ia': 'Rainfall intensity parameter a (regional IDF form).',
    'ib': 'Rainfall intensity parameter b (regional IDF form).',
    'ic': 'Rainfall intensity parameter c (regional IDF form).',

    # ── Advanced / optional features ──────────────────────────────────
    'use2d': 'Route the hydrograph through 2D diffusive-wave physics rather '
             'than a single static water level. More realistic, considerably '
             'slower; the DEM is auto-coarsened to keep runtime sane.',
    'obs_hyd': 'CSV of a REAL observed flood hydrograph to check the model '
               'against (columns: Time_hr, Discharge_m3s). Without this, the '
               'CN/roughness/method choices are unvalidated estimates.',
    'cwc_co': "CWC subzone regression coefficients, e.g. Ct=0.53,m=0.31. Each "
              "of India's 26 subzones has its own published values — leave "
              "blank and clearly-flagged placeholders are used instead.",
    'run_sens': 'Vary CN, roughness, rainfall and flow path by ±20% and report '
                'how much peak discharge moves. Shows which input is worth '
                'refining and demonstrates robustness in a report.',
    'batch_on': 'Run the analysis once per polygon in the catchment layer, '
                'each into its own output folder, plus an aggregate summary.',
    'batch_field': 'Attribute field used to name each batch output folder. '
                   'Leave blank to auto-detect a Name/ID field.',

    # ── Output ────────────────────────────────────────────────────────
    'out': 'Folder where all results are written: spreadsheets, maps, '
           'hydrographs, rasters and the HTML report.',
    'gm': 'Produce flood inundation maps (extent, depth, velocity and '
          'depth-velocity hazard classification).',
    'lr': 'Automatically load the output rasters into the QGIS Layers panel '
          'with appropriate styling.',
    'eh': 'Export files formatted for import into HEC-HMS.',
    'graphs': 'Generate charts alongside the numerical outputs.',
    'load_c': 'Load the generated layers into QGIS when finished.',

    # ── DEM & Slope / delineation tab ─────────────────────────────────
    'slope_unit': 'Report slope as percent or degrees. Percent is what the '
                  'hydrology methods here expect.',
    'ext_dl': 'Area to fetch land cover for and derive CN / Manning\'s rasters over. A catchment polygon is not needed here.',
    'lulc_dl': 'Existing LULC raster to derive CN and roughness from.',
    'ltype_dl': 'Classification scheme of the LULC raster above.',
    'hsg_dl': 'Hydrologic Soil Group raster, if available.',
    'amc_dl': 'Antecedent Moisture Condition applied when generating the CN raster.',
    'der_out': 'Output folder for the derived CN and roughness rasters.',
    'esa_out': 'Output folder for the downloaded ESA WorldCover tiles.',
    'man_cn': 'Uniform Curve Number to write across the whole catchment.',
    'man_mn': "Uniform Manning's n to write across the whole catchment.",
    'man_res': 'Pixel size (m) of the generated uniform rasters.',
    'man_out': 'Output folder for the manually-generated rasters.',
}


def _apply_tooltips(tab):
    """
    Apply _TOOLTIPS to a tab's widgets by attribute name, including
    widgets held inside the dict-based groups (_cat_grp, _cn_grp,
    _spatial_rain_grp) that several tabs share.

    Never overwrites a tooltip that was set explicitly at the widget —
    those are usually more specific to that tab's context than the
    generic entry here.
    """
    def _set(name, w):
        text = _TOOLTIPS.get(name)
        if not text or not hasattr(w, 'setToolTip'):
            return
        try:
            if w.toolTip():
                return
            w.setToolTip(text)
        except Exception:
            pass

    for attr, w in list(vars(tab).items()):
        if attr.startswith('__') or w is None:
            continue
        if isinstance(w, dict):
            for k, sub in w.items():
                _set(k, sub)
        else:
            _set(attr, w)


class _LC(QWidget):
    def __init__(self, filt=None, opt=True, parent=None):
        super().__init__(parent)
        l=QHBoxLayout(self); l.setContentsMargins(0,0,0,0)
        self.c=QgsMapLayerComboBox()
        if opt: self.c.setAllowEmptyLayer(True)
        if filt is not None: self.c.setFilters(filt)
        self._is_raster = (filt == QgsMapLayerProxyModel.RasterLayer)
        b = QToolButton()
        b.setText('...')
        b.setToolTip(
            'Browse for a file not yet loaded in QGIS — it will be added '
            'to the project and selected here.'
        )
        b.clicked.connect(self._browse)
        l.addWidget(self.c); l.addWidget(b)

    def _browse(self):
        if self._is_raster:
            path, _ = QFileDialog.getOpenFileName(
                self, 'Select Raster File', '', _RASTER_FILE_FILTER)
        else:
            path, _ = QFileDialog.getOpenFileName(
                self, 'Select Vector File', '', _VECTOR_FILE_FILTER)
        if not path:
            return
        name = os.path.splitext(os.path.basename(path))[0]
        lyr = QgsRasterLayer(path, name) if self._is_raster else QgsVectorLayer(path, name, 'ogr')
        if not lyr.isValid():
            QMessageBox.warning(
                self, 'Invalid File',
                f'Could not load this file as a {"raster" if self._is_raster else "vector"} layer:\n{path}'
            )
            return
        QgsProject.instance().addMapLayer(lyr)
        self.c.setLayer(lyr)

    def setAutoItem(self, text):
        """
        Add a non-layer entry to the top of the combo — e.g.
        'Auto — delineate upstream of pour point'.

        QgsMapLayerComboBox supports this natively via setAdditionalItems;
        when one is selected currentLayer() returns None, so callers must
        test isAuto() BEFORE falling back to 'nothing selected'. Without
        that distinction an auto entry is indistinguishable from an empty
        combo and the option silently does nothing.
        """
        self._auto_text = text
        try:
            self.c.setAdditionalItems([text])
        except Exception:
            self._auto_text = None

    def isAuto(self):
        t = getattr(self, '_auto_text', None)
        if not t:
            return False
        return self.c.currentLayer() is None and self.c.currentText() == t

    def selectAuto(self):
        t = getattr(self, '_auto_text', None)
        if not t:
            return False
        i = self.c.findText(t)
        if i >= 0:
            self.c.setCurrentIndex(i)
            return True
        return False

    def currentLayer(self): return self.c.currentLayer()
    def source(self): lyr=self.c.currentLayer(); return lyr.source() if lyr else ''

class _FB(QgsProcessingFeedback):
    def __init__(self, log, pb=None):
        super().__init__(); self._l=log; self._p=pb
    def pushInfo(self, m):
        # Section headers ('=== C. Rainfall Data ===') carry the accent so
        # a long run is scannable; the body stays near-black for reading.
        txt = str(m)
        if txt.strip().startswith('==='):
            self._l.append(
                f'<b style="color:{LOG_HEAD}">{txt}</b>')
        elif txt.startswith('  '):
            self._l.append(f'<span style="color:{LOG_DIM}">{txt}</span>')
        else:
            self._l.append(f'<span style="color:{LOG_TEXT}">{txt}</span>')
        QApplication.processEvents()
    def pushWarning(self, m):
        self._l.append(
            f'<span style="color:{LOG_WARN}"><b>Warning:</b> {m}</span>')
        QApplication.processEvents()
    def reportError(self, m, f=False):
        self._l.append(
            f'<span style="color:{LOG_ERROR}"><b>Error:</b> {m}</span>')
        QApplication.processEvents()
    def setProgress(self, v):
        if self._p: self._p.setValue(int(v))
        QApplication.processEvents()

class _ThreadFeedback(QgsProcessingFeedback):
    """QgsProcessingFeedback that emits Qt signals instead of touching
    widgets directly, so it is safe to use from a background QThread."""
    def __init__(self, worker):
        super().__init__()
        self._w = worker
    def pushInfo(self, m):
        self._w.logMsg.emit(str(m))
    def pushWarning(self, m):
        self._w.warnMsg.emit(str(m))
    def reportError(self, m, fatalError=False):
        self._w.errorMsg.emit(str(m))
    def setProgress(self, v):
        self._w.progressChanged.emit(int(v))


class _CallableWorker(QThread):
    """
    Runs an arbitrary function (with a thread-safe feedback object injected
    as the 'feedback' kwarg) on a background thread, so any tool that does
    blocking network I/O or CPU-heavy work doesn't freeze the QGIS UI while
    it runs. The log and progress bar are updated via the signals below
    instead of direct widget access from the worker thread. Not currently
    wired into any tab (the feature that motivated it, Spatial Rainfall,
    has been removed) — kept available for any future tab that needs it.
    """
    logMsg          = pyqtSignal(str)
    warnMsg         = pyqtSignal(str)
    errorMsg        = pyqtSignal(str)
    progressChanged = pyqtSignal(int)
    finishedOk      = pyqtSignal(dict)
    failed          = pyqtSignal(str, str)

    def __init__(self, func, kwargs):
        super().__init__()
        self._func   = func
        self._kwargs = kwargs

    def run(self):
        fb = _ThreadFeedback(self)
        try:
            result = self._func(feedback=fb, **self._kwargs)
            self.finishedOk.emit(result if isinstance(result, dict) else {})
        except Exception as e:
            import traceback
            self.failed.emit(str(e), traceback.format_exc())


def _scroll(w):
    s = QScrollArea()
    s.setWidgetResizable(True)
    s.setWidget(w)
    s.setFrameShape(_QFrame_NoFrame)
    # The viewport is a separate widget from the scroll area and does not
    # inherit its background from the stylesheet rule on QScrollArea, so
    # without this the tab content sits on Qt's default grey while
    # everything around it is dark.
    s.setStyleSheet(f'QScrollArea{{background:{BG};border:none;}}')
    try:
        s.viewport().setStyleSheet(f'background:{BG};')
    except Exception:
        pass
    return s

def _coord_row(iface, lat_e, lon_e):
    w=QWidget(); l=QHBoxLayout(w); l.setContentsMargins(0,0,0,0); l.setSpacing(4)
    l.addWidget(lat_e); l.addWidget(QLabel(',')); l.addWidget(lon_e)
    if iface:
        btn=PointPickerButton(iface, lat_e, lon_e)
        btn.setText('Pick from Map'); btn.setMinimumWidth(130)
        l.addWidget(btn)
    return w


# ── Shared group builders ─────────────────────────────────────────────────

def _cat_grp():
    g,f=_grp('Catchment Parameters'); r={}
    r['method']=QComboBox()
    r['method'].addItems(['GIS Layers','Manual Parameters',
                          'Pour Point + DEM (auto-delineate)'])
    r['method'].setToolTip(
        'Pour Point + DEM delineates the upstream catchment from the pour '
        'point set at the top of this tab, so no catchment polygon is '
        'needed. The point is snapped to the modelled stream network first. '
        'Area and the longest flow path both come from the traced D8 path.')
    r['cat']=_LC(QgsMapLayerProxyModel.PolygonLayer)
    r['cat'].setAutoItem('Auto — delineate upstream of pour point')
    r['dem']=_LC(QgsMapLayerProxyModel.RasterLayer)
    r['slp']=_LC(QgsMapLayerProxyModel.RasterLayer)
    r['fp']=_LC(QgsMapLayerProxyModel.LineLayer)
    r['fp'].setAutoItem('Auto — trace longest flow path from pour point')
    r['area']=QDoubleSpinBox(); r['area'].setRange(0.01,1e6); r['area'].setValue(10); r['area'].setSuffix(' km2')
    r['slope']=QDoubleSpinBox(); r['slope'].setRange(0.0001,1); r['slope'].setValue(0.02); r['slope'].setDecimals(4)
    r['snap']=QSpinBox(); r['snap'].setRange(0,200); r['snap'].setValue(10)
    r['snap'].setSuffix(' cells')
    r['snap'].setToolTip(
        'How far to search for the stream network when snapping the pour '
        'point. If nothing is found the search widens automatically (to 2x, '
        '3x, 5x) and reports how far it had to go. A point that moves a long '
        'way has probably landed on a different river than the one intended.')
    f.addRow('Input method:',r['method']); f.addRow('Catchment layer:',r['cat'])
    f.addRow('DEM layer:',r['dem']); f.addRow('Slope raster (%):',r['slp'])
    f.addRow('Flow path line:',r['fp']); f.addRow('Manual area:',r['area'])
    f.addRow('Manual slope (dec):',r['slope'])
    f.addRow('Snap radius:',r['snap'])
    cat_note=QLabel(
        'With <b>Pour Point + DEM</b> you only need the DEM layer — the '
        'catchment polygon and flow path line are delineated for you and '
        'loaded into QGIS as <b>Upstream Catchment</b> (hollow boundary) and '
        '<b>Longest Flow Path</b>. Any flow path line supplied above still '
        'takes precedence if you have a surveyed one.')
    cat_note.setWordWrap(True); cat_note.setTextFormat(_Qt_RichText)
    cat_note.setStyleSheet(_note_style('success'))
    f.addRow(cat_note)

    # Keep the method combo and the two 'Auto' entries in sync in both
    # directions, so the panel can never show a contradictory state (method
    # 'Manual Parameters' while the catchment dropdown reads 'Auto').
    def _method_changed(idx):
        if idx == 2:
            r['cat'].selectAuto()
            r['fp'].selectAuto()
    r['method'].currentIndexChanged.connect(_method_changed)

    def _auto_picked():
        if (r['cat'].isAuto() or r['fp'].isAuto()) and r['method'].currentIndex() != 2:
            r['method'].setCurrentIndex(2)
    r['cat'].c.currentIndexChanged.connect(lambda _i: _auto_picked())
    r['fp'].c.currentIndexChanged.connect(lambda _i: _auto_picked())

    return g, r

def _cat_method_index(c):
    """
    Which catchment input method to send.

    Selecting either 'Auto' entry — in the catchment dropdown or the flow
    path dropdown — implies the pour-point method (index 2), regardless of
    what the 'Input method' combo says. Making the user set both the combo
    AND the dropdown would be a trap: picking 'Auto' and leaving the combo
    on 'GIS Layers' would send an empty catchment path and the run would
    fail with a confusing error about a missing boundary.
    """
    if c['cat'].isAuto() or c['fp'].isAuto():
        return 2
    return c['method'].currentIndex()


def _cat_source(w):
    """Empty string for an 'Auto' selection — there is no layer to send."""
    return '' if w.isAuto() else w.source()


def _cn_grp(alg):
    g,f=_grp("CN / LULC / Manning's  (generate in Tab 3 CN/LULC)"); r={}
    r['src']=QComboBox(); r['src'].addItems(alg.CN_SOURCES)
    r['cn']=_LC(QgsMapLayerProxyModel.RasterLayer)
    r['lulc']=_LC(QgsMapLayerProxyModel.RasterLayer)
    r['ltype']=QComboBox(); r['ltype'].addItems(alg.LULC_TYPES)
    r['mann']=_LC(QgsMapLayerProxyModel.RasterLayer)
    r['hsg']=QComboBox(); r['hsg'].addItems(['A','B','C','D']); r['hsg'].setCurrentIndex(1)
    r['cn_v']=QDoubleSpinBox(); r['cn_v'].setRange(1,100); r['cn_v'].setValue(75)
    r['c_v']=QDoubleSpinBox(); r['c_v'].setRange(0.01,1); r['c_v'].setValue(0.60); r['c_v'].setDecimals(2)
    r['mn_v']=QDoubleSpinBox(); r['mn_v'].setRange(0.005,0.5); r['mn_v'].setValue(0.035); r['mn_v'].setDecimals(4)
    f.addRow('CN source:',r['src']); f.addRow('CN raster:',r['cn'])
    f.addRow('LULC raster:',r['lulc']); f.addRow('LULC type:',r['ltype'])
    f.addRow("Manning's n raster:",r['mann']); f.addRow('HSG:',r['hsg'])
    f.addRow('CN (manual):',r['cn_v']); f.addRow('C (rational):',r['c_v'])
    f.addRow("Manning's n (manual):",r['mn_v'])
    return g, r

def _spatial_rain_grp():
    g,f=_grp('External Gridded Rainfall Raster (optional)'); r={}
    r['use']=QCheckBox('Use a storm-depth raster instead of the point source above')
    r['rast']=_LC(QgsMapLayerProxyModel.RasterLayer)
    note=QLabel('Load any storm-depth raster (mm) from an external source '
                '(e.g. CHIRPS/ERA5 export, interpolated gauge data).\n'
                'The catchment-weighted mean depth is used across all return periods.')
    note.setWordWrap(True)
    note.setStyleSheet(_note_style('warn'))
    f.addRow('',r['use']); f.addRow('Rainfall raster:',r['rast']); f.addRow(note)
    return g, r

def _run_batch_alg(alg_cls, params, catchment_layer, output_dir, name_field, log, pb):
    """
    Run an algorithm once per polygon in catchment_layer via
    batch_processing.run_batch, bridging its feedback into this tab's
    log widget.
    """
    try:
        from .batch_processing import run_batch
    except ImportError:
        from batch_processing import run_batch
    from qgis.core import QgsProcessingContext

    fb = _FB(log, pb)
    ctx = QgsProcessingContext()
    summary, failures = run_batch(
        alg_cls, params, catchment_layer, output_dir,
        name_field=name_field, feedback=fb, context=ctx)
    if failures:
        log.append(
            f'<span style="color:{WARN}">{len(failures)} catchment(s) failed — '
            f'see batch_summary.csv for which ones and why.</span>')
    return summary


def _run_alg(alg_cls, params, log, pb, on_done=None):
    fb=_FB(log,pb); alg=alg_cls(); alg.initAlgorithm()
    ctx=QgsProcessingContext(); ctx.setProject(QgsProject.instance())
    alg.processAlgorithm(params, ctx, fb)
    if on_done: on_done(fb)


# ═══════════════════════════════════════════════════════════════════════════
#  Main Dialog
# ═══════════════════════════════════════════════════════════════════════════

class Rain2FloodDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowFlags(_Qt_Window | _Qt_WinMin | _Qt_WinMax | _Qt_WinClose)
        self.setWindowTitle(f'Rain2Flood v{PLUGIN_VERSION}')
        avail = QApplication.primaryScreen().availableGeometry()
        w, h  = int(avail.width()*0.90), int(avail.height()*0.90)
        self.resize(w, h)
        self.move(avail.left()+(avail.width()-w)//2, avail.top()+(avail.height()-h)//2)
        self.setMinimumSize(900, 680)
        self.setStyleSheet(GLOBAL_STYLE)
        _install_tooltip_palette()

        # Real window translucency, off by default — see the THEME notes.
        # Guarded because WA_TranslucentBackground is unreliable inside
        # QGIS: without a running compositor it renders the dialog black
        # rather than translucent, which is unrecoverable from the UI.
        if TRANSLUCENT:
            try:
                self.setAttribute(_Qt_Translucent, True)
                self.setStyleSheet(
                    GLOBAL_STYLE
                    + f'\nQDialog {{ background: rgba(255,255,255,0.90);'
                      f' border: 1px solid {LINE_STRONG}; border-radius: 10px; }}')
            except Exception:
                pass

        missing = DependencyManager.check_dependencies()
        if missing:
            DependencyManager.show_install_dialog(self)

        root = QVBoxLayout(self); root.setSpacing(0); root.setContentsMargins(0,0,0,0)

        # ── Header ────────────────────────────────────────────────────
        # A quiet surface strip with an accent rule underneath, rather
        # than a solid accent slab. A full-width block of saturated blue
        # is the loudest thing on screen and competes with the accent
        # used for focus and the primary action; the hairline gives the
        # same brand cue without taking attention.
        hdr = QFrame()
        hdr.setStyleSheet(
            f'QFrame{{background:{ACCENT_SOFT};border:none;'
            f'border-bottom:2px solid {ACCENT};}}')
        hl = QHBoxLayout(hdr); hl.setContentsMargins(20, 12, 20, 12); hl.setSpacing(12)

        mark = QLabel('R2F')
        mark.setAlignment(_Qt_AlignCenter)
        mark.setFixedSize(34, 34)
        mark.setStyleSheet(
            f'background:qlineargradient(x1:0,y1:0,x2:1,y2:1,'
            f'stop:0 {ACCENT}, stop:1 {ACCENT_DEEP});'
            f'color:{ON_ACCENT};border-radius:9px;'
            f'font-size:12px;font-weight:700;')

        t1 = QLabel('Rain2Flood')
        t1.setStyleSheet(f'color:{TEXT};font-size:17px;font-weight:600;')
        ver = QLabel(f'v{PLUGIN_VERSION}')
        ver.setStyleSheet(
            f'color:{ACCENT_DEEP};font-size:10px;font-weight:600;'
            f'background:{ACCENT_SOFT};'
            f'padding:3px 8px;border-radius:9px;')
        t2 = QLabel('Hydrological Analysis & Flood Mapping Toolkit')
        t2.setStyleSheet(f'color:{TEXT_FAINT};font-size:11px;')

        hl.addWidget(mark); hl.addWidget(t1); hl.addWidget(ver)
        hl.addSpacing(6); hl.addWidget(t2); hl.addStretch()

        # Credit, with working links. setOpenExternalLinks is what makes
        # them actually open a browser — without it a rich-text <a> in a
        # QLabel is just blue underlined text that does nothing when
        # clicked, which is worse than no link at all.
        credit = QLabel(
            f'cooked by <a href="{LINKEDIN_URL}" '
            f'style="color:{ACCENT};text-decoration:none">'
            f'<b>Rahul Pandey</b></a>'
            f' &nbsp;·&nbsp; '
            f'<a href="{GITHUB_URL}" '
            f'style="color:{ACCENT};text-decoration:none">GitHub</a>')
        credit.setTextFormat(_Qt_RichText)
        credit.setOpenExternalLinks(True)
        credit.setToolTip('Open LinkedIn profile or the plugin repository')
        credit.setStyleSheet(f'color:{TEXT_DIM};font-size:11px;')
        hl.addWidget(credit)
        root.addWidget(hdr)

        # Tabs  (workflow order, no emojis)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs)
        # Tab order follows the actual data dependency chain: reproject
        # the DEM, delineate streams from it, build CN rasters, then run
        # either flood analysis. Rainfall is deliberately NOT numbered —
        # it is a standalone utility, not step 6 of 6. The flood tabs
        # fetch their own rainfall when they run (Open-Meteo, IMD, etc.),
        # so nobody needs to visit this tab before running an analysis;
        # it exists for downloading a series to inspect, archive, or feed
        # back in as an Excel/CSV input. Numbering it implied a sequence
        # step that does not exist.
        self.tabs.addTab(_scroll(DemSlopeTab(iface,self)),           '1. DEM && Slope')
        self.tabs.addTab(_scroll(StreamsSubBasinsTab(iface,self)),   '2. Streams && Sub-basins')
        self.tabs.addTab(_scroll(CNLULCTab(iface,self)),             '3. CN / LULC')
        self.tabs.addTab(_scroll(FlashFloodTab(iface,self)),         '4. Flash Flood')
        self.tabs.addTab(_scroll(StandardFloodTab(iface,self)),      '5. Standard Flood')
        self.tabs.addTab(_scroll(RainfallDownloadTab(iface,self)),   'Rainfall Data (utility)')
        self.tabs.addTab(_scroll(AboutTab(self)),                    'About')

        # Footer
        ftr = QFrame()
        ftr.setStyleSheet(
            f'QFrame{{background:{ACCENT_SOFT};border:none;'
            f'border-top:1px solid {ACCENT};}}')
        fl  = QHBoxLayout(ftr); fl.setContentsMargins(20,9,20,9); fl.setSpacing(10)
        # Workflow line matches the actual tab order — the old one still
        # listed Rainfall and Spatial as pipeline steps.
        crumb = QLabel('DEM & Slope  ›  Streams & Sub-basins  ›  CN / LULC  ›  '
                       'Flash Flood  ·  Standard Flood')
        crumb.setStyleSheet(f'color:{TEXT_FAINT};font-size:11px;')
        fl.addWidget(crumb)
        fl.addStretch()
        bh=QPushButton('Help');  _sb(bh,SURFACE_2,small=True)
        bc=QPushButton('Close'); _sb(bc,SURFACE_2,small=True)
        bh.clicked.connect(self._help); bc.clicked.connect(self.close)
        fl.addWidget(bh); fl.addWidget(bc)
        root.addWidget(ftr)

    def _help(self):
        QMessageBox.information(self,'Rain2Flood – Help',(
            'Workflow (follow tab order):\n'
            '1  DEM & Slope          – reproject terrain to a projected CRS, derive slope\n'
            '2  Streams & Sub-basins – delineate sub-catchments + stream network (GRASS)\n'
            '3  CN / LULC            – download or generate CN and Manning\'s n rasters\n'
            '4  Flash Flood          – SCS, NRCS-DUH, Snyder, Clark, Rational, Wadi\n'
            '5  Standard Flood       – FEH, ARR2019, Canada, NZ, Wadi regional methods\n\n'
            'Rainfall Data (utility)  – NOT a pipeline step. The flood tabs fetch\n'
            '  their own rainfall when they run, so you do not need to visit this\n'
            '  tab first. Use it to download a series to inspect or archive, or to\n'
            '  produce an Excel/CSV you can feed back in as a rainfall input.\n\n'
            'Pour point (Tabs 4/5):\n'
            '  Set a pour point and the upstream catchment is delineated from the\n'
            '  DEM for that point, so you do not need to supply a catchment\n'
            '  polygon. The point is SNAPPED to the modelled stream network first\n'
            '  (a point a cell or two off the channel otherwise delineates a\n'
            '  hillslope, not a basin). Outputs loaded into QGIS:\n'
            '  upstream_catchment.gpkg   hollow boundary, Area_km2/FlowPath_m/S1085\n'
            '  longest_flow_path.gpkg    traced D8 path, Length_m\n'
            '  pour_point_snapped.gpkg   where the point actually ended up\n'
            '  Check how far the point moved — a large jump means it landed on a\n'
            '  different river than the one you clicked.\n\n'
            'Tab 2 Streams & Sub-basins:\n'
            '  Run after Tab 1. Outputs:\n'
            '  sub_basins.gpkg  Name (S1..SN), Area_km2\n'
            '  streams.gpkg     StreamID, Order (Strahler), Length_km,\n'
            '                   UpstreamArea_km2, AvgSlope_pct\n'
            '  Reduce stream threshold for denser network.\n'
            '  Set minimum basin area to merge tiny slivers.\n'
            '  Uses GRASS (r.watershed/r.to.vect) via QGIS Processing — enable\n'
            '  the "Processing GRASS Provider" plugin if this tab errors out.\n\n'
            'External rainfall raster -> Flood (Tabs 5/6):\n'
            '  If you already have a storm-depth raster from elsewhere (CHIRPS,\n'
            '  ERA5 export, interpolated gauge data), tick "Use a storm-depth\n'
            '  raster" and point it there instead of using the point source.\n\n'
            '2D diffusive-wave routing (optional, Tabs 5/6):\n'
            '  Routes the actual computed hydrograph (rise/peak/recession) over\n'
            '  simulated time using Manning\'s equation on the local water-surface\n'
            '  gradient, instead of one static water level — more realistic, much\n'
            '  slower. The DEM is auto-coarsened for tractable runtime; still a\n'
            '  simplified diffusive-wave scheme (no inertial terms), and the\n'
            '  hydrograph is injected at one representative upstream point, not\n'
            '  routed through the actual channel network sub-basin by sub-basin.\n'
            '  For real design/regulatory work, use a proper 2D hydraulic model\n'
            '  (HEC-RAS 2D, TUFLOW, InfoWorks ICM, etc.).\n\n'
            'Required packages:\n'
            '  pip install numpy pandas scipy matplotlib openpyxl rasterio\n'
            '              geopandas shapely xarray --break-system-packages'
        ))

# ═══════════════════════════════════════════════════════════════════════════
#  Tab 1 – DEM & Slope
# ═══════════════════════════════════════════════════════════════════════════

class DemSlopeTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface=iface
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(10)

        g,f=_grp('Input Layers')
        self.dem=_LC(QgsMapLayerProxyModel.RasterLayer)
        # _LC already offers an empty entry (opt=True by default), so the
        # user can simply leave this unset.
        self.cat=_LC(QgsMapLayerProxyModel.PolygonLayer)
        f.addRow('DEM Raster:',self.dem)
        f.addRow('Catchment Boundary:',self.cat)
        cat_hint = QLabel(
            'Optional. Leave empty to reproject the whole DEM — that is what '
            'Tab 2 and the pour-point workflow in Tabs 4/5 want, because flow '
            'accumulation on a clipped raster truncates upstream area at the '
            'clip edge. Supply one only if you already have a boundary and '
            'want the output trimmed to it.')
        cat_hint.setWordWrap(True)
        cat_hint.setStyleSheet(_note_style('muted'))
        f.addRow('', cat_hint)
        root.addWidget(g)

        g2,f2=_grp('Settings')
        self.crs=QgsProjectionSelectionWidget()
        self.crs.setCrs(QgsCoordinateReferenceSystem('EPSG:32643'))
        self.slope_unit=QComboBox(); self.slope_unit.addItems(['Percent','Degrees'])
        self.load_c=QCheckBox('Load outputs in QGIS'); self.load_c.setChecked(True)
        f2.addRow('Target CRS:',self.crs)
        f2.addRow('Slope output unit:',self.slope_unit)
        f2.addRow('',self.load_c)
        root.addWidget(g2)

        note = QLabel(
            'Slope is computed on the reprojected DEM <b>before</b> any clip, '
            'so boundary cells keep real neighbours in Horn\'s method. '
            'Streams and sub-basins are not generated here — run '
            '<b>Tab 2 (Streams &amp; Sub-basins)</b> for that, using the '
            'reprojected DEM from this tab.'
        )
        note.setWordWrap(True); note.setTextFormat(_Qt_RichText)
        note.setStyleSheet(_note_style('info'))
        root.addWidget(note)

        g3,f3=_grp('Output')
        self.out=QLineEdit()
        b=QPushButton('Browse'); _sb(b,ACCENT2,small=True)
        b.clicked.connect(lambda: _bd(self.out,self))
        r=QHBoxLayout(); r.addWidget(self.out); r.addWidget(b)
        f3.addRow('Output folder:',r); root.addWidget(g3)

        gL,vl=_grp('Log',QVBoxLayout)
        self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setFixedHeight(140)
        self.pb=QProgressBar()
        vl.addWidget(self.log); vl.addWidget(self.pb); root.addWidget(gL)

        run=QPushButton('Run DEM and Slope Processing')
        _sb(run,ACCENT); run.clicked.connect(self._run)
        root.addWidget(run); root.addStretch()

        _apply_tooltips(self)

    def _run(self):
        self.log.clear()
        if not self.dem.currentLayer() or not self.out.text().strip():
            QMessageBox.warning(self,'Missing','Select a DEM and an output folder.'); return
        try:
            _run_alg(DemSlopeProcessing,{
                'DEM':self.dem.source(),
                'CATCHMENT':(self.cat.source() if self.cat.currentLayer() else None),
                'TARGET_CRS':self.crs.crs().authid(),
                'SLOPE_UNIT':self.slope_unit.currentIndex(),
                'LOAD_IN_QGIS':self.load_c.isChecked(),
                'OUTPUT_FOLDER':self.out.text().strip(),
            }, self.log, self.pb)
            self.log.append(f'<b style="color:{SUCCESS}">Done.</b>')
        except Exception as e:
            import traceback
            self.log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')



# ═══════════════════════════════════════════════════════════════════════════
#  Tab 2 – Streams & Sub-basins
# ═══════════════════════════════════════════════════════════════════════════

class StreamsSubBasinsTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface = iface
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18); root.setSpacing(10)

        # Info banner
        info = QLabel(
            'Delineates sub-catchment polygons and a stream network directly from '
            'the DEM. Run <b>Tab 1 (DEM &amp; Slope)</b> first. '
            'A catchment boundary is <b>not required</b> — leave it empty to '
            'delineate the whole DEM. '
            '<br>Outputs: <b>sub_basins.gpkg</b> (Name: S1 S2 …, Area_km2) and '
            '<b>streams.gpkg</b> (StreamID, Strahler Order, Length_km, '
            'UpstreamArea_km2, AvgSlope_pct).'
        )
        info.setWordWrap(True)
        info.setTextFormat(_Qt_RichText)
        info.setStyleSheet(_note_style('success'))
        root.addWidget(info)

        # ── Input layers ───────────────────────────────────────────────────
        g1, f1 = _grp('Input Layers')
        self.dem = _LC(QgsMapLayerProxyModel.RasterLayer)
        self.cat = _LC(QgsMapLayerProxyModel.PolygonLayer)
        f1.addRow('DEM Raster (reprojected):', self.dem)
        f1.addRow('Catchment Boundary (optional):', self.cat)
        cat_hint = QLabel(
            'Optional, and usually better left empty. Cropping to a boundary '
            'truncates upstream contributing area at the clip edge, so cells '
            'near that edge get an accumulation that is too low and the '
            'derived stream network is wrong there. Supply one only if you '
            'specifically want the output polygons trimmed.')
        cat_hint.setWordWrap(True)
        cat_hint.setStyleSheet(_note_style('muted'))
        f1.addRow('', cat_hint)
        root.addWidget(g1)

        # ── Delineation parameters ─────────────────────────────────────────
        g2, f2 = _grp('Delineation Parameters')

        self.crs = QgsProjectionSelectionWidget()
        self.crs.setCrs(QgsCoordinateReferenceSystem('EPSG:32643'))

        # Stream threshold
        self.thresh = QSpinBox()
        self.thresh.setRange(10, 1000000); self.thresh.setValue(500)
        self.thresh.setToolTip(
            'Minimum number of upstream cells to define a stream cell.\n'
            'Lower value = denser network with more sub-basins.\n'
            'Higher value = fewer, larger sub-basins.'
        )
        thresh_note = QLabel('cells  —  lower = denser network, more sub-basins')
        thresh_note.setStyleSheet(_note_style('muted'))
        thresh_row = QHBoxLayout(); thresh_row.setContentsMargins(0,0,0,0)
        thresh_row.addWidget(self.thresh); thresh_row.addWidget(thresh_note)
        thresh_row.addStretch()
        thresh_w = QWidget(); thresh_w.setLayout(thresh_row)

        # Minimum basin area
        self.min_area = QDoubleSpinBox()
        self.min_area.setRange(0.01, 10000.0); self.min_area.setValue(1.0)
        self.min_area.setDecimals(2); self.min_area.setSuffix(' km²')
        self.min_area.setToolTip('Sub-basins smaller than this are merged into adjacent basins.')
        area_note = QLabel('—  small basins are merged into neighbours')
        area_note.setStyleSheet(_note_style('muted'))
        area_row = QHBoxLayout(); area_row.setContentsMargins(0,0,0,0)
        area_row.addWidget(self.min_area); area_row.addWidget(area_note)
        area_row.addStretch()
        area_w = QWidget(); area_w.setLayout(area_row)

        self.load_chk = QCheckBox('Load outputs in QGIS after processing')
        self.load_chk.setChecked(True)

        f2.addRow('Target CRS:', self.crs)
        f2.addRow('Stream threshold:', thresh_w)
        f2.addRow('Minimum basin area:', area_w)
        f2.addRow('', self.load_chk)
        root.addWidget(g2)

        # ── Output folder ──────────────────────────────────────────────────
        g3, f3 = _grp('Output')
        self.out_folder = QLineEdit()
        b_browse = QPushButton('Browse'); _sb(b_browse, ACCENT2, small=True)
        b_browse.clicked.connect(lambda: _bd(self.out_folder, self))
        out_row = QHBoxLayout(); out_row.addWidget(self.out_folder); out_row.addWidget(b_browse)
        f3.addRow('Output folder:', out_row)

        out_note = QLabel(
            'Files written to output folder:\n'
            '  sub_basins.gpkg       – polygon  |  Name (S1…SN), Area_km2 (decimal)\n'
            '  streams.gpkg          – line     |  StreamID, Order (Strahler),\n'
            '                                       Length_km, UpstreamArea_km2, AvgSlope_pct\n'
            '  subcatchment_stats.txt – summary table (text)'
        )
        out_note.setStyleSheet(
            f'color:{TEXT};font-size:11px;font-family:Consolas,monospace;'
            f'background:{SUNKEN};padding:9px 11px;border-radius:7px;'
            f'border:1px solid {LINE_STRONG};'
        )
        f3.addRow(out_note)
        root.addWidget(g3)

        # ── Log ────────────────────────────────────────────────────────────
        gL, vl = _grp('Processing Log', QVBoxLayout)
        self.log = QTextEdit(); self.log.setReadOnly(True); self.log.setFixedHeight(200)
        self.pb  = QProgressBar()
        vl.addWidget(self.log); vl.addWidget(self.pb)
        root.addWidget(gL)

        btn_run = QPushButton('Run Streams && Sub-basin Delineation')
        _sb(btn_run, ACCENT)
        btn_run.clicked.connect(self._run)
        root.addWidget(btn_run)
        root.addStretch()

    # ── Run ────────────────────────────────────────────────────────────────

        _apply_tooltips(self)
    def _run(self):
        self.log.clear(); self.pb.setValue(0)
        dem_layer = self.dem.currentLayer()
        cat_layer = self.cat.currentLayer()
        out_dir   = self.out_folder.text().strip()

        if not dem_layer:
            QMessageBox.warning(self, 'Missing Input', 'Please select a DEM raster layer.'); return
        if not out_dir:
            QMessageBox.warning(self, 'Missing Input', 'Please select an output folder.'); return

        self.log.append('<b>Starting sub-basin delineation …</b>')
        try:
            _run_alg(SubcatchmentDelineation, {
                'DEM':            dem_layer.source(),
                'CATCHMENT':      (cat_layer.source() if cat_layer else None),
                'TARGET_CRS':     self.crs.crs().authid(),
                'STREAM_THRESH':  self.thresh.value(),
                'MIN_BASIN_AREA': self.min_area.value(),
                'LOAD_IN_QGIS':   self.load_chk.isChecked(),
                'OUTPUT_FOLDER':  out_dir,
            }, self.log, self.pb)
            self.log.append(
                f'<b style="color:{SUCCESS}">Done. Check the output folder and QGIS Layers panel.</b>'
            )
        except Exception as e:
            import traceback
            self.log.append(f'<span style="color:{LOG_ERROR}"><b>Error:</b> {e}</span>')
            self.log.append(
                f'<pre style="font-size:10px;color:#B71C1C">{traceback.format_exc()}</pre>'
            )

# ═══════════════════════════════════════════════════════════════════════════
#  Tab 3 – CN / LULC / Manning's
# ═══════════════════════════════════════════════════════════════════════════

class CNLULCTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface=iface
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(8)
        inner=QTabWidget(); root.addWidget(inner)
        inner.addTab(self._gen_tab(),   'Generate Rasters')
        inner.addTab(self._cn_tab(),    'TR-55 CN Table')
        inner.addTab(self._lulc_tab(),  'LULC to CN')
        inner.addTab(self._mann_tab(),  "Manning's n")
        inner.addTab(self._hr_tab(),    'HEC-RAS Classes')

        _apply_tooltips(self)

    def _gen_tab(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14); root.setSpacing(9)

        g0,f0=_grp('Common Settings')
        # LULC extent, not a catchment. This tab fetches land cover and
        # derives CN / Manning's rasters — it needs to know which AREA to
        # process, not a catchment boundary. Requiring a polygon here was
        # circular: the catchment is delineated later from a pour point,
        # so at this point the user usually does not have one.
        self.ext_dl = ExtentPicker(self.iface, self)
        self.hsg_dl=QComboBox(); self.hsg_dl.addItems(['A','B','C','D']); self.hsg_dl.setCurrentIndex(1)
        self.amc_dl=QComboBox(); self.amc_dl.addItems(['AMC I (Dry)','AMC II (Normal)','AMC III (Wet)']); self.amc_dl.setCurrentIndex(1)
        f0.addRow('LULC Extent:',self.ext_dl)
        f0.addRow('HSG default:',self.hsg_dl)
        f0.addRow('AMC condition:',self.amc_dl)
        ext_note = _note(
            'Generating over a slightly larger area is harmless — the flood '
            'tabs clip to the delineated catchment when they run. Generating '
            'over too <b>small</b> an area is what hurts: land cover that '
            'stops short of the catchment edge leaves holes in the CN raster.',
            'info', rich=True)
        f0.addRow(ext_note)
        root.addWidget(g0)

        g1,f1=_grp('Option 1: ESA WorldCover 2021 – AWS Download (10 m, global, free)')
        note1=QLabel(
            'Downloads tiles from ESA AWS bucket (tokenless).\n'
            'Tile naming: ESA_WorldCover_10m_2021_v200_{TILE}_Map.tif\n'
            'If tiles return 404, download manually from viewer.esa-worldcover.org\n'
            'and use Option 2 below.'
        )
        note1.setWordWrap(True); note1.setStyleSheet(_note_style('muted'))
        self.esa_out=QLineEdit()
        be=QPushButton('Browse'); _sb(be,ACCENT2,small=True)
        be.clicked.connect(lambda: _bd(self.esa_out,w))
        re_=QHBoxLayout(); re_.addWidget(self.esa_out); re_.addWidget(be)
        f1.addRow(note1); f1.addRow('Download + output folder:',re_)
        root.addWidget(g1)
        b1=QPushButton('Download ESA WorldCover and Derive CN / Manning\'s Rasters')
        _sb(b1,ACCENT); b1.clicked.connect(self._esa); root.addWidget(b1)

        g2,f2=_grp('Option 2: Derive from Existing LULC Raster')
        self.lulc_dl=_LC(QgsMapLayerProxyModel.RasterLayer)
        b_merge=QPushButton('Merge Multiple Tiles...'); _sb(b_merge,ACCENT2,small=True)
        b_merge.setToolTip(
            'If your LULC download came as several separate tile files '
            '(not pre-merged into one raster), pick them all here — '
            'they\'ll be combined into one mosaic and selected above '
            'automatically.'
        )
        b_merge.clicked.connect(self._merge_tiles)
        lulc_row=QHBoxLayout(); lulc_row.addWidget(self.lulc_dl); lulc_row.addWidget(b_merge)
        self.ltype_dl=QComboBox()
        self.ltype_dl.addItems(['ESA WorldCover 2021','Esri 10m Annual LULC',
                                'NLCD 2019 (USA)','CORINE (Europe)','MODIS IGBP'])
        self.ltype_dl.setToolTip(
            'Which product the raster came from. This decides both the '
            'CN / Manning\'s lookup AND the class colours, and the two '
            'schemes overlap: value 10 is Clouds in the Esri product but '
            'Tree cover in ESA WorldCover. Picking the wrong one produces '
            'a plausible-looking map that is wrong throughout.')
        self.der_out=QLineEdit()
        bd_=QPushButton('Browse'); _sb(bd_,ACCENT2,small=True)
        bd_.clicked.connect(lambda: _bd(self.der_out,w))
        rd=QHBoxLayout(); rd.addWidget(self.der_out); rd.addWidget(bd_)
        f2.addRow('LULC raster:',lulc_row)
        f2.addRow('Dataset type:',self.ltype_dl)
        f2.addRow('Output folder:',rd)
        root.addWidget(g2)
        b2=QPushButton('Derive CN and Manning\'s Rasters from LULC')
        _sb(b2,ACCENT2); b2.clicked.connect(self._derive); root.addWidget(b2)

        g3,f3=_grp('Option 3: Uniform Rasters from Manual Value')
        self.man_cn=QDoubleSpinBox(); self.man_cn.setRange(1,100); self.man_cn.setValue(75)
        self.man_mn=QDoubleSpinBox(); self.man_mn.setRange(0.005,0.5); self.man_mn.setValue(0.035); self.man_mn.setDecimals(4)
        self.man_res=QDoubleSpinBox(); self.man_res.setRange(1,1000); self.man_res.setValue(30); self.man_res.setSuffix(' m')
        self.man_out=QLineEdit()
        bm=QPushButton('Browse'); _sb(bm,ACCENT2,small=True)
        bm.clicked.connect(lambda: _bd(self.man_out,w))
        rm=QHBoxLayout(); rm.addWidget(self.man_out); rm.addWidget(bm)
        f3.addRow('CN value:',self.man_cn); f3.addRow("Manning's n:",self.man_mn)
        f3.addRow('Resolution:',self.man_res); f3.addRow('Output folder:',rm)
        root.addWidget(g3)
        b3=QPushButton('Generate Uniform CN and Manning\'s Rasters')
        _sb(b3,SURFACE_2); b3.clicked.connect(self._manual); root.addWidget(b3)

        gL,vl=_grp('Log',QVBoxLayout)
        self.cn_log=QTextEdit(); self.cn_log.setReadOnly(True); self.cn_log.setFixedHeight(130)
        self.cn_pb=QProgressBar()
        vl.addWidget(self.cn_log); vl.addWidget(self.cn_pb); root.addWidget(gL)
        root.addStretch(); return w

    def _hsg(self):   return ['A','B','C','D'][self.hsg_dl.currentIndex()]
    def _amc(self):   return self.amc_dl.currentIndex()+1
    def _ltype(self): return ['ESA','ESRI','NLCD','CORINE','MODIS'][self.ltype_dl.currentIndex()]

    def _load_lyr(self, path, raster_kind=None):
        """
        raster_kind: 'cn', 'manning', or None (generic/no special styling —
        e.g. the LULC integer raster, which already gets a proper QGIS
        Raster Attribute Table + class names embedded elsewhere and
        renders adequately with QGIS's own default paletted handling for
        an integer classification raster).

        Builds the renderer PROGRAMMATICALLY via the QGIS API rather than
        writing a .qml file and calling loadNamedStyle() on it — that
        approach had several failure points that couldn't be fully
        verified without a real QGIS install (file I/O timing, XML
        schema differences across QGIS versions, or loadNamedStyle()
        failing silently with no error surfaced). Constructing the
        renderer directly in Python is the same proven approach already
        used for flood depth rasters (see flood_mapping.py's
        load_flood_rasters_to_qgis), which hasn't had this problem.
        """
        from qgis.core import (QgsRasterLayer, QgsRasterShader, QgsColorRampShader,
                                QgsSingleBandPseudoColorRenderer)
        from qgis.PyQt.QtGui import QColor
        if not (path and os.path.exists(path)):
            return
        n = os.path.splitext(os.path.basename(path))[0].replace('_', ' ')
        lyr = QgsRasterLayer(path, n)
        if not lyr.isValid():
            return
        QgsProject.instance().addMapLayer(lyr)

        # Palettes live in ui_palettes so the ramp a raster gets when it is
        # generated here is the same one it gets anywhere else.
        try:
            from .ui_palettes import (CN_RAMP, MANNING_RAMP, LULC_RAMP,
                                       apply_ramp, lulc_items)
        except ImportError:
            from ui_palettes import (CN_RAMP, MANNING_RAMP, LULC_RAMP,
                                      apply_ramp, lulc_items)

        # DISCRETE classes with equal-count breaks throughout — see
        # ui_palettes.quantile_breaks. Pinning CN to 30-100 and Manning's
        # to 0.01-0.20 was defensible in theory (the same colour means the
        # same value across scenarios) but wrong in practice: a catchment
        # sitting at CN 60-85 only ever reached a third of the palette, and
        # one at n = 0.05-0.14 rather less, which is why only three or four
        # colours were showing. Legibility of the map you actually have
        # beats comparability with a map you might make later.
        ok = True
        if raster_kind == 'cn':
            ok = apply_ramp(lyr, CN_RAMP, fmt='{:.0f}')
        elif raster_kind == 'manning':
            ok = apply_ramp(lyr, MANNING_RAMP, fmt='{:.3f}')
        elif raster_kind == 'lulc':
            # A classification: the product's OWN official colour per
            # class code, never a stretch. Which table applies depends on
            # the dataset, and the two supported schemes overlap — value
            # 10 is Clouds in Esri and Tree cover in ESA WorldCover — so
            # the dataset the user selected is passed through rather than
            # guessed from the codes alone.
            vals = self._lulc_class_values(lyr)
            items, scheme = lulc_items(vals or [], declared=self._ltype())
            if items:
                ok = apply_ramp(lyr, [c for _, c, _ in items],
                                 values=[v for v, _, _ in items],
                                 labels=[l for _, _, l in items])
                if hasattr(self, 'cn_log'):
                    named = {'esri': 'Esri 10m Annual LULC',
                             'esa': 'ESA WorldCover'}.get(scheme, scheme)
                    self.cn_log.append(
                        f'<span style="color:{LOG_DIM}">  Styled with the '
                        f'official {named} class colours '
                        f'({len(items)} classes present).</span>')
            elif vals:
                # Codes we don't have a table for (NLCD, CORINE, MODIS):
                # distinct colours per class beats a meaningless stretch.
                ok = apply_ramp(lyr, LULC_RAMP, values=vals,
                                 labels=[str(v) for v in vals])
            else:
                ok = apply_ramp(lyr, LULC_RAMP, fmt='{:.0f}')

        if not ok and hasattr(self, 'cn_log'):
            self.cn_log.append(
                f'<span style="color:{LOG_WARN}">Styling {n} failed — '
                f'loaded with QGIS defaults.</span>')

        lyr.triggerRepaint()
        try:
            lyr.emitStyleChanged()
        except Exception:
            pass

    @staticmethod
    def _lulc_class_values(lyr):
        """
        The distinct class codes present in a LULC raster.

        Read from the histogram rather than assumed, because the code set
        differs per dataset (ESA WorldCover uses 10-95, NLCD 11-95, CORINE
        1-44) and a hard-coded list would mis-colour three of the four
        datasets the plugin supports.
        """
        try:
            prov = lyr.dataProvider()
            st = prov.bandStatistics(1)
            lo, hi = int(st.minimumValue), int(st.maximumValue)
            if hi - lo > 300:
                return None            # not a classification; let it stretch
            hist = prov.histogram(1, hi - lo + 1, lo, hi + 1)
            vals = [lo + i for i, c in enumerate(hist.histogramVector) if c > 0]
            return vals or None
        except Exception:
            return None

    def _merge_tiles(self):
        out = self.der_out.text().strip()
        if not out:
            QMessageBox.warning(None, 'Missing', 'Select an output folder first (below).')
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, 'Select LULC tiles to merge', '',
            'Raster files (*.tif *.tiff *.img *.vrt);;All files (*.*)'
        )
        if not paths:
            return
        self.cn_log.clear()
        fb = _FB(self.cn_log, self.cn_pb)
        try:
            merged = merge_raster_tiles(list(paths), out, feedback=fb)
            if not merged:
                self.cn_log.append(f'<span style="color:{LOG_ERROR}">Merge failed — see log above.</span>')
                return
            from qgis.core import QgsRasterLayer
            name = os.path.splitext(os.path.basename(merged))[0]
            lyr = QgsRasterLayer(merged, name)
            if not lyr.isValid():
                self.cn_log.append(f'<span style="color:{LOG_ERROR}">Merged file could not be loaded as a raster.</span>')
                return
            QgsProject.instance().addMapLayer(lyr)
            self.lulc_dl.c.setLayer(lyr)
            self.cn_log.append(
                f'<b style="color:{SUCCESS}">Merged {len(paths)} tile(s) and selected the '
                f'result above — ready to derive CN/Manning\'s rasters.</b>'
            )
        except Exception as e:
            import traceback
            self.cn_log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.cn_log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')

    def _esa(self):
        self.cn_log.clear()
        fb=_FB(self.cn_log,self.cn_pb)
        e=self.ext_dl.extent_4326(); out=self.esa_out.text().strip()
        if e is None or not out:
            QMessageBox.warning(None,'Missing','Set an LULC extent and an output folder.'); return
        try:
            # The picker has already applied padding, so no second pad here.
            minx,miny,maxx,maxy = e
            fb.pushInfo(f"LULC extent: {minx:.4f}, {miny:.4f} -> {maxx:.4f}, {maxy:.4f} (EPSG:4326)")
            merged=download_esa_worldcover_for_bbox(
                (miny,maxy,minx,maxx),
                os.path.join(out,'esa_tiles'), fb)
            if merged:
                res=generate_cn_raster_from_lulc_file(
                    merged,out,'ESA',self._hsg(),self._amc(),
                    catchment_geoms=self.ext_dl.geoms_4326(),feedback=fb)
                kind_map = {'cn_raster': 'cn', 'manning_raster': 'manning', 'lulc_int_raster': 'lulc'}
                for k, kind in kind_map.items(): self._load_lyr(res.get(k), raster_kind=kind)
                self.cn_log.append(
                    f'<b style="color:{SUCCESS}">Done. Weighted CN={res.get("weighted_cn",0):.1f}, '
                    f'n={res.get("weighted_manning",0):.4f}</b>')
            else:
                self.cn_log.append(
                    f'<span style="color:{LOG_ERROR}">Download failed (404 or network error).<br>'
                    'Download tiles manually from viewer.esa-worldcover.org<br>'
                    'then use Option 2 "Derive from Existing LULC Raster".</span>')
        except Exception as e:
            import traceback
            self.cn_log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.cn_log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')

    def _derive(self):
        self.cn_log.clear()
        fb=_FB(self.cn_log,self.cn_pb)
        lulc=self.lulc_dl.currentLayer(); out=self.der_out.text().strip()
        if not lulc or not out: QMessageBox.warning(None,'Missing','Select LULC raster and output folder.'); return
        try:
            geoms=self.ext_dl.geoms_4326()
            res=generate_cn_raster_from_lulc_file(
                lulc.source(),out,self._ltype(),self._hsg(),self._amc(),
                catchment_geoms=geoms,feedback=fb)
            kind_map = {'cn_raster': 'cn', 'manning_raster': 'manning', 'lulc_int_raster': 'lulc'}
            for k, kind in kind_map.items(): self._load_lyr(res.get(k), raster_kind=kind)
            self.cn_log.append(
                f'<b style="color:{SUCCESS}">Done. CN={res.get("weighted_cn",0):.1f}, '
                f'n={res.get("weighted_manning",0):.4f}</b>')
        except Exception as e:
            import traceback
            self.cn_log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.cn_log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')

    def _manual(self):
        self.cn_log.clear()
        fb=_FB(self.cn_log,self.cn_pb)
        out=self.man_out.text().strip()
        if not self.ext_dl.is_set() or not out:
            QMessageBox.warning(None,'Missing','Set an LULC extent and an output folder.'); return
        # generate_cn_raster_manual takes a vector PATH, so the extent is
        # written out as a one-polygon GeoPackage. For a uniform raster the
        # shape is irrelevant anyway — only the area covered matters.
        cat_path=self.ext_dl.as_temp_gpkg()
        if not cat_path:
            QMessageBox.warning(None,'Extent','Could not build a polygon from the chosen extent.'); return
        try:
            res=generate_cn_raster_manual(
                cat_path,self.man_cn.value(),self.man_mn.value(),
                out,resolution=self.man_res.value(),feedback=fb)
            kind_map = {'cn_raster': 'cn', 'manning_raster': 'manning', 'lulc_int_raster': 'lulc'}
            for k, kind in kind_map.items(): self._load_lyr(res.get(k), raster_kind=kind)
            self.cn_log.append(f'<b style="color:{SUCCESS}">Done. Uniform rasters created.</b>')
        except Exception as e:
            import traceback
            self.cn_log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.cn_log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')

    def _cn_tab(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14)
        root.addWidget(_lbl('NRCS TR-55 CN Table (AMC II)',bold=True,color=ACCENT))
        hl=QHBoxLayout(); hl.addWidget(QLabel('HSG:'))
        self._ch=QComboBox(); self._ch.addItems(['A','B','C','D']); self._ch.setCurrentIndex(1)
        self._ch.currentIndexChanged.connect(self._rcn)
        hl.addWidget(self._ch); hl.addStretch(); root.addLayout(hl)
        self._ct=QTableWidget(); self._ct.setAlternatingRowColors(True)
        self._ct.setEditTriggers(_QAbs_NoEdit)
        self._ct.horizontalHeader().setSectionResizeMode(_QHdr_Stretch)
        root.addWidget(self._ct); self._rcn(); return w

    def _rcn(self):
        idx=self._ch.currentIndex(); col=idx+1; hsg='ABCD'[idx]
        rows=list(CN_TABLE_TR55.items())
        self._ct.setRowCount(len(rows)); self._ct.setColumnCount(3)
        self._ct.setHorizontalHeaderLabels(['Land Cover',f'CN HSG {hsg}','Code'])
        for i,(k,v) in enumerate(rows):
            self._ct.setItem(i,0,QTableWidgetItem(v[0]))
            cn=v[col]; it=QTableWidgetItem(str(cn)); it.setTextAlignment(_Qt_AlignCenter)
            it.setBackground(QColor('#FFCDD2')if cn>=90 else QColor('#FFE0B2')if cn>=75 else
                             QColor('#FFF9C4')if cn>=60 else QColor('#DCEDC8'))
            self._ct.setItem(i,1,it); self._ct.setItem(i,2,QTableWidgetItem(k))

    def _lulc_tab(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14)
        root.addWidget(_lbl("LULC to CN and Manning's n",bold=True,color=ACCENT))
        hl=QHBoxLayout()
        self._ld=QComboBox()
        self._ld.addItems(['ESA WorldCover 2021','NLCD 2019','CORINE','MODIS IGBP'])
        self._lh=QComboBox(); self._lh.addItems(['A','B','C','D']); self._lh.setCurrentIndex(1)
        self._ld.currentIndexChanged.connect(self._rl); self._lh.currentIndexChanged.connect(self._rl)
        hl.addWidget(QLabel('Dataset:')); hl.addWidget(self._ld)
        hl.addWidget(QLabel('  HSG:')); hl.addWidget(self._lh); hl.addStretch()
        root.addLayout(hl)
        self._lt=QTableWidget(); self._lt.setAlternatingRowColors(True)
        self._lt.setEditTriggers(_QAbs_NoEdit)
        self._lt.horizontalHeader().setSectionResizeMode(_QHdr_ResizeCont)
        root.addWidget(self._lt); self._rl(); return w

    def _rl(self):
        luts=[ESA_WORLDCOVER_TO_PARAMS,NLCD_TO_PARAMS,CORINE_TO_PARAMS,MODIS_IGBP_TO_PARAMS]
        lut=luts[self._ld.currentIndex()]; hi=self._lh.currentIndex(); hsg='ABCD'[hi]; cc=hi+1
        rows=list(lut.items())
        self._lt.setRowCount(len(rows)); self._lt.setColumnCount(5)
        self._lt.setHorizontalHeaderLabels(['Pixel','Description',f'CN HSG {hsg}','n channel','n overland'])
        for i,(pv,val) in enumerate(rows):
            self._lt.setItem(i,0,QTableWidgetItem(str(pv)))
            self._lt.setItem(i,1,QTableWidgetItem(val[0]))
            cn=val[cc]; it=QTableWidgetItem(str(cn)); it.setTextAlignment(_Qt_AlignCenter)
            it.setBackground(QColor('#FFCDD2')if cn>=90 else QColor('#FFE0B2')if cn>=75 else
                             QColor('#FFF9C4')if cn>=60 else QColor('#DCEDC8'))
            self._lt.setItem(i,2,it)
            self._lt.setItem(i,3,QTableWidgetItem(f'{val[5]:.4f}'))
            self._lt.setItem(i,4,QTableWidgetItem(f'{val[6]:.4f}'))

    def _mann_tab(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14)
        root.addWidget(_lbl("Manning's n Reference (Chow 1959 / HEC-15)",bold=True,color=ACCENT))
        inner=QTabWidget(); root.addWidget(inner)
        for title,lut in [('Channels',MANNING_N_CHANNELS),('Overland',MANNING_N_OVERLAND)]:
            tw=QTableWidget(len(lut),2); tw.setHorizontalHeaderLabels(['Description',"Manning's n"])
            tw.setAlternatingRowColors(True); tw.setEditTriggers(_QAbs_NoEdit)
            tw.horizontalHeader().setSectionResizeMode(0,_QHdr_Stretch)
            tw.horizontalHeader().setSectionResizeMode(1,_QHdr_ResizeCont)
            for i,(d,n) in enumerate(lut.items()):
                tw.setItem(i,0,QTableWidgetItem(d))
                it=QTableWidgetItem(f'{n:.4f}'); it.setTextAlignment(_Qt_AlignCenter)
                tw.setItem(i,1,it)
            inner.addTab(tw,title)
        return w

    def _hr_tab(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14); root.setSpacing(10)
        root.addWidget(_lbl('HEC-RAS CN Raster Class Definitions',bold=True,color=ACCENT))
        note=QLabel('In HEC-RAS, CN rasters store the curve number as the pixel value (integer 1-100).\n'
                    'Rain2Flood reads these directly for area-weighted mean CN extraction.')
        note.setWordWrap(True); note.setStyleSheet(_note_style('success'))
        root.addWidget(note)
        tbl=QTableWidget(len(HECRAS_CN_CLASSES),4)
        tbl.setHorizontalHeaderLabels(['CN Min','CN Max','Description','Colour'])
        tbl.setAlternatingRowColors(True); tbl.setEditTriggers(_QAbs_NoEdit)
        tbl.horizontalHeader().setSectionResizeMode(2,_QHdr_Stretch)
        for i,(mn,mx,desc,col) in enumerate(HECRAS_CN_CLASSES):
            tbl.setItem(i,0,QTableWidgetItem(str(mn))); tbl.setItem(i,1,QTableWidgetItem(str(mx)))
            tbl.setItem(i,2,QTableWidgetItem(desc))
            it=QTableWidgetItem(col); it.setBackground(QColor(col))
            it.setForeground(QColor('white' if mn>=50 else '#111')); tbl.setItem(i,3,it)
        root.addWidget(tbl)
        root.addWidget(_lbl('AMC Adjustment Equations (SCS NEH-4, 1985)',bold=True))
        root.addWidget(QLabel(
            'AMC I  (Dry):    CN1 = 4.2 x CN2 / (10 - 0.058 x CN2)\n'
            'AMC II (Normal): CN2 = table value\n'
            'AMC III (Wet):   CN3 = 23 x CN2 / (10 + 0.13 x CN2)'
        )); root.addStretch(); return w


# ═══════════════════════════════════════════════════════════════════════════
#  Rainfall Data Download (standalone utility — not a pipeline step)
# ═══════════════════════════════════════════════════════════════════════════

class RainfallDownloadTab(QWidget):
    SRCS=['Open-Meteo ERA5 (Daily)','Open-Meteo ERA5 (Hourly)',
          'Open-Meteo CERRA (Hourly, Europe)','NASA POWER (Daily)',
          'NOAA GHCND (Nearest Station)','IMD Gridded 0.25 deg (India)',
          'CHIRPS NetCDF (local files)','Excel / CSV','Synthetic']

    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface=iface
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(10)

        g,f=_grp('Source and Location')
        self.src=QComboBox(); self.src.addItems(self.SRCS)
        self.lat=QLineEdit('20.0'); self.lon=QLineEdit('77.0')
        self.sd=QDateTimeEdit(QDateTime(QDate.currentDate().addDays(-3650),QTime(0,0,0)))
        self.ed=QDateTimeEdit(QDateTime(QDate.currentDate(),QTime(0,0,0)))
        self.sd.setCalendarPopup(True); self.ed.setCalendarPopup(True)
        f.addRow('Source:',self.src)
        f.addRow('Lat, Lon:',_coord_row(iface,self.lat,self.lon))
        f.addRow('Start:',self.sd); f.addRow('End:',self.ed)
        root.addWidget(g)

        g2,f2=_grp('File Inputs')
        self.xls=QLineEdit(); bx=QPushButton('Browse'); _sb(bx,ACCENT2,small=True)
        bx.clicked.connect(lambda: _bf(self.xls,self,'Excel/CSV','Excel/CSV (*.xlsx *.xls *.csv)'))
        self.chirps=QLineEdit(); bc=QPushButton('Browse'); _sb(bc,ACCENT2,small=True)
        bc.clicked.connect(lambda: _bd(self.chirps,self,'CHIRPS folder'))
        self.dcol=QLineEdit('Date'); self.rcol=QLineEdit('Rainfall_mm')
        rx=QHBoxLayout(); rx.addWidget(self.xls); rx.addWidget(bx)
        rc=QHBoxLayout(); rc.addWidget(self.chirps); rc.addWidget(bc)
        f2.addRow('Excel/CSV:',rx); f2.addRow('CHIRPS folder:',rc)
        f2.addRow('Date column:',self.dcol); f2.addRow('Rainfall column:',self.rcol)
        root.addWidget(g2)

        g3,f3=_grp('Output')
        self.out=QLineEdit(); bo=QPushButton('Browse'); _sb(bo,ACCENT2,small=True)
        bo.clicked.connect(lambda: _bd(self.out,self))
        self.graphs=QCheckBox('Generate rainfall graphs'); self.graphs.setChecked(True)
        ro=QHBoxLayout(); ro.addWidget(self.out); ro.addWidget(bo)
        f3.addRow('Output folder:',ro); f3.addRow('',self.graphs); root.addWidget(g3)

        gL,vl=_grp('Log',QVBoxLayout)
        self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setFixedHeight(130)
        self.pb=QProgressBar()
        vl.addWidget(self.log); vl.addWidget(self.pb); root.addWidget(gL)

        run=QPushButton('Download Rainfall Data')
        _sb(run,ACCENT); run.clicked.connect(self._run); root.addWidget(run); root.addStretch()

        _apply_tooltips(self)

    def _run(self):
        self.log.clear()
        out=self.out.text().strip()
        if not out: QMessageBox.warning(self,'Missing','Select output folder.'); return
        try: lat=float(self.lat.text()); lon=float(self.lon.text())
        except ValueError: QMessageBox.warning(self,'Error','Invalid coordinates.'); return
        try:
            _run_alg(RainfallDataDownloader,{
                'SOURCE':self.src.currentIndex(),
                'COORDINATES_MANUAL':f'{lat},{lon}',
                'START_DATE':self.sd.dateTime(),'END_DATE':self.ed.dateTime(),
                'EXCEL_FILE':self.xls.text(),'DATE_COLUMN':self.dcol.text(),
                'RAINFALL_COLUMN':self.rcol.text(),'CHIRPS_FOLDER':self.chirps.text(),
                'GENERATE_GRAPHS':self.graphs.isChecked(),'OUTPUT_FOLDER':out,
            }, self.log, self.pb)
            self.log.append(f'<b style="color:{SUCCESS}">Done.</b>')
        except Exception as e:
            import traceback
            self.log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')


# ═══════════════════════════════════════════════════════════════════════════
#  Tab 4 – Flash Flood
# ═══════════════════════════════════════════════════════════════════════════

class FlashFloodTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface=iface
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(10)
        gpp,fpp=_grp('Pour Point / Outlet — where results correspond to')
        self.pp_lat=QLineEdit(); self.pp_lon=QLineEdit()
        self.pp_lat.setPlaceholderText('latitude'); self.pp_lon.setPlaceholderText('longitude')
        pp_btn=PointPickerButton(iface, self.pp_lat, self.pp_lon)
        pp_row=QHBoxLayout()
        pp_row.addWidget(QLabel('Lat:')); pp_row.addWidget(self.pp_lat)
        pp_row.addWidget(QLabel('Lon:')); pp_row.addWidget(self.pp_lon)
        pp_row.addWidget(pp_btn)
        self.sub_lyr=_LC(QgsMapLayerProxyModel.PolygonLayer)
        self.wave_cel=QDoubleSpinBox(); self.wave_cel.setRange(0.1,10.0)
        self.wave_cel.setValue(1.0); self.wave_cel.setDecimals(2); self.wave_cel.setSuffix(' m/s')
        pp_note=QLabel(
            'Set this FIRST — it defines the whole analysis. Every discharge '
            'this tool reports is the flow AT THIS POINT.\n'
            'Choose "Pour Point + DEM (auto-delineate)" under Catchment '
            'Parameters below and the upstream catchment, longest flow path '
            'and channel slope are all derived from this point, so no '
            'catchment polygon is needed. The point is snapped onto the '
            'modelled stream network first — check the reported snap distance, '
            'because a large move means it landed on a different river.\n'
            'Leave blank and the DEM\'s lowest cell is used.\n'
            'Supplying sub-basins from Tab 2 switches the analysis from LUMPED '
            '(whole catchment as one unit, one CN, one time of concentration) to '
            'SEMI-DISTRIBUTED: each sub-basin gets its own CN and timing, is '
            'lagged to the pour point by travel time, and summed there. This '
            'usually gives a LOWER, broader peak, because sub-basins do not all '
            'peak at the same moment — which a lumped calculation assumes they do.'
        )
        pp_note.setWordWrap(True)
        pp_note.setStyleSheet(_note_style('info'))
        fpp.addRow('Pour point:',pp_row)
        fpp.addRow('Sub-basins (Tab 2):',self.sub_lyr)
        fpp.addRow('Wave celerity:',self.wave_cel)
        fpp.addRow(pp_note)
        root.addWidget(gpp)


        g,f=_grp('Rainfall Source')
        self.src=QComboBox(); self.src.addItems(_FA.RAINFALL_SOURCES)
        self.lat=QLineEdit('20.0'); self.lon=QLineEdit('77.0')
        self.sd=QDateTimeEdit(QDateTime(QDate.currentDate().addDays(-365),QTime(0,0,0)))
        self.ed=QDateTimeEdit(QDateTime(QDate.currentDate(),QTime(23,0,0)))
        self.sd.setCalendarPopup(True); self.ed.setCalendarPopup(True)
        self.xls=QLineEdit(); bx=QPushButton('Browse'); _sb(bx,ACCENT2,small=True)
        bx.clicked.connect(lambda: _bf(self.xls,self,'Hourly File','Excel/CSV (*.xlsx *.xls *.csv)'))
        self.dcol=QLineEdit('DateTime'); self.rcol=QLineEdit('Rainfall_mm')
        rx=QHBoxLayout(); rx.addWidget(self.xls); rx.addWidget(bx)
        f.addRow('Source:',self.src)
        f.addRow('Lat, Lon:',_coord_row(iface,self.lat,self.lon))
        f.addRow('Start:',self.sd); f.addRow('End:',self.ed)
        f.addRow('Excel/CSV:',rx)
        f.addRow('Date column:',self.dcol); f.addRow('Rainfall column:',self.rcol)
        root.addWidget(g)

        gs,self.sr=_spatial_rain_grp(); root.addWidget(gs)

        g2,f2=_grp('Analysis')
        self.method=QComboBox(); self.method.addItems(_FA.ANALYSIS_METHODS)
        self.method.setToolTip(
            'If you select Wadi: enter your CN as the standard AMC-II value '
            '— the arid-region AMC-I conversion (drier antecedent '
            'conditions) is applied automatically inside that method.'
        )
        self.dur=QComboBox(); self.dur.addItems(_FA.STORM_DURATIONS)
        self.rps=QLineEdit('10,25,50,100')
        self.freq=QComboBox(); self.freq.addItems(_FA.FREQ_METHODS)
        self.freq.setToolTip(
            'Auto (best fit by AIC) fits Gumbel, Log-Pearson III, GEV, and '
            'Log-Normal and picks whichever fits this record best, instead of '
            'always using one fixed distribution. Every option also reports a '
            '90% confidence interval and runs Mann-Kendall trend / Grubbs-Beck '
            'outlier checks automatically — see the log and the \'Frequency '
            'Uncertainty\' sheet in the output Excel file.'
        )
        self.amc=QComboBox(); self.amc.addItems(_FA.AMC_OPTIONS); self.amc.setCurrentIndex(1)
        f2.addRow('Method:',self.method); f2.addRow('Storm duration:',self.dur)
        f2.addRow('Return periods (yr):',self.rps); f2.addRow('Frequency method:',self.freq)
        f2.addRow('AMC:',self.amc)
        root.addWidget(g2)

        gc,self.c=_cat_grp(); root.addWidget(gc)
        gcn,self.cn=_cn_grp(_FA); root.addWidget(gcn)

        g5,f5=_grp('Muskingum-Cunge Routing')
        self.rout=QCheckBox('Enable routing')
        self.mk=QDoubleSpinBox(); self.mk.setRange(0.01,200); self.mk.setValue(1.0); self.mk.setSuffix(' hr')
        self.mx=QDoubleSpinBox(); self.mx.setRange(0,0.5); self.mx.setValue(0.20); self.mx.setDecimals(2)
        f5.addRow('',self.rout); f5.addRow('K (travel time):',self.mk); f5.addRow('X (weighting):',self.mx)
        root.addWidget(g5)

        g5d,f5d=_grp('Sensitivity Analysis (optional)')
        self.run_sens=QCheckBox('Run sensitivity analysis (\u00b120% on CN, Manning\'s n, rainfall, flow path)')
        self.run_sens.setToolTip(
            'Re-runs the analysis with each key input varied up and down by 20% '
            'and reports how much peak discharge moves. Tells you which input is '
            'worth refining, and demonstrates result robustness in a report. '
            'Outputs a CSV table and a tornado diagram. Adds roughly 8 extra '
            'analysis runs, so it takes noticeably longer.'
        )
        f5d.addRow('',self.run_sens)
        root.addWidget(g5d)


        g5c,f5c=_grp('CWC Subzone Coefficients (only for the CWC method)')
        self.cwc_co=QLineEdit()
        self.cwc_co.setPlaceholderText('Ct=0.53,m=0.31,Cq=1.79,nq=0.78,Cw50=2.2,...')
        cwc_note=QLabel(
            'The CWC method uses DIFFERENT regression coefficients for each of '
            'India\'s 26 hydro-meteorological subzones, published in that '
            'subzone\'s own CWC Flood Estimation Report. Enter your subzone\'s '
            'values here.\n'
            'Leave blank and the tool falls back to clearly-flagged placeholder '
            'values and warns you — it will NOT silently substitute another '
            'subzone\'s numbers, because those produce a plausible-looking but '
            'wrong hydrograph with no visible error.'
        )
        cwc_note.setWordWrap(True)
        cwc_note.setStyleSheet(_note_style('warn'))
        f5c.addRow('Coefficients:',self.cwc_co)
        f5c.addRow(cwc_note)
        root.addWidget(g5c)

        g5b,f5b=_grp('Calibration against Observed Data (optional)')
        self.obs_hyd=QLineEdit()
        bobs=QPushButton('Browse'); _sb(bobs,ACCENT2,small=True)
        bobs.clicked.connect(lambda: _bf(self.obs_hyd, self,
                                          'Select Observed Hydrograph CSV',
                                          'CSV files (*.csv);;All files (*.*)'))
        obs_row=QHBoxLayout(); obs_row.addWidget(self.obs_hyd); obs_row.addWidget(bobs)
        obs_note=QLabel(
            'Load a real observed flood hydrograph to check whether the model '
            'actually reproduces it. CSV needs a time column (Time_hr / time / hours) '
            'and a discharge column (Discharge_m3s / discharge / flow / Q).\n'
            'Reports NSE, PBIAS, RMSE, RSR, R² plus peak magnitude and timing error, '
            'rated against Moriasi et al. (2007) guidelines — without this step, '
            'CN / Manning\'s n / method choices are unvalidated estimates.'
        )
        obs_note.setWordWrap(True)
        obs_note.setStyleSheet(_note_style('success'))
        f5b.addRow('Observed hydrograph CSV:',obs_row)
        f5b.addRow(obs_note)
        root.addWidget(g5b)

        g6,f6=_grp('Output')
        self.gm=QCheckBox('Generate flood inundation maps'); self.gm.setChecked(True)
        self.use2d=QCheckBox(
            'Also route hydrograph through 2D diffusive-wave physics '
            '(slower, more realistic)'
        )
        self.use2d.setToolTip(
            'Simulates the flood actually rising, spreading, and receding '
            'over time using each cell\'s own Manning\'s n, instead of one '
            'static water level. Can take from tens of seconds to a couple '
            'of minutes per return period, since the DEM is automatically '
            'coarsened for tractable runtime — see the Help button for '
            'details on the method and its assumptions.'
        )
        self.lr=QCheckBox('Load flood rasters in QGIS'); self.lr.setChecked(True)
        self.eh=QCheckBox('Export HEC-HMS files'); self.eh.setChecked(True)
        self.out=QLineEdit(); bo=QPushButton('Browse'); _sb(bo,ACCENT2,small=True)
        bo.clicked.connect(lambda: _bd(self.out,self))
        ro=QHBoxLayout(); ro.addWidget(self.out); ro.addWidget(bo)
        f6.addRow('',self.gm); f6.addRow('',self.use2d); f6.addRow('',self.lr); f6.addRow('',self.eh)
        f6.addRow('Output folder:',ro); root.addWidget(g6)

        gL,vl=_grp('Log',QVBoxLayout)
        self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setFixedHeight(160)
        self.pb=QProgressBar()
        vl.addWidget(self.log); vl.addWidget(self.pb); root.addWidget(gL)

        g5e,f5e=_grp('Batch Mode (optional)')
        self.batch_on=QCheckBox('Run for EVERY polygon in the catchment layer')
        self.batch_on.setToolTip(
            'Instead of one run on the whole catchment layer, runs the analysis '
            'once per polygon (e.g. every sub-basin from Tab 2), each into its own '
            'output subfolder, plus an aggregate batch_summary.csv comparing them.\n'
            'All other settings on this tab are applied identically to every '
            'catchment, so results are comparable. A failure in one catchment is '
            'recorded and the rest continue.'
        )
        self.batch_field=QLineEdit()
        self.batch_field.setPlaceholderText('Name field for folder names (blank = auto-detect)')
        f5e.addRow('',self.batch_on)
        f5e.addRow('Name field:',self.batch_field)
        root.addWidget(g5e)

        cfg_row=QHBoxLayout()
        b_save=QPushButton('Save Settings...'); _sb(b_save,ACCENT2,small=True)
        b_save.setToolTip('Save every setting on this tab to a JSON file so you '
                          'can reload the same run later without re-entering it all.')
        b_save.clicked.connect(lambda: _save_config_dialog(self,'FlashFlood',self))
        b_load=QPushButton('Load Settings...'); _sb(b_load,ACCENT2,small=True)
        b_load.setToolTip('Reload a previously saved configuration. Layer pickers '
                          'match by layer name, so anything not currently loaded '
                          'in the project is reported rather than silently skipped.')
        b_load.clicked.connect(lambda: _load_config_dialog(self,'FlashFlood',self))
        cfg_row.addWidget(b_save); cfg_row.addWidget(b_load); cfg_row.addStretch()
        root.addLayout(cfg_row)

        run=QPushButton('Run Flash Flood Analysis')
        _sb(run,'#B71C1C'); run.clicked.connect(self._run); root.addWidget(run); root.addStretch()

        _apply_tooltips(self)

    def _run(self):
        self.log.clear()
        out=self.out.text().strip()
        if not out: QMessageBox.warning(self,'Missing','Select output folder.'); return
        c=self.c; cn=self.cn; sr=self.sr
        sr_lyr=sr['rast'].currentLayer()
        try:
            _params = {
                'RAINFALL_SOURCE':self.src.currentIndex(),
                'COORDINATES_MANUAL':f'{self.lat.text()},{self.lon.text()}',
                'START_DATE':self.sd.dateTime(),'END_DATE':self.ed.dateTime(),
                'EXCEL_FILE':self.xls.text(),'DATE_COLUMN':self.dcol.text(),
                'RAINFALL_COLUMN':self.rcol.text(),
                'USE_SPATIAL_RAIN':sr['use'].isChecked(),
                'RAINFALL_RASTER':sr_lyr.source() if sr_lyr else '',
                'ANALYSIS_METHOD':self.method.currentIndex(),
                'STORM_DURATION':self.dur.currentIndex(),
                'RETURN_PERIODS':self.rps.text(),
                'FREQ_METHOD':self.freq.currentIndex(),
                'AMC_CONDITION':self.amc.currentIndex(),
                'CATCHMENT_INPUT':_cat_method_index(c),
                'SNAP_RADIUS':c['snap'].value(),
                'CATCHMENT':_cat_source(c['cat']),'DEM':c['dem'].source(),
                'SLOPE_RASTER':c['slp'].source(),'FLOW_PATH':_cat_source(c['fp']),
                'AREA':c['area'].value(),'SLOPE':c['slope'].value(),
                'CN_RASTER_SOURCE':cn['src'].currentIndex(),
                'CN_RASTER':cn['cn'].source(),'LULC_RASTER':cn['lulc'].source(),
                'LULC_TYPE':cn['ltype'].currentIndex(),
                'MANNING_RASTER':cn['mann'].source(),'HSG':cn['hsg'].currentIndex(),
                'CN':str(cn['cn_v'].value()),'RUNOFF_COEFF':str(cn['c_v'].value()),
                'MANNING_N':str(cn['mn_v'].value()),
                'ENABLE_ROUTING':self.rout.isChecked(),
                'MUSK_K':self.mk.value(),'MUSK_X':self.mx.value(),
                'GENERATE_MAPS':self.gm.isChecked(),'USE_2D_ROUTING':self.use2d.isChecked(),'LOAD_RASTERS':self.lr.isChecked(),
                'OBSERVED_HYDROGRAPH':self.obs_hyd.text().strip(),
                'CWC_COEFFS':self.cwc_co.text().strip(),
                'POUR_POINT_MANUAL':(f"{self.pp_lat.text().strip()},{self.pp_lon.text().strip()}"
                                     if self.pp_lat.text().strip() and self.pp_lon.text().strip() else ''),
                'SUBBASIN_LAYER':self.sub_lyr.currentLayer(),
                'WAVE_CELERITY':self.wave_cel.value(),
                'RUN_SENSITIVITY':self.run_sens.isChecked(),
                'EXPORT_HEC_HMS':self.eh.isChecked(),'OUTPUT_DIR':out,
            }
            if self.batch_on.isChecked():
                cat_lyr = c['cat'].currentLayer()
                if cat_lyr is None:
                    QMessageBox.warning(self,'Missing',
                                        'Batch mode needs a catchment layer selected.')
                    return
                n_feats = cat_lyr.featureCount()
                if n_feats < 2:
                    self.log.append(
                        f'<span style="color:{WARN}">Batch mode is on but this layer '
                        f'has only {n_feats} feature — running normally.</span>')
                else:
                    self.log.append(
                        f'<b>Batch mode: {n_feats} catchments. Each is a full '
                        f'analysis run, so this will take roughly {n_feats}x a '
                        f'single run.</b>')
                    _run_batch_alg(FlashFloodAnalysis, _params, cat_lyr, out,
                                    self.batch_field.text().strip() or None,
                                    self.log, self.pb)
                    self.log.append(
                        f'<b style="color:{SUCCESS}">Batch complete. Per-catchment '
                        f'folders and batch_summary.csv in {out}</b>')
                    return
            _run_alg(FlashFloodAnalysis, _params, self.log, self.pb)
            self.log.append(f'<b style="color:{SUCCESS}">Flash Flood complete. Results in {out}</b>')
        except Exception as e:
            import traceback
            self.log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')


# ═══════════════════════════════════════════════════════════════════════════
#  Tab 5 – Standard Flood
# ═══════════════════════════════════════════════════════════════════════════

class StandardFloodTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent); self.iface=iface
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(10)
        gpp,fpp=_grp('Pour Point / Outlet — where results correspond to')
        self.pp_lat=QLineEdit(); self.pp_lon=QLineEdit()
        self.pp_lat.setPlaceholderText('latitude'); self.pp_lon.setPlaceholderText('longitude')
        pp_btn=PointPickerButton(iface, self.pp_lat, self.pp_lon)
        pp_row=QHBoxLayout()
        pp_row.addWidget(QLabel('Lat:')); pp_row.addWidget(self.pp_lat)
        pp_row.addWidget(QLabel('Lon:')); pp_row.addWidget(self.pp_lon)
        pp_row.addWidget(pp_btn)
        self.sub_lyr=_LC(QgsMapLayerProxyModel.PolygonLayer)
        self.wave_cel=QDoubleSpinBox(); self.wave_cel.setRange(0.1,10.0)
        self.wave_cel.setValue(1.0); self.wave_cel.setDecimals(2); self.wave_cel.setSuffix(' m/s')
        pp_note=QLabel(
            'Set this FIRST — it defines the whole analysis. Every discharge '
            'this tool reports is the flow AT THIS POINT.\n'
            'Choose "Pour Point + DEM (auto-delineate)" under Catchment '
            'Parameters below and the upstream catchment, longest flow path '
            'and channel slope are all derived from this point, so no '
            'catchment polygon is needed. The point is snapped onto the '
            'modelled stream network first — check the reported snap distance, '
            'because a large move means it landed on a different river.\n'
            'Leave blank and the DEM\'s lowest cell is used.\n'
            'Supplying sub-basins from Tab 2 switches the analysis from LUMPED '
            '(whole catchment as one unit, one CN, one time of concentration) to '
            'SEMI-DISTRIBUTED: each sub-basin gets its own CN and timing, is '
            'lagged to the pour point by travel time, and summed there. This '
            'usually gives a LOWER, broader peak, because sub-basins do not all '
            'peak at the same moment — which a lumped calculation assumes they do.'
        )
        pp_note.setWordWrap(True)
        pp_note.setStyleSheet(_note_style('info'))
        fpp.addRow('Pour point:',pp_row)
        fpp.addRow('Sub-basins (Tab 2):',self.sub_lyr)
        fpp.addRow('Wave celerity:',self.wave_cel)
        fpp.addRow(pp_note)
        root.addWidget(gpp)


        g,f=_grp('Rainfall Source')
        self.src=QComboBox(); self.src.addItems(_SA.RAINFALL_SOURCES)
        self.lat=QLineEdit('20.0'); self.lon=QLineEdit('77.0')
        self.sd=QDateTimeEdit(QDateTime(QDate.currentDate().addDays(-3650),QTime(0,0,0)))
        self.ed=QDateTimeEdit(QDateTime(QDate.currentDate(),QTime(0,0,0)))
        self.sd.setCalendarPopup(True); self.ed.setCalendarPopup(True)
        self.xls=QLineEdit(); bx=QPushButton('Browse'); _sb(bx,ACCENT2,small=True)
        bx.clicked.connect(lambda: _bf(self.xls,self,'Daily File','Excel/CSV (*.xlsx *.xls *.csv)'))
        self.chirps=QLineEdit(); bc=QPushButton('Browse'); _sb(bc,ACCENT2,small=True)
        bc.clicked.connect(lambda: _bd(self.chirps,self,'CHIRPS folder'))
        self.dcol=QLineEdit('Date'); self.rcol=QLineEdit('Rainfall_mm')
        rx=QHBoxLayout(); rx.addWidget(self.xls); rx.addWidget(bx)
        rc=QHBoxLayout(); rc.addWidget(self.chirps); rc.addWidget(bc)
        f.addRow('Source:',self.src)
        f.addRow('Lat, Lon:',_coord_row(iface,self.lat,self.lon))
        f.addRow('Start:',self.sd); f.addRow('End:',self.ed)
        f.addRow('Excel/CSV:',rx); f.addRow('CHIRPS folder:',rc)
        f.addRow('Date column:',self.dcol); f.addRow('Rainfall column:',self.rcol)
        root.addWidget(g)

        gs,self.sr=_spatial_rain_grp(); root.addWidget(gs)

        g2,f2=_grp('Analysis')
        self.method=QComboBox(); self.method.addItems(_SA.ANALYSIS_METHODS)
        self.reg=QComboBox(); self.reg.addItems(_SA.REGIONAL_METHODS)
        self.reg.setToolTip(
            'Middle East Wadi: enter your CN as the standard AMC-II value — '
            'the arid-region AMC-I conversion (drier antecedent conditions) '
            'is applied automatically inside this method, you don\'t need '
            'to convert it yourself.'
        )
        self.rps=QLineEdit('2,5,10,25,50,100,200')
        self.freq=QComboBox(); self.freq.addItems(_SA.FREQ_METHODS); self.freq.setCurrentIndex(1)
        self.freq.setToolTip(
            'Auto (best fit by AIC) fits Gumbel, Log-Pearson III, GEV, and '
            'Log-Normal and picks whichever fits this record best, instead of '
            'always using one fixed distribution. Every option also reports a '
            '90% confidence interval and runs Mann-Kendall trend / Grubbs-Beck '
            'outlier checks automatically — see the log and the \'Frequency '
            'Uncertainty\' sheet in the output Excel file.'
        )
        self.amc=QComboBox(); self.amc.addItems(_SA.AMC_OPTIONS); self.amc.setCurrentIndex(1)
        self.dst=QComboBox(); self.dst.addItems(_SA.DESIGN_STORMS)
        f2.addRow('Method:',self.method); f2.addRow('Regional standard:',self.reg)
        f2.addRow('Return periods (yr):',self.rps); f2.addRow('Frequency method:',self.freq)
        f2.addRow('AMC:',self.amc); f2.addRow('Design storm type:',self.dst)
        root.addWidget(g2)

        gc,self.c=_cat_grp(); root.addWidget(gc)
        gcn,self.cn=_cn_grp(_SA); root.addWidget(gcn)

        g5,f5=_grp('Regional Parameters')
        self.saar=QDoubleSpinBox(); self.saar.setRange(100,5000); self.saar.setValue(800); self.saar.setSuffix(' mm')
        self.sc=QComboBox(); self.sc.addItems(_SA.SOIL_CLASSES); self.sc.setCurrentIndex(2)
        self.ux=QDoubleSpinBox(); self.ux.setRange(0,1); self.ux.setValue(0.10); self.ux.setDecimals(3)
        self.c10=QDoubleSpinBox(); self.c10.setRange(0.05,1.0); self.c10.setValue(0.45); self.c10.setDecimals(3)
        self.ia=QDoubleSpinBox(); self.ia.setRange(1,1e5); self.ia.setValue(1200)
        self.ib=QDoubleSpinBox(); self.ib.setRange(0.1,100); self.ib.setValue(10)
        self.ic=QDoubleSpinBox(); self.ic.setRange(0.1,3.0); self.ic.setValue(0.75); self.ic.setDecimals(3)
        f5.addRow('FEH SAAR:',self.saar); f5.addRow('FEH HOST soil class:',self.sc)
        f5.addRow('FEH URBEXT:',self.ux); f5.addRow('ARR/NZ C10:',self.c10)
        f5.addRow('Canada IDF a:',self.ia); f5.addRow('Canada IDF b:',self.ib)
        f5.addRow('Canada IDF c:',self.ic)
        root.addWidget(g5)

        gob,fob=_grp('Calibration against Observed Data (optional)')
        self.obs_hyd=QLineEdit()
        bobs2=QPushButton('Browse'); _sb(bobs2,ACCENT2,small=True)
        bobs2.clicked.connect(lambda: _bf(self.obs_hyd, self,
                                           'Select Observed Hydrograph CSV',
                                           'CSV files (*.csv);;All files (*.*)'))
        obr=QHBoxLayout(); obr.addWidget(self.obs_hyd); obr.addWidget(bobs2)
        fob.addRow('Observed hydrograph CSV:',obr)
        root.addWidget(gob)


        g6,f6=_grp('Routing and Output')
        self.rout=QCheckBox('Muskingum-Cunge routing')
        self.mk=QDoubleSpinBox(); self.mk.setRange(0.01,200); self.mk.setValue(2.0); self.mk.setSuffix(' hr')
        self.mx=QDoubleSpinBox(); self.mx.setRange(0,0.5); self.mx.setValue(0.20); self.mx.setDecimals(2)
        self.gm=QCheckBox('Generate flood maps'); self.gm.setChecked(True)
        self.use2d=QCheckBox(
            'Also route hydrograph through 2D diffusive-wave physics '
            '(slower, more realistic)'
        )
        self.use2d.setToolTip(
            'Simulates the flood actually rising, spreading, and receding '
            'over time using each cell\'s own Manning\'s n, instead of one '
            'static water level. Can take from tens of seconds to a couple '
            'of minutes per return period, since the DEM is automatically '
            'coarsened for tractable runtime — see the Help button for '
            'details on the method and its assumptions.'
        )
        self.lr=QCheckBox('Load rasters in QGIS'); self.lr.setChecked(True)
        self.eh=QCheckBox('Export HEC-HMS files'); self.eh.setChecked(True)
        self.out=QLineEdit(); bo=QPushButton('Browse'); _sb(bo,ACCENT2,small=True)
        bo.clicked.connect(lambda: _bd(self.out,self))
        ro=QHBoxLayout(); ro.addWidget(self.out); ro.addWidget(bo)
        f6.addRow('',self.rout); f6.addRow('K (hr):',self.mk); f6.addRow('X:',self.mx)
        f6.addRow('',self.gm); f6.addRow('',self.use2d); f6.addRow('',self.lr); f6.addRow('',self.eh)
        f6.addRow('Output folder:',ro); root.addWidget(g6)

        gL,vl=_grp('Log',QVBoxLayout)
        self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setFixedHeight(160)
        self.pb=QProgressBar()
        vl.addWidget(self.log); vl.addWidget(self.pb); root.addWidget(gL)

        cfg_row=QHBoxLayout()
        b_save=QPushButton('Save Settings...'); _sb(b_save,ACCENT2,small=True)
        b_save.setToolTip('Save every setting on this tab to a JSON file so you '
                          'can reload the same run later without re-entering it all.')
        b_save.clicked.connect(lambda: _save_config_dialog(self,'StandardFlood',self))
        b_load=QPushButton('Load Settings...'); _sb(b_load,ACCENT2,small=True)
        b_load.setToolTip('Reload a previously saved configuration. Layer pickers '
                          'match by layer name, so anything not currently loaded '
                          'in the project is reported rather than silently skipped.')
        b_load.clicked.connect(lambda: _load_config_dialog(self,'StandardFlood',self))
        cfg_row.addWidget(b_save); cfg_row.addWidget(b_load); cfg_row.addStretch()
        root.addLayout(cfg_row)

        run=QPushButton('Run Standard Flood Analysis')
        _sb(run,'#1B5E20'); run.clicked.connect(self._run); root.addWidget(run); root.addStretch()

        _apply_tooltips(self)

    def _run(self):
        self.log.clear()
        out=self.out.text().strip()
        if not out: QMessageBox.warning(self,'Missing','Select output folder.'); return
        c=self.c; cn=self.cn; sr=self.sr
        sr_lyr=sr['rast'].currentLayer()
        try:
            _run_alg(StandardFloodAnalysis,{
                'RAINFALL_SOURCE':self.src.currentIndex(),
                'COORDINATES_MANUAL':f'{self.lat.text()},{self.lon.text()}',
                'START_DATE':self.sd.dateTime(),'END_DATE':self.ed.dateTime(),
                'EXCEL_FILE':self.xls.text(),'DATE_COLUMN':self.dcol.text(),
                'RAINFALL_COLUMN':self.rcol.text(),'CHIRPS_FOLDER':self.chirps.text(),
                'USE_SPATIAL_RAIN':sr['use'].isChecked(),
                'RAINFALL_RASTER':sr_lyr.source() if sr_lyr else '',
                'ANALYSIS_METHOD':self.method.currentIndex(),
                'REGIONAL_METHOD':self.reg.currentIndex(),
                'RETURN_PERIODS':self.rps.text(),
                'FREQ_METHOD':self.freq.currentIndex(),
                'AMC_CONDITION':self.amc.currentIndex(),
                'DESIGN_STORM_TYPE':self.dst.currentIndex(),
                'CATCHMENT_INPUT':_cat_method_index(c),
                'SNAP_RADIUS':c['snap'].value(),
                'CATCHMENT':_cat_source(c['cat']),'DEM':c['dem'].source(),
                'SLOPE_RASTER':c['slp'].source(),'FLOW_PATH':_cat_source(c['fp']),
                'AREA':c['area'].value(),'SLOPE':c['slope'].value(),
                'CN_RASTER_SOURCE':cn['src'].currentIndex(),
                'CN_RASTER':cn['cn'].source(),'LULC_RASTER':cn['lulc'].source(),
                'LULC_TYPE':cn['ltype'].currentIndex(),
                'MANNING_RASTER':cn['mann'].source(),'HSG':cn['hsg'].currentIndex(),
                'CN':str(cn['cn_v'].value()),'RUNOFF_COEFF':str(cn['c_v'].value()),
                'MANNING_N':str(cn['mn_v'].value()),
                'SAAR':self.saar.value(),'SOIL_CLASS':self.sc.currentIndex(),
                'URBEXT':self.ux.value(),'C10':self.c10.value(),
                'IDF_A':self.ia.value(),'IDF_B':self.ib.value(),'IDF_C':self.ic.value(),
                'ENABLE_ROUTING':self.rout.isChecked(),
                'MUSK_K':self.mk.value(),'MUSK_X':self.mx.value(),
                'GENERATE_MAPS':self.gm.isChecked(),'USE_2D_ROUTING':self.use2d.isChecked(),'LOAD_RASTERS':self.lr.isChecked(),
                'POUR_POINT_MANUAL':(f"{self.pp_lat.text().strip()},{self.pp_lon.text().strip()}"
                                     if self.pp_lat.text().strip() and self.pp_lon.text().strip() else ''),
                'SUBBASIN_LAYER':self.sub_lyr.currentLayer(),
                'WAVE_CELERITY':self.wave_cel.value(),
                'OBSERVED_HYDROGRAPH':self.obs_hyd.text().strip(),
                'EXPORT_HEC_HMS':self.eh.isChecked(),'OUTPUT_DIR':out,
            }, self.log, self.pb)
            self.log.append(f'<b style="color:{SUCCESS}">Standard Flood complete. Results in {out}</b>')
        except Exception as e:
            import traceback
            self.log.append(f'<span style="color:{LOG_ERROR}">{e}</span>')
            self.log.append(f'<pre style="font-size:10px">{traceback.format_exc()}</pre>')


# ═══════════════════════════════════════════════════════════════════════════
#  About
# ═══════════════════════════════════════════════════════════════════════════

class AboutTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root=QVBoxLayout(self); root.setContentsMargins(30,20,30,20)
        root.addWidget(_lbl('Rain2Flood  v3.0', bold=True, color=ACCENT))
        root.addWidget(QLabel('Rainfall-Runoff and Flood Analysis QGIS Plugin'))

        credit = QLabel(
            f'Cooked by <a href="{LINKEDIN_URL}" style="color:{ACCENT};'
            f'text-decoration:none"><b>Rahul Pandey</b></a> &nbsp;·&nbsp; '
            f'<a href="{GITHUB_URL}" style="color:{ACCENT};'
            f'text-decoration:none">GitHub</a>')
        credit.setTextFormat(_Qt_RichText)
        credit.setOpenExternalLinks(True)
        credit.setStyleSheet(f'color:{TEXT_DIM};font-size:12px;')
        root.addWidget(credit)

        te = QTextEdit(); te.setReadOnly(True)
        te.setHtml(f"""
<h3 style="color:{ACCENT_DEEP}">Tabs and Workflow</h3>
<ol>
<li><b>DEM and Slope</b> – Reproject to a projected CRS, nodata-aware Horn's-method
slope computed before any clip, void/sentinel detection, catchment statistics</li>
<li><b>Streams and Sub-basins</b> – GRASS r.watershed + r.to.vect, Strahler order
from vector topology, sub-basin delineation. Catchment boundary optional</li>
<li><b>CN / LULC</b> – ESA WorldCover download (AWS), NLCD/CORINE/MODIS tables,
CN and Manning's rasters, AMC I/II/III adjustment. Takes an <b>extent</b>,
not a catchment</li>
<li><b>Flash Flood</b> – SCS Triangular UH, NRCS Dimensionless UH, Snyder, Clark
IUH, Rational, Wadi; IDF; ABM; HEC-HMS export</li>
<li><b>Standard Flood</b> – Daily analysis; UK FEH, Australia ARR2019, Canada MTO,
NZ NIWA, Middle East Wadi; SCS Type-II / ABM / Chicago; flood inundation maps</li>
</ol>
<p><b>Rainfall Data</b> is a standalone utility, not a pipeline step — the
flood tabs fetch their own rainfall when they run.</p>

<h3 style="color:{ACCENT_DEEP}">Pour-Point Workflow</h3>
<p>Set a pour point in Tab 4 or 5 and choose <b>Pour Point + DEM
(auto-delineate)</b>. The upstream catchment, the longest flow path and the
channel slope are all derived from that one point — no catchment polygon
needed anywhere in the plugin. The point is snapped to the modelled stream
network first; check the reported snap distance, because a large jump means
it landed on a different river.</p>

<h3 style="color:{ACCENT_DEEP}">What's New in 3.0</h3>
<p>{CHANGELOG_HTML}</p>

<h3 style="color:{ACCENT_DEEP}">ESA WorldCover Note</h3>
<p>If tile download fails (404 or network error), download tiles manually from
<b>viewer.esa-worldcover.org</b> and use "Derive from Existing LULC Raster"
in Tab 3 (CN / LULC).</p>
""")
        root.addWidget(te)
