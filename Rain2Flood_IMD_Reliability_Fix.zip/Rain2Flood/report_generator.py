"""
Report Generator
================
Assembles a single self-contained HTML report from whatever analysis
outputs actually exist, so results can be handed to a client, reviewer,
or regulator without them having to open a folder of loose PNGs, CSVs
and spreadsheets.

Design notes:

- HTML, not PDF. A PDF writer would need an extra dependency
  (reportlab/weasyprint) that isn't currently required and that users
  would have to install separately — for a plugin whose dependency list
  is already a friction point, that's a poor trade. HTML opens in any
  browser, prints to PDF from there (Ctrl+P), and is trivially
  emailable. Images are embedded as base64 so the file is genuinely
  self-contained rather than breaking the moment it's moved.

- Everything is OPTIONAL and discovered, not assumed. Sections appear
  only when the underlying output actually exists on disk. A report that
  silently shows an empty "Calibration" heading because the user didn't
  run calibration is worse than one that just omits it.

- The report states its own assumptions and limitations rather than
  presenting numbers as more authoritative than they are. That's a
  professional-practice requirement, not decoration: whoever reads this
  needs to know it's screening-level output from simplified methods.
"""

import os
import base64
import datetime


def _img_b64(path, max_bytes=6_000_000):
    """
    Embed an image as a base64 data URI so the report is self-contained.
    Skips anything implausibly large — a handful of very high-res maps
    could otherwise produce a report too big to email, which defeats the
    point of a single shareable file.
    """
    try:
        if not path or not os.path.exists(path):
            return None
        if os.path.getsize(path) > max_bytes:
            return None
        with open(path, 'rb') as f:
            return 'data:image/png;base64,' + base64.b64encode(f.read()).decode('ascii')
    except Exception:
        return None


def _csv_to_html_table(path, max_rows=60):
    """Render a CSV as an HTML table, truncating very long ones so the
    report stays readable (the full CSV is always still on disk)."""
    try:
        import pandas as pd
        df = pd.read_csv(path)
    except Exception:
        return None
    truncated = len(df) > max_rows
    if truncated:
        df = df.head(max_rows)
    html = df.to_html(index=False, border=0, classes='data', float_format=lambda v: f'{v:,.3f}')
    if truncated:
        html += (f'<p class="note">Showing first {max_rows} rows — '
                 f'see the CSV file for the complete table.</p>')
    return html


def _df_to_html_table(df):
    try:
        return df.to_html(index=False, border=0, classes='data',
                          float_format=lambda v: f'{v:,.3f}')
    except Exception:
        return None


_CSS = """
body { font-family: -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
       color: #2C3E50; max-width: 1100px; margin: 0 auto; padding: 32px 24px;
       line-height: 1.55; background: #fff; }
h1 { color: #0D47A1; border-bottom: 3px solid #0D47A1; padding-bottom: 10px;
     margin-bottom: 4px; font-size: 26px; }
h2 { color: #1565C0; margin-top: 34px; border-bottom: 1px solid #D5D8DC;
     padding-bottom: 6px; font-size: 19px; }
h3 { color: #2C3E50; margin-top: 22px; font-size: 15px; }
.subtitle { color: #5D6D7E; font-size: 13px; margin-top: 0; }
table.data { border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 13px; }
table.data th { background: #0D47A1; color: #fff; padding: 8px 10px;
                text-align: left; font-weight: 600; }
table.data td { padding: 6px 10px; border-bottom: 1px solid #E5E8EA; }
table.data tr:nth-child(even) td { background: #FAFBFC; }
.meta { background: #F4F6F7; border-left: 4px solid #1565C0; padding: 12px 16px;
        margin: 16px 0; font-size: 13px; }
.meta dt { font-weight: 600; float: left; width: 210px; clear: left; }
.meta dd { margin-left: 220px; margin-bottom: 4px; }
.limits { background: #FFF8E1; border-left: 4px solid #F39C12; padding: 14px 18px;
          margin: 20px 0; font-size: 13px; }
.limits h3 { margin-top: 0; color: #8A6D1B; }
img.fig { max-width: 100%; border: 1px solid #D5D8DC; border-radius: 4px;
          margin: 10px 0 4px 0; }
.caption { font-size: 12px; color: #5D6D7E; margin: 0 0 18px 0; }
.note { font-size: 12px; color: #5D6D7E; font-style: italic; }
footer { margin-top: 40px; padding-top: 14px; border-top: 1px solid #D5D8DC;
         font-size: 12px; color: #5D6D7E; }
@media print { body { padding: 0; } h2 { page-break-after: avoid; }
                img.fig { page-break-inside: avoid; } }
"""


def generate_html_report(output_dir, analysis_type, metadata, results_df=None,
                          feedback=None):
    """
    Build an HTML report from whatever outputs exist in output_dir.

    Parameters
    ----------
    output_dir    : the analysis output folder (scanned for artifacts)
    analysis_type : 'Flash Flood' or 'Standard Flood'
    metadata      : dict of run settings to document (catchment area,
                    CN, method, etc.) — this is what makes the report
                    reproducible rather than just a pile of numbers
    results_df    : the main results DataFrame (optional)

    Returns the report path, or None on failure.
    """
    try:
        parts = []
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')

        parts.append(f"<h1>{analysis_type} Analysis Report</h1>")
        parts.append(f'<p class="subtitle">Generated by Rain2Flood on {now}</p>')

        section_n = 1

        # ── Run metadata: what was actually run, so it's reproducible ──
        if metadata:
            parts.append(f"<h2>{section_n}. Analysis Setup</h2>")
            section_n += 1
            parts.append('<div class="meta"><dl>')
            for k, v in metadata.items():
                parts.append(f"<dt>{k}</dt><dd>{v}</dd>")
            parts.append("</dl></div>")

        # ── Results table ──
        if results_df is not None:
            tbl = _df_to_html_table(results_df)
            if tbl:
                parts.append(f"<h2>{section_n}. Design Flood Results</h2>")
                section_n += 1
                parts.append(tbl)

        # ── Frequency uncertainty (only if the Excel sheet was written) ──
        xlsx_candidates = [
            os.path.join(output_dir, 'Flash_Flood_Analysis_Results.xlsx'),
            os.path.join(output_dir, 'Standard_Flood_Analysis_Results.xlsx'),
        ]
        for xp in xlsx_candidates:
            if not os.path.exists(xp):
                continue
            try:
                import pandas as pd
                sheets = pd.read_excel(xp, sheet_name=None)
                if 'Frequency Uncertainty' in sheets:
                    df_ci = sheets['Frequency Uncertainty']
                    if not df_ci.empty:
                        parts.append(f"<h2>{section_n}. Frequency Analysis and Uncertainty</h2>")
                        parts.append(
                            "<p>Design rainfall depths with 90% bootstrap confidence "
                            "intervals, and the probability distribution selected for "
                            "each duration. Wide intervals indicate a short record — "
                            "the design value is still the best estimate, but the "
                            "uncertainty around it is real and should inform how much "
                            "freeboard or conservatism is applied.</p>")
                        parts.append(_df_to_html_table(df_ci) or '')
                        section_n += 1
            except Exception:
                pass
            break

        # ── Figures: IDF, hydrographs, sensitivity, calibration, maps ──
        figures = []
        idf = os.path.join(output_dir, 'IDF_DDF_Curves.png')
        if os.path.exists(idf):
            figures.append((idf, 'Intensity-Duration-Frequency curves fitted to the '
                                  'analysed rainfall record.'))

        hydro_dir = os.path.join(output_dir, 'hydrographs')
        if os.path.isdir(hydro_dir):
            for fn in sorted(os.listdir(hydro_dir)):
                if fn.lower().endswith('.png'):
                    figures.append((os.path.join(hydro_dir, fn),
                                     f'Hydrograph output: {fn}'))

        if figures:
            parts.append(f"<h2>{section_n}. Rainfall and Hydrograph Analysis</h2>")
            section_n += 1
            for path, cap in figures:
                b64 = _img_b64(path)
                if b64:
                    parts.append(f'<img class="fig" src="{b64}" alt="{cap}"/>')
                    parts.append(f'<p class="caption">{cap}</p>')

        # ── Calibration (only if the user actually ran it) ──
        calib_csv = os.path.join(output_dir, 'calibration', 'calibration_metrics.csv')
        calib_png = os.path.join(output_dir, 'calibration', 'observed_vs_simulated.png')
        if os.path.exists(calib_csv):
            parts.append(f"<h2>{section_n}. Calibration Against Observed Data</h2>")
            section_n += 1
            parts.append(
                "<p>Model performance measured against a real observed event. "
                "Ratings follow Moriasi et al. (2007): NSE &gt; 0.50 and "
                "|PBIAS| &lt; 25% are the thresholds for 'satisfactory' streamflow "
                "simulation. Note PBIAS sign convention here is "
                "<em>positive = model under-estimates</em>.</p>")
            t = _csv_to_html_table(calib_csv)
            if t:
                parts.append(t)
            b64 = _img_b64(calib_png)
            if b64:
                parts.append(f'<img class="fig" src="{b64}" alt="Observed vs simulated"/>')
                parts.append('<p class="caption">Observed versus simulated hydrograph '
                             'for the best-matching return period.</p>')

        # ── Sensitivity (only if run) ──
        sens_csv = os.path.join(output_dir, 'sensitivity', 'sensitivity_analysis.csv')
        sens_png = os.path.join(output_dir, 'sensitivity', 'sensitivity_tornado.png')
        if os.path.exists(sens_csv):
            parts.append(f"<h2>{section_n}. Sensitivity Analysis</h2>")
            section_n += 1
            parts.append(
                "<p>One-at-a-time sensitivity showing how much peak discharge moves "
                "when each input is varied. Elasticity is the percentage change in "
                "peak discharge per percentage change in the input, so parameters "
                "measured in different units can be ranked directly. The highest-"
                "elasticity parameter is where refinement effort pays off most.</p>")
            t = _csv_to_html_table(sens_csv)
            if t:
                parts.append(t)
            b64 = _img_b64(sens_png)
            if b64:
                parts.append(f'<img class="fig" src="{b64}" alt="Sensitivity tornado"/>')
                parts.append('<p class="caption">Tornado diagram of parameter '
                             'sensitivity.</p>')

        # ── Flood maps ──
        maps_dir = os.path.join(output_dir, 'flood_maps')
        if os.path.isdir(maps_dir):
            map_files = [f for f in sorted(os.listdir(maps_dir)) if f.lower().endswith('.png')]
            if map_files:
                parts.append(f"<h2>{section_n}. Flood Inundation Maps</h2>")
                section_n += 1
                parts.append(
                    "<p>Screening-level flood extent and depth. Depth &times; velocity "
                    "hazard classification (where produced) follows the UK Defra/"
                    "Environment Agency FD2320/FD2321 methodology.</p>")
                for fn in map_files:
                    b64 = _img_b64(os.path.join(maps_dir, fn))
                    if b64:
                        parts.append(f'<img class="fig" src="{b64}" alt="{fn}"/>')
                        parts.append(f'<p class="caption">{fn}</p>')

        # ── Limitations: stated plainly, not buried ──
        parts.append(f"<h2>{section_n}. Methods, Assumptions and Limitations</h2>")
        parts.append("""
<div class="limits">
<h3>Read this before using these numbers</h3>
<ul>
<li><strong>Screening-level tool.</strong> Flood extent and depth are produced by a
    simplified HAND (Height Above Nearest Drainage) approach with a Manning's-equation
    depth estimate, not a full 2D hydraulic solve. Use HEC-RAS 2D, TUFLOW, InfoWorks ICM
    or equivalent for design or regulatory submissions.</li>
<li><strong>Uncalibrated unless stated.</strong> If no calibration section appears above,
    the model has not been checked against any observed event for this catchment, and
    the CN / Manning's n / method choices are unvalidated estimates.</li>
<li><strong>Short records give wide uncertainty.</strong> Design values derived from
    10&ndash;20 years of record carry substantial uncertainty at 100-year return periods.
    The confidence intervals reported above are the honest range, not a formality.</li>
<li><strong>Rainfall source matters.</strong> Reanalysis and satellite products
    (ERA5, IMD gridded, CHIRPS) can differ materially from local gauge records,
    particularly for short-duration extremes.</li>
<li><strong>Regional methods need regional coefficients.</strong> Methods such as CWC
    (India) use subzone-specific coefficients. If placeholder coefficients were used,
    that is flagged in the analysis log and the results are indicative only.</li>
</ul>
</div>""")

        parts.append(
            "<footer>Generated by the Rain2Flood QGIS plugin. This report is a summary "
            "of automated analysis output; it does not constitute a certified flood "
            "study and should be reviewed by a qualified hydrologist before use in "
            "design or planning decisions.</footer>")

        html = (f"<!DOCTYPE html><html><head><meta charset='utf-8'>"
                f"<title>{analysis_type} Report — Rain2Flood</title>"
                f"<style>{_CSS}</style></head><body>"
                + '\n'.join(parts) + "</body></html>")

        report_path = os.path.join(
            output_dir, f"{analysis_type.replace(' ', '_')}_Report.html")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html)

        if feedback:
            size_mb = os.path.getsize(report_path) / 1e6
            feedback.pushInfo(
                f"  Report saved: {os.path.basename(report_path)} ({size_mb:.1f} MB) "
                f"— open in a browser; print to PDF from there if you need one.")
        return report_path

    except Exception as e:
        if feedback:
            feedback.pushWarning(f"  Report generation failed: {e}")
        return None
