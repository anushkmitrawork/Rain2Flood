"""
Hydrological Calculations  – Rain2Flood v3.0
=======================================================
Methods and corrections:
  - SCS/NRCS: NEH-4 (correct Ia=0.2S, lag equation in ft/in/%)
  - Snyder: corrected to miles as per original Snyder (1938)
  - Clark IUH: correct time-area curve and linear reservoir routing
  - NRCS Dimensionless UH: NEH-4 Exhibit 16-1
  - Green-Ampt: corrected Mein-Larson two-phase model
  - Muskingum-Cunge: standard formulation (C0+C1+C2=1 verified)
  - IDF: power-law curve_fit
  - UK FEH parametric (planning-grade)
  - ARR2019 PRM, Canada, NZ
  - Middle East Wadi (Ia=0.05S for arid)
  - L-moments GEV (Hosking 1990)
"""

import numpy as np
from scipy.stats import genextreme, gumbel_r, pearson3


def _trapz(y, x):
    """Version-agnostic trapezoidal integration (np.trapz removed in NumPy 2.0)."""
    if hasattr(np, 'trapezoid'):
        return np.trapezoid(y, x)
    if hasattr(np, 'trapz'):
        return np.trapz(y, x)
    y = np.asarray(y, dtype=np.float64); x = np.asarray(x, dtype=np.float64)
    return float(np.sum((x[1:]-x[:-1]) * (y[1:]+y[:-1]) / 2.0))


# ============================================================================
# 1.  FREQUENCY ANALYSIS
# ============================================================================

def frequency_analysis(data, return_periods, method, feedback):
    """Fit distribution to annual-maximum data and return design values."""
    data = np.asarray(data, dtype=np.float64)
    data = data[np.isfinite(data) & (data > 0)]
    if len(data) == 0:
        raise ValueError("No valid data for frequency analysis.")
    if len(data) < 10:
        feedback.pushWarning(f"Only {len(data)} data points – results may be unreliable.")
    # Remove gross outliers (>6σ)
    mu, sig = np.mean(data), np.std(data)
    if sig > 0:
        data = data[np.abs(data - mu) <= 6 * sig]

    feedback.pushInfo(
        f"Freq analysis: n={len(data)}, mean={np.mean(data):.2f}, "
        f"max={np.max(data):.2f}, cv={np.std(data)/np.mean(data):.3f}"
    )
    rps       = np.asarray(return_periods, dtype=float)
    exc_prob  = 1.0 - 1.0 / rps        # non-exceedance probability
    design    = None
    dist_name = ''
    params    = []

    try:
        if method == 1:   # Gumbel EV1
            params = gumbel_r.fit(data)
            design = gumbel_r.ppf(exc_prob, *params)
            dist_name = 'Gumbel (EV1)'
        elif method == 2: # Log-Pearson III
            log_d = np.log(data)
            params = pearson3.fit(log_d)
            design = np.exp(pearson3.ppf(exc_prob, *params))
            dist_name = 'Log-Pearson III'
        elif method == 3: # GEV MLE
            params = genextreme.fit(data)
            design = genextreme.ppf(exc_prob, *params)
            dist_name = 'GEV (MLE)'
        elif method == 4: # GEV L-moments
            l1, l2, t3 = _lmoments(data)
            params = _gev_from_lmoments(l1, l2, t3)
            design = genextreme.ppf(exc_prob, *params)
            dist_name = 'GEV (L-moments)'
        else:
            raise ValueError(f"Unknown method {method}")

        design = np.asarray(design, dtype=float)
        if not np.all(np.isfinite(design)):
            raise ValueError("Non-finite design values.")
    except Exception as e:
        feedback.pushWarning(f"Distribution fit failed ({e}). Falling back to Gumbel.")
        try:
            params = gumbel_r.fit(data)
            design = gumbel_r.ppf(exc_prob, *params)
            dist_name = 'Gumbel (fallback)'
        except Exception:
            design = empirical_frequency_analysis(data, return_periods, feedback)
            dist_name = 'Empirical'

    cap    = np.max(data) * 4.0
    design = np.clip(design, 0, cap)
    for rp, dr in zip(return_periods, design):
        feedback.pushInfo(f"  T={rp:5d} yr → {dr:.2f} mm  [{dist_name}]")
    return design, dist_name, params


def mann_kendall_test(data, alpha=0.05):
    """
    Mann-Kendall non-parametric trend test (Mann 1945, Kendall 1975) —
    standard practice before accepting a flow/rainfall record as
    representative for frequency analysis: a strong monotonic trend
    means the record isn't really drawn from one stationary distribution,
    which the whole frequency-analysis framework assumes.

    S = sum over all pairs i<j of sign(x_j - x_i)
    Var(S) = n(n-1)(2n+5)/18 (no tie-correction — annual-maxima series
             from continuous measurements essentially never have exact
             ties, so this is the standard simplification)
    Z = (S-1)/sqrt(Var(S))  if S>0
        (S+1)/sqrt(Var(S))  if S<0
        0                   if S==0
    p = 2*(1-Phi(|Z|))  (two-tailed)

    Returns dict: trend ('increasing'/'decreasing'/'no trend'),
    p_value, S, z_score, significant (bool, p < alpha).
    """
    from scipy.stats import norm
    x = np.asarray(data, dtype=np.float64)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 4:
        return {'trend': 'no trend', 'p_value': 1.0, 'S': 0, 'z_score': 0.0,
                'significant': False, 'note': 'Too few points (<4) for a meaningful trend test.'}

    s = 0
    for i in range(n - 1):
        s += np.sum(np.sign(x[i+1:] - x[i]))

    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    p_value = 2 * (1 - norm.cdf(abs(z)))
    significant = p_value < alpha

    if not significant:
        trend = 'no trend'
    else:
        trend = 'increasing' if s > 0 else 'decreasing'

    return {'trend': trend, 'p_value': float(p_value), 'S': float(s),
            'z_score': float(z), 'significant': bool(significant)}


def grubbs_beck_test(data, alpha=0.10):
    """
    Grubbs-Beck one-sided low-outlier test, US Bulletin 17B/17C
    convention: works in LOG space (standard for flood/rainfall data),
    flags values below a critical threshold as low outliers that
    (per Bulletin 17C guidance) are typically conditioned on rather
    than simply discarded — this function only IDENTIFIES them and
    reports the threshold; it does not remove anything itself.

    Critical deviate K_N via the standard Bonferroni-corrected
    Student's t approximation:
        K_N = t_(alpha/N, N-2) * (N-1) / sqrt(N * (N-2+t^2))
    threshold_low = exp(mean(log x) - K_N * std(log x))

    Returns dict: threshold (in original units), low_outliers (values
    below threshold), n_outliers, K_N.
    """
    from scipy.stats import t as student_t
    x = np.asarray(data, dtype=np.float64)
    x = x[np.isfinite(x) & (x > 0)]
    n = len(x)
    if n < 10:
        return {'threshold': None, 'low_outliers': np.array([]), 'n_outliers': 0,
                'K_N': None, 'note': 'Need at least 10 points for a reliable Grubbs-Beck test.'}

    log_x = np.log(x)
    mean_log, std_log = np.mean(log_x), np.std(log_x, ddof=1)

    t_crit = student_t.ppf(1 - alpha / n, n - 2)
    K_N = t_crit * (n - 1) / np.sqrt(n * (n - 2 + t_crit ** 2))

    threshold = np.exp(mean_log - K_N * std_log)
    low_outliers = x[x < threshold]

    return {'threshold': float(threshold), 'low_outliers': low_outliers,
            'n_outliers': int(len(low_outliers)), 'K_N': float(K_N)}


def _aic_for_fit(data, dist, params, log_jacobian_data=None):
    """
    Akaike Information Criterion for a fitted scipy distribution — lower
    is better. Penalises extra parameters (GEV/LP3 have 3, Gumbel has
    2), so distributions with more flexibility don't win just by
    over-fitting a small sample.

    log_jacobian_data: pass the ORIGINAL (untransformed) data when
    `dist`/`params` were fit to a TRANSFORMED version of it (e.g. LP3
    fit to log(data)) — comparing likelihoods across a transformed and
    an untransformed fit isn't valid without the Jacobian correction
    from the change-of-variables formula: for Y=log(X),
    log f_X(x) = log f_Y(log x) - log(x). Omitting this systematically
    and massively overstates the transformed model's likelihood
    (confirmed directly: an ~-4 log-likelihood without the correction
    vs. the correct ~-104, a mistake large enough to make LP3 "win"
    against every other distribution regardless of actual fit quality).
    """
    k = len(params)
    log_lik = np.sum(dist.logpdf(data, *params))
    if log_jacobian_data is not None:
        log_lik -= np.sum(np.log(log_jacobian_data))
    if not np.isfinite(log_lik):
        return np.inf
    return 2 * k - 2 * log_lik


def select_best_distribution(data, feedback=None):
    """
    Fit Gumbel, Log-Pearson III, GEV (MLE), and Log-Normal to the data
    and pick the best by AIC, rather than always defaulting to Gumbel
    regardless of whether it actually fits. Reports every candidate's
    AIC for transparency (a close call between two distributions is
    itself useful information — it means the record is short enough
    that distribution choice is genuinely uncertain).

    Returns (method_code, dist_name, params, comparison_table) where
    method_code matches frequency_analysis()'s existing method
    parameter (1=Gumbel, 2=LP3, 3=GEV MLE), so the result can be fed
    straight back into the existing fitting/design-value code.
    """
    from scipy.stats import lognorm
    data = np.asarray(data, dtype=np.float64)
    data = data[np.isfinite(data) & (data > 0)]
    candidates = []

    try:
        p = gumbel_r.fit(data)
        candidates.append((1, 'Gumbel (EV1)', gumbel_r, p, _aic_for_fit(data, gumbel_r, p)))
    except Exception:
        pass
    try:
        log_d = np.log(data)
        p = pearson3.fit(log_d)
        # LP3 is fit to log(data) — needs the Jacobian correction (see
        # _aic_for_fit docstring) to be comparable against the other
        # distributions, which are fit directly to the original data.
        aic = _aic_for_fit(log_d, pearson3, p, log_jacobian_data=data)
        candidates.append((2, 'Log-Pearson III', pearson3, p, aic))
    except Exception:
        pass
    try:
        p = genextreme.fit(data)
        candidates.append((3, 'GEV (MLE)', genextreme, p, _aic_for_fit(data, genextreme, p)))
    except Exception:
        pass
    try:
        p = lognorm.fit(data, floc=0)
        candidates.append((5, 'Log-Normal', lognorm, p, _aic_for_fit(data, lognorm, p)))
    except Exception:
        pass

    if not candidates:
        if feedback:
            feedback.pushWarning("All distribution fits failed — falling back to Gumbel.")
        return 1, 'Gumbel (EV1)', [], []

    candidates.sort(key=lambda c: c[4])
    best = candidates[0]
    comparison = [(name, round(aic, 2)) for _, name, _, _, aic in candidates]

    if feedback:
        table = ', '.join(f"{name}: AIC={aic:.2f}" for name, aic in comparison)
        feedback.pushInfo(f"  Distribution comparison (lower AIC = better fit): {table}")
        feedback.pushInfo(f"  Selected: {best[1]} (best AIC fit for this record)")

    return best[0], best[1], best[3], comparison


def frequency_analysis_with_uncertainty(data, return_periods, method, feedback,
                                         n_bootstrap=500, ci_pct=90, random_state=None):
    """
    Wraps frequency_analysis() with the diagnostics and uncertainty
    quantification a professional flood-frequency study needs and a
    bare point estimate can't provide:
      - Mann-Kendall trend test (is this record even stationary?)
      - Grubbs-Beck low-outlier identification (Bulletin 17B/17C)
      - Bootstrap confidence intervals on each return period's design
        value, via case resampling: resample the ORIGINAL data with
        replacement, refit the SAME distribution, recompute the design
        value, repeat n_bootstrap times, take percentiles. This works
        the same way regardless of which distribution is used (no
        distribution-specific analytical variance formula needed), and
        directly reflects how much the small sample sizes typical of
        this kind of record (10-20 years) limit confidence — a short
        record gives a WIDE interval, which is itself the point: a
        bare point estimate hides exactly this.

    Returns dict: design (point estimates), dist_name, params,
    ci_lower, ci_upper (same length/order as return_periods),
    mann_kendall (dict), grubbs_beck (dict).
    """
    data = np.asarray(data, dtype=np.float64)
    data = data[np.isfinite(data) & (data > 0)]

    mk = mann_kendall_test(data)
    if mk['significant'] and feedback:
        feedback.pushWarning(
            f"  Mann-Kendall trend test: significant {mk['trend']} trend "
            f"detected (p={mk['p_value']:.3f}) — this record may not be "
            f"stationary, which the frequency-analysis framework assumes. "
            f"Treat design values with extra caution."
        )

    gb = grubbs_beck_test(data)
    if gb.get('n_outliers', 0) > 0 and feedback:
        feedback.pushWarning(
            f"  Grubbs-Beck low-outlier test: {gb['n_outliers']} value(s) "
            f"below the threshold ({gb['threshold']:.2f}) — per Bulletin "
            f"17B/17C guidance these are typically conditioned on rather "
            f"than discarded outright; reported here for awareness, not "
            f"automatically removed."
        )

    design, dist_name, params = frequency_analysis(data, return_periods, method, feedback)

    rng = np.random.default_rng(random_state)
    n = len(data)
    boot_designs = np.zeros((n_bootstrap, len(return_periods)))
    n_failed = 0
    for b in range(n_bootstrap):
        sample = rng.choice(data, size=n, replace=True)
        try:
            class _QuietFB:
                def pushInfo(self, m): pass
                def pushWarning(self, m): pass
            d, _, _ = frequency_analysis(sample, return_periods, method, _QuietFB())
            boot_designs[b] = d
        except Exception:
            boot_designs[b] = np.nan
            n_failed += 1

    lo_pct, hi_pct = (100 - ci_pct) / 2, 100 - (100 - ci_pct) / 2
    with np.errstate(all='ignore'):
        ci_lower = np.nanpercentile(boot_designs, lo_pct, axis=0)
        ci_upper = np.nanpercentile(boot_designs, hi_pct, axis=0)

    if feedback:
        if n_failed > n_bootstrap * 0.1:
            feedback.pushWarning(
                f"  {n_failed}/{n_bootstrap} bootstrap resamples failed to "
                f"fit — confidence intervals below are based on the "
                f"remaining {n_bootstrap - n_failed} and may be less reliable."
            )
        feedback.pushInfo(f"  {ci_pct}% confidence intervals ({n_bootstrap} bootstrap resamples):")
        for rp, d, lo, hi in zip(return_periods, design, ci_lower, ci_upper):
            feedback.pushInfo(f"    T={rp:5d} yr → {d:.2f} mm  [{lo:.2f} – {hi:.2f}]")

    return {
        'design': design, 'dist_name': dist_name, 'params': params,
        'ci_lower': ci_lower, 'ci_upper': ci_upper, 'ci_pct': ci_pct,
        'mann_kendall': mk, 'grubbs_beck': gb,
    }


def empirical_frequency_analysis(data, return_periods, feedback=None):
    """
    Weibull plotting-position empirical method.

    The `def` line for this function had gone missing, leaving the body
    indented inside the function above it as unreachable code after that
    function's return. The name was therefore never bound, so the last
    line of defence in the frequency-analysis fallback chain —
    distribution fit fails, Gumbel fit also fails, fall back to empirical
    — raised NameError instead of returning an estimate. A silent trap:
    it only fires on data pathological enough to defeat two fitters, and
    then produces a crash rather than the degraded-but-usable answer the
    code was clearly written to give.
    """
    s = np.sort(data)[::-1]
    n = len(s)
    rp_emp = (n + 1) / np.arange(1, n + 1)
    result = []
    for rp in return_periods:
        if rp >= rp_emp[0]:
            result.append(s[0] * (rp / rp_emp[0]) ** 0.25)
        elif rp <= rp_emp[-1]:
            result.append(s[-1])
        else:
            idx = np.searchsorted(-rp_emp, -rp)
            idx = min(max(idx, 1), n - 1)
            x1, x2 = rp_emp[idx-1], rp_emp[idx]
            y1, y2 = s[idx-1], s[idx]
            if x2 != x1:
                result.append(y1 + (y2-y1)*(np.log(rp)-np.log(x1))/(np.log(x2)-np.log(x1)))
            else:
                result.append((y1+y2)/2)
    return np.array(result)


def _lmoments(data):
    """First 3 L-moments (Hosking 1990)."""
    x = np.sort(data); n = len(x)
    l1 = np.mean(x)
    c  = np.arange(n, dtype=float)
    b1 = np.sum(c * x) / (n * (n-1))
    b2 = np.sum(c * (c-1) * x) / (n*(n-1)*(n-2)) if n > 2 else 0.0
    l2 = 2*b1 - l1
    l3 = 6*b2 - 6*b1 + l1 if n > 2 else 0.0
    t3 = l3/l2 if l2 != 0 else 0.0
    return l1, l2, t3


def _gev_from_lmoments(l1, l2, t3):
    """GEV parameters from L-moments (Hosking & Wallis 1997, rational approx)."""
    if abs(t3) < 0.5:
        k = 7.8590*t3 + 2.9554*t3**2
    else:
        k = 0.0
    import math
    if k == 0.0:
        alpha = l2 / math.log(2)
        xi    = l1 - 0.5772156649 * alpha
    else:
        gk    = math.gamma(1 + k) if abs(k) < 30 else 1.0
        alpha = l2 * k / ((1 - 2**(-k)) * gk)
        xi    = l1 - alpha * (1 - gk) / k
    return (-k, xi, abs(alpha))   # scipy GEV sign convention: shape=-k


# ============================================================================
# 2.  SCS / NRCS METHODS
# ============================================================================

def calculate_scs_cn_runoff(rainfall, cn):
    """
    NRCS SCS Curve Number runoff depth (NEH-4, Chapter 10).
    Q = (P - Ia)² / (P - Ia + S)   for P > Ia
    Ia = 0.2S  (standard; for arid use Ia = 0.05S – see wadi_flood_estimation)
    S  = (25400/CN) - 254  [mm]

    Returns numpy array of direct runoff depth (mm).
    """
    cn  = np.clip(float(cn), 1.0, 99.9)
    S   = (25400.0 / cn) - 254.0        # max potential retention (mm)
    Ia  = 0.2 * S                        # initial abstraction (mm)
    P   = np.asarray(rainfall, dtype=np.float64)
    Q   = np.where(P > Ia, (P - Ia)**2 / (P - Ia + S), 0.0)
    return np.maximum(Q, 0.0)


def calculate_peak_discharge_scs(runoff_depth_mm, area_km2, tp_hr):
    """
    SCS peak discharge  Qp = 0.208 × A × Q / Tp  (NEH-4 Ch.16, SI).
    Qp [m³/s], A [km²], Q [mm], Tp [hr]
    """
    if tp_hr <= 0:
        raise ValueError("Time to peak must be > 0")
    return (0.208 * area_km2 * runoff_depth_mm) / tp_hr

calculate_peak_discharge = calculate_peak_discharge_scs   # alias


def calculate_time_of_concentration_kirpich(L_m, slope_decimal):
    """
    Kirpich (1940): Tc = 0.0078 × L_ft^0.77 × S^-0.385  [minutes → hours]
    Valid for: agricultural catchments, L < 500 m, well-defined channels.
    """
    L_ft = L_m * 3.28084
    S    = max(slope_decimal, 1e-5)
    Tc_min = 0.0078 * (L_ft**0.77) * (S**-0.385)
    return Tc_min / 60.0


def calculate_time_to_peak(longest_flow_path_m, slope_percent, cn, feedback, duration_hr=1.0):
    """
    NRCS SCS Lag Equation (NEH-4, Chapter 15):
        tL = (L^0.8 × (S+1)^0.7) / (1900 × Y^0.5)   [hours]
        Tp = tL + D/2  where D = the storm's rainfall input increment

    L  = flow path length [feet]
    S  = (1000/CN) - 10  [inches, retention parameter]
    Y  = average watershed slope [%]
    D  = storm duration [hr] (defaults to 1 hr if not given — but pass
         the actual design-storm duration being used; Tp shifts with it,
         and using the wrong D here throws off the resulting unit
         hydrograph's timing for any storm longer than 1 hr)

    Valid range: CN 30–98, L 30–24 000 ft, Y 0.5–30%.
    """
    try:
        L_ft     = longest_flow_path_m * 3.28084
        cn_safe  = float(np.clip(cn, 30, 98))
        S_in     = (1000.0 / cn_safe) - 10.0      # retention [inches]
        Y        = max(float(slope_percent), 0.1)  # slope [%]
        D        = max(float(duration_hr), 0.01)

        tL_hr    = (L_ft**0.8 * (S_in + 1.0)**0.7) / (1900.0 * Y**0.5)
        Tp_hr    = tL_hr + D / 2.0

        # ── Validity range of the NRCS lag equation ───────────────────────
        # NEH-4 Ch.15 calibrated this on small agricultural watersheds:
        # L up to about 24,000 ft (7.3 km), which corresponds to roughly
        # 8 km² of drainage area. It is routinely applied well past that,
        # but the extrapolation is not free — lag grows as L^0.8 with no
        # upper bound, so on a large catchment it returns a time to peak
        # longer than the design storm itself. A 2577 km² catchment with
        # L=180 km gives tL=21.3 hr and Tp=33.3 hr against a 24-hr storm:
        # the storm has finished before the unit hydrograph peaks, which
        # heavily attenuates the computed peak and is not flash-flood
        # behaviour in any meaningful sense.
        _L_FT_MAX = 24000.0
        if L_ft > _L_FT_MAX:
            feedback.pushWarning(
                f"SCS lag equation is being extrapolated {L_ft / _L_FT_MAX:.0f}x "
                f"past its validity range: L={L_ft:.0f} ft against a documented "
                f"limit of {_L_FT_MAX:.0f} ft (~7.3 km, ~8 km² of drainage "
                f"area, NEH-4 Ch.15). Lag scales as L^0.8 with no upper "
                f"bound, so tL={tL_hr:.1f} hr / Tp={Tp_hr:.1f} hr here is an "
                f"extrapolation, not a calibrated result."
            )
            if Tp_hr > D:
                feedback.pushWarning(
                    f"  Time to peak ({Tp_hr:.1f} hr) exceeds the design storm "
                    f"duration ({D:.1f} hr), so the storm ends before the unit "
                    f"hydrograph peaks and the computed peak is heavily "
                    f"attenuated. For a catchment this size use Clark or "
                    f"Snyder (both available in the Unit Hydrograph Method "
                    f"list), or supply a measured lag, rather than SCS."
                )
        if not (0.5 <= Y <= 30.0):
            feedback.pushWarning(
                f"Watershed slope Y={Y:.2f}% is outside the SCS lag "
                f"equation's calibrated range (0.5-30%). Lag scales as "
                f"Y^-0.5, so values near zero inflate it sharply."
            )

        # Sanity bounds (NRCS valid range approx)
        if not (0.05 < Tp_hr < 200.0):
            feedback.pushWarning(
                f"Tp={Tp_hr:.3f} hr outside normal range. "
                f"(L={L_ft:.0f} ft, S={S_in:.1f} in, Y={Y:.2f}%) – clamped to 1 hr."
            )
            Tp_hr = 1.0

        feedback.pushInfo(
            f"SCS Lag: L={longest_flow_path_m:.0f} m ({L_ft:.0f} ft), "
            f"CN={cn_safe:.0f}, S={S_in:.2f} in, Y={Y:.2f}%, "
            f"tL={tL_hr:.3f} hr, Tp={Tp_hr:.3f} hr"
        )
        return Tp_hr
    except Exception as e:
        feedback.pushWarning(f"Tp calculation error ({e}). Using default 1.0 hr.")
        return 1.0


def generate_scs_unit_hydrograph(area_km2, tp_hr, feedback):
    """
    NRCS triangular unit hydrograph (NEH-4, Chapter 16).
    Qp = 2.08 × A / Tp  [m³/s per cm of runoff]
    Tb = 2.67 × Tp      [base time, hours]
    Volume check: 0.5 × Qp × Tb = A × 1 cm  (automatically satisfied by 2.08 factor)
    """
    Qp = 2.08 * area_km2 / max(tp_hr, 0.01)
    Tb = 2.67 * tp_hr
    dt = min(0.1, tp_hr / 20.0)
    t  = np.arange(0.0, Tb + dt, dt)
    Q  = np.where(
        t <= tp_hr,
        Qp * t / tp_hr,
        Qp * (Tb - t) / (Tb - tp_hr)
    )
    Q  = np.maximum(Q, 0.0)
    # Volume check
    vol_computed = _trapz(Q, t) * 3600.0           # m³ per cm
    vol_expected = area_km2 * 1e6 * 0.01              # 1 cm over area
    feedback.pushInfo(
        f"SCS Triangular UH: Qp={Qp:.3f} m³/s/cm, Tp={tp_hr:.3f} hr, Tb={Tb:.3f} hr, "
        f"Vol check={vol_computed/vol_expected:.3f} (≈1.0 expected)"
    )
    return t, Q


def generate_nrcs_dimensionless_uh(area_km2, tp_hr, feedback):
    """
    NRCS Dimensionless Unit Hydrograph (NEH-4, Exhibit 16-1).
    More accurate than triangular UH, especially for short Tp.
    Qp = 2.08 × A / Tp  [m³/s per cm]
    """
    # Official NEH-4 Exhibit 16-1 dimensionless ordinates
    dim_t = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0,
             1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
             2.2, 2.4, 2.6, 2.8, 3.0, 3.5, 4.0, 4.5, 5.0]
    dim_q = [0.000, 0.030, 0.100, 0.190, 0.310, 0.470, 0.660, 0.820, 0.930, 0.990, 1.000,
             0.990, 0.930, 0.860, 0.780, 0.680, 0.560, 0.460, 0.390, 0.330, 0.280,
             0.207, 0.147, 0.107, 0.077, 0.055, 0.025, 0.011, 0.005, 0.000]
    Qp = 2.08 * area_km2 / max(tp_hr, 0.01)
    t  = np.array(dim_t) * tp_hr
    Q  = np.array(dim_q) * Qp
    # Volume (should equal A × 1 cm)
    vol_computed = _trapz(Q, t) * 3600.0
    vol_expected = area_km2 * 1e6 * 0.01
    feedback.pushInfo(
        f"NRCS Dimensionless UH: Qp={Qp:.3f} m³/s/cm, Tp={tp_hr:.3f} hr, "
        f"Vol check={vol_computed/vol_expected:.3f}"
    )
    return t, Q


def generate_flood_hydrograph(time_uh, discharge_uh, runoff_depth_mm, feedback):
    """
    Scale unit hydrograph [m³/s per cm] by runoff depth.
    discharge_uh × (Q_mm/10) → m³/s
    """
    scale = runoff_depth_mm / 10.0    # mm → cm
    peak  = discharge_uh.max() * scale
    feedback.pushInfo(
        f"Flood hydrograph: Q={runoff_depth_mm:.2f} mm, "
        f"scale={scale:.4f} cm, peak={peak:.3f} m³/s"
    )
    return time_uh, discharge_uh * scale


# ============================================================================
# 3.  SNYDER SYNTHETIC UNIT HYDROGRAPH  (corrected – miles as original)
# ============================================================================

def generate_snyder_unit_hydrograph(area_km2, L_m, Lca_m, Ct=2.0, Cp=0.625,
                                     feedback=None):
    """
    Snyder (1938) Synthetic Unit Hydrograph – CORRECTED metric implementation.

    Original Snyder equation uses US customary units (miles):
        tL = Ct × (L × Lca)^0.3   [L, Lca in miles → tL in hours]
    Metric conversion applied internally.

    Peak discharge (metric, from Gray 1961):
        Qp = 2.75 × Cp × A / tL   [A km², tL hr → Qp m³/s per cm]

    Parameters
    ----------
    Ct : float  – basin lag coefficient; typically 1.8–2.2 (humid USA)
                  use 0.4–1.0 for steep/arid basins
    Cp : float  – peaking coefficient; 0.4 (low storage) – 0.8 (flashy)
    """
    # Convert to miles (Snyder original)
    L_mi   = L_m   / 1609.344
    Lca_mi = Lca_m / 1609.344

    tL_hr = Ct * (L_mi * Lca_mi) ** 0.3   # basin lag [hours]
    tL_hr = max(tL_hr, 0.1)
    tR_hr = tL_hr / 5.5                    # standard unit storm duration [hr]

    # Peak discharge per cm of runoff (Gray 1961 metric conversion)
    Qp = 2.75 * Cp * area_km2 / tL_hr     # m³/s per cm

    # Base time (Snyder approximation)
    Tb_hr = 3.0 + tL_hr / 8.0
    Tb_hr = max(Tb_hr, tL_hr * 2.67)

    # Triangular approximation of Snyder shape
    dt  = min(0.1, tL_hr / 20.0)
    t   = np.arange(0.0, Tb_hr + dt, dt)
    Q   = np.where(
        t <= tL_hr,
        Qp * (t / tL_hr),
        Qp * (Tb_hr - t) / (Tb_hr - tL_hr)
    )
    Q = np.maximum(Q, 0.0)

    if feedback:
        feedback.pushInfo(
            f"Snyder UH: L={L_mi:.3f} mi, Lca={Lca_mi:.3f} mi, "
            f"tL={tL_hr:.3f} hr, tR={tR_hr:.3f} hr, "
            f"Qp={Qp:.4f} m³/s/cm, Tb={Tb_hr:.3f} hr"
        )
    return t, Q, tL_hr


# ============================================================================
# 4.  CLARK INSTANTANEOUS UNIT HYDROGRAPH
# ============================================================================

def generate_clark_iuh(area_km2, tc_hr, R_hr, n_steps=200, feedback=None):
    """
    Clark (1945) IUH via time-area curve + linear reservoir routing.

    Time-area relationship (NRCS synthetic – Simas & Hawkins 2002):
        A(τ) = 1.414 τ^1.5              for τ ≤ 0.5
        A(τ) = 1 - 1.414(1-τ)^1.5      for τ > 0.5
    where τ = t/Tc.

    Linear reservoir: dS/dt = I - Q,  S = R×Q
    Routing coefficient: Kc = dt / (R + 0.5×dt)

    Returns IUH in m³/s per mm of runoff.
    """
    dt = tc_hr / n_steps
    t  = np.arange(0.0, tc_hr + 1.5*dt, dt)
    tau = np.clip(t / tc_hr, 0.0, 1.0)

    # Synthetic time-area curve [km²]
    At = np.where(tau <= 0.5,
                  1.414 * tau**1.5,
                  1.0 - 1.414 * (1.0 - tau)**1.5)
    At = np.clip(At, 0.0, 1.0) * area_km2

    # Translation inflow [m³/s per mm] = dAt/dt / 3.6
    # (dAt/dt [km²/hr] × 1e6 m²/km² × 1e-3 m/mm / 3600 s/hr = / 3.6)
    I = np.gradient(At, dt) / 3.6
    I = np.maximum(I, 0.0)

    # Linear reservoir routing
    Q  = np.zeros_like(I)
    Kc = dt / (R_hr + 0.5 * dt)
    for i in range(1, len(I)):
        Q[i] = Kc * I[i] + (1.0 - Kc) * Q[i-1]

    Q = np.maximum(Q, 0.0)
    if feedback:
        vol = _trapz(Q, t) * 3600.0
        vol_exp = area_km2 * 1e6 * 1e-3
        feedback.pushInfo(
            f"Clark IUH: Tc={tc_hr:.3f} hr, R={R_hr:.3f} hr, "
            f"peak IUH={np.max(Q):.4f} m³/s/mm, "
            f"vol check={vol/vol_exp:.3f}"
        )
    return t, Q


# ============================================================================
# 5.  RATIONAL METHOD
# ============================================================================

def rational_method_peak_discharge(C, i_mm_hr, area_km2):
    """
    Q = C × i × A / 3.6   [m³/s]
    C dimensionless [0–1], i [mm/hr], A [km²]
    """
    return C * i_mm_hr * area_km2 / 3.6


def modified_rational_method(C, design_rainfall_mm, tc_hr, area_km2, storm_dur_hr):
    """
    Modified Rational Method – accounts for storm duration ≠ Tc.
    When D >= Tc: full rational flow
    When D <  Tc: flow = Q_full × D/Tc  (linear reduction)
    """
    i  = design_rainfall_mm / max(storm_dur_hr, 0.01)
    Qf = rational_method_peak_discharge(C, i, area_km2)
    return Qf if storm_dur_hr >= tc_hr else Qf * (storm_dur_hr / tc_hr)


# ============================================================================
# 6.  IDF CURVE GENERATION
# ============================================================================

def fit_idf_curves(design_storms_dict, return_periods, feedback=None):
    """
    Fit IDF power-law  i = a / (t + b)^c  to multi-duration design storms.

    Returns (idf_coeffs, idf_func) where
      idf_coeffs : {return_period: (a, b, c)}
      idf_func   : callable(duration_hr, return_period) → intensity mm/hr
    """
    from scipy.optimize import curve_fit

    idf_coeffs = {}
    durations  = sorted(design_storms_dict.keys())

    for rp_idx, rp in enumerate(return_periods):
        ints, durs = [], []
        for d in durations:
            storms = design_storms_dict[d]
            if rp_idx < len(storms) and storms[rp_idx] > 0:
                ints.append(storms[rp_idx] / d)
                durs.append(d)
        if len(durs) < 3:
            if feedback:
                feedback.pushWarning(f"IDF: < 3 durations for T={rp} yr, skipping.")
            continue
        da = np.array(durs, float); ia = np.array(ints, float)

        def model(t, a, b, c): return a / (t + b)**c

        try:
            p0 = [ia[0] * (da[0] + 1.0), 1.0, 0.7]
            popt, _ = curve_fit(model, da, ia, p0=p0,
                                bounds=(0, [1e6, 100, 3]), maxfev=5000)
            idf_coeffs[rp] = tuple(popt)
            if feedback:
                feedback.pushInfo(
                    f"IDF T={rp} yr: a={popt[0]:.3f}, b={popt[1]:.3f}, c={popt[2]:.3f}"
                )
        except Exception as e:
            if feedback:
                feedback.pushWarning(f"IDF fit failed T={rp}: {e}")

    def idf_func(duration_hr, return_period):
        if return_period in idf_coeffs:
            a, b, c = idf_coeffs[return_period]
            return a / (duration_hr + b)**c
        return None

    return idf_coeffs, idf_func


def generate_idf_table(idf_coeffs, durations_hr, return_periods):
    """Return pandas DataFrame of IDF table."""
    import pandas as pd
    rows = []
    for rp in return_periods:
        row = {'Return Period (yr)': rp}
        if rp in idf_coeffs:
            a, b, c = idf_coeffs[rp]
            for d in durations_hr:
                row[f'{d}hr (mm/hr)'] = round(a / (d + b)**c, 2)
        rows.append(row)
    return pd.DataFrame(rows)


# ============================================================================
# 7.  DESIGN STORM TEMPORAL DISTRIBUTIONS
# ============================================================================

def alternating_block_hyetograph(design_rainfall_mm, duration_hr, n_intervals,
                                  idf_func=None, return_period=None, feedback=None):
    """
    Alternating Block Method (Chow, Maidment & Mays 1988).
    Produces a peaked, realistic design storm hyetograph.
    """
    dt = duration_hr / n_intervals
    times = np.arange(dt, duration_hr + dt, dt)

    if idf_func and return_period:
        depths = []
        for t in times:
            intensity = idf_func(t, return_period)
            # idf_func returns None if this return period wasn't
            # successfully fit (e.g. too few durations — see the warning
            # in fit_idf_curves). The previous check here
            # (`np.where(depths is None, ...)`) was always False, since
            # `depths` is a numpy array object (never actually `None`),
            # not an element-wise check — and idf_func(t, ...) returning
            # None would already have crashed the list comprehension with
            # a TypeError before that check ever ran. Guard per-point
            # instead, falling back to linear scaling only where needed.
            if intensity is not None:
                depths.append(intensity * t)
            else:
                depths.append(design_rainfall_mm * t / duration_hr)
        depths = np.array(depths)
    else:
        depths = design_rainfall_mm * times / duration_hr

    increments = np.diff(np.concatenate([[0], depths]))
    increments = np.maximum(increments, 0.0)

    # Sort descending, place alternately around centre
    sorted_inc = np.sort(increments)[::-1]
    result     = np.zeros(n_intervals)
    left, right = n_intervals // 2, n_intervals // 2 + 1
    for i, val in enumerate(sorted_inc):
        if i % 2 == 0:
            if 0 <= left < n_intervals:
                result[left] = val; left -= 1
        else:
            if 0 < right < n_intervals:
                result[right] = val; right += 1

    result = np.clip(result, 0, None)
    if feedback:
        feedback.pushInfo(
            f"ABM hyetograph: {n_intervals} intervals × {dt:.3f} hr, "
            f"total={result.sum():.1f} mm"
        )
    return np.arange(0.0, duration_hr, dt), result


def scs_type_ii_distribution(design_rainfall_mm, duration_hr=24, n_points=97):
    """
    SCS Type-II 24-hr design storm (NRCS, humid/semi-arid USA, standard).
    Returns (time_hr, cumulative_mm, incremental_mm).
    """
    # Official SCS Type-II dimensionless table (t/24hr, P/P24)
    t_norm = [0.000,0.100,0.200,0.300,0.400,0.500,0.550,0.600,0.620,0.640,
              0.650,0.660,0.670,0.680,0.690,0.700,0.710,0.720,0.730,0.740,
              0.750,0.800,0.850,0.900,0.950,1.000]
    p_norm = [0.000,0.011,0.022,0.035,0.048,0.063,0.075,0.100,0.116,0.135,
              0.146,0.158,0.174,0.194,0.219,0.254,0.303,0.362,0.416,0.464,
              0.504,0.636,0.783,0.887,0.957,1.000]
    t_interp = np.linspace(0, 1, n_points)
    p_interp = np.interp(t_interp, t_norm, p_norm)
    t_hr     = t_interp * duration_hr
    cum_mm   = p_interp * design_rainfall_mm
    incr_mm  = np.diff(np.concatenate([[0], cum_mm]))
    return t_hr, cum_mm, incr_mm


# ============================================================================
# 8.  UK FEH PARAMETRIC (planning-grade)
# ============================================================================

def feh_rainfall_runoff(area_km2, saar_mm, soil_class, urbext, slope_percent,
                         return_period, design_rainfall_mm=None, feedback=None):
    """
    UK FEH Rainfall-Runoff parametric method (FEH Vol.4, 1999; QMED
    equation per Kjeldsen et al. 2008 revision).
    Planning-grade: uses HOST soil class to approximate SPRHOST and BFIHOST.
    For detailed UK design use FEH Web Service + WINFAP-FEH.

    QMED_rural = 8.3062 × AREA^0.8510 × 0.1536^(1000/SAAR)
                 × FARL^3.4451 × 0.0460^(BFIHOST²)   [m³/s]

    (Verified against the published worked example in FEH Vol.3 — Afon
    Dwyryd at Maentwrog: AREA=78.15 km², SAAR=2212 mm, BFIHOST=0.378 →
    QMED≈93.6 m³/s, matching this implementation to within the precision
    of the published example.)

    Growth factors from pooled UK growth curve (FEH Vol.3).

    Note: URBEXT is NOT part of the QMED_rural regression itself — FEH
    applies urban adjustment as a separate step, recommended when URBEXT
    exceeds 0.025. This planning-grade implementation does not apply that
    adjustment; for urbanised catchments, treat this QMED as an
    UNDER-estimate and use the FEH Web Service / WINFAP-FEH for anything
    beyond a rough first pass.
    """
    # HOST soil class → SPRHOST (standard percentage runoff) and BFIHOST
    sprhost_map = {1: 0.04, 2: 0.12, 3: 0.20, 4: 0.32, 5: 0.45}
    bfihost_map = {1: 0.95, 2: 0.65, 3: 0.40, 4: 0.25, 5: 0.10}
    sc          = int(np.clip(soil_class, 1, 5))
    spr         = sprhost_map[sc]
    bfi         = bfihost_map[sc]

    FARL = 1.0  # flood attenuation by reservoirs and lakes (1 = no attenuation)
    saar = max(float(saar_mm), 1.0)

    QMED = (8.3062 * area_km2**0.8510 *
            0.1536**(1000.0 / saar) *
            FARL**3.4451 *
            0.0460**(bfi**2))

    if urbext and urbext > 0.025 and feedback:
        feedback.pushWarning(
            f"  URBEXT={urbext:.3f} exceeds FEH's 0.025 threshold for "
            f"needing urban adjustment, which this planning-grade "
            f"implementation does not apply — QMED below is likely an "
            f"UNDER-estimate for this catchment. Use FEH Web Service / "
            f"WINFAP-FEH for urbanised catchments."
        )

    # Pooled growth curve (FEH Vol.3, UK)
    growth_table = {2: 1.00, 5: 1.30, 10: 1.50, 25: 1.85,
                    50: 2.10, 100: 2.40, 200: 2.70, 1000: 3.40}
    T_vals = sorted(growth_table.keys())
    G_vals = [growth_table[t] for t in T_vals]
    gf     = float(np.interp(np.log10(max(return_period, 1.0)),
                             np.log10(T_vals), G_vals))
    Qp     = QMED * gf

    # Time to peak (FEH Vol.4 Eq 6.3)
    Tp_hr = max(0.3, (area_km2**0.48) / max(slope_percent, 0.01)**0.35)

    if design_rainfall_mm is not None:
        # Blend statistical Qp with rainfall-runoff estimate
        Qp_rf = (design_rainfall_mm * spr * 0.278 * area_km2) / Tp_hr
        Qp    = 0.5 * Qp + 0.5 * Qp_rf

    notes = (
        f"FEH planning-grade: QMED={QMED:.2f} m³/s, GF={gf:.2f}, "
        f"Qp={Qp:.2f} m³/s, Tp={Tp_hr:.2f} hr. "
        "Use FEH Web Service for regulatory design."
    )
    if feedback:
        feedback.pushInfo(notes)
    return {'Qp': Qp, 'Tp': Tp_hr, 'QMED': QMED, 'growth_factor': gf, 'notes': notes}


# ============================================================================
# 9.  AUSTRALIA ARR2019 PRM
# ============================================================================

def arr_probabilistic_rational(area_km2, design_intensity_mm_hr, C10,
                                return_period, freq_factor_table=None,
                                feedback=None):
    """
    ARR2019 Probabilistic Rational Method (Book 5, Section 5.3).
    Recommended for rural catchments ≤ 25 km² in Australia.

    Q_y = 0.278 × C_y × i_y × A
    C_y = C10 × F_y   (frequency factor from ARR Table 5.3.2)

    F_y values are AEP-based (ARR 2019 Table 5.3.2).
    """
    # ARR Table 5.3.2 frequency factors (AEP basis)
    default_ff = {2: 0.65, 5: 0.85, 10: 1.00, 20: 1.15,
                  50: 1.30, 100: 1.45, 200: 1.60, 500: 1.80}
    ff         = freq_factor_table or default_ff
    Fy = float(np.interp(return_period,
                         sorted(ff.keys()),
                         [ff[k] for k in sorted(ff.keys())]))
    Cy = C10 * Fy
    Qp = 0.278 * Cy * design_intensity_mm_hr * area_km2
    if feedback:
        feedback.pushInfo(
            f"ARR2019 PRM: C10={C10:.3f}, Fy={Fy:.3f}, Cy={Cy:.3f}, "
            f"i={design_intensity_mm_hr:.1f} mm/hr, Qp={Qp:.3f} m³/s"
        )
    return Qp


# ============================================================================
# 10.  MUSKINGUM-CUNGE CHANNEL ROUTING
# ============================================================================

def muskingum_cunge_routing(inflow, dt_hr, K_hr, X=0.2, feedback=None):
    """
    Muskingum-Cunge routing (standard formulation).

    Coefficients:
        C0 = (-KX + 0.5dt) / D
        C1 = ( KX + 0.5dt) / D
        C2 = (K(1-X) - 0.5dt) / D
    where D = K(1-X) + 0.5dt

    Check: C0 + C1 + C2 = 1  (always satisfied by construction).
    Constraint: 2KX ≤ dt ≤ 2K(1-X) for non-negative coefficients.

    K  = travel time through reach [hr]
    X  = weighting factor [0, 0.5]; 0 = pure reservoir, 0.5 = pure translation
    """
    K  = max(K_hr,  1e-6)
    dt = max(dt_hr, 1e-6)
    D  = K * (1.0 - X) + 0.5 * dt

    C0 = (-K * X + 0.5 * dt) / D
    C1 = ( K * X + 0.5 * dt) / D
    C2 = ( K * (1.0 - X) - 0.5 * dt) / D

    # Warn if coefficients become negative (violates stability)
    if C0 < 0 or C1 < 0 or C2 < 0:
        if feedback:
            feedback.pushWarning(
                f"Muskingum: negative coefficient(s) (C0={C0:.3f}, C1={C1:.3f}, C2={C2:.3f}). "
                f"Increase dt or reduce X. Using |C| values."
            )
        C0, C1, C2 = abs(C0), abs(C1), abs(C2)
        total = C0 + C1 + C2
        C0 /= total; C1 /= total; C2 /= total

    outflow    = np.zeros(len(inflow))
    outflow[0] = inflow[0]
    for i in range(1, len(inflow)):
        outflow[i] = max(0.0, C0 * inflow[i] + C1 * inflow[i-1] + C2 * outflow[i-1])

    if feedback:
        feedback.pushInfo(
            f"Muskingum: K={K:.2f} hr, X={X:.2f}, "
            f"C0={C0:.3f}, C1={C1:.3f}, C2={C2:.3f} (sum={C0+C1+C2:.4f}), "
            f"Qin_max={np.max(inflow):.2f} → Qout_max={np.max(outflow):.2f} m³/s"
        )
    return outflow


# ============================================================================
# 11.  GREEN-AMPT INFILTRATION  (corrected Mein-Larson two-phase model)
# ============================================================================

def green_ampt_infiltration(rainfall_intensity_mm_hr, Ks_mm_hr, psi_mm,
                              theta_d, dt_hr, n_steps, feedback=None):
    """
    Green-Ampt (1911) infiltration – Mein-Larson (1973) two-phase model.

    Phase 1 (pre-ponding): rainfall rate < infiltration capacity → no runoff.
    Phase 2 (post-ponding): solve implicit GA equation iteratively.

    Implicit GA equation (Mein-Larson):
        F(t+dt) = F(t) + Ks×dt + ψΔθ × ln[(F(t+dt)+ψΔθ)/(F(t)+ψΔθ)]
    Solved by successive substitution (converges in <20 iterations).

    Parameters
    ----------
    psi_mm  : matric suction head (mm, positive; typical: sandy 50, clay 300)
    theta_d : initial soil moisture deficit = n(1-S_e) where n=porosity, S_e=effective saturation

    Typical Ks values (mm/hr): sand 120, loam 8, clay 1
    """
    F      = np.zeros(n_steps + 1)
    fp     = np.zeros(n_steps + 1)
    runoff = np.zeros(n_steps + 1)
    time   = np.zeros(n_steps + 1)
    ponded = False
    Fp     = 0.0  # cumulative infiltration at ponding

    for i in range(1, n_steps + 1):
        time[i] = i * dt_hr

        if not ponded:
            # Phase 1: no ponding, all rainfall infiltrates
            F[i] = F[i-1] + rainfall_intensity_mm_hr * dt_hr
            fp[i] = Ks_mm_hr * (1.0 + psi_mm * theta_d / max(F[i], 1e-6))
            if rainfall_intensity_mm_hr > fp[i]:
                # Ponding occurs: back-calculate Fp
                ponded = True
                Fp     = (Ks_mm_hr * psi_mm * theta_d) / max(rainfall_intensity_mm_hr - Ks_mm_hr, 1e-9)
                F[i]   = max(F[i], Fp)  # reset to ponding depth
            else:
                runoff[i] = 0.0
                continue

        # Phase 2: ponded – implicit GA equation via successive substitution
        F_prev = max(F[i-1], Fp, 1e-6)
        psi_dtheta = psi_mm * theta_d
        F_new  = F_prev + Ks_mm_hr * dt_hr  # initial guess

        for _ in range(30):
            arg    = (F_new + psi_dtheta) / (F_prev + psi_dtheta)
            F_try  = F_prev + Ks_mm_hr * dt_hr + psi_dtheta * np.log(max(arg, 1e-10))
            if abs(F_try - F_new) < 1e-6:
                F_new = F_try; break
            F_new = F_try

        F[i]  = max(F_new, F_prev)
        fp[i] = Ks_mm_hr * (1.0 + psi_dtheta / max(F[i], 1e-6))

        # Actual infiltration this step
        actual_inf = min(F[i] - F[i-1], rainfall_intensity_mm_hr * dt_hr)
        actual_inf = max(actual_inf, 0.0)
        runoff[i]  = max(0.0, rainfall_intensity_mm_hr * dt_hr - actual_inf)

    if feedback:
        feedback.pushInfo(
            f"Green-Ampt: Ks={Ks_mm_hr:.1f} mm/hr, ψ={psi_mm:.0f} mm, "
            f"Δθ={theta_d:.3f}, ponded={ponded}, "
            f"F_total={F[-1]:.1f} mm, "
            f"runoff_total={np.sum(runoff)*dt_hr:.1f} mm"
        )
    return time, F, runoff


# ============================================================================
# 12.  MIDDLE EAST WADI METHOD  (arid / semi-arid)
# ============================================================================

def wadi_flood_estimation(area_km2, design_rainfall_mm, cn=85, slope_percent=2.0,
                           feedback=None):
    """
    Wadi flash flood estimation for arid/semi-arid regions.
    Adaptations from ASCE Manual 36 and Al-Zahrani & Husain (1998):
      - AMC I (very dry antecedent conditions)
      - Ia = 0.05S (reduced initial abstraction; standard 0.2S is too conservative for arid)
      - Tc from D'Onofrio (1970) wadi formula

    CN input should be AMC-II; function converts to AMC-I internally.
    """
    # AMC-II → AMC-I (NEH-4)
    cn2   = float(np.clip(cn, 30, 99))
    cn1   = (4.2 * cn2) / (10.0 - 0.058 * cn2)
    cn1   = np.clip(cn1, 1, 99)

    S_mm  = (25400.0 / cn1) - 254.0
    Ia    = 0.05 * S_mm             # reduced Ia for arid catchments
    P     = design_rainfall_mm
    if P > Ia:
        Q_mm = (P - Ia)**2 / (P - Ia + S_mm)
    else:
        Q_mm = 0.0

    # Wadi time of concentration (D'Onofrio 1970)
    L_km  = max(np.sqrt(area_km2 * 1.5), 0.1)
    S_pct = max(slope_percent, 0.01)
    Tc_hr = max(0.05, (L_km / S_pct**0.5) * 0.02)

    Qp = 0.208 * area_km2 * Q_mm / Tc_hr

    if feedback:
        feedback.pushInfo(
            f"Wadi (arid, AMC-I): CN_II={cn2:.0f} → CN_I={cn1:.0f}, "
            f"S={S_mm:.1f} mm, Ia={Ia:.1f} mm (0.05S), "
            f"P={P:.1f} mm, Q={Q_mm:.2f} mm, Tc={Tc_hr:.3f} hr, Qp={Qp:.3f} m³/s"
        )
    return Qp, Q_mm, Tc_hr


# ============================================================================
# 13.  CANADA RATIONAL / NZ PRM
# ============================================================================

def canada_rational_peak(C, area_km2, idf_a, idf_b, idf_c, tc_hr,
                          feedback=None):
    """
    Canadian Rational Method with Environment Canada power-law IDF.
    i = a / (tc + b)^c  [mm/hr],  Q = C × i × A / 3.6  [m³/s]
    """
    i  = idf_a / (tc_hr + idf_b)**idf_c
    Qp = C * i * area_km2 / 3.6
    if feedback:
        feedback.pushInfo(f"Canada IDF: i={i:.2f} mm/hr, Qp={Qp:.3f} m³/s")
    return Qp, i


def nz_probabilistic_rational(C10, area_km2, design_intensity_mm_hr,
                               return_period, feedback=None):
    """
    New Zealand Probabilistic Rational Method (NIWA, based on TR69 / TP108).
    Uses NZ-specific frequency factors calibrated to NZ regional flood data.
    """
    nz_ff = {2: 0.60, 5: 0.82, 10: 1.00, 20: 1.15,
             50: 1.35, 100: 1.50, 200: 1.65, 500: 1.85}
    Fy = float(np.interp(return_period,
                         sorted(nz_ff.keys()),
                         [nz_ff[k] for k in sorted(nz_ff.keys())]))
    Cy = C10 * Fy
    Qp = 0.278 * Cy * design_intensity_mm_hr * area_km2
    if feedback:
        feedback.pushInfo(f"NZ PRM: Fy={Fy:.3f}, Cy={Cy:.3f}, Qp={Qp:.3f} m³/s")
    return Qp


# ============================================================================
# Model calibration / validation against observed data
# ============================================================================

def nash_sutcliffe_efficiency(observed, simulated):
    """
    Nash-Sutcliffe Efficiency (Nash & Sutcliffe, 1970) — the standard
    hydrologic model performance metric. Measures how well simulated
    values match observed ones relative to just using the observed
    mean as a baseline prediction.

    NSE = 1 - sum((O-S)^2) / sum((O-mean(O))^2)

    NSE = 1   : perfect match
    NSE = 0   : model is only as good as predicting the observed mean
    NSE < 0   : model is WORSE than just predicting the observed mean
    """
    obs = np.asarray(observed, dtype=np.float64)
    sim = np.asarray(simulated, dtype=np.float64)
    denom = np.sum((obs - np.mean(obs)) ** 2)
    if denom <= 0:
        return float('nan')
    return float(1.0 - np.sum((obs - sim) ** 2) / denom)


def percent_bias(observed, simulated):
    """
    Percent Bias (Gupta et al. 1999; as used in Moriasi et al. 2007 —
    the most widely cited streamflow model evaluation reference).

    PBIAS = 100 * sum(O - S) / sum(O)

    Sign convention (Moriasi et al. 2007's original — note this is NOT
    universal; some other papers use the opposite sign (S-O), so always
    check which convention a source uses before comparing PBIAS values
    across studies):
      Positive PBIAS -> model UNDERestimates (simulated < observed)
      Negative PBIAS -> model OVERestimates (simulated > observed)
    """
    obs = np.asarray(observed, dtype=np.float64)
    sim = np.asarray(simulated, dtype=np.float64)
    denom = np.sum(obs)
    if denom == 0:
        return float('nan')
    return float(100.0 * np.sum(obs - sim) / denom)


def rmse(observed, simulated):
    """Root Mean Square Error, same units as the data (e.g. m3/s)."""
    obs = np.asarray(observed, dtype=np.float64)
    sim = np.asarray(simulated, dtype=np.float64)
    return float(np.sqrt(np.mean((obs - sim) ** 2)))


def rsr(observed, simulated):
    """
    RMSE-observations Standard deviation Ratio (Moriasi et al. 2007) —
    RMSE normalised by the observed data's own spread, so it can be
    compared across catchments/events with very different flow
    magnitudes. RSR=0 is a perfect fit; lower is better.
    """
    obs = np.asarray(observed, dtype=np.float64)
    std_obs = np.std(obs)
    if std_obs <= 0:
        return float('nan')
    return float(rmse(observed, simulated) / std_obs)


def r_squared(observed, simulated):
    """Coefficient of determination (squared Pearson correlation) —
    measures how well simulated tracks the SHAPE of observed, without
    penalising a consistent offset the way NSE does."""
    obs = np.asarray(observed, dtype=np.float64)
    sim = np.asarray(simulated, dtype=np.float64)
    if np.std(obs) == 0 or np.std(sim) == 0:
        return float('nan')
    r = np.corrcoef(obs, sim)[0, 1]
    return float(r ** 2)


def interpret_nse(nse_value):
    """Performance rating per Moriasi et al. (2007) — a widely-used
    guideline, not an absolute rule; treat as indicative."""
    if not np.isfinite(nse_value):
        return 'N/A'
    if nse_value > 0.75:
        return 'Very good'
    if nse_value > 0.65:
        return 'Good'
    if nse_value > 0.50:
        return 'Satisfactory'
    return 'Unsatisfactory'


def interpret_pbias(pbias_value):
    """Performance rating per Moriasi et al. (2007) for STREAMFLOW
    specifically (their thresholds differ for sediment/nutrients) — a
    widely-used guideline, not an absolute rule; treat as indicative."""
    if not np.isfinite(pbias_value):
        return 'N/A'
    a = abs(pbias_value)
    if a < 10:
        return 'Very good'
    if a < 15:
        return 'Good'
    if a < 25:
        return 'Satisfactory'
    return 'Unsatisfactory'


def hydrograph_comparison_metrics(obs_time_hr, obs_q, sim_time_hr, sim_q, feedback=None):
    """
    Compare a simulated hydrograph against an observed one — the actual
    calibration/validation workflow a professional flood study needs:
    load a real historical event, run the model against the same storm,
    and check whether it reproduces what actually happened.

    Interpolates the simulated hydrograph onto the observed time base
    (they'll almost never share identical timestamps), then computes
    NSE, PBIAS, RMSE, RSR, R^2, and separately reports peak magnitude
    error (%) and peak timing error (hours) — the two numbers a
    practitioner usually cares about most for design purposes, which
    the continuous-fit metrics above don't directly capture (a model
    can have a mediocre NSE but still nail the peak, or vice versa).

    Returns a dict with all metrics, their Moriasi (2007) ratings where
    applicable, and the interpolated series (for plotting).
    """
    obs_t = np.asarray(obs_time_hr, dtype=np.float64)
    obs_v = np.asarray(obs_q, dtype=np.float64)
    sim_t = np.asarray(sim_time_hr, dtype=np.float64)
    sim_v = np.asarray(sim_q, dtype=np.float64)

    order = np.argsort(obs_t)
    obs_t, obs_v = obs_t[order], obs_v[order]
    sim_order = np.argsort(sim_t)
    sim_t, sim_v = sim_t[sim_order], sim_v[sim_order]

    # Only compare over the overlapping time window — extrapolating the
    # simulated hydrograph beyond its own computed range isn't meaningful.
    t_min = max(obs_t.min(), sim_t.min())
    t_max = min(obs_t.max(), sim_t.max())
    mask = (obs_t >= t_min) & (obs_t <= t_max)
    if np.sum(mask) < 3:
        if feedback:
            feedback.pushWarning(
                "  Observed and simulated hydrographs have too little time "
                "overlap for a meaningful comparison."
            )
        return None

    obs_t_c, obs_v_c = obs_t[mask], obs_v[mask]
    sim_interp = np.interp(obs_t_c, sim_t, sim_v)

    nse = nash_sutcliffe_efficiency(obs_v_c, sim_interp)
    pb = percent_bias(obs_v_c, sim_interp)
    rm = rmse(obs_v_c, sim_interp)
    rs = rsr(obs_v_c, sim_interp)
    r2 = r_squared(obs_v_c, sim_interp)

    obs_peak_idx = int(np.argmax(obs_v_c))
    obs_peak_q, obs_peak_t = float(obs_v_c[obs_peak_idx]), float(obs_t_c[obs_peak_idx])
    sim_peak_idx = int(np.argmax(sim_v)) if len(sim_v) else 0
    sim_peak_q = float(sim_v[sim_peak_idx]) if len(sim_v) else float('nan')
    sim_peak_t = float(sim_t[sim_peak_idx]) if len(sim_t) else float('nan')

    peak_mag_error_pct = (100.0 * (sim_peak_q - obs_peak_q) / obs_peak_q
                           if obs_peak_q != 0 else float('nan'))
    peak_time_error_hr = sim_peak_t - obs_peak_t

    result = {
        'NSE': nse, 'NSE_rating': interpret_nse(nse),
        'PBIAS_pct': pb, 'PBIAS_rating': interpret_pbias(pb),
        'RMSE': rm, 'RSR': rs, 'R2': r2,
        'obs_peak_q': obs_peak_q, 'obs_peak_time_hr': obs_peak_t,
        'sim_peak_q': sim_peak_q, 'sim_peak_time_hr': sim_peak_t,
        'peak_magnitude_error_pct': peak_mag_error_pct,
        'peak_timing_error_hr': peak_time_error_hr,
        'obs_time_compared': obs_t_c, 'obs_q_compared': obs_v_c,
        'sim_q_interpolated': sim_interp,
    }

    if feedback:
        feedback.pushInfo(
            f"  Calibration metrics: NSE={nse:.3f} ({interpret_nse(nse)}), "
            f"PBIAS={pb:.1f}% ({interpret_pbias(pb)}), RMSE={rm:.2f}, "
            f"RSR={rs:.3f}, R²={r2:.3f}"
        )
        feedback.pushInfo(
            f"  Peak: observed={obs_peak_q:.2f} m³/s at t={obs_peak_t:.1f}hr, "
            f"simulated={sim_peak_q:.2f} m³/s at t={sim_peak_t:.1f}hr "
            f"(magnitude error={peak_mag_error_pct:+.1f}%, "
            f"timing error={peak_time_error_hr:+.1f} hr)"
        )
        if nse < 0.5 or abs(pb) >= 25:
            feedback.pushWarning(
                "  Model performance is rated 'Unsatisfactory' by Moriasi et "
                "al. (2007) guidelines for this event — consider reviewing "
                "CN, Manning's n, or method choice before trusting design "
                "results for this catchment."
            )

    return result


# ============================================================================
# CWC (Central Water Commission, India) Synthetic Unit Hydrograph
# ============================================================================

def cwc_synthetic_unit_hydrograph(area_km2, L_km, Lc_km, S_slope,
                                   coeffs=None, tr_hr=1.0, feedback=None):
    """
    CWC Synthetic Unit Hydrograph for ungauged Indian catchments
    (CWC "Estimation of Design Flood", Hydrology Studies Organisation,
    New Delhi; regional method under the long-term hydrological plan).

    IMPORTANT — WHY COEFFICIENTS ARE USER-SUPPLIED, NOT BUILT IN:
    The CWC method divides India into 26 hydro-meteorologically
    homogeneous subzones, and each subzone has its OWN set of regression
    coefficients, published in that subzone's individual Flood Estimation
    Report (e.g. "Subzone 3(a) Report", "Subzone 5(a)/5(b) west coast
    report"). The equation STRUCTURE below is common across subzones, but
    the coefficients are not — using another subzone's numbers gives a
    confidently wrong answer with no warning sign.

    This implementation therefore does NOT ship hardcoded coefficients:
    look up the values for YOUR subzone in the relevant CWC report and
    pass them in. That's also how the method is meant to be applied in
    practice. Defaults below are placeholders from the general literature
    form and are deliberately flagged as such — they are NOT a substitute
    for your subzone's published values.

    Equation form (per CWC regional SUH methodology):
        tp   = Ct * (L * Lc / sqrt(S)) ** m       [hr]   basin lag
        Qp   = Cq * A * tp ** (-nq)               [m3/s] peak of 1-cm UH
        W50  = Cw50 * (Qp/A) ** (-nw50)           [hr]   width at 50% Qp
        W75  = Cw75 * (Qp/A) ** (-nw75)           [hr]   width at 75% Qp
        WR50 = Cwr50 * (Qp/A) ** (-nwr50)         [hr]   rising limb @50%
        WR75 = Cwr75 * (Qp/A) ** (-nwr75)         [hr]   rising limb @75%
        TB   = Ctb * tp ** ntb                    [hr]   base width
        Tm   = tp + tr/2                          [hr]   time to peak

    Parameters
    ----------
    area_km2 : catchment area (km2)
    L_km     : length of main stream (km)
    Lc_km    : length along main stream from outlet to a point nearest
               the catchment centroid (km)
    S_slope  : equivalent stream slope (dimensionless, m/m)
    coeffs   : dict of subzone coefficients (see CWC_SUH_DEFAULT_COEFFS
               for the expected keys). Pass YOUR subzone's published
               values.
    tr_hr    : unit rainfall duration (hr), normally 1.0 for CWC

    Returns dict with tp, Qp, Tm, TB, W50, W75, WR50, WR75, and the
    synthesised UH ordinates (time_hr, discharge_m3s), plus a
    volume-check ratio that should be close to 1.0.
    """
    c = dict(CWC_SUH_DEFAULT_COEFFS)
    if coeffs:
        c.update(coeffs)

    if feedback and not coeffs:
        feedback.pushWarning(
            "  CWC SUH is using PLACEHOLDER coefficients, not your "
            "subzone's published values. Results are indicative only. "
            "Look up your subzone's CWC Flood Estimation Report and "
            "supply its coefficients for design use."
        )

    S = max(float(S_slope), 1e-5)
    catchment_factor = (L_km * Lc_km) / np.sqrt(S)

    tp = c['Ct'] * catchment_factor ** c['m']
    tp = max(tp, 0.1)
    Qp = c['Cq'] * area_km2 * tp ** (-c['nq'])
    qp_per_area = Qp / max(area_km2, 1e-6)

    W50  = c['Cw50']  * qp_per_area ** (-c['nw50'])
    W75  = c['Cw75']  * qp_per_area ** (-c['nw75'])
    WR50 = c['Cwr50'] * qp_per_area ** (-c['nwr50'])
    WR75 = c['Cwr75'] * qp_per_area ** (-c['nwr75'])
    TB   = c['Ctb']   * tp ** c['ntb']
    Tm   = tp + tr_hr / 2.0

    # Build the UH through the CWC control points: the method defines the
    # hydrograph by its peak plus widths at 50%/75% of peak (split into
    # rising and falling limbs), so the curve is interpolated through
    # those points rather than assumed to follow a fixed shape.
    pts_t = [0.0,
             Tm - WR75, Tm - WR50,
             Tm,
             Tm + (W75 - WR75), Tm + (W50 - WR50),
             TB]
    pts_q = [0.0, 0.75 * Qp, 0.50 * Qp, Qp, 0.75 * Qp, 0.50 * Qp, 0.0]

    # Enforce monotonic time ordering — with unusual coefficient/geometry
    # combinations a width can exceed its own limb position and put the
    # control points out of order, which would silently produce a
    # nonsense (self-crossing) hydrograph rather than an obvious error.
    pairs = sorted(zip(pts_t, pts_q), key=lambda p: p[0])
    pts_t = [max(0.0, p[0]) for p in pairs]
    pts_q = [p[1] for p in pairs]
    for i in range(1, len(pts_t)):
        if pts_t[i] <= pts_t[i - 1]:
            pts_t[i] = pts_t[i - 1] + 1e-3

    n_steps = max(50, int(TB / max(tr_hr, 0.1)) * 4)
    t = np.linspace(0.0, max(TB, Tm * 2), n_steps)
    q = np.interp(t, pts_t, pts_q, left=0.0, right=0.0)

    # Volume check: a 1-cm UH over area A should contain A*1e6*0.01 m3.
    vol_computed = _trapz(q, t) * 3600.0
    vol_expected = area_km2 * 1e6 * 0.01
    vol_ratio = vol_computed / vol_expected if vol_expected > 0 else float('nan')

    if feedback:
        feedback.pushInfo(
            f"  CWC SUH: tp={tp:.2f} hr, Qp={Qp:.2f} m³/s, Tm={Tm:.2f} hr, "
            f"TB={TB:.2f} hr"
        )
        feedback.pushInfo(
            f"    W50={W50:.2f} hr, W75={W75:.2f} hr, "
            f"WR50={WR50:.2f} hr, WR75={WR75:.2f} hr"
        )
        feedback.pushInfo(f"    Volume check={vol_ratio:.3f} (1.0 = exact 1-cm UH)")
        if not (0.7 < vol_ratio < 1.4):
            feedback.pushWarning(
                f"    UH volume ratio {vol_ratio:.2f} is well off 1.0 — the "
                f"coefficient set and this catchment's geometry may be "
                f"inconsistent (check you're using the right subzone's "
                f"coefficients, and that L/Lc/slope units are km and m/m)."
            )

    return {
        'tp_hr': tp, 'Qp_m3s': Qp, 'Tm_hr': Tm, 'TB_hr': TB,
        'W50_hr': W50, 'W75_hr': W75, 'WR50_hr': WR50, 'WR75_hr': WR75,
        'time_hr': t, 'discharge_m3s': q,
        'volume_ratio': vol_ratio,
        'used_default_coeffs': coeffs is None,
    }


# Placeholder coefficient set in the general CWC SUH form. These are NOT
# any specific subzone's published values — see the docstring above.
# Replace with your subzone's coefficients from its CWC Flood Estimation
# Report before using results for design.
CWC_SUH_DEFAULT_COEFFS = {
    'Ct': 0.50,  'm': 0.32,
    'Cq': 1.79,  'nq': 0.78,
    'Cw50': 2.20, 'nw50': 1.07,
    'Cw75': 1.24, 'nw75': 1.07,
    'Cwr50': 0.85, 'nwr50': 1.09,
    'Cwr75': 0.61, 'nwr75': 1.03,
    'Ctb': 5.50, 'ntb': 0.72,
}


# ============================================================================
# Level-pool (Modified Puls) reservoir / detention basin routing
# ============================================================================

def level_pool_routing(inflow_time_hr, inflow_q, stage_storage_discharge,
                       initial_storage_m3=0.0, feedback=None):
    """
    Level-pool (Modified Puls) reservoir routing — the standard method
    for routing a flood hydrograph through a detention basin, pond, or
    reservoir with an uncontrolled outlet.

    Solves the storage-indication form of the continuity equation. For
    each timestep, continuity says:

        (I1 + I2)/2 - (O1 + O2)/2 = (S2 - S1)/dt

    Rearranged so all unknowns (S2, O2) sit on the left:

        (2*S2/dt + O2) = (I1 + I2) + (2*S1/dt - O1)

    The right-hand side is fully known at each step, and the left-hand
    side is a monotonic function of stage — so O2 can be found by
    interpolating the storage-indication curve. That monotonicity is what
    makes this method unconditionally stable, unlike the explicit schemes
    elsewhere in this plugin: no timestep constraint to violate.

    Parameters
    ----------
    inflow_time_hr : 1D array, times (hr) — must be evenly spaced
    inflow_q       : 1D array, inflow discharge (m3/s)
    stage_storage_discharge : list of (stage_m, storage_m3, discharge_m3s)
                     defining the basin. Must be sorted by ascending
                     stage and cover the full range the flood will reach.
    initial_storage_m3 : storage at t=0 (0 = basin starts empty)

    Returns dict with time_hr, outflow_q, storage_m3, stage_m, plus
    peak attenuation and lag, and a mass-balance error check.
    """
    t = np.asarray(inflow_time_hr, dtype=np.float64)
    I = np.asarray(inflow_q, dtype=np.float64)
    if len(t) < 2:
        if feedback:
            feedback.pushWarning("  Level-pool routing needs at least 2 inflow points.")
        return None

    dt_hr = float(np.median(np.diff(t)))
    dt_s = dt_hr * 3600.0
    if dt_s <= 0:
        if feedback:
            feedback.pushWarning("  Level-pool routing: inflow times must increase.")
        return None

    ssd = sorted(stage_storage_discharge, key=lambda r: r[0])
    stages = np.array([r[0] for r in ssd], dtype=np.float64)
    storages = np.array([r[1] for r in ssd], dtype=np.float64)
    discharges = np.array([r[2] for r in ssd], dtype=np.float64)

    if np.any(np.diff(storages) < 0) or np.any(np.diff(discharges) < 0):
        if feedback:
            feedback.pushWarning(
                "  Storage and discharge must both increase with stage — "
                "the storage-indication curve won't be monotonic otherwise "
                "and the routing solution becomes ambiguous."
            )
        return None

    # Storage-indication curve: (2S/dt + O) as a function of stage.
    si_curve = 2.0 * storages / dt_s + discharges

    S = float(initial_storage_m3)
    O = float(np.interp(S, storages, discharges))
    out_q, out_S, out_stage = [O], [S], [float(np.interp(S, storages, stages))]

    for k in range(len(I) - 1):
        rhs = (I[k] + I[k + 1]) + (2.0 * S / dt_s - O)
        # Interpolating the monotonic storage-indication curve is what
        # replaces an iterative solve here.
        O_next = float(np.interp(rhs, si_curve, discharges))
        S_next = max(0.0, (rhs - O_next) * dt_s / 2.0)
        if rhs > si_curve[-1] and feedback and k == int(np.argmax(I)):
            feedback.pushWarning(
                "  Inflow exceeds the top of the stage-storage-discharge "
                "curve — the basin would overtop. Results are clipped at "
                "the highest defined stage and UNDERSTATE the real outflow; "
                "extend the curve to cover the design event."
            )
        O, S = O_next, S_next
        out_q.append(O)
        out_S.append(S)
        out_stage.append(float(np.interp(min(S, storages[-1]), storages, stages)))

    out_q = np.array(out_q)
    out_S = np.array(out_S)

    # Mass balance: inflow volume must equal outflow volume plus the
    # change in stored volume. This is the single best check that the
    # routing is actually solving continuity rather than just producing
    # a plausible-looking attenuated curve.
    vol_in = _trapz(I, t) * 3600.0
    vol_out = _trapz(out_q, t) * 3600.0
    dS = out_S[-1] - float(initial_storage_m3)
    residual = vol_in - vol_out - dS
    mb_error_pct = 100.0 * abs(residual) / vol_in if vol_in > 0 else 0.0

    peak_in, peak_out = float(np.max(I)), float(np.max(out_q))
    attenuation_pct = 100.0 * (peak_in - peak_out) / peak_in if peak_in > 0 else 0.0
    lag_hr = float(t[int(np.argmax(out_q))] - t[int(np.argmax(I))])

    if feedback:
        feedback.pushInfo(
            f"  Level-pool routing: peak {peak_in:.2f} -> {peak_out:.2f} m³/s "
            f"({attenuation_pct:.1f}% attenuation), peak delayed {lag_hr:.2f} hr"
        )
        feedback.pushInfo(
            f"    Max storage={np.max(out_S)/1e6:.3f} Mm³, "
            f"max stage={np.max(out_stage):.2f} m, "
            f"mass balance error={mb_error_pct:.2f}%"
        )
        if mb_error_pct > 5.0:
            feedback.pushWarning(
                f"    Mass balance error {mb_error_pct:.1f}% is high — check "
                f"that the stage-storage-discharge curve covers the full "
                f"range of this event and that the inflow timestep isn't "
                f"too coarse relative to the hydrograph's rise."
            )

    return {
        'time_hr': t, 'outflow_q': out_q, 'storage_m3': out_S,
        'stage_m': np.array(out_stage),
        'peak_inflow': peak_in, 'peak_outflow': peak_out,
        'attenuation_pct': attenuation_pct, 'peak_lag_hr': lag_hr,
        'max_storage_m3': float(np.max(out_S)),
        'max_stage_m': float(np.max(out_stage)),
        'mass_balance_error_pct': mb_error_pct,
    }


def build_ssd_from_geometry(area_m2_at_stages, stages_m, outlet_type='weir',
                            weir_length_m=5.0, weir_coeff=1.7,
                            orifice_area_m2=1.0, orifice_coeff=0.6,
                            crest_stage_m=0.0):
    """
    Build a stage-storage-discharge table from simple basin geometry,
    for users who don't have a surveyed SSD table to hand.

    Storage by the average-end-area method between successive stages
    (standard for reservoir volumetrics). Discharge from either:
      weir:    Q = C * L * H^1.5        (broad-crested weir)
      orifice: Q = C * A * sqrt(2*g*H)  (submerged orifice)
    where H is head above the outlet crest.

    Returns a list of (stage_m, storage_m3, discharge_m3s) suitable for
    level_pool_routing().
    """
    stages = np.asarray(stages_m, dtype=np.float64)
    areas = np.asarray(area_m2_at_stages, dtype=np.float64)
    order = np.argsort(stages)
    stages, areas = stages[order], areas[order]

    storages = [0.0]
    for i in range(1, len(stages)):
        # Average-end-area: mean of the two surface areas times the
        # height between them.
        dv = 0.5 * (areas[i] + areas[i - 1]) * (stages[i] - stages[i - 1])
        storages.append(storages[-1] + dv)

    g = 9.81
    discharges = []
    for s in stages:
        H = max(0.0, s - crest_stage_m)
        if H <= 0:
            discharges.append(0.0)
        elif outlet_type == 'orifice':
            discharges.append(orifice_coeff * orifice_area_m2 * np.sqrt(2 * g * H))
        else:
            discharges.append(weir_coeff * weir_length_m * H ** 1.5)

    return [(float(s), float(v), float(q))
            for s, v, q in zip(stages, storages, discharges)]
