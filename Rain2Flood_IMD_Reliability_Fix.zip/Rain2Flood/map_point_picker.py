"""
Map Canvas Point Picker
========================
A reusable QGIS map canvas click tool that lets the user
pick a point on the map and populates lat/lon QLineEdit widgets.

Usage in any tab:
    from .map_point_picker import MapPointPicker, PointPickerButton
    btn = PointPickerButton(iface, self.lat_edit, self.lon_edit, parent=self)
    layout.addWidget(btn)
"""

from qgis.gui import QgsMapTool
from qgis.core import (
    QgsCoordinateTransform, QgsCoordinateReferenceSystem, QgsProject
)
from qgis.PyQt.QtWidgets import QPushButton, QHBoxLayout, QWidget, QLabel
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QCursor, QIcon, QPixmap, QPainter, QColor, QPen


# ── Map tool ─────────────────────────────────────────────────────────────

class MapPointTool(QgsMapTool):
    """Click once on the canvas to capture a WGS84 point."""

    def __init__(self, canvas, lat_edit, lon_edit, button, callback=None):
        super().__init__(canvas)
        self._lat_edit = lat_edit
        self._lon_edit = lon_edit
        self._button   = button
        self._callback = callback

        # Crosshair cursor
        try:
            self.setCursor(QCursor(Qt.CursorShape.CrossCursor))
        except AttributeError:
            self.setCursor(QCursor(Qt.CrossCursor))  # type: ignore[attr-defined]

    def canvasReleaseEvent(self, event):
        """Convert click point to WGS84 and populate line edits."""
        try:
            point = self.toMapCoordinates(event.pos())
            canvas_crs = self.canvas().mapSettings().destinationCrs()
            wgs84     = QgsCoordinateReferenceSystem('EPSG:4326')

            if canvas_crs != wgs84:
                transform = QgsCoordinateTransform(
                    canvas_crs, wgs84, QgsProject.instance()
                )
                point = transform.transform(point)

            lat = round(point.y(), 6)
            lon = round(point.x(), 6)

            self._lat_edit.setText(str(lat))
            self._lon_edit.setText(str(lon))

            if self._button:
                self._button.setChecked(False)
                self._button.setText('📍 Pick from Map')
                self._button.setToolTip('Click to pick a point from the map canvas')

            if self._callback:
                self._callback(lat, lon)

        except Exception as e:
            if self._button:
                self._button.setChecked(False)
                self._button.setText('📍 Pick from Map')
        finally:
            # Restore previous map tool
            self.canvas().unsetMapTool(self)

    def deactivate(self):
        if self._button and self._button.isChecked():
            self._button.setChecked(False)
            self._button.setText('📍 Pick from Map')
        super().deactivate()


# ── Convenience widget ────────────────────────────────────────────────────

class PointPickerButton(QPushButton):
    """
    A toggle button that activates the MapPointTool on the canvas.

    Parameters
    ----------
    iface    : QgisInterface
    lat_edit : QLineEdit  – latitude field to populate
    lon_edit : QLineEdit  – longitude field to populate
    callback : callable   – optional f(lat, lon) called after pick
    """

    def __init__(self, iface, lat_edit, lon_edit, callback=None, parent=None):
        super().__init__('📍 Pick from Map', parent)
        self._iface    = iface
        self._lat_edit = lat_edit
        self._lon_edit = lon_edit
        self._callback = callback
        self._tool     = None

        self.setCheckable(True)
        self.setToolTip(
            'Click to activate the point picker, then click on the map canvas '
            'to capture the latitude and longitude of that location.'
        )
        self.setStyleSheet(
            'QPushButton{'
            '  background:#0277BD;color:white;border:none;'
            '  border-radius:5px;padding:5px 12px;font-weight:bold;font-size:11px;'
            '}'
            'QPushButton:checked{'
            '  background:#E65100;color:white;'
            '}'
            'QPushButton:hover{background:#01579B;}'
        )
        self.toggled.connect(self._on_toggle)

    def _on_toggle(self, checked):
        canvas = self._iface.mapCanvas()
        if checked:
            self.setText('🔴 Click on Map…')
            self._tool = MapPointTool(
                canvas, self._lat_edit, self._lon_edit, self, self._callback
            )
            canvas.setMapTool(self._tool)
        else:
            self.setText('📍 Pick from Map')
            if self._tool:
                canvas.unsetMapTool(self._tool)
                self._tool = None


# ── Convenience row builder ───────────────────────────────────────────────

def make_coord_row(iface, lat_edit, lon_edit, callback=None, label='Location (Lat, Lon):'):
    """
    Build a QWidget row containing:
      [label] [lat QLineEdit] [lon QLineEdit] [PointPickerButton]

    Drop it directly into a QFormLayout.addRow() call.
    """
    w   = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(6)
    lay.addWidget(lat_edit)
    lay.addWidget(QLabel('  ,  '))
    lay.addWidget(lon_edit)
    btn = PointPickerButton(iface, lat_edit, lon_edit, callback)
    lay.addWidget(btn)
    return w
