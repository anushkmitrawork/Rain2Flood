"""
Raster colour ramps
===================
One place for every raster palette the plugin applies, so a ramp is
defined once and cannot drift between the tab that generates a raster and
the tab that reloads it.

The hex sequences below are exactly as supplied — not re-derived, not
"improved". They are interpolated across each raster's own value range,
so the same ramp works whatever the actual min/max turns out to be.

A note on direction, because it is easy to get backwards:

  CN        low CN = permeable = little runoff. Ramp runs cyan -> blue ->
            green -> yellow -> orange -> red -> magenta, so the hot end
            is impervious, high-runoff ground.
  Manning's low n = smooth = fast flow. Ramp is diverging through white
            at mid-roughness: blues for smooth surfaces, reds for rough
            vegetated ground.
  LULC      a classification, not a continuum, so its colours are
            assigned to CLASSES rather than interpolated. Interpolating
            a class raster produces colours that mean nothing.
  DEM       elevation, low to high.
  Slope     the DEM palette, same direction: flat is cool and pale,
            steep is hot. No separate slope palette was supplied.
"""

# ── Supplied palettes ────────────────────────────────────────────────────
CN_RAMP = [
    '#00FFFF', '#00BFFF', '#1E90FF', '#0000FF', '#7FFF00', '#32CD32',
    '#008000', '#006400', '#FFFF00', '#FFD700', '#FFA500', '#FF0000',
    '#FF00FF', '#8B008B',
]

LULC_RAMP = [
    '#001f4d', '#0a3d8f', '#1565c0', '#1e88e5', '#29b6f6', '#80deea',
    '#a5d6a7', '#ffee58', '#ff7043', '#d32f2f', '#7b0000',
]

MANNING_RAMP = [
    '#000099', '#0033CC', '#3380F2', '#99CCFF', '#E6F2FF', '#FFFFFF',
    '#FFF2E6', '#FFB280', '#FF4C1A', '#CC0000', '#8C0000',
]

# ── Official land-cover class colours ────────────────────────────────────
# LULC is a classification, so its colours are FIXED PER CLASS from the
# product's own specification, never stretched or interpolated. A colour
# on a land-cover map is supposed to mean the same thing in every map
# anyone has ever seen.
#
# Two schemes are supported and they MUST NOT be confused, because their
# code ranges overlap while meaning different things. Value 10 is
# "Clouds" in the Esri product and "Tree cover" in ESA WorldCover, so
# applying one table to the other's raster paints forest dark grey while
# looking perfectly plausible.

# Esri 10m Annual Land Use Land Cover (Sentinel-2 derived).
# Official values and colours, exactly as published.
ESRI_LULC_CLASSES = {
    1:  ('#419bdf', 'Water'),
    2:  ('#397d49', 'Trees'),
    4:  ('#7a87c6', 'Flooded Vegetation'),
    5:  ('#e49635', 'Crops'),
    7:  ('#c4281b', 'Built Area'),
    8:  ('#a59b8f', 'Bare Ground'),
    9:  ('#a8ebff', 'Snow/Ice'),
    10: ('#616161', 'Clouds'),
    11: ('#e3e2c3', 'Rangeland'),
}

# ESA WorldCover v100 / v200. This is what the plugin's own AWS download
# fetches, so it needs its own table rather than borrowing the Esri one.
#
# Values verified against the official v200 "Map Class Table" as published
# in the Google Earth Engine catalogue entry for ESA/WorldCover/v200 and
# the Microsoft Planetary Computer dataset example, both of which agree
# with the ESA Product User Manual v2.0. All 11 classes, exact match.
# Checked rather than recalled: these are pinned by a test, and a test
# that enshrines a misremembered colour is worse than no test.
ESA_WORLDCOVER_CLASSES = {
    10:  ('#006400', 'Tree cover'),
    20:  ('#ffbb22', 'Shrubland'),
    30:  ('#ffff4c', 'Grassland'),
    40:  ('#f096ff', 'Cropland'),
    50:  ('#fa0000', 'Built-up'),
    60:  ('#b4b4b4', 'Bare / sparse vegetation'),
    70:  ('#f0f0f0', 'Snow and ice'),
    80:  ('#0064c8', 'Permanent water bodies'),
    90:  ('#0096a0', 'Herbaceous wetland'),
    95:  ('#00cf75', 'Mangroves'),
    100: ('#fae6a0', 'Moss and lichen'),
}


def detect_lulc_scheme(values, declared=None):
    """
    Work out which land-cover scheme a set of class codes belongs to.

    `declared` is the dataset type the user picked in the UI and wins
    outright when given — the user knows what they downloaded, and code
    ranges alone cannot always tell. Detection is the fallback for
    rasters loaded without that context.

    Returns ('esri' | 'esa' | None, table).
    """
    if declared:
        d = str(declared).strip().upper()
        if d.startswith('ESRI'):
            return 'esri', ESRI_LULC_CLASSES
        if d.startswith('ESA'):
            return 'esa', ESA_WORLDCOVER_CLASSES

    vals = {int(v) for v in (values or []) if v is not None}
    if not vals:
        return None, None

    esri_hit = len(vals & set(ESRI_LULC_CLASSES))
    esa_hit = len(vals & set(ESA_WORLDCOVER_CLASSES))

    # Anything above 11 can only be ESA — the Esri scheme stops there.
    if max(vals) > 11:
        return ('esa', ESA_WORLDCOVER_CLASSES) if esa_hit else (None, None)
    # Everything at or below 11 and matching the Esri codes is Esri. The
    # one genuinely ambiguous case is a raster containing ONLY value 10:
    # all-cloud (Esri) or all-forest (ESA). Treated as Esri because a
    # single-value ESA raster of nothing but tree cover is not a real
    # product, whereas a fully clouded Esri tile is.
    if esri_hit:
        return 'esri', ESRI_LULC_CLASSES
    return None, None


def lulc_items(values, declared=None):
    """
    (value, hex, label) per class for a land-cover raster, or None if the
    scheme is unrecognised. Codes not in the table are skipped rather
    than guessed at.
    """
    scheme, table = detect_lulc_scheme(values, declared)
    if not table:
        return None, None
    items = [(int(v), table[int(v)][0], f'{int(v)} — {table[int(v)][1]}')
             for v in sorted({int(x) for x in values}) if int(v) in table]
    return (items or None), scheme


DEM_RAMP = [
    '#d9e5d6', '#6dc6dc', '#00a7e1', '#77c3c3', '#eddea4', '#f2bf8b',
    '#f5b07f', '#f7a072', '#fb9e5a', '#ff9b42',
]

# Slope reuses the DEM palette in the SAME direction, not reversed.
#
# I had it reversed and a rendered legend caught it. The DEM palette runs
# pale green -> blues -> yellow -> orange, so its hot end is the HIGH end.
# Reversing it for slope put orange on flat ground and pale green on the
# steepest terrain — precisely backwards, and the kind of error that is
# invisible in code and obvious the moment you look at the legend.
#
# Left as-is, low slope reads cool and pale and steep slope reads hot,
# which matches both the DEM's own reading order and the convention that
# the alarming colour marks the alarming value.
SLOPE_RAMP = list(DEM_RAMP)


def _band_range(layer, band=1):
    """(min, max) for a band, or (None, None)."""
    try:
        st = layer.dataProvider().bandStatistics(band)
        lo, hi = float(st.minimumValue), float(st.maximumValue)
        if lo == lo and hi == hi and hi > lo:      # NaN-safe
            return lo, hi
        return lo, hi
    except Exception:
        return None, None


def quantile_breaks(layer, band, n_classes, bins=512):
    """
    Class boundaries that put roughly equal AREA in each class.

    This is the fix for "I only see three or four colours". A ramp
    stretched linearly between a raster's min and max only shows its full
    range if the values are spread evenly across it, and real rasters
    almost never are. A DEM whose cells sit mostly between 560 and 660 m
    but which touches 1030 m at one peak spends nine tenths of its colour
    range on ground that barely exists; a CN raster pinned to 30-100 when
    the catchment is 60-85 uses a third of the palette. Slope is the worst
    of the three — heavily right-skewed, so almost everything lands in the
    first class or two.

    Equal-count breaks put the same number of cells in each class, so
    every colour in the palette appears and the differences you care about
    are the ones that get the colour separation.

    Derived from the band histogram rather than by reading the raster:
    a histogram is one provider call regardless of raster size, where
    pulling pixels into Python is not.

    Returns ascending interior breaks (n_classes - 1 of them), or None.
    """
    lo, hi = _band_range(layer, band)
    if lo is None or not (hi > lo) or n_classes < 2:
        return None
    try:
        h = layer.dataProvider().histogram(band, bins, lo, hi)
        counts = list(h.histogramVector)
    except Exception:
        return None
    total = sum(counts)
    if total <= 0:
        return None

    width = (hi - lo) / len(counts)
    breaks, cum, target_i = [], 0, 1
    for i, c in enumerate(counts):
        cum += c
        while (target_i < n_classes
               and cum >= total * target_i / n_classes):
            breaks.append(lo + (i + 1) * width)
            target_i += 1
        if target_i >= n_classes:
            break

    # Collapse duplicates. A raster with large flat areas — a constant
    # CN patch, a lake in a DEM — can put several quantiles inside one
    # histogram bin, and repeated break values make QGIS drop classes,
    # which would reintroduce the very problem this is solving.
    out = []
    for b in breaks:
        if not out or b > out[-1] + 1e-9:
            out.append(b)
    return out or None


def discrete_items(layer, colours, band=1, fmt='{:.2f}', feedback=None):
    """
    Discrete class items using equal-count breaks, falling back to
    equal-interval when the histogram is unavailable.

    Discrete, not interpolated: interpolation blends neighbouring colours
    into a continuum, which looks smooth but makes it impossible to read a
    value off the map. With distinct steps each colour means one band of
    values.
    """
    lo, hi = _band_range(layer, band)
    if lo is None or not (hi > lo):
        return []
    n = len(colours)
    if n == 0:
        return []

    brk = quantile_breaks(layer, band, n)
    if brk is None or len(brk) < max(1, n // 3):
        # Too few distinct quantiles to be worth it (a near-constant
        # raster): fall back to equal intervals over the real range.
        step = (hi - lo) / n
        brk = [lo + step * (i + 1) for i in range(n - 1)]
        if feedback:
            feedback.pushInfo(
                "  Histogram gave too few distinct quantiles; using "
                "equal-interval classes instead.")

    edges = [lo] + list(brk) + [hi]
    # One colour per class, spread across the palette if the break count
    # came back short after de-duplication.
    k = len(edges) - 1
    items = []
    for i in range(k):
        c = colours[round(i * (n - 1) / max(k - 1, 1))] if k > 1 else colours[0]
        # Discrete shader semantics: the item value is the class UPPER
        # bound and the colour applies to everything at or below it.
        items.append((edges[i + 1],
                      c,
                      f'{fmt.format(edges[i])} – {fmt.format(edges[i + 1])}'))
    return items


def ramp_items(vmin, vmax, colours, labels=None, fmt='{:.2f}'):
    """
    Spread `colours` evenly across [vmin, vmax].

    Returns [(value, hex, label), …] suitable for a QgsColorRampShader in
    Interpolated mode. Degenerate ranges (a constant raster) collapse to a
    single stop rather than dividing by zero.
    """
    n = len(colours)
    if n == 0:
        return []
    try:
        vmin, vmax = float(vmin), float(vmax)
    except (TypeError, ValueError):
        return []
    if not (vmax > vmin):
        return [(vmin, colours[0], fmt.format(vmin))]

    step = (vmax - vmin) / (n - 1) if n > 1 else 0.0
    out = []
    for i, c in enumerate(colours):
        v = vmin + i * step
        lbl = labels[i] if (labels and i < len(labels)) else fmt.format(v)
        out.append((v, c, lbl))
    return out


def class_items(values, colours, labels=None):
    """
    Assign colours to discrete class values, cycling if there are more
    classes than colours. For LULC, where interpolation is meaningless.
    """
    if not values or not colours:
        return []
    out = []
    for i, v in enumerate(values):
        lbl = labels[i] if (labels and i < len(labels)) else str(v)
        out.append((v, colours[i % len(colours)], lbl))
    return out


def apply_ramp(layer, colours, band=1, interpolated=False,
                values=None, labels=None, fmt='{:.2f}', feedback=None):
    """
    Build and attach a single-band pseudocolour renderer.

    Constructed through the QGIS API rather than by writing a .qml and
    calling loadNamedStyle(): that route fails silently across QGIS
    versions with nothing surfaced to the log, which is the last thing
    you want from symbology.

    `values` supplied  -> discrete classes at those values.
    `values` omitted   -> the ramp is stretched over the band's own
                          min/max, read from the layer statistics.
    """
    from qgis.core import (QgsRasterShader, QgsColorRampShader,
                            QgsSingleBandPseudoColorRenderer)
    from qgis.PyQt.QtGui import QColor

    try:
        if values is not None:
            items = class_items(values, colours, labels)
            ramp_type = QgsColorRampShader.Exact
        else:
            # DISCRETE by default, with equal-count breaks. Interpolated
            # ramps were showing only three or four colours on real data
            # — see quantile_breaks for why.
            items = discrete_items(layer, colours, band, fmt=fmt,
                                    feedback=feedback)
            ramp_type = (QgsColorRampShader.Interpolated if interpolated
                         else QgsColorRampShader.Discrete)
        if not items:
            return False

        shader = QgsRasterShader()
        cr = QgsColorRampShader()
        cr.setColorRampType(ramp_type)
        cr.setColorRampItemList(
            [QgsColorRampShader.ColorRampItem(v, QColor(c), lbl)
             for v, c, lbl in items])
        shader.setRasterShaderFunction(cr)

        renderer = QgsSingleBandPseudoColorRenderer(
            layer.dataProvider(), band, shader)
        renderer.setClassificationMin(items[0][0])
        renderer.setClassificationMax(items[-1][0])
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        try:
            layer.emitStyleChanged()
        except Exception:
            pass
        return True
    except Exception as e:
        if feedback:
            feedback.pushWarning(
                f"  Could not apply symbology to {layer.name()}: {e}. "
                f"The layer is loaded with QGIS defaults.")
        return False
