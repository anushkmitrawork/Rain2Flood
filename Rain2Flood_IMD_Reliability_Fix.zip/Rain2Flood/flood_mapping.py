"""
Flood Mapping
=============
Generates flood inundation rasters and visualisation maps.
Uses:
  - Simplified hydraulic depth estimation (planar water surface)
  - D8 flow direction for connectivity
  - Manning's equation for channel depth
  - CN-weighted runoff volume for extent calibration
  - Optional spatially-variable Manning's n from raster

LIMITATIONS — read before using for anything beyond a rough first pass:
This computes a SINGLE representative water depth for the whole catchment
(from one Manning's-equation calculation using a valley-bottom-
representative slope) and floods everywhere below that single water
surface elevation, connected to the outlet. It is NOT a 2D hydraulic
model: it doesn't route water downstream over time, doesn't resolve
backwater effects, doesn't vary depth realistically along a long reach
with changing channel geometry, and doesn't capture floodplain storage
dynamics. For anything beyond a quick, approximate screening-level
extent, use a proper 2D hydraulic model (HEC-RAS 2D, TUFLOW, InfoWorks
ICM, etc.) with actual channel/floodplain geometry.
"""

import os
import gc
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, BoundaryNorm
from matplotlib.patches import Patch


def generate_flood_map_2d(hydrograph_time_s, hydrograph_q_cms,
                           dem_path, catchment_path, output_dir,
                           return_period, manning_n=0.05, feedback=None,
                           cn_raster_path=None, manning_raster_path=None,
                           target_cells=90000, sim_duration_s=None,
                           max_wall_time_s=150.0):
    """
    2D diffusive-wave flood extent, routing an actual time-varying
    discharge hydrograph across the catchment (see flood_routing_2d.py
    for the numerical scheme and its validation). This is the more
    realistic — and much slower — alternative to generate_flood_map()'s
    single static water-surface approximation: it actually simulates the
    flood rising, spreading, and receding over time, and reports the
    MAXIMUM depth reached at each cell as the flood extent, rather than
    flood-filling below one fixed elevation.

    Scope/assumptions to be upfront about:
      - Source and outlet are DIFFERENT points: source is the highest-
        elevation valid cell (representing inflow arriving from
        upstream), outlet is the lowest-elevation cell on the domain
        BOUNDARY (a genuine exit point, not just the lowest cell
        anywhere, which could be an interior pit). They must not be the
        same cell — verified directly during development that if they
        are, injected water exits in the same step it enters and never
        spreads (depth stays at 0 everywhere despite a "perfect" mass
        balance, since inflow and outflow just cancel out at one point).
      - This does NOT model flow routing through the upstream channel
        network itself — it's a single point-source simplification of
        "the whole catchment's computed discharge entering and crossing
        the modelled floodplain." For per-sub-basin routing, route each
        sub-basin's own hydrograph separately (a larger undertaking).
      - Runs on a COARSENED grid (see target_cells) for tractable
        runtime — an explicit 2D scheme at native DEM resolution over a
        whole catchment can take from many minutes to multiple hours
        (measured directly: ~0.5s/step at native 30m resolution for a
        ~2500 km² catchment, and thousands of steps are typically
        needed). The output is at the coarsened resolution, not
        upsampled back to native resolution, so as not to imply detail
        that wasn't actually computed.

    Returns
    -------
    (flood_map_png_path, flood_raster_tif_path, RoutingResult) or
    (None, None, None) on error
    """
    try:
        import geopandas as gpd
        import rasterio
        from rasterio.mask import mask as rasterio_mask
        from rasterio.transform import from_origin
        from shapely.geometry import mapping
        from scipy.ndimage import zoom
        try:
            from .flood_routing_2d import route_2d_diffusive_wave
        except ImportError:
            from flood_routing_2d import route_2d_diffusive_wave

        os.makedirs(os.path.join(output_dir, 'flood_maps'),    exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'flood_rasters'), exist_ok=True)
        flood_image  = os.path.join(output_dir, 'flood_maps',    f"flood_map_2d_{return_period}yr.png")
        flood_raster = os.path.join(output_dir, 'flood_rasters', f"flood_depth_2d_{return_period}yr.tif")

        catchment = gpd.read_file(catchment_path)
        with rasterio.open(dem_path) as src:
            original_nodata = src.nodata
            catchment_dem = catchment.to_crs(src.crs)
            geoms = [mapping(g) for g in catchment_dem.geometry]
            out_image, out_transform = rasterio_mask(src, geoms, crop=True,
                                                      nodata=np.nan, filled=True)
            dem_data  = out_image[0].astype(np.float64)
            dem_crs   = src.crs
            cell_size = abs(src.transform[0])

        if original_nodata is not None:
            dem_data[dem_data == original_nodata] = np.nan
        dem_data[dem_data < -1000] = np.nan
        valid_mask = ~np.isnan(dem_data)
        if not valid_mask.any():
            if feedback: feedback.reportError("No valid DEM data in catchment.")
            return None, None, None

        # ── Manning's n grid (uniform or from raster) ───────────────────────
        mann_grid = np.full(dem_data.shape, manning_n, dtype=np.float64)
        if manning_raster_path and os.path.exists(manning_raster_path):
            try:
                with rasterio.open(manning_raster_path) as msrc:
                    m_catchment = catchment.to_crs(msrc.crs)
                    m_geoms = [mapping(g) for g in m_catchment.geometry]
                    m_out, _ = rasterio_mask(msrc, m_geoms, crop=True, nodata=-9999.0, filled=True)
                    m_arr = m_out[0].astype(np.float64)
                    m_arr[(m_arr <= 0) | (m_arr > 1)] = np.nan
                    if m_arr.shape != dem_data.shape:
                        m_arr = zoom(m_arr, (dem_data.shape[0]/m_arr.shape[0],
                                              dem_data.shape[1]/m_arr.shape[1]), order=0)
                    mann_grid = np.where(np.isnan(m_arr), manning_n, m_arr)
            except Exception as e:
                if feedback: feedback.pushWarning(f"Manning's n raster load failed ({e}); using uniform n.")

        # ── Coarsen for tractable runtime, sized to the ACTUAL time budget ─
        # Measured on real runs: the explicit scheme manages roughly 200
        # steps/s at ~74,000 cells. A 144-hour event at the stable dt that
        # implies needs ~1.5 million steps — about two hours of wall time.
        # With a 150 s budget the simulation therefore always truncated
        # after 4-7 simulated hours and then wrote out "0.2% of catchment
        # flooded", which looks like a result but is really just "the
        # flood wave has not arrived yet". That output was being saved and
        # loaded into QGIS as though it were an answer.
        #
        # Coarsening helps twice over: fewer cells per step AND a larger
        # stable timestep (dt scales with cell size), so runtime falls
        # roughly with the cube of the coarsening factor. Size the grid to
        # what can actually finish, rather than picking a fixed target and
        # truncating.
        n_cells = dem_data.shape[0] * dem_data.shape[1]
        coarsen_factor = max(1, int(np.ceil(np.sqrt(n_cells / target_cells))))

        _sim_hr_est = (float(np.max(hydrograph_time_s)) * 1.5 / 3600.0
                       if sim_duration_s is None else sim_duration_s / 3600.0)
        _STEPS_PER_SEC_AT_74K = 200.0   # measured on real runs
        _MIN_USEFUL_GRID = 100          # cells across the smaller dimension

        def _estimate_seconds(cf):
            # Stable dt depends on actual CELL SIZE IN METRES, not on the
            # coarsening factor (which is relative to whatever the source
            # DEM resolution happens to be). Mirrors _estimate_stable_dt
            # in flood_routing_2d: dt ~ 0.4*dx*n / (h^(2/3)*sqrt(g)).
            cells = n_cells / (cf ** 2)
            dx = cell_size * cf
            h_ref = 3.0          # representative flood depth for sizing
            dt = 0.4 * dx * max(manning_n, 0.02) / (h_ref ** (2.0/3.0) * np.sqrt(9.81))
            dt = float(np.clip(dt, 0.05, 30.0))
            steps = _sim_hr_est * 3600.0 / dt
            rate = _STEPS_PER_SEC_AT_74K * (74000.0 / max(cells, 1.0))
            return steps / max(rate, 1e-6), cells, dt

        _est_s, _, _ = _estimate_seconds(coarsen_factor)
        # How coarse would we need to go to actually finish in budget?
        _cf_fit = coarsen_factor
        while _cf_fit < 200:
            _e, _, _ = _estimate_seconds(_cf_fit)
            if _e <= max_wall_time_s * 0.8:
                break
            _cf_fit += 1
        _grid_at_fit = min(dem_data.shape[0], dem_data.shape[1]) // max(_cf_fit, 1)

        if _est_s > max_wall_time_s and _grid_at_fit < _MIN_USEFUL_GRID:
            # Coarsening enough to finish would destroy the result: the
            # valley would be only a couple of cells wide. Producing a
            # meaningless-but-complete map, or a truncated one that looks
            # like an answer, are both worse than declining and saying why.
            if feedback:
                feedback.pushWarning(
                    f"  2D routing SKIPPED for this catchment. A full "
                    f"{_sim_hr_est:.0f} hr simulation at a useful resolution would "
                    f"take about {_est_s/60.0:.0f} minutes, far beyond the "
                    f"{max_wall_time_s:.0f}s limit. Coarsening enough to fit would "
                    f"need ~{cell_size*_cf_fit:.0f} m cells "
                    f"(~{_grid_at_fit}x grid), at which the valley is only a few "
                    f"cells wide and the output would be meaningless."
                )
                feedback.pushWarning(
                    f"  Previously this ran anyway, truncated after a few simulated "
                    f"hours, and reported a small flood extent that was really just "
                    f"'the wave hasn't arrived yet'. The standard (non-2D) flood map "
                    f"is complete and is the one to use. To force 2D, raise the "
                    f"wall-time limit to at least {_est_s/60.0:.0f} minutes."
                )
            return None, None, None

        if _est_s > max_wall_time_s * 0.8:
            coarsen_factor = _cf_fit
            _est_s, _, _ = _estimate_seconds(coarsen_factor)
        if feedback:
            feedback.pushInfo(
                f"  2D routing sized to the {max_wall_time_s:.0f}s budget: "
                f"coarsening {coarsen_factor}x (estimated {_est_s:.0f}s for the "
                f"full {_sim_hr_est:.0f} hr simulation)."
            )
        if coarsen_factor > 1:
            new_shape = (max(2, dem_data.shape[0] // coarsen_factor),
                         max(2, dem_data.shape[1] // coarsen_factor))
            if feedback:
                feedback.pushInfo(
                    f"2D routing: coarsening {dem_data.shape[0]}x{dem_data.shape[1]} "
                    f"({n_cells:,} cells) -> {new_shape[0]}x{new_shape[1]} "
                    f"({new_shape[0]*new_shape[1]:,} cells, factor {coarsen_factor}x) "
                    f"for tractable runtime. Native-resolution 2D routing over a "
                    f"whole catchment can take minutes to hours — see module docs."
                )
            zy, zx = new_shape[0] / dem_data.shape[0], new_shape[1] / dem_data.shape[1]
            dem_c  = zoom(np.where(valid_mask, dem_data, np.nanmean(dem_data[valid_mask])),
                          (zy, zx), order=1)
            mann_c = zoom(mann_grid, (zy, zx), order=1)
            valid_c = zoom(valid_mask.astype(np.float32), (zy, zx), order=0) > 0.5
            cell_size_c = cell_size / zx  # approx — square-ish cells assumed
        else:
            dem_c, mann_c, valid_c, cell_size_c = dem_data, mann_grid, valid_mask, cell_size

        # ── Source and outlet placement ─────────────────────────────────────
        # These must NOT be the same cell: if they were, injected water
        # would exit through the very same cell's open boundary in the
        # same step it entered, never spreading anywhere (max depth stays
        # at 0 everywhere despite a "perfect" mass balance — inflow and
        # outflow just cancel out immediately at one point). Outlet is the
        # lowest cell on the DOMAIN BOUNDARY (a genuine exit point, not
        # just the lowest cell anywhere, which could be an interior pit).
        # Source is the highest-elevation valid cell, representing inflow
        # arriving from upstream — a single point-source simplification
        # (real rainfall arrives distributed across the whole catchment;
        # this routes the already-computed catchment-integrated hydrograph
        # from one representative upstream point instead).
        edge_mask = np.zeros_like(valid_c, dtype=bool)
        edge_mask[0, :] = edge_mask[-1, :] = True
        edge_mask[:, 0] = edge_mask[:, -1] = True
        boundary_valid = valid_c & edge_mask
        if boundary_valid.any():
            outlet_idx = np.unravel_index(
                np.nanargmin(np.where(boundary_valid, dem_c, np.inf)), dem_c.shape)
        else:
            outlet_idx = np.unravel_index(
                np.nanargmin(np.where(valid_c, dem_c, np.inf)), dem_c.shape)

        source_idx = np.unravel_index(
            np.nanargmax(np.where(valid_c, dem_c, -np.inf)), dem_c.shape)
        if source_idx == outlet_idx:
            # Degenerate (near-flat) domain — nudge the source to the
            # farthest valid cell from the outlet instead.
            rr, cc = np.where(valid_c)
            d2 = (rr - outlet_idx[0])**2 + (cc - outlet_idx[1])**2
            far = np.argmax(d2)
            source_idx = (int(rr[far]), int(cc[far]))

        outlet_mask_c = np.zeros_like(valid_c, dtype=bool)
        outlet_mask_c[outlet_idx] = True

        if feedback:
            feedback.pushInfo(
                f"Routing hydrograph (peak {np.max(hydrograph_q_cms):.1f} m³/s) "
                f"through 2D diffusive-wave scheme: source at {source_idx} "
                f"(highest elevation), outlet at {outlet_idx} (lowest "
                f"boundary cell) ..."
            )

        class _NoProgressFeedback:
            """Forwards log messages from the 2D routing engine but
            SWALLOWS its setProgress calls. The engine reports its own
            0-100% for just that one sub-step; letting that reach the
            main progress bar makes the bar jump backwards and then
            freeze at whatever the routing reached (this is exactly why
            a completed run was observed sitting at 32% — the last 2D
            routing call stopped at t=38.5/116.25 hr = 33%)."""
            def __init__(self, real): self._r = real
            def pushInfo(self, m):
                if self._r: self._r.pushInfo(m)
            def pushWarning(self, m):
                if self._r: self._r.pushWarning(m)
            def reportError(self, m, fatalError=False):
                if self._r: self._r.reportError(m, fatalError)
            def setProgress(self, v): pass
            def isCanceled(self):
                try:
                    return self._r.isCanceled() if self._r else False
                except Exception:
                    return False

        result = route_2d_diffusive_wave(
            dem_c, cell_size_c, mann_c,
            np.asarray(hydrograph_time_s, dtype=np.float64),
            np.asarray(hydrograph_q_cms, dtype=np.float64),
            source_rc=source_idx, outlet_mask=outlet_mask_c, valid_mask=valid_c,
            sim_duration_s=sim_duration_s, max_wall_time_s=max_wall_time_s,
            feedback=_NoProgressFeedback(feedback),
        )

        depth = np.where(valid_c, result.max_depth, -9999.0).astype(np.float32)
        flood_mask = (depth > 0.02) & valid_c   # 2cm threshold to exclude numerical noise
        flood_pct = 100.0 * float(np.sum(flood_mask)) / float(np.sum(valid_c)) if np.sum(valid_c) else 0.0
        max_depth_val = float(np.nanmax(depth[flood_mask])) if flood_mask.any() else 0.0

        out_transform_c = from_origin(
            out_transform.c, out_transform.f,
            cell_size_c, cell_size_c
        )
        out_meta = {
            'driver': 'GTiff', 'height': depth.shape[0], 'width': depth.shape[1],
            'count': 1, 'dtype': 'float32', 'crs': dem_crs,
            'transform': out_transform_c, 'nodata': -9999.0, 'compress': 'lzw',
        }
        with rasterio.open(flood_raster, 'w', **out_meta) as dst:
            dst.write(depth, 1)

        _render_flood_map_2d(
            dem_c, depth, flood_mask, valid_c,
            float(np.nanmin(dem_c[valid_c])), float(np.nanmax(dem_c[valid_c])),
            max_depth_val, flood_pct, hydrograph_q_cms, return_period,
            result, coarsen_factor, flood_image, feedback
        )

        if feedback:
            feedback.pushInfo(
                f"2D flood map done: {flood_pct:.1f}% of catchment flooded, "
                f"max depth {max_depth_val:.2f} m, "
                f"mass balance error {result.mass_balance_error_pct:.1f}%"
            )
            # A truncated run produces a map that LOOKS like an answer but
            # is really "the flood wave has not arrived yet". Say so
            # plainly rather than letting a partial envelope be read as a
            # flood extent.
            if not result.converged:
                pct_done = 100.0 * result.sim_time_s / max(sim_duration_s or 1.0, 1e-6) \
                    if sim_duration_s else None
                feedback.pushWarning(
                    f"  INCOMPLETE: the simulation stopped after "
                    f"{result.sim_time_s/3600.0:.1f} simulated hours before the "
                    f"flood wave finished spreading. The {flood_pct:.1f}% extent "
                    f"above is therefore an UNDER-estimate — it shows how far the "
                    f"water had travelled when time ran out, NOT the flood extent. "
                    f"Do not use this map. Either raise the wall-time limit or "
                    f"use the (already complete) non-2D flood map instead."
                )

        return flood_image, flood_raster, result

    except Exception as e:
        if feedback:
            import traceback
            feedback.reportError(f"2D flood mapping failed: {e}")
            feedback.pushInfo(traceback.format_exc())
        return None, None, None


def _render_flood_map_2d(dem_data, depth, flood_mask, valid_mask,
                          min_elev, max_elev, max_depth_val, flood_pct,
                          hydrograph_q_cms, return_period, result,
                          coarsen_factor, output_path, feedback):
    """Internal: render and save the 2D-routing flood inundation PNG."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(16, 8),
                                  gridspec_kw={'width_ratios': [3, 1]})
        ax_map, ax_info = axes

        dem_masked = np.ma.masked_where(~valid_mask, dem_data)
        im_dem = ax_map.imshow(dem_masked, cmap='terrain',
                                vmin=min_elev, vmax=max_elev,
                                interpolation='bilinear', aspect='auto')
        cbar = plt.colorbar(im_dem, ax=ax_map, fraction=0.03, pad=0.01)
        cbar.set_label('Elevation (m)', fontsize=9)

        if max_depth_val > 0:
            depth_cmap = LinearSegmentedColormap.from_list(
                'flood', [(0.529, 0.808, 0.980, 0.0), (0.0, 0.4, 0.8, 0.85)])
            depth_masked = np.ma.masked_where(~flood_mask, depth)
            ax_map.imshow(depth_masked, cmap=depth_cmap, vmin=0,
                          vmax=max(0.5, max_depth_val), interpolation='bilinear',
                          aspect='auto')

        ax_map.set_title(
            f"2D Diffusive-Wave Flood Extent — {return_period}-yr "
            f"(coarsened {coarsen_factor}x for runtime)",
            fontsize=12, fontweight='bold'
        )
        ax_map.axis('off')

        ax_info.axis('off')
        info_text = (
            f"2D Diffusive-Wave Routing\n"
            f"{'='*32}\n\n"
            f"Peak inflow: {np.max(hydrograph_q_cms):.1f} m³/s\n"
            f"Simulated: {result.sim_time_s/3600.0:.2f} hr "
            f"({'reached target' if result.converged else 'stopped early — see log'})\n"
            f"Steps: {result.n_steps}\n"
            f"Mass balance error: {result.mass_balance_error_pct:.1f}%\n\n"
            f"Max depth: {max_depth_val:.2f} m\n"
            f"Flooded: {flood_pct:.1f}% of catchment\n\n"
            f"This routes the full hydrograph over simulated\n"
            f"time (rise/peak/recession), reporting the max\n"
            f"depth reached at each cell — not a single static\n"
            f"water level. Still a diffusive-wave simplification,\n"
            f"not a full dynamic 2D solve; injected at a single\n"
            f"upstream point, not per sub-basin (see function\n"
            f"docstring for scope/assumptions)."
        )
        ax_info.text(0.05, 0.95, info_text, transform=ax_info.transAxes,
                     fontsize=9.5, verticalalignment='top', family='monospace')

        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        if feedback:
            feedback.pushInfo(f"  Saved: {os.path.basename(output_path)}")
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"2D flood map rendering failed: {e}")


def _fill_sinks(dem, valid_mask=None, epsilon=1e-3, feedback=None):
    """
    Depression filling by PRIORITY-FLOOD (Barnes, Lehman & Mulla 2014) —
    the standard algorithm for this, and correct for depressions of any
    size and shape.

    `valid_mask` marks the cells that are actually inside the catchment.
    THIS MATTERS ENORMOUSLY and getting it wrong was the cause of the
    grossly over-large flood extents. A catchment clipped out of a DEM is
    an irregular blob inside a rectangular array; every cell outside the
    polygon is nodata. If those nodata cells are first replaced by some
    constant (the catchment mean elevation, say) and priority-flood is
    then seeded from the ARRAY edge, that constant ring behaves as a solid
    dam all the way around the catchment: the algorithm concludes that
    every cell below the ring elevation is sitting in one enormous
    depression with no outlet, and raises the entire lower catchment to
    the ring level. Measured on a synthetic catchment with exactly that
    geometry: 46.9% of cells raised, by up to 175.8 m, leaving the whole
    lower catchment as one dead-flat surface at the fill elevation. HAND
    measured against a flat surface is ~0 everywhere, so essentially all
    of it floods, and the extent then barely responds to discharge (55%
    at 1 m depth vs 69% at 6 m) — the signature seen in real runs, where
    a 1.9x increase in discharge moved extent from 65.8% to 65.9%.

    With `valid_mask` supplied, the queue is instead seeded from the
    catchment's OWN perimeter (valid cells on the array edge or touching
    nodata) at each cell's own elevation, and nodata cells are never
    processed. Water can therefore leave through the real outlet, which
    is on that perimeter, and only genuine interior depressions get
    filled. Cells outside the mask are returned unchanged.

    `valid_mask=None` preserves the original behaviour (whole array valid,
    drainage through the array edge) for the case where the DEM really
    does fill its rectangle.

    Why not the simpler iterative neighbour-minimum approach used
    previously: that can only fill SINGLE-CELL pits. In any multi-cell
    depression, every interior cell has at least one neighbour at its own
    elevation, so "raise to the minimum of my neighbours" leaves it
    exactly where it is and the depression never fills. Confirmed
    directly on a test DEM: a pit floor at 90 m inside a rim at 115 m
    rose only to 90.15 m after 150 iterations. Unfilled depressions trap
    flow, so the derived stream network fragments into disconnected
    stubs, and HAND distances measured to those fragments are what
    produced the straight-line and blocky artifacts in the flood maps.

    Priority-flood works from the DEM boundary inward using a min-heap:
    always process the lowest unresolved cell next, and raise each
    newly-reached neighbour to at least the current water level. That
    naturally floods every depression up to its true pour point in a
    single pass.

    The `epsilon` increment (1 mm by default, far below DEM vertical
    accuracy) makes each filled cell slightly higher than the one it
    drains to, guaranteeing D8 always finds a strictly-lower neighbour.
    Without it, filled areas are perfectly flat and D8 flow simply stops
    there.
    """
    import heapq
    from scipy import ndimage

    z = dem.astype(np.float64).copy()
    rows, cols = z.shape

    if valid_mask is None:
        valid = np.isfinite(z)
    else:
        valid = np.asarray(valid_mask, dtype=bool) & np.isfinite(z)

    # Cells outside the catchment are never processed and never act as a
    # barrier: mark them closed up front.
    closed = ~valid

    # Seed from the catchment PERIMETER: valid cells that lie on the array
    # edge or that touch a nodata cell. These are the cells through which
    # water can physically leave the modelled domain (the outlet is one of
    # them), so they are the correct starting level for the flood.
    edge = np.zeros((rows, cols), dtype=bool)
    edge[0, :] = edge[-1, :] = True
    edge[:, 0] = edge[:, -1] = True
    touches_nodata = valid & (ndimage.binary_dilation(~valid) | edge)
    seed_r, seed_c = np.nonzero(touches_nodata)
    heap = [(float(z[r, c]), int(r), int(c)) for r, c in zip(seed_r, seed_c)]
    heapq.heapify(heap)
    closed[seed_r, seed_c] = True

    if not heap:
        return z

    neighbours = ((-1, -1), (-1, 0), (-1, 1), (0, -1),
                  (0, 1), (1, -1), (1, 0), (1, 1))

    while heap:
        zc, r, c = heapq.heappop(heap)
        for dr, dc in neighbours:
            nr, nc = r + dr, c + dc
            if nr < 0 or nr >= rows or nc < 0 or nc >= cols:
                continue
            if closed[nr, nc]:
                continue
            closed[nr, nc] = True
            # Raise to just above the level it drains through, so a
            # downhill path always exists.
            if z[nr, nc] <= zc:
                z[nr, nc] = zc + epsilon
            heapq.heappush(heap, (z[nr, nc], nr, nc))

    return z


def _main_stem_slope(dem_filled, dem_raw, valid_mask, accumulation,
                      flow_dr, flow_dc, has_target, cell_size,
                      stream_mask=None, feedback=None):
    """
    Longitudinal slope of the main channel, measured as S1085 over the
    main-stem long profile.

    Why not the drop from each stream cell to its own D8 neighbour: one
    cell is far too short a baseline. Over 30 m, DEM vertical noise and
    the 1 mm epsilon increment left behind by depression filling are both
    larger than the real fall, so the per-cell drops are mostly noise.
    Taking their median doesn't rescue it — where filling has flattened a
    stretch of valley, MOST stream cells carry only the epsilon drop
    (3e-5 over 30 m), so the median lands on the flats. Measured on a
    synthetic catchment routed at native 30 m resolution, where 11% of
    cells were epsilon-filled: the per-cell median returned S=0.00010,
    pinning against the lower bound, and the back-calculated depth
    exploded from 3.3 m to 16.4 m (depth ~ S^-0.3), flooding 38% of the
    catchment.

    S1085 is the standard main-stem measure (UK FEH practice): the fall
    between the points 10% and 85% of the way up the longest flow path
    from the outlet, divided by that 75% of the path length. Trimming
    both ends drops the flat outlet reach and the steep headwater tip,
    neither of which represents the reach that governs flood depth, and a
    baseline of ~75% of the whole flow path is long enough that DEM noise
    and fill epsilon are negligible against the real fall.

    The profile is walked UPSTREAM from the cell of maximum accumulation,
    at each step taking whichever inflowing neighbour carries the most
    upstream area — i.e. following the main stem, not an arbitrary
    tributary. Elevations are read from the unfilled DEM so fill
    artefacts don't enter the profile.

    The walk STOPS at the top of the stream network (`stream_mask`), not
    at the topographic divide. Above the channel head the flow path is
    hillslope, which is far steeper than any channel and is not where
    flood depth is set; letting the trace continue onto it drags the
    profile up the valley wall. Measured on a test DEM with a known 1.5%
    channel slope whose channel head sits at the grid edge: the trace ran
    on along the ridge for another 100 cells, and S1085 came back as
    0.060 — four times the true value — because the 85% point had ended
    up on the hillslope rather than in the channel.

    Returns the slope (m/m), or None if no usable profile exists.
    """
    rows, cols = dem_filled.shape
    if not np.any(valid_mask):
        return None

    acc_masked = np.where(valid_mask, accumulation, -1.0)
    outlet = np.unravel_index(int(np.argmax(acc_masked)), (rows, cols))

    on_stream = None if stream_mask is None else np.asarray(stream_mask, dtype=bool)

    offsets = ((-1, -1), (-1, 0), (-1, 1), (0, -1),
               (0, 1), (1, -1), (1, 0), (1, 1))

    bed = np.where(np.isfinite(dem_raw), dem_raw, dem_filled)

    r, c = int(outlet[0]), int(outlet[1])
    elevs = [float(bed[r, c])]
    dists = [0.0]
    seen = {(r, c)}
    max_steps = rows * cols

    for _ in range(max_steps):
        best = None
        best_acc = -1.0
        for dr, dc in offsets:
            nr, nc = r + dr, c + dc
            if nr < 0 or nr >= rows or nc < 0 or nc >= cols:
                continue
            if not valid_mask[nr, nc] or (nr, nc) in seen:
                continue
            if not has_target[nr, nc]:
                continue
            if on_stream is not None and not on_stream[nr, nc]:
                continue
            # Does this neighbour drain INTO the current cell?
            if int(flow_dr[nr, nc]) != -dr or int(flow_dc[nr, nc]) != -dc:
                continue
            if accumulation[nr, nc] > best_acc:
                best_acc = float(accumulation[nr, nc])
                best = (nr, nc, dr, dc)
        if best is None:
            break
        nr, nc, dr, dc = best
        step = cell_size * (np.sqrt(2.0) if (dr != 0 and dc != 0) else 1.0)
        r, c = nr, nc
        seen.add((r, c))
        elevs.append(float(bed[r, c]))
        dists.append(dists[-1] + step)

    if len(dists) < 10:
        return None

    elevs = np.asarray(elevs, dtype=np.float64)
    dists = np.asarray(dists, dtype=np.float64)
    total_len = dists[-1]
    if total_len <= 0:
        return None

    z10 = float(np.interp(0.10 * total_len, dists, elevs))
    z85 = float(np.interp(0.85 * total_len, dists, elevs))
    fall = z85 - z10                      # profile runs upstream, so this is positive
    slope = fall / (0.75 * total_len)

    if feedback:
        feedback.pushInfo(
            f"  Main-stem long profile: {len(dists)} cells, "
            f"length {total_len / 1000.0:.1f} km, "
            f"fall {fall:.1f} m between the 10% and 85% points (S1085)."
        )

    if not np.isfinite(slope) or slope <= 0:
        return None
    return float(slope)


def _drainage_reference(dem_filled, dem_raw, valid_mask, stream_mask,
                         flow_dr, flow_dc, has_target, contrib_area):
    """
    For every cell, find the elevation and contributing area of the stream
    cell that it ACTUALLY DRAINS INTO, by walking down its D8 flow path.

    This is the definition of HAND (Height Above Nearest Drainage) that
    the name is usually taken to mean, and it is not the same thing as
    "the elevation of the geometrically closest stream cell". The
    Euclidean version has a specific failure mode on real terrain: a cell
    sitting in a small headwater gully whose own contributing area is
    below the stream-initiation threshold has no mapped channel nearby,
    so the closest mapped stream cell is often one valley over, across a
    divide, and HIGHER than the cell itself. HAND then comes out as 0 and
    the cell is marked flooded. Measured on a synthetic catchment: 16% of
    all cells returned HAND = 0 this way, against a genuine channel
    network covering 0.88% of the area.

    Walking the flow path instead guarantees the reference is somewhere
    the cell's own water would actually reach, which is always at or
    below the cell.

    Cells are resolved in ASCENDING elevation order. Every cell drains to
    a strictly lower neighbour on the filled DEM, so a cell's downstream
    target is always already resolved by the time the cell is reached —
    a topological ordering of the flow graph for free.

    Returns (reference_elevation, reference_contributing_area), both on
    the same grid as the inputs. Reference elevations come from `dem_raw`
    (the unfilled DEM) so that fill artefacts don't propagate into flood
    depths.
    """
    rows, cols = dem_filled.shape
    ref_elev = np.full((rows, cols), np.nan, dtype=np.float64)
    ref_area = np.zeros((rows, cols), dtype=np.float64)

    bed = np.where(np.isfinite(dem_raw), dem_raw, dem_filled)

    flat_valid = np.flatnonzero(valid_mask)
    if flat_valid.size == 0:
        return ref_elev, ref_area
    order = flat_valid[np.argsort(dem_filled.flat[flat_valid], kind='stable')]

    rr, cc = np.unravel_index(order, (rows, cols))
    is_str = stream_mask.flat[order]
    ht = has_target.flat[order]
    fdr = flow_dr.flat[order]
    fdc = flow_dc.flat[order]

    ref_e = ref_elev.reshape(-1)
    ref_a = ref_area.reshape(-1)
    bed_f = bed.reshape(-1)
    area_f = contrib_area.reshape(-1)

    for i in range(order.size):
        idx = order[i]
        if is_str[i]:
            ref_e[idx] = bed_f[idx]
            ref_a[idx] = area_f[idx]
            continue
        if ht[i]:
            tr, tc = rr[i] + fdr[i], cc[i] + fdc[i]
            if 0 <= tr < rows and 0 <= tc < cols:
                tidx = tr * cols + tc
                if np.isfinite(ref_e[tidx]):
                    ref_e[idx] = ref_e[tidx]
                    ref_a[idx] = ref_a[tidx]
                    continue
        # Terminal cell with no resolved downstream reference (the outlet
        # itself, or a cell draining straight off the catchment edge):
        # it is its own reference.
        ref_e[idx] = bed_f[idx]
        ref_a[idx] = area_f[idx]

    return ref_elev, ref_area


def _block_min_coarsen(dem, valid_mask, factor):
    """
    Coarsen a DEM for drainage analysis by taking the MINIMUM of each
    factor x factor block, ignoring nodata.

    Minimum (not bilinear interpolation) because the point of the coarse
    grid is to find where water flows. Averaging a block that contains a
    narrow valley and two hillslopes erases the valley — the coarse cell
    ends up at hillslope elevation and the channel disappears, which
    fragments the derived network. The block minimum preserves the
    thalweg, which is the standard way to downsample a DEM when the
    derived product is a stream network.

    Bilinear interpolation was also unsafe here for a second reason: with
    nodata left as NaN it smears NaN into every coarse cell near the
    catchment boundary, and with nodata replaced by a constant it smears
    that constant into real terrain.

    Returns (dem_coarse, valid_coarse). Invalid coarse cells are NaN.
    """
    rows, cols = dem.shape
    nr, nc = max(1, rows // factor), max(1, cols // factor)
    r_end, c_end = nr * factor, nc * factor

    work = np.where(valid_mask, dem, np.inf).astype(np.float64)[:r_end, :c_end]
    vmask = np.asarray(valid_mask, dtype=bool)[:r_end, :c_end]

    blocks = work.reshape(nr, factor, nc, factor)
    dem_c = blocks.min(axis=(1, 3))
    valid_c = vmask.reshape(nr, factor, nc, factor).any(axis=(1, 3))
    dem_c = np.where(valid_c & np.isfinite(dem_c), dem_c, np.nan)
    return dem_c, valid_c & np.isfinite(dem_c)


def _flow_accumulation_d8(dem_filled, valid_mask, return_dirs=False):
    """
    Self-contained D8 flow accumulation. Needed because the actual
    stream/channel network occupies a tiny fraction of a catchment's
    area — using an elevation percentile (e.g. "lowest 25%") as a stand-
    in for "near the channel" was confirmed as the root cause of flood
    extent getting stuck near a fixed ~25% regardless of discharge
    magnitude: a broad, gently-sloping valley floor can easily fall
    within the lowest 25% of elevation across its whole width, which
    has nothing to do with how close any given cell actually is to
    where the water flows. Real flow accumulation (how many upstream
    cells drain through each cell) is the correct way to identify the
    channel network, and scales appropriately with terrain shape.

    Returns an array where each cell's value = number of upstream cells
    (including itself) that drain through it, via steepest-descent (D8)
    routing on the filled DEM.
    """
    rows, cols = dem_filled.shape
    offsets = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    dists   = [np.sqrt(2), 1.0, np.sqrt(2), 1.0, 1.0, np.sqrt(2), 1.0, np.sqrt(2)]

    dem_work = np.where(valid_mask, dem_filled, np.inf).astype(np.float64)
    best_slope  = np.zeros((rows, cols), dtype=np.float64)
    flow_dr     = np.zeros((rows, cols), dtype=np.int8)
    flow_dc     = np.zeros((rows, cols), dtype=np.int8)
    has_target  = np.zeros((rows, cols), dtype=bool)

    for (dy, dx), dist in zip(offsets, dists):
        neighbor = np.full((rows, cols), np.inf)
        dst_r0, dst_r1 = max(0, -dy), rows - max(0, dy)
        dst_c0, dst_c1 = max(0, -dx), cols - max(0, dx)
        src_r0, src_r1 = max(0, dy), rows - max(0, -dy)
        src_c0, src_c1 = max(0, dx), cols - max(0, -dx)
        neighbor[dst_r0:dst_r1, dst_c0:dst_c1] = dem_work[src_r0:src_r1, src_c0:src_c1]
        with np.errstate(invalid='ignore'):
            slope = (dem_work - neighbor) / dist
        better = np.isfinite(slope) & (slope > best_slope) & valid_mask
        best_slope = np.where(better, slope, best_slope)
        flow_dr = np.where(better, dy, flow_dr)
        flow_dc = np.where(better, dx, flow_dc)
        has_target = has_target | better

    # Process cells in descending elevation order so each cell's full
    # accumulation is resolved before it's added to its downstream
    # neighbour (a cell only ever flows to a strictly lower neighbour on
    # the filled DEM, so this order is always valid — equivalent to a
    # topological sort of the flow graph without needing one explicitly).
    accumulation = np.where(valid_mask, 1.0, 0.0)
    valid_flat_idx = np.flatnonzero(valid_mask)
    order = valid_flat_idx[np.argsort(-dem_work.flat[valid_flat_idx])]
    rr, cc = np.unravel_index(order, (rows, cols))
    fdr, fdc = flow_dr.flat[order], flow_dc.flat[order]
    ht = has_target.flat[order]

    acc_flat = accumulation.reshape(-1)
    for i in range(len(order)):
        if not ht[i]:
            continue
        r, c = rr[i], cc[i]
        tr, tc = r + fdr[i], c + fdc[i]
        if 0 <= tr < rows and 0 <= tc < cols:
            acc_flat[tr * cols + tc] += acc_flat[r * cols + c]

    if return_dirs:
        # flow_dr/flow_dc give each cell's D8 downstream neighbour offset,
        # which is what a LONGITUDINAL (along-channel) slope has to be
        # measured along — see the channel-slope section of
        # generate_flood_map for why the gradient magnitude can't be used.
        return accumulation, flow_dr, flow_dc, has_target
    return accumulation


def _write_qml_hazard_class(qml_path):
    """
    QML for the hazard-classification raster (1=Low, 2=Danger for some,
    3=Danger for most, 4=Danger for all; 0/255=not flooded/nodata).
    Colours follow the conventional low-to-extreme hazard progression
    used in UK EA/Defra flood hazard mapping products.

    Uses a plain 6-digit RGB hex string with transparency controlled by
    the separate alpha XML attribute (0-255) — matching the paletted-
    renderer format already validated working elsewhere (write_qml_lulc
    in raster_downloader.py), not the 8-digit #AARRGGBB format (which is
    a QColor string-parsing convention relevant only to the
    singlebandpseudocolor <item> elements used for CN/Manning's n/DEM/
    slope, a genuinely different QML element with different rules).
    """
    items = [
        (0,   0,   '#FFFFFF', 'Not flooded'),
        (1,   255, '#F9E4B7', 'Low hazard (caution)'),
        (2,   255, '#F4A582', 'Danger for some (children, elderly)'),
        (3,   255, '#D6604D', 'Danger for most'),
        (4,   255, '#B2182B', 'Danger for all (extreme)'),
        (255, 0,   '#FFFFFF', 'No data'),
    ]
    entries = '\n'.join(
        f'    <paletteEntry alpha="{alpha}" color="{col}" label="{lbl}" value="{v}"/>'
        for v, alpha, col, lbl in items
    )
    qml = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="paletted" band="1" opacity="1">
      <colorPalette>
{entries}
      </colorPalette>
    </rasterrenderer>
    <rasterresampler maxOversampling="2"/>
  </pipe>
</qgis>"""
    with open(qml_path, 'w') as f:
        f.write(qml)


def generate_flood_map(discharge, dem_path, catchment_path, output_dir,
                        return_period, manning_n=0.05, feedback=None,
                        cn_raster_path=None, manning_raster_path=None,
                        runoff_depth_mm=None):
    """
    Generate a flood inundation map (GeoTIFF + PNG) with depth, velocity,
    and depth x velocity hazard classification.

    This is a screening-level approximation (single catchment-wide water
    depth, planar water surface flood-filled from the outlet) — see the
    module docstring for what it does and doesn't capture. It is useful
    for a quick first look at approximate flood extent, not a substitute
    for a proper 2D hydraulic model for design or regulatory work.

    Hazard classification follows the UK Defra/Environment Agency "Flood
    Risks to People" methodology (FD2320/FD2321, Ramsbottom et al.):
    Hazard Rating = depth * (velocity + 0.5) + debris_factor, classified
    into Low / Danger for some / Danger for most / Danger for all.
    Velocity is estimated via Manning's equation using local depth as
    hydraulic radius (standard for wide, shallow overland flow) and the
    local per-pixel slope.

    Parameters
    ----------
    discharge         : float   – peak discharge (m³/s)
    dem_path          : str     – path to DEM raster (GeoTIFF)
    catchment_path    : str     – path to catchment polygon (shapefile/GeoJSON)
    output_dir        : str     – output directory
    return_period     : int     – return period (years, for labelling)
    manning_n         : float   – uniform Manning's n (used if manning_raster_path=None)
    feedback          : QgsProcessingFeedback or None
    cn_raster_path    : str     – path to CN raster (optional, for extent calibration)
    manning_raster_path : str   – path to Manning's n raster (optional, spatial)
    runoff_depth_mm   : float   – runoff depth (mm), used for volume consistency check

    Returns
    -------
    (flood_map_png_path, flood_depth_raster_path, flood_velocity_raster_path,
     flood_hazard_class_raster_path) or (None, None, None, None) on error
    """
    try:
        import geopandas as gpd
        import rasterio
        from rasterio.mask import mask as rasterio_mask
        from rasterio import features as rio_features
        from shapely.geometry import mapping
        from scipy import ndimage

        os.makedirs(os.path.join(output_dir, 'flood_maps'),    exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'flood_rasters'), exist_ok=True)

        flood_image  = os.path.join(output_dir, 'flood_maps',    f"flood_map_{return_period}yr.png")
        flood_raster = os.path.join(output_dir, 'flood_rasters', f"flood_depth_{return_period}yr.tif")

        # ── Load catchment ─────────────────────────────────────────────────
        catchment = gpd.read_file(catchment_path)

        # ── Load and clip DEM ──────────────────────────────────────────────
        with rasterio.open(dem_path) as src:
            original_nodata = src.nodata
            catchment_dem   = catchment.to_crs(src.crs)
            geoms = [mapping(g) for g in catchment_dem.geometry]

            out_image, out_transform = rasterio_mask(src, geoms, crop=True,
                                                      nodata=np.nan, filled=True)
            dem_data  = out_image[0].astype(np.float32)
            dem_crs   = src.crs
            dem_meta  = src.meta.copy()
            cell_size = abs(src.transform[0])   # metres/pixel (approx for projected)

        # Handle nodata
        if original_nodata is not None:
            dem_data[dem_data == original_nodata] = np.nan
        dem_data[dem_data < -1000] = np.nan

        # ── Sanity check: DEM resolution vs. catchment size ────────────────
        # The flood extent below is built by flood-filling from the outlet
        # through 8-connected pixels. If the catchment only spans a small
        # number of cells across, that connectivity search (and the
        # Gaussian-smoothed slope calculation) becomes unreliable — a
        # coarse DEM relative to catchment size can produce a flood extent
        # that's really just an artifact of having too few pixels to work
        # with, not a meaningful result.
        n_rows, n_cols = dem_data.shape
        min_span_cells = min(n_rows, n_cols)
        if min_span_cells < 20 and feedback:
            feedback.pushWarning(
                f"  DEM resolution is coarse relative to this catchment: "
                f"only {n_rows}×{n_cols} cells ({cell_size:.0f} m/pixel) "
                f"span it. Flood extent/connectivity results below may be "
                f"unreliable — consider a finer-resolution DEM if one is "
                f"available."
            )

        valid_elev = dem_data[~np.isnan(dem_data)]
        if len(valid_elev) == 0:
            if feedback:
                feedback.reportError("No valid DEM data in catchment.")
            return None, None, None, None

        min_elev  = float(np.nanmin(dem_data))
        max_elev  = float(np.nanmax(dem_data))
        mean_elev = float(np.nanmean(dem_data))

        if feedback:
            feedback.pushInfo(f"DEM: min={min_elev:.2f}, max={max_elev:.2f}, "
                              f"mean={mean_elev:.2f} m, cell={cell_size:.1f} m")

        # ── Load spatially-variable Manning's n (optional) ────────────────
        mann_grid = None
        if manning_raster_path and os.path.exists(manning_raster_path):
            try:
                with rasterio.open(manning_raster_path) as msrc:
                    m_catchment = catchment.to_crs(msrc.crs)
                    m_geoms = [mapping(g) for g in m_catchment.geometry]
                    m_out, _ = rasterio_mask(msrc, m_geoms, crop=True,
                                              nodata=-9999.0, filled=True)
                    m_arr = m_out[0].astype(np.float32)
                    m_arr[m_arr <= 0]  = np.nan
                    m_arr[m_arr > 5.0] = np.nan
                    # Resize to DEM grid if needed (nearest neighbour)
                    if m_arr.shape != dem_data.shape:
                        from scipy.ndimage import zoom
                        zy = dem_data.shape[0] / m_arr.shape[0]
                        zx = dem_data.shape[1] / m_arr.shape[1]
                        m_arr = zoom(m_arr, (zy, zx), order=0)
                    mann_grid = np.where(np.isnan(m_arr), manning_n, m_arr)
                    mean_mann = float(np.nanmean(mann_grid))
                    if feedback:
                        feedback.pushInfo(f"Spatial Manning's n loaded: mean n={mean_mann:.4f}")
            except Exception as e:
                if feedback:
                    feedback.pushWarning(f"Manning raster load failed ({e}). Using uniform n.")

        eff_manning = float(np.nanmean(mann_grid)) if mann_grid is not None else manning_n

        # ── Load CN raster (optional): full grid, not just the mean ────────
        # Previously this only computed a catchment mean for display text
        # ("CN raster: mean CN=...") and never actually fed into the
        # extent/depth calculation despite the parameter being documented
        # as "for extent calibration" — that claim wasn't accurate. It's
        # now used below to make local depth respond to imperviousness
        # (less infiltration capacity -> more of the local rainfall excess
        # stays on the surface).
        cn_grid = None
        mean_cn = None
        if cn_raster_path and os.path.exists(cn_raster_path):
            try:
                with rasterio.open(cn_raster_path) as csrc:
                    c_catchment = catchment.to_crs(csrc.crs)
                    c_geoms = [mapping(g) for g in c_catchment.geometry]
                    c_out, _ = rasterio_mask(csrc, c_geoms, crop=True,
                                              nodata=-9999.0, filled=True)
                    c_arr = c_out[0].astype(np.float32)
                    c_arr[(c_arr < 1) | (c_arr > 100)] = np.nan
                    if c_arr.shape != dem_data.shape:
                        from scipy.ndimage import zoom
                        zy = dem_data.shape[0] / c_arr.shape[0]
                        zx = dem_data.shape[1] / c_arr.shape[1]
                        c_arr = zoom(c_arr, (zy, zx), order=0)
                    if np.any(~np.isnan(c_arr)):
                        mean_cn = float(np.nanmean(c_arr[~np.isnan(c_arr)]))
                        cn_grid = np.where(np.isnan(c_arr), mean_cn, c_arr)
                    if feedback and mean_cn:
                        feedback.pushInfo(f"CN raster: mean CN={mean_cn:.1f}")
            except Exception as e:
                if feedback:
                    feedback.pushWarning(f"CN raster load failed ({e}).")

        # ── Hydraulic water depth estimation ──────────────────────────────
        # Method: planar water surface with Manning's depth back-calculation
        # Q = (1/n) * A * R^(2/3) * S^(1/2)
        # Approximate: wide rectangular channel, R ≈ y, A = W*y
        # Estimate channel width from discharge (regime equation)
        channel_width = max(1.0, 3.0 * (discharge ** 0.5))   # Lacey-type estimate (m)

        # Slope from DEM gradient, smoothed with a NODATA-AWARE (normalised)
        # Gaussian. Substituting the catchment mean elevation for nodata and
        # smoothing that, as before, invents a cliff all the way around the
        # catchment boundary — typically 100 m+ of fake relief over a couple
        # of cells — which inflates slope_grid in a ring around the edge and
        # drags the representative slope with it. Weighting by the valid
        # mask smooths only real terrain.
        _valid0 = ~np.isnan(dem_data)
        _num = ndimage.gaussian_filter(np.where(_valid0, dem_data, 0.0).astype(np.float64), sigma=2)
        _den = ndimage.gaussian_filter(_valid0.astype(np.float64), sigma=2)
        _dem_smooth = np.where(_den > 1e-6, _num / np.maximum(_den, 1e-6), mean_elev)
        grad_y, grad_x = np.gradient(_dem_smooth, cell_size)
        slope_grid = np.sqrt(grad_x**2 + grad_y**2)
        slope_grid = np.where(slope_grid < 1e-5, 1e-5, slope_grid)

        # Representative slope for the Manning's depth calculation: use only
        # the lowest-elevation portion of the catchment (valley bottom /
        # near the outlet), not the whole-catchment mean. Natural terrain
        # slope statistics are dominated by hillslope area, which is
        # typically much steeper than the channel/floodplain that actually
        # governs flood depth — averaging over the whole catchment mixes
        # those in and biases the slope (and therefore the back-calculated
        # depth, since depth ~ S^-0.3) toward values not representative of
        # where the flooding actually happens.
        valid_elev = dem_data[~np.isnan(dem_data)]
        if valid_elev.size > 0:
            low_thresh = np.nanpercentile(dem_data, 25)
            valley_mask = (~np.isnan(dem_data)) & (dem_data <= low_thresh)
            if np.any(valley_mask):
                mean_slope = float(np.nanmean(slope_grid[valley_mask]))
            else:
                mean_slope = float(np.nanmean(slope_grid))
        else:
            mean_slope = float(np.nanmean(slope_grid))
        mean_slope = max(mean_slope, 0.0001)

        # Manning's depth: y = (Q * n / (W * S^0.5))^(3/5)
        Qn     = discharge * eff_manning
        Ws05   = channel_width * (mean_slope ** 0.5)
        if Ws05 > 0:
            water_depth = (Qn / Ws05) ** (3.0 / 5.0)
        else:
            water_depth = max(1.0, discharge ** 0.4 * 0.3)

        # Clamp to reasonable bounds
        water_depth = np.clip(water_depth, 0.1, 30.0)
        if feedback:
            feedback.pushInfo(
                f"Hydraulic: Q={discharge:.1f} m³/s, n={eff_manning:.4f}, "
                f"W={channel_width:.1f} m, S={mean_slope:.5f} "
                f"(valley-bottom, lowest 25% of elevation), "
                f"depth={water_depth:.2f} m"
            )

        # ── Flood extent via Height Above Nearest Drainage (HAND) ──────────
        # The previous approach used ONE global water surface elevation
        # (min_elev + water_depth) and flood-filled from the single lowest
        # point in the whole catchment. That fundamentally can't work well
        # across a large, high-relief catchment: water_depth is only a few
        # metres, so a single global reference point is either miles from
        # any other low terrain (extent collapses to a tiny sliver near
        # that one point) or happens to sit near other unrelated low areas
        # elsewhere in the DEM (extent balloons to include them) — this
        # exact oscillation between "way too small" and "way too large"
        # showed up in real testing round after round, because there is
        # no single global reference elevation that works for varied
        # terrain shape.
        #
        # HAND instead computes each cell's height above its OWN nearest
        # drainage reference, not one shared global point — the standard
        # simplification used in real operational flood-mapping tools
        # (e.g. NOAA's, USGS's). The reference set matters a lot: an
        # earlier version used valley_mask (lowest 25% of catchment
        # elevation) as a lightweight proxy for "near the channel" — but
        # a real channel occupies a tiny fraction of a catchment's area,
        # while "lowest 25% by elevation" captures the ENTIRE broad
        # valley floor for any gently-sloping terrain. Confirmed directly
        # in real-world testing: flood extent got stuck near a fixed 25%
        # regardless of discharge (a 15x increase in Q only moved extent
        # from 25.3% to 26.3%), because that broad, roughly-flat 25%
        # swath satisfies "within water_depth of its own nearest
        # reference" almost by construction, independent of how much
        # water is actually present. Real flow accumulation (self-
        # contained D8 routing, see _flow_accumulation_d8) identifies
        # the actual channel network instead, which is what should be
        # driving flood proximity, not a raw elevation percentile.
        valid_mask = ~np.isnan(dem_data)

        # HAND heights are measured on the RAW DEM, not a sink-filled one.
        # Filling exists to make flow routing work; it is not terrain, and
        # using filled elevations as the "height above drainage" builds the
        # fill artefacts straight into the flood depths. Routing below is
        # done on a filled COARSE grid, which is all the filling is needed
        # for.
        dem_hand = np.where(valid_mask, dem_data, np.nan).astype(np.float64)

        # Flow accumulation runs on a COARSENED grid for tractable runtime
        # — measured directly: at native resolution, a real ~7.6M-cell
        # catchment DEM (matching real-world catchment sizes seen in
        # testing) took an estimated ~30 minutes total across 4 return
        # periods, which would make the tool appear to hang. Coarsening
        # only affects which cells get identified as "stream network"; the
        # HAND heights and depths below stay at native resolution, and
        # 30 m-scale stream identification doesn't need pixel-perfect
        # resolution to begin with.
        target_acc_cells = 250000
        n_cells_native = dem_data.shape[0] * dem_data.shape[1]
        acc_coarsen = max(1, int(np.ceil(np.sqrt(n_cells_native / target_acc_cells))))
        if acc_coarsen > 1:
            dem_c_raw, valid_c = _block_min_coarsen(dem_hand, valid_mask, acc_coarsen)
            cell_size_c = cell_size * acc_coarsen
            if feedback:
                feedback.pushInfo(
                    f"  Flow accumulation: coarsening {dem_data.shape[0]}x{dem_data.shape[1]} "
                    f"-> {dem_c_raw.shape[0]}x{dem_c_raw.shape[1]} ({acc_coarsen}x) "
                    f"for tractable runtime (block minimum, preserves valley bottoms)."
                )
        else:
            dem_c_raw, valid_c, cell_size_c = dem_hand, valid_mask, cell_size

        if not np.any(valid_c):
            if feedback:
                feedback.reportError("Catchment is too small for the DEM resolution.")
            return None, None, None, None

        # Fill depressions on the coarse grid ONLY, and with the catchment
        # mask supplied so water drains out through the catchment's own
        # perimeter instead of being dammed by the nodata surround. See
        # _fill_sinks for what the unmasked version did to extents.
        dem_c = _fill_sinks(dem_c_raw, valid_mask=valid_c)
        n_raised = int(np.sum((dem_c[valid_c] - dem_c_raw[valid_c]) > 0.5))
        if feedback:
            feedback.pushInfo(
                f"  Depression fill (catchment-masked): {n_raised} of "
                f"{int(np.sum(valid_c))} coarse cells raised "
                f"({100.0 * n_raised / max(int(np.sum(valid_c)), 1):.1f}%)."
            )

        accumulation_c, fdr_c, fdc_c, has_tgt_c = _flow_accumulation_d8(
            dem_c, valid_c, return_dirs=True)
        cell_area_km2_c = (cell_size_c ** 2) / 1e6
        total_area_km2 = float(np.sum(valid_mask)) * (cell_size ** 2) / 1e6

        # Stream initiation threshold, SCALED TO CATCHMENT SIZE. A fixed
        # 0.5 km² threshold is a headwater-gully criterion: appropriate
        # for a small catchment, but on a large one it maps every minor
        # gully as "channel". Confirmed in real testing on a 2577 km²
        # catchment: a fixed 0.5 km² threshold classified 11.7% of the
        # whole catchment (301 km²) as channel, when a real channel
        # network occupies well under 1% of catchment area. With
        # essentially every cell then sitting close to a "stream", HAND
        # values were small everywhere and nearly the whole catchment
        # flooded.
        # Using ~0.5% of catchment area (bounded to a sensible range)
        # keeps the network to genuine channels across catchment sizes.
        stream_thresh_km2 = float(np.clip(0.005 * total_area_km2, 0.25, 25.0))
        min_stream_cells_c = max(1, int(stream_thresh_km2 / cell_area_km2_c))
        stream_mask_c = (accumulation_c >= min_stream_cells_c) & valid_c
        if not np.any(stream_mask_c):
            stream_mask_c = np.zeros_like(valid_c)
            stream_mask_c[np.unravel_index(np.argmax(np.where(valid_c, accumulation_c, -1)),
                                            accumulation_c.shape)] = True

        # Upstream contributing area per cell (km²) — needed below to
        # scale local discharge, so headwater tributaries aren't treated
        # as carrying the whole catchment's flood.
        contrib_area_c = accumulation_c * cell_area_km2_c

        if acc_coarsen > 1:
            zy_up = dem_data.shape[0] / stream_mask_c.shape[0]
            zx_up = dem_data.shape[1] / stream_mask_c.shape[1]
            stream_band = ndimage.zoom(stream_mask_c.astype(np.float32),
                                        (zy_up, zx_up), order=0) > 0.5
            stream_band = stream_band & valid_mask

            # Nearest-neighbour upsampling turns each coarse stream cell
            # into a solid acc_coarsen x acc_coarsen block of native cells
            # — at 6x that is a 180 m-wide band that spans the channel AND
            # the valley walls beside it. Every cell in that band is then
            # treated as a drainage reference, so a cell partway up the
            # hillside can end up measuring its HAND against another
            # hillside cell and come out at ~0 m above "drainage". On an
            # 11.7%-slope catchment a 180 m positional error is ~21 m of
            # spurious elevation, far larger than the few metres of flood
            # depth being tested against.
            #
            # Snap the band back down to the thalweg: within each block-
            # sized neighbourhood, keep only the cells sitting at (or
            # within 1 m of) the local minimum. That recovers roughly
            # channel-width detail from a coarse-grid network.
            win = 2 * acc_coarsen + 1
            local_min = ndimage.minimum_filter(
                np.where(valid_mask, dem_hand, np.inf), size=win, mode='nearest')
            stream_mask = stream_band & (dem_hand <= local_min + 1.0)
            if not np.any(stream_mask):
                stream_mask = stream_band
            if not np.any(stream_mask):
                stream_mask = np.zeros_like(valid_mask)
                stream_mask[np.unravel_index(
                    np.argmin(np.where(valid_mask, dem_hand, np.inf)),
                    dem_hand.shape)] = True
        else:
            stream_mask = stream_mask_c

        if feedback:
            n_str = int(np.sum(stream_mask))
            feedback.pushInfo(
                f"  Stream network reference: {n_str} cells "
                f"({100.0*n_str/max(int(np.sum(valid_mask)),1):.2f}% of catchment, "
                f">={stream_thresh_km2:.2f} km² contributing area, scaled to a "
                f"{total_area_km2:.0f} km² catchment)"
            )

        # ── Refine the hydraulic slope using the ACTUAL channel cells ─────
        # mean_slope above was taken over the lowest 25% of elevation,
        # which is a rough proxy for "valley bottom" but still includes
        # broad flat areas and parts of the valley walls. Now that the
        # real stream network is known, the gradient measured AT stream
        # cells is a much better estimate of the longitudinal water-
        # surface slope that Manning's actually needs: at a channel cell
        # the cross-valley gradient is near zero (it is the local low
        # point), so the remaining gradient is predominantly along-
        # channel. Depth and velocity are then recomputed from it, so
        # both are consistent with the same physically-appropriate slope.
        # It has to be measured ALONG the flow path, not as the magnitude
        # of the DEM gradient at stream cells. The gradient magnitude at a
        # 30 m cell is dominated by the cross-section and by DEM noise, and
        # it has no sign: on a real 2577 km² catchment it returned S=0.091,
        # about 30x the true main-stem slope implied by 500 m of relief
        # over a 180 km flow path (~0.003). Manning's velocity goes as
        # sqrt(S), so that alone inflated velocity ~5.5x and was what drove
        # the depth-velocity hazard rating to "Danger for all" over most of
        # the catchment.
        #
        # Preferred estimate is S1085 over the main-stem long profile (see
        # _main_stem_slope). Per-cell D8 drops are kept only as a fallback
        # for the case where no usable profile can be traced, and are
        # restricted to cells the depression fill did NOT raise — on a
        # filled flat every drop is just the 1 mm fill epsilon.
        channel_slope = _main_stem_slope(
            dem_c, dem_c_raw, valid_c, accumulation_c,
            fdr_c, fdc_c, has_tgt_c, cell_size_c,
            stream_mask=stream_mask_c, feedback=feedback)

        if channel_slope is None:
            unfilled_c = valid_c & (
                (dem_c - np.where(np.isfinite(dem_c_raw), dem_c_raw, dem_c)) <= 0.01)
            stem_c = stream_mask_c & has_tgt_c & unfilled_c
            if not np.any(stem_c):
                stem_c = stream_mask_c & has_tgt_c
            if np.any(stem_c):
                sr, sc = np.nonzero(stem_c)
                acc_here = accumulation_c[sr, sc]
                main = acc_here >= np.median(acc_here)
                if np.any(main):
                    sr, sc = sr[main], sc[main]
                tr, tc = sr + fdr_c[sr, sc], sc + fdc_c[sr, sc]
                inb = (tr >= 0) & (tr < dem_c.shape[0]) & (tc >= 0) & (tc < dem_c.shape[1])
                sr, sc, tr, tc = sr[inb], sc[inb], tr[inb], tc[inb]
                if sr.size:
                    drop = dem_c[sr, sc] - dem_c[tr, tc]
                    dist = cell_size_c * np.where(
                        (sr != tr) & (sc != tc), np.sqrt(2.0), 1.0)
                    longit = drop / np.maximum(dist, 1e-6)
                    longit = longit[np.isfinite(longit) & (longit > 0)]
                    if longit.size:
                        channel_slope = float(np.median(longit))
                        if feedback:
                            feedback.pushWarning(
                                "  Could not trace a main-stem long profile; falling "
                                "back to median per-cell D8 drop for channel slope. "
                                "This is a short baseline and the resulting depth "
                                "should be treated as indicative only."
                            )

        if channel_slope is not None:
            # Bound to the range real channel slopes occupy.
            #
            # The lower bound was 1e-3, chosen to stop an under-estimated
            # slope inflating depth (depth ~ S^-0.3). That was too
            # aggressive: large alluvial rivers on a floodplain genuinely
            # run at 1e-4 or flatter, and a real 2355 km² catchment
            # measured S1085 = 2.3e-4 over a 138 km main stem — a
            # plausible value for that terrain that the clamp then
            # overrode on every return period. Depth blow-up is now
            # prevented by the volume budget below, which is a physical
            # constraint rather than a guess, so the floor can drop to
            # 1e-4 and let the terrain speak. Hitting either bound is
            # still reported.
            raw_slope = channel_slope
            channel_slope = float(np.clip(channel_slope, 1e-4, 0.10))
            if feedback and abs(channel_slope - raw_slope) > 1e-9:
                feedback.pushWarning(
                    f"  Channel slope estimate {raw_slope:.6f} was outside the "
                    f"plausible range [0.001, 0.10] and has been clamped to "
                    f"{channel_slope:.5f}. Depths for this return period are "
                    f"bounded by that clamp rather than by the terrain — check "
                    f"the DEM for flat or noisy valley floors."
                )
            Ws05_ch = channel_width * (channel_slope ** 0.5)
            if Ws05_ch > 0:
                refined_depth = float(np.clip((Qn / Ws05_ch) ** (3.0 / 5.0), 0.1, 30.0))
                if feedback:
                    feedback.pushInfo(
                        f"  Longitudinal channel slope along D8 flow paths: "
                        f"S={channel_slope:.5f} "
                        f"(vs {mean_slope:.5f} from the lowest-25%-elevation proxy) "
                        f"-> depth {water_depth:.2f} m -> {refined_depth:.2f} m"
                    )
                water_depth = refined_depth
                mean_slope = channel_slope

        # HAND reference by walking each cell's own D8 flow path down to
        # the channel it drains into — see _drainage_reference for why the
        # geometrically-nearest stream cell is not a safe substitute.
        # Computed on the coarse routing grid, then sampled back to native
        # resolution: the REFERENCE is coarse (a channel bed elevation
        # varies slowly along a valley), but the heights measured against
        # it stay at full native DEM resolution.
        ref_elev_c, ref_area_c = _drainage_reference(
            dem_c, dem_c_raw, valid_c, stream_mask_c,
            fdr_c, fdc_c, has_tgt_c, contrib_area_c)

        # Fill any unresolved coarse cells from their nearest resolved
        # neighbour so the native lookup never lands on a NaN.
        unresolved = ~np.isfinite(ref_elev_c)
        if np.any(unresolved) and np.any(~unresolved):
            _, fill_idx = ndimage.distance_transform_edt(
                unresolved, return_indices=True)
            ref_elev_c = ref_elev_c[fill_idx[0], fill_idx[1]]
            ref_area_c = ref_area_c[fill_idx[0], fill_idx[1]]

        if acc_coarsen > 1:
            zy_r = dem_data.shape[0] / ref_elev_c.shape[0]
            zx_r = dem_data.shape[1] / ref_elev_c.shape[1]
            drain_elev = ndimage.zoom(ref_elev_c, (zy_r, zx_r), order=0)
            nearest_stream_area = ndimage.zoom(ref_area_c, (zy_r, zx_r), order=0)
        else:
            drain_elev = ref_elev_c
            nearest_stream_area = ref_area_c

        hand = np.where(valid_mask, np.maximum(0.0, dem_hand - drain_elev), np.nan)

        # ── Local flow depth scaled by contributing area ───────────────────
        # water_depth above is the depth at the OUTLET, computed from the
        # full catchment discharge. Applying it to every stream cell says
        # a headwater gully draining 0.5 km² conveys the same 1460 m³/s as
        # the outlet of a 2577 km² catchment — which is what made nearly
        # every stream order appear flooded, and made extent almost
        # independent of return period.
        #
        # Discharge scales with contributing area roughly as Q ∝ A^0.75
        # (a standard regional-envelope exponent; sub-linear because
        # larger catchments have longer, more attenuated response). Depth
        # then follows Manning's with the regime width relation
        # (W ∝ Q^0.5), giving depth ∝ (Q/W)^0.6 ∝ Q^0.3, so:
        #     depth_local = depth_outlet * (A_local / A_total)^(0.75*0.3)
        area_ratio = np.clip(nearest_stream_area / max(total_area_km2, 1e-6), 1e-6, 1.0)
        local_depth_scale = area_ratio ** (0.75 * 0.3)
        local_water_depth = water_depth * local_depth_scale

        # ── Volume budget ────────────────────────────────────────────────
        # The water standing in the floodplain cannot exceed the water the
        # storm actually produced. Nothing upstream of here enforces that:
        # depth comes from Manning's normal depth in a channel of regime
        # width W = 3*sqrt(Q), and that depth is then used as a HAND
        # threshold across a valley that may be kilometres wide. When Q is
        # small the regime width collapses (Q = 4.7 m3/s gives W = 6.5 m)
        # while the valley it is spread across does not, so a trickle can
        # be rendered as a 2 m deep, 40 km2 flood.
        #
        # Observed on a real run: 34.4 Mm3 of mapped flood water from an
        # event that generated 0.42 Mm3 of runoff — a ratio of 82. Earlier
        # runs showed 6.9, 5.6, 5.0, 4.5. The check existed and warned
        # every time, but nothing acted on it, so the maps were published
        # with the warning buried in the log.
        #
        # Peak instantaneous floodplain storage is bounded above by the
        # total event runoff volume (in reality it is well below it, since
        # water is leaving the outlet throughout). Using the full runoff
        # volume as the cap is therefore generous and only bites when the
        # result is physically impossible rather than merely conservative.
        if runoff_depth_mm is not None and runoff_depth_mm > 0 and cell_size > 0:
            cell_area = cell_size ** 2
            catch_area_m2 = float(np.sum(valid_mask)) * cell_area
            budget_m3 = (runoff_depth_mm / 1000.0) * catch_area_m2

            def _stored(scale):
                d = local_water_depth * scale
                m = (hand <= d) & valid_mask & np.isfinite(hand)
                if not np.any(m):
                    return 0.0
                return float(np.sum(np.maximum(0.0, d[m] - hand[m]))) * cell_area

            vol_full = _stored(1.0)
            if vol_full > budget_m3 and budget_m3 > 0:
                # Bisect the depth scale. Stored volume increases
                # monotonically with the scale, so 30 iterations bracket it
                # to ~1e-9 of the range — cheap next to the raster work.
                lo, hi = 0.0, 1.0
                for _ in range(30):
                    mid = 0.5 * (lo + hi)
                    if _stored(mid) > budget_m3:
                        hi = mid
                    else:
                        lo = mid
                scale = lo
                if feedback:
                    feedback.pushWarning(
                        f"  Volume budget: unconstrained depths would store "
                        f"{vol_full / 1e6:.1f} Mm³ of water against "
                        f"{budget_m3 / 1e6:.1f} Mm³ of event runoff "
                        f"({vol_full / max(budget_m3, 1e-9):.0f}x). Flood depths "
                        f"scaled by {scale:.3f} so the mapped volume does not "
                        f"exceed the water the storm produced.")
                    feedback.pushWarning(
                        f"  A discrepancy this large usually means the "
                        f"hydrology, not the mapping: check the design storm "
                        f"duration against the catchment's time to peak, and "
                        f"the resulting runoff depth ({runoff_depth_mm:.2f} mm). "
                        f"The extent below is volume-limited and should be "
                        f"treated as indicative.")
                local_water_depth = local_water_depth * scale
                water_depth = water_depth * scale

        flood_mask = (hand <= local_water_depth) & valid_mask & np.isfinite(hand)

        # Water reaching a cell has to get there from the channel. A cell
        # that satisfies the HAND threshold but sits in an isolated hollow
        # with no continuous below-threshold path back to a stream is a
        # local pit, not part of the flood — keep only the 8-connected
        # components that actually touch the stream network. This is cheap
        # and it removes exactly the "unconnected low cells anywhere in the
        # DEM get marked flooded" artefact.
        if np.any(flood_mask) and np.any(stream_mask):
            labels, n_lab = ndimage.label(
                flood_mask, structure=np.ones((3, 3), dtype=bool))
            if n_lab > 0:
                connected_ids = np.unique(labels[stream_mask & flood_mask])
                connected_ids = connected_ids[connected_ids > 0]
                if connected_ids.size:
                    keep = np.zeros(n_lab + 1, dtype=bool)
                    keep[connected_ids] = True
                    dropped = int(np.sum(flood_mask & ~keep[labels]))
                    flood_mask = keep[labels]
                    if feedback and dropped > 0:
                        feedback.pushInfo(
                            f"  Connectivity filter: removed {dropped} cell(s) "
                            f"({100.0 * dropped / max(int(np.sum(valid_mask)), 1):.2f}% "
                            f"of catchment) that met the depth threshold but had no "
                            f"continuous path to a channel."
                        )

        if feedback:
            feedback.pushInfo(
                f"  Local depth scaling by contributing area: outlet depth="
                f"{water_depth:.2f} m, headwater depth≈"
                f"{float(np.nanmin(local_water_depth[stream_mask])) if np.any(stream_mask) else 0:.2f} m "
                f"(a tributary carries a fraction of the outlet discharge, so "
                f"it floods to a fraction of the outlet depth)"
            )

        # ── Per-pixel local depth adjustment from LULC (n) and soil/CN ─────
        # water_depth (the Manning's-derived scalar above) is the LOCAL
        # water depth applied relative to each cell's own HAND reference —
        # this is no longer a single global water surface (see the HAND
        # section above for why that didn't work). What changes here:
        # instead of the exact same depth everywhere under the flood_mask,
        # each ALREADY-FLOODED cell's depth is nudged by its own local
        # conditions instead of being perfectly uniform:
        #   - Local Manning's n: from Manning's equation, y ∝ n^0.6 holding
        #     discharge/width/slope fixed, so rougher cells (natural
        #     vegetation, high n) get MORE depth and smoother cells
        #     (channels, pavement, low n) get LESS, relative to the
        #     catchment-mean-n baseline depth computed above.
        #   - Local CN: higher CN means less infiltration capacity, so a
        #     larger share of the local rainfall excess stays on the
        #     surface rather than infiltrating — nudges depth up a little
        #     in high-CN (impervious/poor-infiltration) cells, down a
        #     little in low-CN (permeable) cells.
        # Both factors are bounded so a patch of unusual n/CN can't
        # produce an implausible local spike.
        #
        # IMPORTANT: this ONLY scales depth within the flood_mask that was
        # already correctly established above — it does NOT touch which
        # cells count as flooded. An earlier version of this also tried to
        # *extend* the mask based on depth_factor, using a comparison that
        # turned out to be almost always true for any non-pit cell once
        # depth_factor > 1 (roughly half the domain) — that pulled in
        # unconnected low-elevation cells from anywhere in the DEM
        # regardless of real physical proximity to drainage, which is
        # exactly how 75%+ of a whole catchment ended up marked "flooded"
        # with implausible depths in testing. Scaling depth only within
        # the mask the HAND calculation already validated avoids that
        # failure mode entirely.
        depth_factor = np.ones_like(dem_data, dtype=np.float64)
        if mann_grid is not None:
            safe_n = np.where(np.isfinite(mann_grid) & (mann_grid > 0), mann_grid, eff_manning)
            n_factor = np.clip((safe_n / max(eff_manning, 1e-6)) ** 0.6, 0.6, 1.8)
            depth_factor *= n_factor
        if cn_grid is not None and mean_cn:
            safe_cn = np.where(np.isfinite(cn_grid), cn_grid, mean_cn)
            cn_factor = 1.0 + np.clip((safe_cn - mean_cn) / 30.0, -1.0, 1.0) * 0.15
            depth_factor *= cn_factor
        depth_factor = np.clip(depth_factor, 0.5, 2.0)

        # water_depth - hand = how much of the local available depth
        # remains above this cell relative to its own nearest-drainage
        # reference (the HAND-consistent analog of the old global
        # "water_surface_elev - dem_data").
        base_local_depth = np.where(flood_mask, np.maximum(0.0, local_water_depth - hand), 0.0)
        local_depth = base_local_depth * depth_factor

        # ── Flood depth raster ────────────────────────────────────────────
        flood_depth = np.where(flood_mask, local_depth, 0.0).astype(np.float32)
        flood_depth = np.where(np.isnan(dem_data), -9999.0, flood_depth)

        # ── Velocity (Manning's equation) and hazard classification ────────
        # Depth alone doesn't determine danger to people — depth AND
        # velocity together do (a person can stand in fairly deep still
        # water but be swept off their feet by shallow fast water). This
        # implements the UK Defra/Environment Agency "Flood Risks to
        # People" methodology (FD2320/FD2321, Ramsbottom et al.), the
        # standard real-world approach and the one most flood-risk
        # software (TUFLOW, HEC-RAS) can export directly for comparison:
        #   V = (1/n) * R^(2/3) * S^(1/2)     (Manning's equation, using
        #       local depth as hydraulic radius R — standard for wide,
        #       shallow overland/floodplain flow where width >> depth)
        #   HR = depth * (V + 0.5) + DF        (Hazard Rating)
        #   DF (debris factor) = 0.5 for depth <= 0.25 m, else 1.0
        #       (FD2320's own default simplification when land-use-
        #       specific debris assessment isn't available)
        # Classification (FD2321, thresholds per the May 2008 EA
        # technical note revision):
        #   HR < 0.75          -> Low hazard (caution)
        #   0.75 <= HR < 1.25  -> Danger for some (children, elderly)
        #   1.25 <= HR < 2.0   -> Danger for most people
        #   HR >= 2.0          -> Danger for all (extreme — loss of life possible)
        if mann_grid is not None:
            safe_n_vel = np.where(np.isfinite(mann_grid) & (mann_grid > 0), mann_grid, eff_manning)
        else:
            safe_n_vel = np.full_like(dem_data, eff_manning, dtype=np.float64)
        # Floor/ceiling on n before it divides into the velocity. A stray
        # near-zero cell in a land-cover-derived n raster produces an
        # arbitrarily large velocity, which previously just hit the 10 m/s
        # clamp and was then reported as though it were a real result.
        # 0.02 is about as smooth as natural ground gets (clean concrete
        # channel); 0.4 covers dense floodplain vegetation.
        safe_n_vel = np.clip(safe_n_vel, 0.02, 0.4)
        # Water-surface slope, NOT the raw per-pixel hillslope gradient.
        # Manning's velocity is governed by the energy/water-surface
        # slope, which in a floodplain closely follows the valley slope —
        # typically a fraction of a percent to a few percent. Using the
        # local DEM gradient instead means a cell on a steep valley wall
        # contributes a hillslope gradient of 0.2+ to a flow that is
        # actually moving along the valley floor. In real runs that drove
        # velocity to the 10 m/s safety clamp across large areas and, via
        # the depth-velocity hazard rating, flagged ~18% of a whole
        # catchment as "Danger for all".
        # mean_slope here is already the valley-bottom representative
        # slope computed earlier for the depth calculation, so velocity
        # and depth are now consistent with each other.
        safe_slope = np.full_like(dem_data, max(float(mean_slope), 1e-5), dtype=np.float64)
        velocity = np.where(
            flood_mask,
            (1.0 / np.maximum(safe_n_vel, 1e-4)) * np.power(np.maximum(flood_depth, 1e-4), 2.0/3.0)
            * np.sqrt(safe_slope),
            0.0
        ).astype(np.float32)
        # Sanity clamp — Manning's equation on a per-pixel local slope can
        # occasionally produce an implausible spike on a single steep
        # cell; velocities in a real flood rarely exceed ~10 m/s even in
        # steep terrain.
        velocity = np.clip(velocity, 0.0, 10.0)

        debris_factor = np.where(flood_depth <= 0.25, 0.5, 1.0)
        hazard_rating = np.where(
            flood_mask, flood_depth * (velocity + 0.5) + debris_factor, 0.0
        ).astype(np.float32)

        # Class codes: 0=not flooded, 1=low, 2=danger-some, 3=danger-most, 4=danger-all
        hazard_class = np.zeros_like(hazard_rating, dtype=np.uint8)
        hazard_class = np.where(flood_mask & (hazard_rating < 0.75), 1, hazard_class)
        hazard_class = np.where(flood_mask & (hazard_rating >= 0.75) & (hazard_rating < 1.25), 2, hazard_class)
        hazard_class = np.where(flood_mask & (hazard_rating >= 1.25) & (hazard_rating < 2.0), 3, hazard_class)
        hazard_class = np.where(flood_mask & (hazard_rating >= 2.0), 4, hazard_class)

        velocity_out = np.where(np.isnan(dem_data), -9999.0, velocity)
        hazard_rating_out = np.where(np.isnan(dem_data), -9999.0, hazard_rating)
        hazard_class_out = np.where(np.isnan(dem_data), 255, hazard_class).astype(np.uint8)

        n_flood    = int(np.sum(flood_mask))
        n_total    = int(np.sum(~np.isnan(dem_data)))
        flood_pct  = n_flood / max(n_total, 1) * 100
        max_depth  = float(np.nanmax(flood_depth[flood_depth > 0])) if n_flood > 0 else 0.0
        max_vel    = float(np.nanmax(velocity[flood_mask])) if n_flood > 0 else 0.0
        n_danger_all = int(np.sum(hazard_class == 4))

        if feedback:
            feedback.pushInfo(
                f"Flood extent: {n_flood} pixels ({flood_pct:.1f}%), "
                f"max depth={max_depth:.2f} m, max velocity={max_vel:.2f} m/s"
            )
            if n_danger_all > 0:
                feedback.pushWarning(
                    f"  {n_danger_all} pixel(s) ({100*n_danger_all/max(n_total,1):.2f}% of "
                    f"catchment) classified 'Danger for all' (Hazard Rating >= 2.0, "
                    f"UK Defra/EA FD2321 methodology) — loss of life is possible in "
                    f"these areas."
                )

        # ── Volume consistency check (if runoff depth provided) ───────────
        if runoff_depth_mm is not None and cell_size > 0:
            area_m2         = n_total * cell_size**2
            flood_vol_m3    = float(np.sum(flood_depth[flood_depth > 0])) * cell_size**2
            expected_vol_m3 = (runoff_depth_mm / 1000.0) * area_m2
            vol_ratio       = flood_vol_m3 / max(expected_vol_m3, 1.0)
            if feedback:
                feedback.pushInfo(
                    f"Volume check: flood vol={flood_vol_m3/1e6:.3f} Mm³, "
                    f"expected={expected_vol_m3/1e6:.3f} Mm³, ratio={vol_ratio:.2f}"
                )
            if vol_ratio > 3.0 or vol_ratio < 0.1:
                feedback.pushWarning(
                    f"Flood volume ratio ({vol_ratio:.2f}) outside expected range [0.1–3.0]. "
                    "Review DEM resolution and catchment slope."
                )

        # ── Save GeoTIFF ──────────────────────────────────────────────────
        flood_meta = dem_meta.copy()
        flood_meta.update({
            'dtype': 'float32', 'count': 1, 'compress': 'lzw',
            'nodata': -9999.0,
            'height': flood_depth.shape[0], 'width': flood_depth.shape[1],
            'transform': out_transform, 'crs': dem_crs,
        })
        with rasterio.open(flood_raster, 'w', **flood_meta) as dst:
            dst.write(flood_depth.astype(np.float32), 1)

        velocity_raster = flood_raster.replace('flood_depth_', 'flood_velocity_')
        with rasterio.open(velocity_raster, 'w', **flood_meta) as dst:
            dst.write(velocity_out.astype(np.float32), 1)

        hazard_class_raster = flood_raster.replace('flood_depth_', 'flood_hazard_class_')
        hazard_meta = flood_meta.copy()
        hazard_meta.update({'dtype': 'uint8', 'nodata': 255})
        with rasterio.open(hazard_class_raster, 'w', **hazard_meta) as dst:
            dst.write(hazard_class_out.astype(np.uint8), 1)
        _write_qml_hazard_class(hazard_class_raster.replace('.tif', '.qml'))

        # ── Visualisation ─────────────────────────────────────────────────
        _render_flood_map(
            dem_data, flood_depth, flood_mask,
            min_elev, max_elev, max_depth, flood_pct,
            discharge, water_depth, return_period,
            mean_cn, eff_manning, cell_size,
            flood_image, feedback
        )

        gc.collect()
        return flood_image, flood_raster, velocity_raster, hazard_class_raster

    except Exception as e:
        import traceback
        if feedback:
            feedback.reportError(f"Flood map generation failed: {e}")
            feedback.pushInfo(traceback.format_exc())
        return None, None, None, None


def _render_flood_map(dem_data, flood_depth, flood_mask,
                       min_elev, max_elev, max_depth, flood_pct,
                       discharge, water_depth, return_period,
                       mean_cn, eff_manning, cell_size,
                       output_path, feedback):
    """Internal: render and save flood inundation PNG."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(16, 8),
                                  gridspec_kw={'width_ratios': [3, 1]})
        ax_map, ax_info = axes

        # ── Left panel: Map ───────────────────────────────────────────────
        dem_masked = np.ma.masked_where(np.isnan(dem_data), dem_data)
        im_dem = ax_map.imshow(dem_masked, cmap='terrain',
                                vmin=min_elev, vmax=max_elev,
                                interpolation='bilinear', aspect='auto')
        cbar_dem = plt.colorbar(im_dem, ax=ax_map, fraction=0.03, pad=0.01)
        cbar_dem.set_label('Elevation (m)', fontsize=9)

        # Flood depth overlay
        if max_depth > 0:
            depth_cmap = LinearSegmentedColormap.from_list(
                'flood',
                [(0.529, 0.808, 0.980, 0.0),    # transparent at 0
                 (0.000, 0.447, 0.698, 0.6),    # light blue
                 (0.000, 0.000, 0.600, 0.75),   # medium blue
                 (0.000, 0.000, 0.300, 0.90),   # dark blue
                 (0.502, 0.000, 0.502, 0.95)],  # purple at deep
                N=256
            )
            depth_disp = np.ma.masked_where(flood_depth <= 0.01, flood_depth)
            if depth_disp.count() > 0:
                im_fl = ax_map.imshow(depth_disp, cmap=depth_cmap,
                                       vmin=0, vmax=max_depth,
                                       interpolation='nearest', aspect='auto')
                cbar_fl = plt.colorbar(im_fl, ax=ax_map, fraction=0.03, pad=0.04)
                cbar_fl.set_label('Flood Depth (m)', fontsize=9)

        # Flood boundary
        from scipy import ndimage as ndi
        boundary = ndi.binary_dilation(flood_mask, iterations=2) & ~flood_mask
        boundary_disp = np.ma.masked_where(~boundary, np.ones_like(dem_data))
        ax_map.contour(flood_mask.astype(float), levels=[0.5],
                        colors=['navy'], linewidths=1.5, alpha=0.8)

        ax_map.set_title(
            f"Flood Inundation — {return_period}-Year Return Period",
            fontsize=13, fontweight='bold', pad=10
        )
        ax_map.set_xticks([])
        ax_map.set_yticks([])

        # Legend patches
        legend_elements = [
            Patch(facecolor='#87CEEB', edgecolor='navy', label=f'Flooded ({flood_pct:.1f}%)'),
            Patch(facecolor='#8FBC8F', edgecolor='gray', label='Not flooded'),
        ]
        ax_map.legend(handles=legend_elements, loc='lower right', fontsize=9,
                       framealpha=0.85)

        # ── Right panel: Info card ────────────────────────────────────────
        ax_info.axis('off')
        cn_str = f"{mean_cn:.0f}" if mean_cn else "N/A (manual)"
        info_lines = [
            ("HYDRAULIC SUMMARY", True),
            ("", False),
            (f"Return Period", True),
            (f"  {return_period} years", False),
            ("", False),
            (f"Peak Discharge", True),
            (f"  {discharge:.1f} m³/s", False),
            ("", False),
            (f"Max Water Depth", True),
            (f"  {water_depth:.2f} m", False),
            ("", False),
            (f"Max Flood Depth", True),
            (f"  {max_depth:.2f} m", False),
            ("", False),
            (f"Flood Extent", True),
            (f"  {flood_pct:.1f}% of catchment", False),
            ("", False),
            (f"Manning's n (eff.)", True),
            (f"  {eff_manning:.4f}", False),
            ("", False),
            (f"Mean CN", True),
            (f"  {cn_str}", False),
            ("", False),
            (f"DEM Cell Size", True),
            (f"  {cell_size:.1f} m", False),
        ]
        y = 0.98
        for text, bold in info_lines:
            if not text:
                y -= 0.018
                continue
            ax_info.text(0.05, y, text, transform=ax_info.transAxes,
                         fontsize=9, fontweight='bold' if bold else 'normal',
                         verticalalignment='top',
                         color='#1a1a2e' if bold else '#2c2c54')
            y -= 0.042 if bold else 0.038

        ax_info.set_facecolor('#f8f9fa')
        ax_info.spines['top'].set_visible(False)
        ax_info.spines['right'].set_visible(False)

        plt.tight_layout()
        plt.savefig(output_path, dpi=200, bbox_inches='tight',
                     facecolor='white', edgecolor='none')
        plt.close()
        if feedback:
            feedback.pushInfo(f"Flood map saved: {output_path}")

    except Exception as e:
        if feedback:
            feedback.pushWarning(f"Map rendering failed: {e}")
        try:
            plt.close()
        except Exception:
            pass


def load_flood_rasters_to_qgis(raster_paths, feedback=None):
    """
    Load flood depth rasters into QGIS with a professional colour ramp.
    Returns list of successfully loaded QgsRasterLayer objects.
    """
    from qgis.core import (QgsRasterLayer, QgsProject, QgsRasterShader,
                            QgsColorRampShader, QgsSingleBandPseudoColorRenderer,
                            QgsRasterBandStats)
    from qgis.PyQt.QtGui import QColor

    loaded = []
    for rpath in raster_paths:
        if not rpath or not os.path.exists(rpath):
            continue
        lname = os.path.splitext(os.path.basename(rpath))[0].replace('_', ' ')
        layer = QgsRasterLayer(rpath, lname)
        if not layer.isValid():
            if feedback:
                feedback.pushWarning(f"Invalid raster: {rpath}")
            continue

        stats   = layer.dataProvider().bandStatistics(1, QgsRasterBandStats.All)
        max_val = max(stats.maximumValue, 0.01)

        # 5-class flood depth colour scheme (blue family, WMO-inspired).
        # QColor parses 8-digit hex strings as #AARRGGBB (alpha FIRST, Qt's
        # own convention — not the CSS #RRGGBBAA alpha-last convention).
        # The "no flood" entry previously used '#FFFFFF00', which Qt reads
        # as alpha=FF (fully OPAQUE) + RGB=FFFF00 — a solid yellow, not
        # the intended transparent white. Fixed to alpha-first order.
        breaks = [0.0, max_val * 0.05, max_val * 0.2, max_val * 0.5, max_val * 0.8, max_val]
        colors = ['#00FFFFFF', '#AED6F1', '#3498DB', '#1A5276', '#6C3483', '#922B21']
        labels = ['No flood (0 m)', '< 5% depth', '5–20%', '20–50%', '50–80%', '> 80%']

        items = []
        for val, col, lbl in zip(breaks, colors, labels):
            items.append(QgsColorRampShader.ColorRampItem(val, QColor(col), lbl))

        shader = QgsRasterShader()
        cr     = QgsColorRampShader()
        cr.setColorRampType(QgsColorRampShader.Interpolated)
        cr.setColorRampItemList(items)
        shader.setRasterShaderFunction(cr)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
        renderer.setClassificationMin(0)
        renderer.setClassificationMax(max_val)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        QgsProject.instance().addMapLayer(layer)
        loaded.append(layer)
        if feedback:
            feedback.pushInfo(f"Loaded: {lname}")
    return loaded


def load_hazard_rasters_to_qgis(raster_paths, feedback=None):
    """
    Load hazard-classification rasters (discrete 0-4 categories) into
    QGIS using the paletted QML written by _write_qml_hazard_class —
    NOT load_flood_rasters_to_qgis's continuous blue-gradient renderer,
    which is only appropriate for continuous data like depth/velocity,
    not a 5-class categorical raster.
    """
    from qgis.core import QgsRasterLayer, QgsProject
    loaded = []
    for rpath in raster_paths:
        if not rpath or not os.path.exists(rpath):
            continue
        lname = os.path.splitext(os.path.basename(rpath))[0].replace('_', ' ')
        layer = QgsRasterLayer(rpath, lname)
        if not layer.isValid():
            if feedback:
                feedback.pushWarning(f"  Failed to load: {lname}")
            continue
        QgsProject.instance().addMapLayer(layer)
        qml = rpath.replace('.tif', '.qml')
        if os.path.exists(qml):
            _, ok = layer.loadNamedStyle(qml)
            if ok:
                layer.triggerRepaint()
                layer.emitStyleChanged()
        loaded.append(layer)
        if feedback:
            feedback.pushInfo(f"Loaded: {lname}")
    return loaded
