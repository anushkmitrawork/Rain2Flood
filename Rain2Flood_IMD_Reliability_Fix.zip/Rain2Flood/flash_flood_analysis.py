"""
Flash Flood Analysis Algorithm (Hourly / Short-Duration)
=========================================================
Supports:
  - SCS Triangular UH  (NRCS NEH-4)
  - NRCS Dimensionless UH
  - Rational / Modified Rational Method
  - Snyder Synthetic UH
  - Clark IUH
  - Wadi / Arid Flash Flood (Middle East)
  - CN / LULC / Manning's raster integration
  - IDF curve generation
  - Multi-duration (1h, 3h, 6h, 12h, 24h) frequency analysis
  - Alternating Block Method design storm
  - Muskingum-Cunge routing
"""

import os, sys, gc, re, traceback, math, warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
try:
    from . import plot_style as _ps
except ImportError:
    import plot_style as _ps
_ps.apply_style()
from datetime import datetime, timedelta

from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterString,
    QgsProcessingParameterEnum, QgsProcessingParameterFile,
    QgsProcessingParameterNumber, QgsProcessingParameterVectorLayer,
    QgsProcessingParameterRasterLayer, QgsProcessingParameterBoolean,
    QgsProcessingParameterFolderDestination, QgsProcessingException,
    QgsProcessing, QgsProject, QgsRasterLayer,
    QgsProcessingOutputFile, QgsProcessingOutputFolder,
    QgsProcessingParameterPoint, QgsProcessingParameterDateTime,
    QgsCoordinateReferenceSystem
)
from qgis.PyQt.QtCore import QDateTime, QDate, QTime

try:
    from .rainfall_data_sources import (
        download_openmeteo_hourly_data, download_gpm_imerg_daily,
        load_excel_rainfall_data, quality_control_rainfall
    )
    from .hydrological_calculations import (
        frequency_analysis, frequency_analysis_with_uncertainty, select_best_distribution,
        cwc_synthetic_unit_hydrograph,
        calculate_scs_cn_runoff, calculate_peak_discharge_scs,
        calculate_time_to_peak, generate_scs_unit_hydrograph,
        generate_nrcs_dimensionless_uh, generate_flood_hydrograph,
        generate_snyder_unit_hydrograph, generate_clark_iuh,
        rational_method_peak_discharge, modified_rational_method,
        fit_idf_curves, generate_idf_table, alternating_block_hyetograph,
        scs_type_ii_distribution, wadi_flood_estimation,
        muskingum_cunge_routing, green_ampt_infiltration
    )
    from .flood_mapping import generate_flood_map, generate_flood_map_2d, load_flood_rasters_to_qgis, load_hazard_rasters_to_qgis
    from .report_generator import generate_html_report
    from .cn_lulc_manager import cn_dropdown_items, adjust_cn_for_amc
    from .raster_downloader import (
        download_esa_worldcover_for_bbox, generate_cn_raster_from_lulc_file,
        extract_catchment_cn_manning, generate_cn_raster_manual
    )
except ImportError:
    from rainfall_data_sources import (
        download_openmeteo_hourly_data, download_gpm_imerg_daily,
        load_excel_rainfall_data, quality_control_rainfall
    )
    from hydrological_calculations import (
        frequency_analysis, frequency_analysis_with_uncertainty, select_best_distribution,
        cwc_synthetic_unit_hydrograph,
        calculate_scs_cn_runoff, calculate_peak_discharge_scs,
        calculate_time_to_peak, generate_scs_unit_hydrograph,
        generate_nrcs_dimensionless_uh, generate_flood_hydrograph,
        generate_snyder_unit_hydrograph, generate_clark_iuh,
        rational_method_peak_discharge, modified_rational_method,
        fit_idf_curves, generate_idf_table, alternating_block_hyetograph,
        scs_type_ii_distribution, wadi_flood_estimation,
        muskingum_cunge_routing
    )
    from flood_mapping import generate_flood_map, generate_flood_map_2d, load_flood_rasters_to_qgis, load_hazard_rasters_to_qgis
    from report_generator import generate_html_report
    from cn_lulc_manager import cn_dropdown_items, adjust_cn_for_amc
    from raster_downloader import (
        download_esa_worldcover_for_bbox, generate_cn_raster_from_lulc_file,
        extract_catchment_cn_manning, generate_cn_raster_manual
    )



def _extract_spatial_rainfall_depth(rain_raster_path, catchment_path, feedback=None):
    """
    Extract area-weighted mean rainfall depth (mm) from a spatial rainfall
    raster clipped to the catchment boundary.

    The raster pixel values must represent storm rainfall depth in mm.
    This accepts any gridded rainfall raster the user supplies from
    elsewhere (e.g. CHIRPS/ERA5 storm-total exports, IDW/Kriging-
    interpolated gauge data, or a raster from another tool) — it doesn't
    depend on any specific source.

    Returns float (weighted mean mm) or None on failure.
    """
    try:
        import rasterio
        from rasterio.mask import mask as rasterio_mask
        import geopandas as gpd
        from shapely.geometry import mapping
        # NOTE: no local `import numpy as np` here — numpy is already
        # imported at module level, and re-importing it inside a function
        # makes `np` function-local for the WHOLE function, breaking any
        # use of np.* above the import line (this exact mistake caused an
        # UnboundLocalError in standard_flood_analysis.py).

        gdf = gpd.read_file(catchment_path)
        with rasterio.open(rain_raster_path) as src:
            gdf_rep = gdf.to_crs(src.crs)
            geoms   = [mapping(g) for g in gdf_rep.geometry]
            out, _  = rasterio_mask(src, geoms, crop=True, nodata=src.nodata or -9999.0)
            arr     = out[0].astype(np.float32)
            nd      = src.nodata if src.nodata is not None else -9999.0
            arr[arr == nd] = np.nan
            arr[arr < 0]   = np.nan

        valid = arr[~np.isnan(arr)]
        if len(valid) == 0:
            if feedback:
                feedback.pushWarning("Spatial rainfall raster: no valid pixels in catchment.")
            return None

        weighted_mean = float(np.mean(valid))
        if feedback:
            feedback.pushInfo(
                f"Spatial rainfall raster: {len(valid)} valid pixels, "
                f"mean={weighted_mean:.2f} mm, "
                f"max={float(np.max(valid)):.2f} mm, "
                f"min={float(np.min(valid)):.2f} mm"
            )
        return weighted_mean

    except ImportError:
        if feedback:
            feedback.pushWarning("rasterio / geopandas required for spatial rainfall extraction.")
        return None
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"Spatial rainfall extraction failed: {e}")
        return None


class FlashFloodAnalysis(QgsProcessingAlgorithm):
    # ── Parameter names ────────────────────────────────────────────────────
    RAINFALL_SOURCE    = 'RAINFALL_SOURCE'
    RAINFALL_RASTER    = 'RAINFALL_RASTER'
    USE_SPATIAL_RAIN   = 'USE_SPATIAL_RAIN'
    COORDINATES_POINT  = 'COORDINATES_POINT'
    COORDINATES_MANUAL = 'COORDINATES_MANUAL'
    START_DATE         = 'START_DATE'
    END_DATE           = 'END_DATE'
    EXCEL_FILE         = 'EXCEL_FILE'
    DATE_COLUMN        = 'DATE_COLUMN'
    RAINFALL_COLUMN    = 'RAINFALL_COLUMN'
    ANALYSIS_METHOD    = 'ANALYSIS_METHOD'
    STORM_DURATION     = 'STORM_DURATION'
    RETURN_PERIODS     = 'RETURN_PERIODS'
    FREQ_METHOD        = 'FREQ_METHOD'
    AMC_CONDITION      = 'AMC_CONDITION'
    CATCHMENT_INPUT    = 'CATCHMENT_INPUT'
    SNAP_RADIUS        = 'SNAP_RADIUS'
    CATCHMENT          = 'CATCHMENT'
    DEM                = 'DEM'
    SLOPE_RASTER       = 'SLOPE_RASTER'
    FLOW_PATH          = 'FLOW_PATH'
    CN_RASTER_SOURCE   = 'CN_RASTER_SOURCE'
    CN_RASTER          = 'CN_RASTER'
    LULC_RASTER        = 'LULC_RASTER'
    LULC_TYPE          = 'LULC_TYPE'
    MANNING_RASTER     = 'MANNING_RASTER'
    HSG                = 'HSG'
    AREA               = 'AREA'
    SLOPE              = 'SLOPE'
    CN                 = 'CN'
    RUNOFF_COEFF       = 'RUNOFF_COEFF'
    MANNING_N          = 'MANNING_N'
    ENABLE_ROUTING     = 'ENABLE_ROUTING'
    MUSK_K             = 'MUSK_K'
    MUSK_X             = 'MUSK_X'
    OUTPUT_DIR         = 'OUTPUT_DIR'
    GENERATE_MAPS      = 'GENERATE_MAPS'
    LOAD_RASTERS       = 'LOAD_RASTERS'
    USE_2D_ROUTING     = 'USE_2D_ROUTING'
    OBSERVED_HYDROGRAPH = 'OBSERVED_HYDROGRAPH'
    CWC_COEFFS          = 'CWC_COEFFS'
    POUR_POINT          = 'POUR_POINT'
    POUR_POINT_MANUAL   = 'POUR_POINT_MANUAL'
    SUBBASIN_LAYER      = 'SUBBASIN_LAYER'
    WAVE_CELERITY       = 'WAVE_CELERITY'
    RUN_SENSITIVITY     = 'RUN_SENSITIVITY'
    EXPORT_HEC_HMS     = 'EXPORT_HEC_HMS'

    OUTPUT_EXCEL       = 'OUTPUT_EXCEL'
    OUTPUT_FLOOD_MAPS  = 'OUTPUT_FLOOD_MAPS'
    OUTPUT_RASTERS     = 'OUTPUT_FLOOD_RASTERS'
    OUTPUT_HYDROGRAPHS = 'OUTPUT_HYDROGRAPHS'
    OUTPUT_HEC_HMS     = 'OUTPUT_HEC_HMS'

    RAINFALL_SOURCES = [
        'Open-Meteo ERA5 (Hourly, Global, Free)',
        'NASA POWER (Daily → disaggregated)',
        'IMD Gridded 0.25° (India, Hourly)',
        'Excel / CSV (Hourly)',
        'Synthetic (planning only)',
    ]
    ANALYSIS_METHODS = [
        'SCS Triangular UH (NRCS NEH-4)',
        'NRCS Dimensionless UH',
        'Snyder Synthetic UH',
        'Clark IUH',
        'Rational Method (Modified)',
        'Wadi / Arid Flash Flood (Middle East)',
        'CWC Synthetic UH (India) — needs subzone coefficients',
    ]
    STORM_DURATIONS = [
        '1 hour (Flash Flood)',
        '3 hours (Short Duration)',
        '6 hours (Medium Duration)',
        '12 hours (Long Duration)',
        '24 hours (Daily Storm)',
    ]
    FREQ_METHODS  = ['Gumbel (EV1)', 'Log-Pearson III', 'GEV (MLE)', 'GEV (L-moments)',
                      'Auto (best fit by AIC)']
    AMC_OPTIONS   = ['AMC I (Dry)', 'AMC II (Normal)', 'AMC III (Wet)']
    CN_SOURCES    = ['Manual Value', 'CN Raster (HEC-RAS)', 'LULC Raster → compute CN',
                     'Download ESA WorldCover → compute CN']
    LULC_TYPES    = ['ESA WorldCover 2021', 'NLCD 2019 (USA)', 'CORINE (Europe)', 'MODIS IGBP']
    HSG_OPTIONS   = ['A (Well-drained sand/gravel)', 'B (Moderate infiltration)',
                     'C (Slow infiltration)', 'D (Clay / high runoff)']

    # GUI drop-down items
    CN_VALUES = cn_dropdown_items('B')
    RUNOFF_COEFF_VALUES = [
        '0.10  (Sandy soil / forests)', '0.15  (Woodland)', '0.20  (Grassland / meadow)',
        '0.30  (Cultivated land)', '0.40  (Residential ≥ 0.5 ac)', '0.50  (Suburban)',
        '0.60  (Urban residential)', '0.70  (Commercial / business)', '0.80  (Industrial)',
        '0.90  (Paved / impervious)', '0.95  (Steep impervious)',
    ]
    MANNING_N_VALUES = [
        '0.011  (Smooth asphalt / concrete)', '0.013  (Formed concrete)',
        '0.022  (Earth channel clean)', '0.025  (Gravel channel)',
        '0.035  (Natural stream clean)', '0.040  (Natural stream winding)',
        '0.050  (Weedy/sluggish stream)', '0.070  (Heavy brush/forest stream)',
        '0.100  (Dense brush floodplain)', '0.120  (Dense forest floodplain)',
    ]

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.RAINFALL_SOURCE, 'Rainfall Data Source',
            options=['Open-Meteo ERA5 (Hourly)', 'NASA POWER (Daily → disaggregated)',
                     'Excel / CSV File (Hourly)', 'Synthetic (planning only)'],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterPoint(
            self.COORDINATES_POINT, 'Select Location on Map', optional=True, defaultValue=''))
        self.addParameter(QgsProcessingParameterString(
            self.COORDINATES_MANUAL, 'Manual Coordinates (Lat, Lon)',
            defaultValue='20.0, 77.0', optional=True))
        self.addParameter(QgsProcessingParameterDateTime(
            self.START_DATE, 'Start Date/Time',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate().addDays(-365), QTime(0,0,0))))
        self.addParameter(QgsProcessingParameterDateTime(
            self.END_DATE, 'End Date/Time',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate(), QTime(23,0,0))))
        self.addParameter(QgsProcessingParameterFile(
            self.EXCEL_FILE, 'Excel/CSV File (Hourly Rainfall)', optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.RUN_SENSITIVITY,
            'Run sensitivity analysis (±20% on CN, Manning\'s n, rainfall, flow path)',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterPoint(
            self.POUR_POINT,
            'Pour point / outlet — click on the map. ALL results correspond '
            'to this location', optional=True, defaultValue=''))
        self.addParameter(QgsProcessingParameterString(
            self.POUR_POINT_MANUAL,
            'Pour point as "lat,lon" (used if nothing picked on the map)',
            defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.SUBBASIN_LAYER,
            'Sub-basins from Tab 2 (optional) — enables semi-distributed '
            'routing instead of treating the catchment as one lump',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.WAVE_CELERITY, 'Flood wave celerity for sub-basin routing (m/s)',
            QgsProcessingParameterNumber.Double, defaultValue=1.0, optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.CWC_COEFFS,
            'CWC subzone coefficients (only for CWC method) — e.g. '
            'Ct=0.53,m=0.31,Cq=1.79,nq=0.78 (from your subzone report)',
            defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterFile(
            self.OBSERVED_HYDROGRAPH,
            'Observed Hydrograph CSV for calibration (optional) — columns: '
            'Time_hr, Discharge_m3s',
            optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.DATE_COLUMN, 'Date Column Name', defaultValue='DateTime', optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.RAINFALL_COLUMN, 'Rainfall Column Name', defaultValue='Rainfall_mm', optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_SPATIAL_RAIN,
            'Use Spatial Rainfall Raster instead of point rainfall',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RAINFALL_RASTER,
            'Spatial Rainfall Raster (mm depth, each pixel = storm rainfall)',
            optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.ANALYSIS_METHOD, 'Flood Analysis Method',
            options=self.ANALYSIS_METHODS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.STORM_DURATION, 'Design Storm Duration',
            options=self.STORM_DURATIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterString(
            self.RETURN_PERIODS, 'Return Periods (comma-separated)',
            defaultValue='10,25,50,100'))
        self.addParameter(QgsProcessingParameterEnum(
            self.FREQ_METHOD, 'Frequency Analysis Method',
            options=self.FREQ_METHODS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.AMC_CONDITION, 'Antecedent Moisture Condition (AMC)',
            options=self.AMC_OPTIONS, defaultValue=1))
        self.addParameter(QgsProcessingParameterEnum(
            self.CATCHMENT_INPUT, 'Catchment Input Method',
            options=['Shapefile + DEM', 'Manual Parameters',
                     'Pour Point + DEM (auto-delineate upstream catchment)'],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP_RADIUS,
            'Pour-point snap radius (cells) — only used by the pour-point method',
            QgsProcessingParameterNumber.Integer, defaultValue=10, minValue=0))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CATCHMENT, 'Catchment Boundary (Polygon)',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DEM, 'DEM Raster', optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.SLOPE_RASTER, 'Slope Raster (%) – optional', optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.FLOW_PATH, 'Longest Flow Path (Line)', optional=True,
            types=[QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterEnum(
            self.CN_RASTER_SOURCE, 'CN / LULC Data Source',
            options=self.CN_SOURCES, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CN_RASTER, 'CN Raster (HEC-RAS, pixel=CN value)', optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.LULC_RASTER, 'LULC Raster (for CN derivation)', optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.LULC_TYPE, 'LULC Dataset Type',
            options=self.LULC_TYPES, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.MANNING_RASTER, "Manning's n Raster (optional)", optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.HSG, 'Hydrologic Soil Group (default)',
            options=self.HSG_OPTIONS, defaultValue=1))
        self.addParameter(QgsProcessingParameterNumber(
            self.AREA, 'Catchment Area (km²)', QgsProcessingParameterNumber.Double,
            optional=True, minValue=0.01))
        self.addParameter(QgsProcessingParameterNumber(
            self.SLOPE, 'Mean Slope (decimal, e.g. 0.02)', QgsProcessingParameterNumber.Double,
            optional=True, minValue=0.0001))
        self.addParameter(QgsProcessingParameterString(
            self.CN, 'Curve Number (manual)', defaultValue='75  (Urban)'))
        self.addParameter(QgsProcessingParameterString(
            self.RUNOFF_COEFF, 'Runoff Coefficient C (Rational method)',
            defaultValue='0.60  (Urban residential)'))
        self.addParameter(QgsProcessingParameterString(
            self.MANNING_N, "Manning's n (manual)",
            defaultValue='0.035  (Natural stream clean)'))
        self.addParameter(QgsProcessingParameterBoolean(
            self.ENABLE_ROUTING, 'Enable Muskingum-Cunge Channel Routing', defaultValue=False))
        self.addParameter(QgsProcessingParameterNumber(
            self.MUSK_K, 'Muskingum K – Travel Time (hr)',
            QgsProcessingParameterNumber.Double, defaultValue=1.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.MUSK_X, 'Muskingum X – Weighting Factor [0–0.5]',
            QgsProcessingParameterNumber.Double, defaultValue=0.2, optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.GENERATE_MAPS, 'Generate Flood Inundation Maps', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_2D_ROUTING,
            'Also route the full hydrograph through 2D diffusive-wave '
            'physics (slower, more realistic — see Help)',
            defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(
            self.LOAD_RASTERS, 'Load Flood Rasters in QGIS', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.EXPORT_HEC_HMS, 'Export HEC-HMS Compatible Files', defaultValue=True))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR, 'Output Directory'))

        self.addOutput(QgsProcessingOutputFile(self.OUTPUT_EXCEL, 'Results Excel'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_FLOOD_MAPS, 'Flood Maps (PNG)'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_RASTERS, 'Flood Rasters (GeoTIFF)'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_HYDROGRAPHS, 'Hydrographs'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_HEC_HMS, 'HEC-HMS Files'))

    def processAlgorithm(self, parameters, context, feedback):
        try:
            import geopandas as gpd
            import rasterio
            from rasterio.mask import mask as rasterio_mask
            from shapely.geometry import mapping
        except ImportError as e:
            raise QgsProcessingException(f"Missing packages: {e}")

        # ── Coordinates ──────────────────────────────────────────────────
        point  = self.parameterAsPoint(parameters, self.COORDINATES_POINT, context)
        manual = self.parameterAsString(parameters, self.COORDINATES_MANUAL, context)
        lat, lon = _resolve_coordinates(point, manual, feedback)

        # ── Dates ────────────────────────────────────────────────────────
        start_dt = self.parameterAsDateTime(parameters, self.START_DATE, context)
        end_dt   = self.parameterAsDateTime(parameters, self.END_DATE, context)
        start_str = start_dt.toString('yyyy-MM-dd')
        end_str   = end_dt.toString('yyyy-MM-dd')

        # ── Basic parameters ─────────────────────────────────────────────
        return_periods  = [int(x) for x in
                           self.parameterAsString(parameters, self.RETURN_PERIODS, context).split(',')]
        rain_source     = self.parameterAsEnum(parameters, self.RAINFALL_SOURCE, context)
        use_spatial     = self.parameterAsBoolean(parameters, self.USE_SPATIAL_RAIN, context)
        rain_raster_lyr = self.parameterAsRasterLayer(parameters, self.RAINFALL_RASTER, context)
        rain_raster_path = rain_raster_lyr.source() if rain_raster_lyr else None
        analysis_method = self.parameterAsEnum(parameters, self.ANALYSIS_METHOD, context)
        storm_dur_enum  = self.parameterAsEnum(parameters, self.STORM_DURATION, context)
        freq_method_idx = self.parameterAsEnum(parameters, self.FREQ_METHOD, context) + 1
        amc_idx         = self.parameterAsEnum(parameters, self.AMC_CONDITION, context)
        amc             = amc_idx + 1   # 1=dry, 2=normal, 3=wet
        catchment_input = self.parameterAsEnum(parameters, self.CATCHMENT_INPUT, context)
        cn_src_idx      = self.parameterAsEnum(parameters, self.CN_RASTER_SOURCE, context)
        lulc_type_idx   = self.parameterAsEnum(parameters, self.LULC_TYPE, context)
        lulc_type_name  = ['ESA', 'NLCD', 'CORINE', 'MODIS'][lulc_type_idx]
        hsg_idx         = self.parameterAsEnum(parameters, self.HSG, context)
        hsg             = ['A', 'B', 'C', 'D'][hsg_idx]
        enable_routing  = self.parameterAsBoolean(parameters, self.ENABLE_ROUTING, context)
        generate_maps   = self.parameterAsBoolean(parameters, self.GENERATE_MAPS, context)
        use_2d_routing  = self.parameterAsBoolean(parameters, self.USE_2D_ROUTING, context)
        observed_hydrograph_path = self.parameterAsFile(
            parameters, self.OBSERVED_HYDROGRAPH, context)
        run_sensitivity = self.parameterAsBoolean(
            parameters, self.RUN_SENSITIVITY, context)
        pour_pt_raw = self.parameterAsPoint(parameters, self.POUR_POINT, context)
        pour_pt_manual = self.parameterAsString(parameters, self.POUR_POINT_MANUAL, context)
        subbasin_layer = self.parameterAsVectorLayer(parameters, self.SUBBASIN_LAYER, context)
        wave_celerity = self.parameterAsDouble(parameters, self.WAVE_CELERITY, context) or 1.0
        pour_lat, pour_lon = _resolve_coordinates(pour_pt_raw, pour_pt_manual, feedback)
        if pour_lat is not None and pour_lon is not None:
            feedback.pushInfo(
                f"Pour point (outlet) set to lat={pour_lat:.5f}, lon={pour_lon:.5f} — "
                f"all discharges and the combined hydrograph correspond to THIS point."
            )
        else:
            feedback.pushInfo(
                "No pour point supplied — results correspond to the catchment's "
                "own lowest point, inferred from the DEM. Supply a pour point if "
                "you need results anchored at a specific location."
            )
        cwc_coeffs = _parse_cwc_coeffs(
            self.parameterAsString(parameters, self.CWC_COEFFS, context), feedback)
        load_rasters    = self.parameterAsBoolean(parameters, self.LOAD_RASTERS, context)
        export_hec_hms  = self.parameterAsBoolean(parameters, self.EXPORT_HEC_HMS, context)
        output_dir      = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        os.makedirs(output_dir, exist_ok=True)

        storm_dur_map = {0:1, 1:3, 2:6, 3:12, 4:24}
        storm_dur_hr  = storm_dur_map[storm_dur_enum]

        # ── Manual parameter parsing ──────────────────────────────────────
        cn_manual  = _parse_first_number(
            self.parameterAsString(parameters, self.CN, context), 75.0)
        runoff_C   = _parse_first_number(
            self.parameterAsString(parameters, self.RUNOFF_COEFF, context), 0.60)
        manning_n  = _parse_first_number(
            self.parameterAsString(parameters, self.MANNING_N, context), 0.035)

        feedback.pushInfo(
            f"Flash Flood Analysis v3.0 | lat={lat:.4f}, lon={lon:.4f} | "
            f"storm={storm_dur_hr}hr | AMC={amc} | method={self.ANALYSIS_METHODS[analysis_method]}"
        )

        # ── Layer resolution ──────────────────────────────────────────────
        catchment_layer = self.parameterAsVectorLayer(parameters, self.CATCHMENT, context)
        dem_layer       = self.parameterAsRasterLayer(parameters, self.DEM, context)
        slope_layer     = self.parameterAsRasterLayer(parameters, self.SLOPE_RASTER, context)
        flow_layer      = self.parameterAsVectorLayer(parameters, self.FLOW_PATH, context)
        cn_raster_layer = self.parameterAsRasterLayer(parameters, self.CN_RASTER, context)
        lulc_layer      = self.parameterAsRasterLayer(parameters, self.LULC_RASTER, context)
        mann_raster_lyr = self.parameterAsRasterLayer(parameters, self.MANNING_RASTER, context)

        catchment_path = catchment_layer.source() if catchment_layer else None
        dem_path       = dem_layer.source()       if dem_layer       else None
        slope_path     = slope_layer.source()     if slope_layer     else None
        flow_path      = flow_layer.source()      if flow_layer      else None
        cn_raster_path = cn_raster_layer.source() if cn_raster_layer else None
        lulc_path      = lulc_layer.source()      if lulc_layer      else None
        mann_path      = mann_raster_lyr.source() if mann_raster_lyr else None

        # ── Step A0: Pour-point delineation (if selected) ────────────────
        # Method 2 delineates the upstream catchment from the pour point
        # rather than asking for a polygon. This removes the circularity of
        # needing a catchment boundary in order to analyse a catchment, and
        # it makes the boundary a true watershed divide by construction, so
        # every later clip is exact. The pour point is SNAPPED to the
        # modelled stream network first — a point a cell or two off the
        # channel delineates a hillslope facet, not a basin.
        pp_result = None
        if catchment_input == 2:
            feedback.setProgress(2)
            feedback.pushInfo("=== A0. Pour-Point Catchment Delineation ===")
            try:
                from .pour_point_catchment import (resolve_catchment_from_pour_point,
                                                    pour_point_xy_in_raster_crs)
            except ImportError:
                from pour_point_catchment import (resolve_catchment_from_pour_point,
                                                   pour_point_xy_in_raster_crs)
            snap_radius = self.parameterAsInt(parameters, self.SNAP_RADIUS, context)
            try:
                pp_result = resolve_catchment_from_pour_point(
                    dem_path, pour_lat, pour_lon, output_dir,
                    snap_radius_cells=max(1, snap_radius),
                    load_in_qgis=load_rasters, feedback=feedback)
            except ValueError as e:
                raise QgsProcessingException(str(e))
            catchment_path = pp_result['catchment_gpkg']
            catchment_layer = None
            feedback.pushInfo(
                f"Delineated upstream catchment: {pp_result['area_km2']:.2f} km², "
                f"longest flow path {pp_result['flow_path_m'] / 1000.0:.2f} km, "
                f"snapped {pp_result['snap_moved_m']:.0f} m from the point given.")

            # ── Is the rainfall point actually in this catchment? ────────
            # The rainfall lat/lon and the pour point are separate inputs
            # and nothing tied them together. A real run fetched ERA5 at
            # 16.7038, 74.1557 for a catchment whose outlet was at
            # 16.66184, 74.46644 — 33 km away, and outside the delineated
            # boundary. Every design rainfall depth, and therefore every
            # discharge, came from a grid cell that drains somewhere else.
            # Nothing in the output said so.
            try:
                from shapely.geometry import Point as _Pt
                import geopandas as _gpd
                _cat = _gpd.read_file(pp_result['catchment_gpkg'])
                _rx, _ry = pour_point_xy_in_raster_crs(lat, lon, dem_path)
                _pt = _Pt(_rx, _ry)
                _geom = _cat.geometry.union_all() if hasattr(
                    _cat.geometry, 'union_all') else _cat.geometry.unary_union
                if not _geom.contains(_pt):
                    _d_km = _geom.distance(_pt) / 1000.0
                    feedback.pushWarning(
                        f"  The rainfall point (lat={lat:.4f}, lon={lon:.4f}) "
                        f"lies OUTSIDE the delineated catchment, {_d_km:.1f} km "
                        f"beyond its boundary. Design rainfall — and so every "
                        f"discharge below — is being taken from a location that "
                        f"does not drain to this pour point. Set the rainfall "
                        f"coordinates inside the catchment, ideally near its "
                        f"centroid.")
                else:
                    _cx = _geom.centroid
                    _off = ((_cx.x - _rx) ** 2 + (_cx.y - _ry) ** 2) ** 0.5 / 1000.0
                    if _off > 25.0:
                        feedback.pushInfo(
                            f"  Rainfall point is inside the catchment but "
                            f"{_off:.0f} km from its centroid — check that it "
                            f"represents the catchment as a whole.")
            except Exception as _e:
                feedback.pushInfo(
                    f"  (Could not check the rainfall point against the "
                    f"catchment: {_e})")

        # ── Step A: Catchment parameters ─────────────────────────────────
        feedback.setProgress(3); feedback.pushInfo("=== A. Catchment Parameters ===")
        area, slope_pct, longest_fp = _extract_catchment_params(
            0 if catchment_input == 2 else catchment_input,
            catchment_path, dem_path, slope_path, flow_path,
            self.parameterAsDouble(parameters, self.AREA, context),
            self.parameterAsDouble(parameters, self.SLOPE, context),
            feedback
        )

        if pp_result is not None:
            # The delineation TRACED the D8 flow path cell by cell, which is
            # the real longest flow path. _extract_catchment_params falls
            # back to the polygon's longest geometric span when no flow-path
            # line is supplied, and the diagonal of a catchment outline is
            # not a flow path — it ignores every meander and is typically
            # well short. Since longest flow path drives SCS lag and hence
            # the whole hydrograph timing, prefer the traced value.
            if flow_path is None:
                if abs(pp_result['flow_path_m'] - longest_fp) > 0.05 * max(longest_fp, 1.0):
                    feedback.pushInfo(
                        f"  Longest flow path: using the traced D8 path "
                        f"({pp_result['flow_path_m'] / 1000.0:.2f} km) rather than "
                        f"the polygon's geometric span "
                        f"({longest_fp / 1000.0:.2f} km).")
                longest_fp = pp_result['flow_path_m']
            area = pp_result['area_km2']

        # ── Step B: CN / LULC / Manning's raster processing ──────────────
        feedback.setProgress(8); feedback.pushInfo("=== B. CN / LULC / Manning's Raster ===")
        derived_cn_path, derived_mann_path, weighted_cn, weighted_mann = \
            _resolve_cn_manning_rasters(
                cn_src_idx, cn_raster_path, lulc_path, lulc_type_name,
                catchment_path, output_dir, lat, lon, catchment_layer,
                hsg, amc, cn_manual, manning_n, feedback
            )

        # Use best available CN
        if weighted_cn is not None:
            effective_cn = float(weighted_cn)
        else:
            effective_cn = adjust_cn_for_amc(cn_manual, amc)
        effective_cn = np.clip(effective_cn, 30, 99)

        # Use best available Manning's n
        effective_mann = float(weighted_mann) if weighted_mann else manning_n
        effective_mann = max(0.01, min(0.5, effective_mann))

        feedback.pushInfo(
            f"Effective CN={effective_cn:.1f} (AMC {amc}), "
            f"Effective Manning n={effective_mann:.4f}"
        )

        # ── Step C: Download / load rainfall ─────────────────────────────
        feedback.setProgress(15); feedback.pushInfo("=== C. Rainfall Data ===")
        spatial_rain_mm = None   # weighted-mean storm depth from raster

        if use_spatial and rain_raster_path and catchment_path:
            feedback.pushInfo("Using SPATIAL rainfall raster …")
            spatial_rain_mm = _extract_spatial_rainfall_depth(
                rain_raster_path, catchment_path, feedback)
            if spatial_rain_mm is None:
                feedback.pushWarning("Spatial raster extraction failed – falling back to point rainfall.")
            else:
                feedback.pushInfo(f"Spatial mean storm rainfall = {spatial_rain_mm:.2f} mm")

        if spatial_rain_mm is None:
            rainfall_df = _load_rainfall_hourly(
                rain_source, lat, lon, start_str, end_str,
                self.parameterAsString(parameters, self.EXCEL_FILE, context),
                self.parameterAsString(parameters, self.DATE_COLUMN, context),
                self.parameterAsString(parameters, self.RAINFALL_COLUMN, context),
                feedback
            )
            if rainfall_df is None or rainfall_df.empty:
                raise QgsProcessingException("Failed to load rainfall data.")
            rainfall_df, qc_report = quality_control_rainfall(rainfall_df, feedback=feedback)
        else:
            rainfall_df = None
            qc_report = {'source': 'spatial_raster', 'spatial_mean_mm': spatial_rain_mm}
        feedback.pushInfo(f"QC report: {qc_report}")

        # ── Step D: Short-duration maxima and frequency analysis ──────────
        feedback.setProgress(30); feedback.pushInfo("=== D. Frequency Analysis ===")
        if spatial_rain_mm is not None:
            # Spatial mode: use the raster mean depth directly as the storm total
            feedback.pushInfo(
                f"Spatial rainfall mode: using mean depth={spatial_rain_mm:.2f} mm "
                f"for storm duration={storm_dur_hr} hr across all return periods."
            )
            design_storms = {storm_dur_hr: np.full(len(return_periods), spatial_rain_mm)}
            design_storms_ci_lower, design_storms_ci_upper = {}, {}
            design_storms_dist_name = {storm_dur_hr: 'N/A (spatial raster mean)'}
            sdm = {}
            durations = [storm_dur_hr]
            idf_coeffs, idf_func = {}, lambda d, r: spatial_rain_mm / storm_dur_hr
            idf_table_df = None
        else:
            durations = [1, 3, 6, 12, 24]
            sdm       = _short_duration_maxima(rainfall_df, durations, feedback)
            design_storms = {}
            design_storms_ci_lower, design_storms_ci_upper = {}, {}
            design_storms_dist_name = {}
            AUTO_METHOD_UI_CODE = 5  # 'Auto (best fit by AIC)' — see FREQ_METHODS
            for dur in durations:
                if dur in sdm and len(sdm[dur]) >= 3:
                    actual_method = freq_method_idx
                    if freq_method_idx == AUTO_METHOD_UI_CODE:
                        auto_code, auto_name, _, _ = select_best_distribution(sdm[dur], feedback)
                        actual_method = auto_code
                    result = frequency_analysis_with_uncertainty(
                        sdm[dur], return_periods, actual_method, feedback, n_bootstrap=500)
                    design_storms[dur] = result['design']
                    design_storms_ci_lower[dur] = result['ci_lower']
                    design_storms_ci_upper[dur] = result['ci_upper']
                    design_storms_dist_name[dur] = result['dist_name']
                    feedback.pushInfo(f"  {dur}hr max → {result['dist_name']}")
            if not design_storms:
                raise QgsProcessingException("Frequency analysis produced no results.")

        # ── Step E: IDF curves ────────────────────────────────────────────
        feedback.setProgress(40); feedback.pushInfo("=== E. IDF Curve Generation ===")
        idf_coeffs, idf_func = fit_idf_curves(design_storms, return_periods, feedback)
        idf_table_df          = generate_idf_table(idf_coeffs, durations, return_periods)

        # ── Step F: Runoff calculations ───────────────────────────────────
        feedback.setProgress(50); feedback.pushInfo("=== F. Runoff Calculations ===")

        # Initial-abstraction sanity check. SCS-CN produces ZERO runoff
        # whenever design rainfall <= Ia = 0.2*S, which is correct
        # behaviour but makes the entire downstream analysis degenerate
        # (zero discharge, meaningless flood maps, and a sensitivity
        # analysis dividing by a near-zero baseline). Without this
        # warning the run "succeeds" and silently produces numbers that
        # look real but aren't usable.
        _S_mm = (25400.0 / max(float(effective_cn), 1.0)) - 254.0
        _Ia_mm = 0.2 * _S_mm
        _rains = design_storms.get(storm_dur_hr)
        if _rains is not None and len(_rains):
            _max_rain = float(np.max(_rains))
            if _max_rain <= _Ia_mm * 1.25:
                feedback.pushWarning(
                    f"  Design rainfall for this {storm_dur_hr}hr storm "
                    f"(max {_max_rain:.1f} mm) is at or below the SCS initial "
                    f"abstraction Ia = 0.2*S = {_Ia_mm:.1f} mm for CN="
                    f"{effective_cn:.1f}. SCS-CN therefore yields little or no "
                    f"runoff, and every downstream result (discharge, flood "
                    f"extent, sensitivity) will be near zero and NOT usable."
                )
                feedback.pushWarning(
                    f"  This usually means the storm duration is too short for "
                    f"this catchment, or CN is too low. Options: use a longer "
                    f"storm duration (a {storm_dur_hr}hr storm on a "
                    f"{area:.0f} km² catchment is very short), raise CN if the "
                    f"land cover justifies it, or use AMC III for wet "
                    f"antecedent conditions."
                )
        runoff_results, hydrograph_data = _run_flash_flood_analysis(
            analysis_method, design_storms, return_periods,
            storm_dur_hr, area, effective_cn, runoff_C, effective_mann,
            longest_fp, slope_pct / 100.0,
            amc, feedback, idf_func=idf_func, cwc_coeffs=cwc_coeffs
        )
        df_out = pd.DataFrame(runoff_results)

        # ── Step G: Channel routing ───────────────────────────────────────
        if enable_routing and hydrograph_data:
            musk_K = self.parameterAsDouble(parameters, self.MUSK_K, context) or 1.0
            musk_X = self.parameterAsDouble(parameters, self.MUSK_X, context) or 0.2
            feedback.setProgress(58); feedback.pushInfo(f"=== G. Muskingum-Cunge Routing (K={musk_K}hr, X={musk_X}) ===")
            for rp, data in hydrograph_data.items():
                dt = float(data['time'][1] - data['time'][0]) if len(data['time']) > 1 else 0.1
                data['discharge_routed'] = muskingum_cunge_routing(
                    data['discharge'], dt, musk_K, musk_X, feedback)

        # ── Step H: Hydrograph plots ──────────────────────────────────────
        feedback.setProgress(65); feedback.pushInfo("=== H. Hydrograph Visualisation ===")
        hydro_dir  = os.path.join(output_dir, 'hydrographs')
        os.makedirs(hydro_dir, exist_ok=True)
        hydro_paths = _plot_hydrographs(
            hydrograph_data, return_periods, storm_dur_hr,
            analysis_method, self.ANALYSIS_METHODS, hydro_dir, enable_routing, feedback)

        # ── Step I: Design storm hyetographs ─────────────────────────────
        if storm_dur_hr in design_storms:
            _plot_design_storms(
                design_storms[storm_dur_hr], return_periods, storm_dur_hr,
                idf_func, hydro_dir, feedback)

        # ── Step J: IDF plots ─────────────────────────────────────────────
        _plot_idf_curves(design_storms, return_periods, durations, output_dir, feedback)

        # ── Step J2: Calibration against observed data (optional) ──────────
        # This is the step that turns everything above from unvalidated
        # first-principles estimation into something checkable: load a
        # real observed event and see whether the model actually
        # reproduces it. Without this there's no way to know if the CN /
        # Manning's n / method choices are right for THIS catchment.
        calib_metrics = None
        if observed_hydrograph_path and os.path.exists(observed_hydrograph_path):
            feedback.pushInfo("=== J2. Calibration vs Observed Hydrograph ===")
            calib_metrics = _run_calibration(
                observed_hydrograph_path, hydrograph_data, return_periods,
                output_dir, feedback)

        # ── Step J2b: Semi-distributed sub-basin routing (optional) ───────
        # The main results above are LUMPED: one area-weighted CN, one Tc
        # from the single longest flow path, one hydrograph. On a large
        # catchment that implicitly assumes every sub-basin contributes
        # with identical timing, which tends to OVER-predict the peak.
        # When sub-basins are supplied, each is run separately with its
        # own CN and timing, lagged to the pour point, and summed.
        if subbasin_layer is not None:
            feedback.pushInfo("=== J2b. Semi-Distributed Sub-Basin Routing ===")
            try:
                from .subbasin_routing import (
                    load_subbasins, route_subbasins_to_outlet, write_subbasin_summary)
            except ImportError:
                from subbasin_routing import (
                    load_subbasins, route_subbasins_to_outlet, write_subbasin_summary)
            try:
                pour_xy = _pour_point_in_layer_crs(
                    pour_lat, pour_lon, subbasin_layer, feedback)
                subs = load_subbasins(subbasin_layer.source(), pour_xy,
                                       catchment_path=catchment_path,
                                       feedback=feedback)
                if subs:
                    sd_rows = []
                    for rp_i, rp in enumerate(return_periods):
                        rain_rp = float(design_storms[storm_dur_hr][rp_i]) \
                            if storm_dur_hr in design_storms else None
                        if rain_rp is None:
                            continue
                        feedback.pushInfo(f"  --- {rp}-yr ---")
                        sd = route_subbasins_to_outlet(
                            subs, rain_rp, storm_dur_hr, effective_cn,
                            effective_mann, slope_pct,
                            cn_raster_path=(derived_cn_path or cn_raster_path),
                            feedback=feedback, wave_celerity_ms=wave_celerity)
                        if not sd:
                            continue
                        write_subbasin_summary(sd, output_dir, rp, feedback)
                        lumped_peak = next(
                            (float(r['Discharge (m³/s)']) for r in runoff_results
                             if int(r['Return Period (yr)']) == rp), None)
                        sd_rows.append({
                            'Return Period (yr)': rp,
                            'Lumped peak (m3/s)': round(lumped_peak, 2) if lumped_peak else None,
                            'Semi-distributed peak (m3/s)': round(sd['peak_m3s'], 2),
                            'Sub-basins': len(subs),
                        })
                        if lumped_peak:
                            diff = 100.0 * (sd['peak_m3s'] - lumped_peak) / lumped_peak
                            feedback.pushInfo(
                                f"    Lumped={lumped_peak:.1f} m³/s vs "
                                f"semi-distributed={sd['peak_m3s']:.1f} m³/s "
                                f"({diff:+.1f}%). The semi-distributed value accounts "
                                f"for sub-basins peaking at different times."
                            )
                    if sd_rows:
                        _sd_dir = os.path.join(output_dir, 'subbasins')
                        os.makedirs(_sd_dir, exist_ok=True)
                        pd.DataFrame(sd_rows).to_csv(
                            os.path.join(_sd_dir, 'lumped_vs_semidistributed.csv'),
                            index=False)
                        feedback.pushInfo(
                            "  Comparison saved: lumped_vs_semidistributed.csv")
            except Exception as e:
                feedback.pushWarning(f"  Sub-basin routing failed: {e}")

        # ── Step J3: Sensitivity analysis (optional) ──────────────────────
        if run_sensitivity:
            _run_sensitivity_analysis(
                analysis_method, design_storms, return_periods, storm_dur_hr,
                area, effective_cn, runoff_C, effective_mann,
                longest_fp, slope_pct / 100.0, amc, output_dir, feedback,
                idf_func=idf_func, cwc_coeffs=cwc_coeffs)

        # ── Step K: Flood mapping ─────────────────────────────────────────
        flood_map_paths, flood_raster_paths = [], []
        flood_velocity_paths, flood_hazard_paths = [], []
        flood_2d_map_paths, flood_2d_raster_paths = [], []
        if generate_maps and dem_path and catchment_path:
            feedback.setProgress(75); feedback.pushInfo("=== K. Flood Inundation Mapping ===")
            for _, row in df_out.iterrows():
                rp       = int(row['Return Period (yr)'])
                Q        = float(row['Discharge (m³/s)'])
                Q_rd_mm  = float(row.get('Runoff Depth (mm)', 0))
                fmap, fraster, fvel, fhaz = generate_flood_map(
                    discharge=Q, dem_path=dem_path, catchment_path=catchment_path,
                    output_dir=output_dir, return_period=rp,
                    manning_n=effective_mann, feedback=feedback,
                    cn_raster_path=derived_cn_path or cn_raster_path,
                    manning_raster_path=derived_mann_path or mann_path,
                    runoff_depth_mm=Q_rd_mm if Q_rd_mm > 0 else None
                )
                if fmap:    flood_map_paths.append(fmap)
                if fraster: flood_raster_paths.append(fraster)
                if fvel:    flood_velocity_paths.append(fvel)
                if fhaz:    flood_hazard_paths.append(fhaz)

                if use_2d_routing and rp in hydrograph_data:
                    hyd = hydrograph_data[rp]
                    # This tool's hydrographs are in hours; the routing
                    # engine works in seconds.
                    t_s = np.asarray(hyd['time'], dtype=np.float64) * 3600.0
                    q_cms = np.asarray(hyd['discharge'], dtype=np.float64)
                    if len(t_s) >= 2 and np.max(q_cms) > 0:
                        feedback.pushInfo(
                            f"  2D routing for {rp}-yr (this is the slow, "
                            f"opt-in step — see Help for what it does "
                            f"differently) ..."
                        )
                        fmap2d, fraster2d, _result2d = generate_flood_map_2d(
                            t_s, q_cms, dem_path, catchment_path, output_dir,
                            return_period=rp, manning_n=effective_mann,
                            feedback=feedback,
                            cn_raster_path=derived_cn_path or cn_raster_path,
                            manning_raster_path=derived_mann_path or mann_path,
                        )
                        if fmap2d:    flood_2d_map_paths.append(fmap2d)
                        if fraster2d: flood_2d_raster_paths.append(fraster2d)

        if load_rasters and flood_raster_paths:
            load_flood_rasters_to_qgis(flood_raster_paths, feedback)
        if load_rasters and flood_velocity_paths:
            load_flood_rasters_to_qgis(flood_velocity_paths, feedback)
        if load_rasters and flood_hazard_paths:
            load_hazard_rasters_to_qgis(flood_hazard_paths, feedback)
        if load_rasters and flood_2d_raster_paths:
            load_flood_rasters_to_qgis(flood_2d_raster_paths, feedback)

        # ── Step L: HEC-HMS export ────────────────────────────────────────
        if export_hec_hms:
            feedback.setProgress(92); feedback.pushInfo("=== L. HEC-HMS Export ===")
            _export_hec_hms(output_dir, df_out, hydrograph_data, design_storms,
                             return_periods, durations, storm_dur_hr,
                             area, effective_cn, effective_mann, slope_pct,
                             longest_fp, analysis_method, self.ANALYSIS_METHODS, feedback)

        # ── Step M: Save Excel ────────────────────────────────────────────
        excel_path = os.path.join(output_dir, 'Flash_Flood_Analysis_Results.xlsx')
        _save_excel(excel_path, df_out, idf_table_df, sdm, return_periods, durations, design_storms,
                    qc_report, effective_cn, effective_mann, amc, storm_dur_hr,
                    self.ANALYSIS_METHODS[analysis_method],
                    design_storms_ci_lower, design_storms_ci_upper, design_storms_dist_name)

        # ── Step N: HTML report ───────────────────────────────────────────
        feedback.setProgress(96); feedback.pushInfo("=== N. Report Generation ===")
        generate_html_report(
            output_dir, 'Flash Flood',
            {
                'Catchment area (km²)': f"{area:.2f}",
                'Mean slope (%)': f"{slope_pct:.2f}",
                'Longest flow path (m)': f"{longest_fp:.0f}",
                'Effective CN (AMC-adjusted)': f"{effective_cn:.1f}",
                "Effective Manning's n": f"{effective_mann:.4f}",
                'Analysis method': self.ANALYSIS_METHODS[analysis_method],
                'Storm duration (hr)': storm_dur_hr,
                'Return periods (yr)': ', '.join(str(r) for r in return_periods),
                'Antecedent moisture condition': amc,
                'Rainfall record length (yr)': qc_report.get('record_length_years', 'N/A'),
            },
            results_df=df_out, feedback=feedback)

        feedback.setProgress(100); feedback.pushInfo(f"=== Analysis complete. Results: {output_dir} ===")
        gc.collect()

        return {
            self.OUTPUT_EXCEL:       excel_path,
            self.OUTPUT_FLOOD_MAPS:  os.path.join(output_dir, 'flood_maps'),
            self.OUTPUT_RASTERS:     os.path.join(output_dir, 'flood_rasters'),
            self.OUTPUT_HYDROGRAPHS: os.path.join(output_dir, 'hydrographs'),
            self.OUTPUT_HEC_HMS:     os.path.join(output_dir, 'hec_hms'),
        }

    def name(self):           return 'flash_flood_analysis'
    def displayName(self):    return 'Flash Flood Analysis (Hourly / Short-Duration)'
    def group(self):          return 'Hydrology'
    def groupId(self):        return 'hydrology'
    def createInstance(self): return FlashFloodAnalysis()


# ===========================================================================
# Private helpers
# ===========================================================================

def _resolve_coordinates(point, manual_str, feedback):
    if point and not point.isEmpty():
        return point.y(), point.x()
    if manual_str and manual_str.strip():
        parts = manual_str.split(',')
        return float(parts[0].strip()), float(parts[1].strip())
    raise QgsProcessingException("No valid coordinates provided.")


def _parse_first_number(s, default):
    import re as _re
    if not s:
        return default
    try:
        return float(s)
    except ValueError:
        m = _re.search(r'[-+]?\d*\.?\d+', s.strip())
        return float(m.group()) if m else default


def _extract_catchment_params(method, catchment_path, dem_path, slope_path,
                               flow_path, area_param, slope_param, feedback):
    """Return (area_km2, slope_percent, longest_fp_m)."""
    area, slope_pct, longest_fp = 1.0, 1.0, 1000.0

    if method == 0 and catchment_path:  # GIS layers
        try:
            import geopandas as gpd
            import rasterio
            from rasterio.mask import mask as rasterio_mask
            from shapely.geometry import mapping

            gdf = gpd.read_file(catchment_path)
            if gdf.crs is None or gdf.crs.is_geographic:
                cx  = gdf.geometry.unary_union.centroid.x
                cy  = gdf.geometry.unary_union.centroid.y
                zone = int((cx + 180) // 6) + 1
                hem  = 'north' if cy >= 0 else 'south'
                utmcrs = f"EPSG:{'326' if hem=='north' else '327'}{zone:02d}"
                gdf = gdf.to_crs(utmcrs)
            area = float(gdf.area.sum()) / 1e6
            feedback.pushInfo(f"Catchment area: {area:.3f} km²")

            if slope_path:
                with rasterio.open(slope_path) as src:
                    geoms = [mapping(g) for g in gdf.to_crs(src.crs).geometry]
                    out, _ = rasterio_mask(src, geoms, crop=True, nodata=np.nan)
                    valid  = out[0][~np.isnan(out[0]) & (out[0] >= 0)]
                    slope_pct = float(np.nanmean(valid)) if len(valid) > 0 else 1.0
                feedback.pushInfo(f"Mean slope: {slope_pct:.2f}%")
            else:
                slope_pct = max(slope_param * 100 if slope_param else 1.0, 0.1)

            if flow_path:
                gdf_fp = gpd.read_file(flow_path).to_crs(gdf.crs)
                longest_fp = float(gdf_fp.geometry.length.max())
                feedback.pushInfo(f"Longest flow path: {longest_fp:.0f} m")
            else:
                longest_fp = math.sqrt(area * 1e6) * 1.5

        except Exception as e:
            feedback.pushWarning(f"GIS extraction failed ({e}). Using manual inputs.")
            area       = max(area_param or 1.0, 0.01)
            slope_pct  = max((slope_param or 0.01) * 100, 0.1)
            longest_fp = math.sqrt(area * 1e6) * 1.5
    else:
        area       = max(area_param or 1.0, 0.01)
        slope_pct  = max((slope_param or 0.01) * 100, 0.1)
        longest_fp = math.sqrt(area * 1e6) * 1.5
        feedback.pushInfo(f"Manual: A={area:.2f} km², S={slope_pct:.2f}%, L={longest_fp:.0f} m")

    return area, max(slope_pct, 0.01), longest_fp


def _resolve_cn_manning_rasters(cn_src_idx, cn_raster_path, lulc_path, lulc_type_name,
                                  catchment_path, output_dir, lat, lon, catchment_layer,
                                  hsg, amc, cn_manual, manning_manual, feedback):
    """
    Returns (derived_cn_path, derived_mann_path, weighted_cn, weighted_mann).
    Source options:
      0 = manual (no rasters)
      1 = existing CN raster (HEC-RAS)
      2 = existing LULC raster → compute CN
      3 = download ESA WorldCover → compute CN
    """
    try:
        import rasterio
        from .raster_downloader import (
            generate_cn_raster_from_lulc_file, extract_catchment_cn_manning,
            download_esa_worldcover_for_bbox
        )
    except ImportError:
        try:
            import rasterio
            from raster_downloader import (
                generate_cn_raster_from_lulc_file, extract_catchment_cn_manning,
                download_esa_worldcover_for_bbox
            )
        except Exception:
            return None, None, None, None

    raster_out = os.path.join(output_dir, 'rasters')
    os.makedirs(raster_out, exist_ok=True)
    derived_cn_path = derived_mann_path = weighted_cn = weighted_mann = None

    if cn_src_idx == 0:  # manual
        feedback.pushInfo("CN source: Manual value (no spatial raster).")
        return None, None, None, None

    elif cn_src_idx == 1:  # existing CN raster
        if cn_raster_path and catchment_path:
            weighted_cn, weighted_mann_tmp = extract_catchment_cn_manning(
                cn_raster_path, None, catchment_path, feedback)
            derived_cn_path = cn_raster_path
            weighted_mann   = weighted_mann_tmp or manning_manual
        else:
            feedback.pushWarning("CN raster selected but no raster provided.")

    elif cn_src_idx == 2:  # LULC raster
        if lulc_path and catchment_path:
            try:
                import geopandas as gpd
                from shapely.geometry import mapping
                gdf   = gpd.read_file(catchment_path)
                geoms = list(gdf.geometry)
                result = generate_cn_raster_from_lulc_file(
                    lulc_path, raster_out, lulc_type_name, hsg, amc,
                    catchment_geoms=geoms, feedback=feedback)
                derived_cn_path  = result.get('cn_raster')
                derived_mann_path = result.get('manning_raster')
                weighted_cn       = result.get('weighted_cn')
                weighted_mann     = result.get('weighted_manning')
            except Exception as e:
                feedback.pushWarning(f"LULC→CN failed: {e}")
        else:
            feedback.pushWarning("LULC raster selected but no raster/catchment provided.")

    elif cn_src_idx == 3:  # download ESA WorldCover
        if catchment_path:
            try:
                import geopandas as gpd
                gdf = gpd.read_file(catchment_path).to_crs('EPSG:4326')
                b   = gdf.total_bounds  # (minx, miny, maxx, maxy)
                # Expand bbox slightly
                pad = 0.05
                bbox = (b[1]-pad, b[3]+pad, b[0]-pad, b[2]+pad)
                esa_dir = os.path.join(raster_out, 'esa_worldcover')
                merged_path = download_esa_worldcover_for_bbox(bbox, esa_dir, feedback)
                if merged_path:
                    geoms  = list(gdf.geometry)
                    result = generate_cn_raster_from_lulc_file(
                        merged_path, raster_out, 'ESA', hsg, amc,
                        catchment_geoms=geoms, feedback=feedback)
                    derived_cn_path  = result.get('cn_raster')
                    derived_mann_path = result.get('manning_raster')
                    weighted_cn       = result.get('weighted_cn')
                    weighted_mann     = result.get('weighted_manning')
                else:
                    feedback.pushWarning("ESA WorldCover download failed. Using manual CN.")
            except Exception as e:
                feedback.pushWarning(f"ESA download/processing failed: {e}")
        else:
            feedback.pushWarning("ESA WorldCover download requires a catchment shapefile.")

    return derived_cn_path, derived_mann_path, weighted_cn, weighted_mann


def _load_rainfall_hourly(rain_source, lat, lon, start_str, end_str,
                            excel_file, date_col, rain_col, feedback):
    if rain_source == 0:
        return download_openmeteo_hourly_data(lat, lon, start_str, end_str, feedback)
    elif rain_source == 1:
        daily = download_gpm_imerg_daily(lat, lon, start_str, end_str, feedback)
        if daily is not None:
            return _disaggregate_daily_to_hourly(daily, feedback)
        return None
    elif rain_source == 2:  # IMD
        try:
            from .rainfall_data_sources import download_imd_data
        except ImportError:
            from rainfall_data_sources import download_imd_data
        start_yr = int(start_str[:4]); end_yr = int(end_str[:4])
        daily = download_imd_data(lat, lon, start_yr, end_yr, None, feedback)
        if daily is not None:
            return _disaggregate_daily_to_hourly(daily, feedback)
        feedback.pushWarning("IMD download failed. Falling back to Open-Meteo ERA5.")
        return download_openmeteo_hourly_data(lat, lon, start_str, end_str, feedback)
    elif rain_source == 3:
        return load_excel_rainfall_data(excel_file, date_col, rain_col, feedback)
    else:  # synthetic
        try:
            from .rainfall_data_sources import generate_synthetic_rainfall
        except ImportError:
            from rainfall_data_sources import generate_synthetic_rainfall
        return generate_synthetic_rainfall(80.0, cv=0.5, n_years=30, feedback=feedback)


def _disaggregate_daily_to_hourly(daily_df, feedback):
    """Simple uniform disaggregation of daily to hourly."""
    rows = []
    for date, row in daily_df.iterrows():
        r_mm = max(0, float(row['Rainfall (mm)']) / 24.0)
        for h in range(24):
            rows.append({'DateTime': date + pd.Timedelta(hours=h), 'Rainfall (mm)': r_mm})
    df = pd.DataFrame(rows).set_index('DateTime')
    feedback.pushInfo(f"Disaggregated {len(daily_df)} days → {len(df)} hourly records")
    return df


def _short_duration_maxima(df, durations, feedback):
    """Annual maxima for rolling-window sums at each duration."""
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    sdm = {}
    for dur in durations:
        yearly_max = []
        for yr in df.index.year.unique():
            sub = df[df.index.year == yr]['Rainfall (mm)']
            if len(sub) >= dur:
                rolling_max = sub.rolling(dur, min_periods=max(1, dur//2)).sum().max()
                if rolling_max > 0:
                    yearly_max.append(float(rolling_max))
        if yearly_max:
            sdm[dur] = yearly_max
            feedback.pushInfo(
                f"  {dur}hr: {len(yearly_max)} years, "
                f"max={max(yearly_max):.1f} mm, mean={np.mean(yearly_max):.1f} mm"
            )
    return sdm


def _run_flash_flood_analysis(method, design_storms, return_periods, storm_dur_hr,
                               area, cn, C, mann_n, L_m, slope_decimal, amc, feedback,
                               idf_func=None, cwc_coeffs=None):
    """Run selected hydrograph method. Returns (results_list, hydrograph_dict)."""
    tp_hr = calculate_time_to_peak(L_m, slope_decimal * 100, cn, feedback, duration_hr=storm_dur_hr)
    results, hyd_data = [], {}

    for i, rp in enumerate(return_periods):
        if storm_dur_hr in design_storms and i < len(design_storms[storm_dur_hr]):
            rain_mm = float(design_storms[storm_dur_hr][i])
        else:
            avail = sorted(design_storms.keys(), key=lambda d: abs(d - storm_dur_hr))
            rain_mm = float(design_storms[avail[0]][i]) if avail else 50.0

        row = {'Return Period (yr)': rp, f'{storm_dur_hr}hr Rainfall (mm)': rain_mm}

        if method == 0:   # SCS Triangular UH
            Q_mm = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
            t, disch = generate_scs_unit_hydrograph(area, tp_hr, feedback)
            _, disch_fh = generate_flood_hydrograph(t, disch, Q_mm, feedback)
            Qp = float(disch_fh.max())
            row.update({'Runoff Depth (mm)': Q_mm, 'Discharge (m³/s)': Qp})
            hyd_data[rp] = {'time': t, 'discharge': disch_fh}

        elif method == 1:  # NRCS Dimensionless UH
            Q_mm = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
            t, disch = generate_nrcs_dimensionless_uh(area, tp_hr, feedback)
            _, disch_fh = generate_flood_hydrograph(t, disch, Q_mm, feedback)
            Qp = float(disch_fh.max())
            row.update({'Runoff Depth (mm)': Q_mm, 'Discharge (m³/s)': Qp})
            hyd_data[rp] = {'time': t, 'discharge': disch_fh}

        elif method == 2:  # Snyder UH
            Q_mm = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
            Lca  = L_m * 0.4  # centroidal distance approx
            t, disch, snyder_tp = generate_snyder_unit_hydrograph(area, L_m, Lca, feedback=feedback)
            disch_fh = disch * (Q_mm / 10.0)
            Qp = float(disch_fh.max())
            row.update({'Runoff Depth (mm)': Q_mm, 'Discharge (m³/s)': Qp})
            hyd_data[rp] = {'time': t, 'discharge': disch_fh}

        elif method == 3:  # Clark IUH
            Q_mm = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
            tc   = tp_hr * 1.7       # Tc from Tp
            R    = tc * 0.8          # storage coefficient
            t, iuh = generate_clark_iuh(area, tc, R, feedback=feedback)
            disch_fh = iuh * Q_mm
            Qp = float(disch_fh.max())
            row.update({'Runoff Depth (mm)': Q_mm, 'Discharge (m³/s)': Qp})
            hyd_data[rp] = {'time': t, 'discharge': disch_fh}

        elif method == 4:  # Modified Rational
            # Tc (time of concentration) vs Tp (time to peak) are different
            # quantities — under the SCS convention used elsewhere in this
            # file, Tp = 0.6 * Tc, so Tc = Tp / 0.6. The Modified Rational
            # Method's "is storm duration >= Tc" comparison needs the
            # actual Tc, not Tp.
            tc_hr_actual = tp_hr / 0.6

            # Textbook Rational Method practice: look up intensity from the
            # IDF curve AT duration = Tc for this return period, not by
            # dividing a fixed design-storm depth (for a possibly different
            # duration, storm_dur_hr) by that duration — IDF curves are
            # non-linear in duration, so those aren't the same number.
            # Falls back to the simple depth/duration approach only when no
            # fitted IDF curve is available (e.g. a single manually-entered
            # design storm with no duration series to fit from).
            i_from_idf = idf_func(tc_hr_actual, rp) if idf_func else None
            if i_from_idf is not None:
                i_mm_hr = i_from_idf
            else:
                i_mm_hr = rain_mm / storm_dur_hr

            Qf = rational_method_peak_discharge(C, i_mm_hr, area)
            Qp = Qf if storm_dur_hr >= tc_hr_actual else Qf * (storm_dur_hr / tc_hr_actual)
            row.update({'Intensity (mm/hr)': i_mm_hr, 'Runoff Coeff C': C,
                        'Tc (hr)': tc_hr_actual, 'Discharge (m³/s)': Qp})
            # Simple trapezoidal hydrograph
            tb = storm_dur_hr + 2 * tp_hr
            t  = np.array([0, tp_hr - 0.001, tp_hr, tb])
            d  = np.array([0, Qp * 0.5, Qp, 0])
            hyd_data[rp] = {'time': t, 'discharge': d}

        elif method == 5:  # Wadi / Arid
            Qp, Q_mm, Tc = wadi_flood_estimation(area, rain_mm, cn, slope_decimal * 100, feedback)
            row.update({'Runoff Depth (mm)': Q_mm, 'Tc Wadi (hr)': Tc,
                        'Discharge (m³/s)': Qp})
            t = np.linspace(0, Tc * 4, 50)
            d = Qp * np.exp(-((t - Tc) / (Tc * 0.5))**2)
            d = np.maximum(d, 0)
            hyd_data[rp] = {'time': t, 'discharge': d}

        elif method == 6:  # CWC Synthetic UH (India)
            Q_mm = float(calculate_scs_cn_runoff([rain_mm], cn)[0])
            # CWC's method needs Lc (outlet-to-centroid distance along the
            # main stream), which isn't separately measured in this
            # pipeline. Lc ≈ 0.5*L is the standard approximation used
            # when it hasn't been measured directly — reported in the
            # log so it's visible rather than silently assumed.
            L_km = L_m / 1000.0
            Lc_km = 0.5 * L_km
            suh = cwc_synthetic_unit_hydrograph(
                area_km2=area, L_km=L_km, Lc_km=Lc_km,
                S_slope=max(slope_decimal, 1e-5),
                coeffs=cwc_coeffs, tr_hr=1.0, feedback=feedback if i == 0 else None)
            if i == 0:
                feedback.pushInfo(
                    f"  CWC SUH: using Lc≈0.5*L={Lc_km:.2f} km "
                    f"(standard approximation — measure Lc directly for "
                    f"design work if available)."
                )
            t = suh['time_hr']
            _, disch_fh = generate_flood_hydrograph(t, suh['discharge_m3s'], Q_mm, feedback)
            Qp = float(np.max(disch_fh)) if len(disch_fh) else 0.0
            row.update({'Runoff Depth (mm)': Q_mm,
                        'CWC tp (hr)': round(suh['tp_hr'], 2),
                        'CWC UH Qp (m³/s)': round(suh['Qp_m3s'], 2),
                        'Discharge (m³/s)': Qp})
            hyd_data[rp] = {'time': t, 'discharge': disch_fh}

        results.append(row)

    return results, hyd_data


def _plot_hydrographs(hyd_data, return_periods, storm_dur_hr, method_idx,
                       method_names, hydro_dir, enable_routing, feedback):
    """Plot and save flood hydrographs."""
    paths = []
    if not hyd_data:
        return paths
    _ps.apply_style()
    colors = plt.cm.coolwarm(np.linspace(0.1, 0.9, len(return_periods)))
    fig, ax = plt.subplots(figsize=(12, 7))
    plotted = [rp for rp in return_periods if rp in hyd_data]
    for rp, col in zip(return_periods, colors):
        if rp not in hyd_data:
            continue
        d = hyd_data[rp]
        ax.plot(d['time'], d['discharge'], color=col, lw=2, label=f'{rp}-yr', zorder=3)
        if enable_routing and 'discharge_routed' in d:
            ax.plot(d['time'], d['discharge_routed'], color=col, lw=2,
                    ls='--', alpha=0.7, label=f'{rp}-yr (routed)', zorder=3)
        # Gradient fill reads considerably better than a flat translucent
        # block when several hydrographs overlap.
        _ps.gradient_fill(ax, d['time'], d['discharge'], col, alpha_top=0.22)

    # Annotate the peak of the largest return period — the single number
    # a reader most often wants off this chart, and otherwise something
    # they have to eyeball against the axis.
    if plotted:
        rp_max = max(plotted)
        d_max = hyd_data[rp_max]
        q_arr = np.asarray(d_max['discharge'])
        if len(q_arr):
            i_pk = int(np.argmax(q_arr))
            _ps.annotate_peak(
                ax, float(np.asarray(d_max['time'])[i_pk]), float(q_arr[i_pk]),
                label_fmt=f"{rp_max}-yr peak: {{y:,.1f}} m³/s")

    _ps.style_axis(
        ax,
        f'Flash Flood Hydrographs — {storm_dur_hr}hr Storm\n'
        f'Method: {method_names[method_idx]}',
        'Time (hr)', 'Discharge (m³/s)')
    _ps.format_thousands(ax, axis='y')
    ax.set_xlim(left=0)
    ax.set_ylim(bottom=0)
    out = os.path.join(hydro_dir, 'flash_flood_hydrographs.png')
    fig.savefig(out, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    paths.append(out)
    return paths


def _plot_design_storms(design_rains, return_periods, storm_dur_hr, idf_func, hydro_dir, feedback):
    """Plot ABM design storm hyetographs."""
    n_intervals = max(6, storm_dur_hr * 4)
    fig, axes = plt.subplots(len(return_periods), 1,
                              figsize=(10, 3 * len(return_periods)),
                              sharex=True)
    if len(return_periods) == 1:
        axes = [axes]
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(return_periods)))
    for ax, rp, rain, col in zip(axes, return_periods, design_rains, colors):
        t, hyeto = alternating_block_hyetograph(
            rain, storm_dur_hr, n_intervals, idf_func, rp, feedback)
        ax.bar(t, hyeto, width=storm_dur_hr / n_intervals * 0.9,
               color=col, align='edge', edgecolor='navy', lw=0.5)
        ax.set_title(f'ABM Design Storm – {rp}-year return period ({rain:.0f} mm total)',
                     fontsize=10)
        ax.set_ylabel('Rainfall (mm)', fontsize=9)
        ax.grid(True, axis='y', ls='--', alpha=0.5)
    axes[-1].set_xlabel('Time (hr)', fontsize=10)
    fig.suptitle(f'{storm_dur_hr}-hr Alternating Block Method Hyetographs',
                 fontsize=12, fontweight='bold')
    fig.tight_layout()
    out = os.path.join(hydro_dir, 'abm_design_storms.png')
    fig.savefig(out, dpi=180, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def _run_sensitivity_analysis(method, design_storms, return_periods, storm_dur_hr,
                               area, cn, C, mann_n, L_m, slope_decimal, amc,
                               output_dir, feedback, idf_func=None, cwc_coeffs=None,
                               perturbation_pct=20.0):
    """
    One-at-a-time (OAT) sensitivity analysis: re-run the analysis with
    each key input perturbed up and down by +/-perturbation_pct, and
    report how much the peak discharge moves.

    Why this matters for a professional report: every design number this
    tool produces rests on parameter choices (CN, Manning's n, design
    rainfall, flow-path length) that carry real uncertainty. Sensitivity
    analysis answers "if my CN estimate is off by 20%, does my design
    discharge change by 5% or 50%?" — which tells you where to spend
    effort refining inputs, and is standard practice for demonstrating
    that results are robust.

    Reports ELASTICITY (% change in output per % change in input) so
    parameters measured in completely different units — a dimensionless
    CN, a roughness coefficient, millimetres of rain, metres of length —
    can be ranked against each other directly.

    Deliberately reuses the SAME _run_flash_flood_analysis() dispatch as
    the main run rather than reimplementing the hydrology, so the
    sensitivity results can't drift away from what the tool actually
    computes.
    """
    class _QuietFB:
        """Suppress per-run logging — a sensitivity sweep makes ~9 full
        analysis runs, and echoing each one would bury the actual
        results in noise."""
        def pushInfo(self, m): pass
        def pushWarning(self, m): pass
        def pushDebugInfo(self, m): pass
        def reportError(self, m, fatalError=False): pass
        def setProgress(self, v): pass

    feedback.pushInfo(
        f"=== Sensitivity Analysis (±{perturbation_pct:.0f}% one-at-a-time) ==="
    )

    def _peak_for(cn_v, mann_v, rain_scale, L_v):
        scaled_storms = {k: np.asarray(v) * rain_scale for k, v in design_storms.items()}
        try:
            res, _ = _run_flash_flood_analysis(
                method, scaled_storms, return_periods, storm_dur_hr,
                area, cn_v, C, mann_v, L_v, slope_decimal, amc, _QuietFB(),
                idf_func=idf_func, cwc_coeffs=cwc_coeffs)
        except Exception:
            return None
        peaks = [r.get('Discharge (m³/s)') for r in res
                 if r.get('Discharge (m³/s)') is not None]
        return float(np.max(peaks)) if peaks else None

    baseline = _peak_for(cn, mann_n, 1.0, L_m)
    if baseline is None or baseline <= 0:
        feedback.pushWarning(
            "  Sensitivity analysis skipped — the baseline run produced no "
            "usable peak discharge."
        )
        return None

    # Percentage change is meaningless against a near-zero baseline: a
    # baseline of 0.5 m3/s rising to 8 m3/s reads as "+1500%", and
    # elasticity values in the tens, which look alarming but are just an
    # artefact of dividing by ~0. This happens whenever design rainfall
    # sits near the SCS initial abstraction threshold (see the Ia warning
    # in Step F). Flag it rather than reporting fake precision.
    _degenerate_baseline = baseline < 1.0
    if _degenerate_baseline:
        feedback.pushWarning(
            f"  Baseline peak discharge is only {baseline:.3f} m³/s — close "
            f"enough to zero that percentage changes and elasticities below "
            f"are numerically unstable and should NOT be read as real "
            f"sensitivities. Fix the near-zero-runoff problem first (see the "
            f"initial abstraction warning above), then re-run."
        )

    f = perturbation_pct / 100.0
    # CN is capped at 100 by definition, so a naive +20% on a high CN
    # would silently clip and understate that parameter's sensitivity.
    # Clamp explicitly and report the value actually used.
    cn_hi = min(cn * (1 + f), 98.0)
    cn_lo = max(cn * (1 - f), 30.0)

    params = [
        ('Curve Number (CN)',   _peak_for(cn_lo, mann_n, 1.0, L_m),
                                 _peak_for(cn_hi, mann_n, 1.0, L_m),
                                 cn_lo, cn, cn_hi),
        ("Manning's n",         _peak_for(cn, mann_n * (1 - f), 1.0, L_m),
                                 _peak_for(cn, mann_n * (1 + f), 1.0, L_m),
                                 mann_n * (1 - f), mann_n, mann_n * (1 + f)),
        ('Design rainfall',     _peak_for(cn, mann_n, 1 - f, L_m),
                                 _peak_for(cn, mann_n, 1 + f, L_m),
                                 f'-{perturbation_pct:.0f}%', 'baseline',
                                 f'+{perturbation_pct:.0f}%'),
        ('Flow path length',    _peak_for(cn, mann_n, 1.0, L_m * (1 - f)),
                                 _peak_for(cn, mann_n, 1.0, L_m * (1 + f)),
                                 L_m * (1 - f), L_m, L_m * (1 + f)),
    ]

    rows = []
    for name, q_lo, q_hi, v_lo, v_base, v_hi in params:
        if q_lo is None or q_hi is None:
            feedback.pushWarning(f"  {name}: sensitivity run failed, skipped.")
            continue
        change_lo = 100.0 * (q_lo - baseline) / baseline
        change_hi = 100.0 * (q_hi - baseline) / baseline
        # Elasticity: mean |%output change| per |%input change|. Uses the
        # actual applied CN change rather than the nominal one, since CN
        # gets clamped at its physical bounds.
        if name == 'Curve Number (CN)':
            applied_pct = 100.0 * (abs(cn_hi - cn) + abs(cn - cn_lo)) / (2 * cn)
        else:
            applied_pct = perturbation_pct
        elasticity = ((abs(change_lo) + abs(change_hi)) / 2.0 / applied_pct
                       if applied_pct > 0 else float('nan'))
        rows.append({
            'Parameter': name,
            'Low Value': v_lo if isinstance(v_lo, str) else round(float(v_lo), 4),
            'Baseline': v_base if isinstance(v_base, str) else round(float(v_base), 4),
            'High Value': v_hi if isinstance(v_hi, str) else round(float(v_hi), 4),
            'Peak Q Low (m3/s)': round(q_lo, 2),
            'Peak Q Baseline (m3/s)': round(baseline, 2),
            'Peak Q High (m3/s)': round(q_hi, 2),
            'Change Low (%)': round(change_lo, 2),
            'Change High (%)': round(change_hi, 2),
            'Elasticity': round(elasticity, 3),
        })

    if not rows:
        feedback.pushWarning("  Sensitivity analysis produced no usable results.")
        return None

    rows.sort(key=lambda r: abs(r['Elasticity']), reverse=True)

    feedback.pushInfo(f"  Baseline peak discharge: {baseline:.2f} m³/s")
    feedback.pushInfo("  Ranked by influence (elasticity = %ΔQ per %Δinput):")
    for r in rows:
        feedback.pushInfo(
            f"    {r['Parameter']:<22} elasticity={r['Elasticity']:.3f}  "
            f"(Q ranges {r['Peak Q Low (m3/s)']:.1f} – "
            f"{r['Peak Q High (m3/s)']:.1f} m³/s)"
        )
    top = rows[0]
    if _degenerate_baseline:
        feedback.pushInfo(
            f"  Ranking above is indicative only ({top['Parameter']} ranks "
            f"highest), but the percentage figures are not meaningful against "
            f"a near-zero baseline — treat them as 'which input matters most', "
            f"not as real magnitudes."
        )
    else:
        feedback.pushInfo(
            f"  Most influential input: {top['Parameter']} — a "
            f"±{perturbation_pct:.0f}% error here moves peak discharge by roughly "
            f"{(abs(top['Change Low (%)']) + abs(top['Change High (%)']))/2:.1f}%. "
            f"Refine this input first if you need tighter design numbers."
        )

    sens_dir = os.path.join(output_dir, 'sensitivity')
    os.makedirs(sens_dir, exist_ok=True)
    csv_path = os.path.join(sens_dir, 'sensitivity_analysis.csv')
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    feedback.pushInfo(f"  Sensitivity table saved: {os.path.basename(csv_path)}")

    # Tornado diagram — the conventional way to present OAT sensitivity,
    # and immediately readable in a report.
    try:
        _ps.apply_style()
        fig, ax = plt.subplots(figsize=(10, max(3.5, 0.9 * len(rows) + 2)))
        names = [r['Parameter'] for r in rows][::-1]
        lows = [r['Change Low (%)'] for r in rows][::-1]
        highs = [r['Change High (%)'] for r in rows][::-1]
        ypos = np.arange(len(names))
        ax.barh(ypos, lows, color=_ps.PALETTE[0], alpha=0.85,
                label=f'-{perturbation_pct:.0f}% input')
        ax.barh(ypos, highs, color=_ps.PALETTE[2], alpha=0.85,
                label=f'+{perturbation_pct:.0f}% input')
        ax.axvline(0, color='#2C3E50', lw=1.2)
        ax.set_yticks(ypos)
        ax.set_yticklabels(names)
        _ps.style_axis(ax, f'Sensitivity of Peak Discharge (baseline {baseline:.1f} m³/s)',
                        'Change in peak discharge (%)', '')
        plt.tight_layout()
        plot_path = os.path.join(sens_dir, 'sensitivity_tornado.png')
        plt.savefig(plot_path, dpi=160, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        feedback.pushInfo(f"  Tornado diagram saved: {os.path.basename(plot_path)}")
    except Exception as e:
        feedback.pushWarning(f"  Tornado diagram failed: {e}")

    return rows


def _pour_point_in_layer_crs(lat, lon, layer, feedback=None):
    """
    Convert a lat/lon pour point into the sub-basin layer's CRS.

    Returns None if no pour point was given — the caller then falls back
    to unlagged summation rather than silently anchoring every result at
    a location the user never chose.
    """
    if lat is None or lon is None or layer is None:
        if feedback:
            feedback.pushWarning(
                "  No pour point given, so sub-basin travel times to the outlet "
                "cannot be computed. Sub-basin hydrographs will be summed WITHOUT "
                "lag, which assumes every sub-basin peaks simultaneously and "
                "therefore OVER-estimates the combined peak. Supply a pour point "
                "for a meaningful semi-distributed result."
            )
        return None
    try:
        from qgis.core import (QgsCoordinateReferenceSystem, QgsPointXY,
                                QgsCoordinateTransform, QgsProject)
        src_crs = QgsCoordinateReferenceSystem('EPSG:4326')
        dst_crs = layer.crs()
        if not dst_crs.isValid():
            return None
        xform = QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
        pt = xform.transform(QgsPointXY(float(lon), float(lat)))
        if feedback:
            feedback.pushInfo(
                f"  Pour point in sub-basin CRS ({dst_crs.authid()}): "
                f"({pt.x():.1f}, {pt.y():.1f})")
        return (pt.x(), pt.y())
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"  Could not transform pour point: {e}")
        return None


def _parse_cwc_coeffs(coeff_string, feedback):
    """
    Parse a 'Ct=0.53,m=0.31,Cq=1.79' style coefficient string into a dict
    for cwc_synthetic_unit_hydrograph().

    Returns None if nothing usable was given, which makes the CWC
    function fall back to its clearly-flagged placeholder coefficients
    and warn the user — deliberately NOT silently substituting numbers
    that would look authoritative but aren't their subzone's.
    """
    if not coeff_string or not coeff_string.strip():
        return None
    valid_keys = {'Ct', 'm', 'Cq', 'nq', 'Cw50', 'nw50', 'Cw75', 'nw75',
                  'Cwr50', 'nwr50', 'Cwr75', 'nwr75', 'Ctb', 'ntb'}
    out, unknown = {}, []
    for part in coeff_string.replace(';', ',').split(','):
        if '=' not in part:
            continue
        k, v = part.split('=', 1)
        k = k.strip()
        try:
            val = float(v.strip())
        except ValueError:
            continue
        if k in valid_keys:
            out[k] = val
        else:
            unknown.append(k)
    if feedback:
        if out:
            feedback.pushInfo(
                f"  CWC coefficients supplied: "
                f"{', '.join(f'{k}={v}' for k, v in sorted(out.items()))}"
            )
            missing = valid_keys - set(out.keys())
            if missing:
                feedback.pushWarning(
                    f"  Not supplied (placeholder values will be used for "
                    f"these): {', '.join(sorted(missing))}. Supply your "
                    f"subzone's full coefficient set for design work."
                )
        if unknown:
            feedback.pushWarning(
                f"  Unrecognised CWC coefficient name(s) ignored: "
                f"{', '.join(unknown)}. Valid names: {', '.join(sorted(valid_keys))}"
            )
    return out or None


def _run_calibration(observed_path, hydrograph_data, return_periods, output_dir, feedback):
    """
    Compare an observed hydrograph against the simulated ones and report
    standard model-performance metrics.

    The observed CSV needs a time column and a discharge column; common
    header spellings are auto-detected so the user doesn't have to match
    an exact format.

    Which simulated return period to compare against is genuinely
    ambiguous — an observed historical event doesn't come labelled with
    its return period. Rather than guess or force the user to pick, this
    compares against ALL of them and reports the full table, highlighting
    whichever scores best by NSE. That also directly answers a question
    practitioners actually have ("which design event does this observed
    flood most resemble?").
    """
    try:
        from .hydrological_calculations import hydrograph_comparison_metrics
    except ImportError:
        from hydrological_calculations import hydrograph_comparison_metrics

    try:
        obs_df = pd.read_csv(observed_path)
    except Exception as e:
        feedback.pushWarning(f"  Could not read observed hydrograph file: {e}")
        return None

    def _find_col(df, candidates):
        lowered = {c.lower().strip(): c for c in df.columns}
        for cand in candidates:
            if cand in lowered:
                return lowered[cand]
        return None

    t_col = _find_col(obs_df, ['time_hr', 'time', 'hours', 'hour', 't_hr', 't'])
    q_col = _find_col(obs_df, ['discharge_m3s', 'discharge', 'q', 'flow',
                                'flow_m3s', 'q_m3s', 'observed', 'obs'])
    if t_col is None or q_col is None:
        feedback.pushWarning(
            f"  Observed hydrograph needs a time column (e.g. 'Time_hr') and a "
            f"discharge column (e.g. 'Discharge_m3s'). Found columns: "
            f"{list(obs_df.columns)}"
        )
        return None

    obs_t = pd.to_numeric(obs_df[t_col], errors='coerce').to_numpy()
    obs_q = pd.to_numeric(obs_df[q_col], errors='coerce').to_numpy()
    valid = np.isfinite(obs_t) & np.isfinite(obs_q)
    obs_t, obs_q = obs_t[valid], obs_q[valid]
    if len(obs_t) < 3:
        feedback.pushWarning("  Observed hydrograph has fewer than 3 usable rows.")
        return None

    feedback.pushInfo(
        f"  Loaded observed hydrograph: {len(obs_t)} points, "
        f"peak={obs_q.max():.2f} m³/s at t={obs_t[int(np.argmax(obs_q))]:.1f} hr"
    )

    rows, best = [], None
    for rp in return_periods:
        if rp not in hydrograph_data:
            continue
        hyd = hydrograph_data[rp]
        feedback.pushInfo(f"  --- vs {rp}-yr simulated ---")
        m = hydrograph_comparison_metrics(
            obs_t, obs_q, np.asarray(hyd['time']), np.asarray(hyd['discharge']), feedback)
        if m is None:
            continue
        rows.append({
            'Return Period (yr)': rp,
            'NSE': round(m['NSE'], 4), 'NSE Rating': m['NSE_rating'],
            'PBIAS (%)': round(m['PBIAS_pct'], 2), 'PBIAS Rating': m['PBIAS_rating'],
            'RMSE (m3/s)': round(m['RMSE'], 3), 'RSR': round(m['RSR'], 4),
            'R2': round(m['R2'], 4),
            'Obs Peak (m3/s)': round(m['obs_peak_q'], 2),
            'Sim Peak (m3/s)': round(m['sim_peak_q'], 2),
            'Peak Magnitude Error (%)': round(m['peak_magnitude_error_pct'], 2),
            'Peak Timing Error (hr)': round(m['peak_timing_error_hr'], 2),
        })
        if best is None or (np.isfinite(m['NSE']) and m['NSE'] > best[1]['NSE']):
            best = (rp, m)

    if not rows:
        feedback.pushWarning("  No simulated hydrograph could be compared against the observed data.")
        return None

    calib_dir = os.path.join(output_dir, 'calibration')
    os.makedirs(calib_dir, exist_ok=True)
    csv_path = os.path.join(calib_dir, 'calibration_metrics.csv')
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    feedback.pushInfo(f"  Calibration metrics saved: {os.path.basename(csv_path)}")

    if best is not None:
        best_rp, best_m = best
        feedback.pushInfo(
            f"  Best match: {best_rp}-yr simulated event "
            f"(NSE={best_m['NSE']:.3f}, {best_m['NSE_rating']}) — i.e. the "
            f"observed event most resembles the {best_rp}-yr design event "
            f"as this model computes it."
        )
        try:
            _ps.apply_style()
            fig, ax = plt.subplots(figsize=(11, 6))
            ax.plot(best_m['obs_time_compared'], best_m['obs_q_compared'],
                    'o-', color='#1a1a1a', markersize=4, linewidth=2,
                    label='Observed', zorder=3)
            ax.plot(best_m['obs_time_compared'], best_m['sim_q_interpolated'],
                    '-', color=_ps.PALETTE[0], linewidth=2.2,
                    label=f'Simulated ({best_rp}-yr)', zorder=2)
            _ps.style_axis(ax, f'Observed vs Simulated Hydrograph — best match: {best_rp}-yr',
                            'Time (hr)', 'Discharge (m³/s)')
            stats_txt = (f"NSE = {best_m['NSE']:.3f} ({best_m['NSE_rating']})\n"
                         f"PBIAS = {best_m['PBIAS_pct']:+.1f}% ({best_m['PBIAS_rating']})\n"
                         f"RMSE = {best_m['RMSE']:.2f} m³/s\n"
                         f"R² = {best_m['R2']:.3f}\n"
                         f"Peak error = {best_m['peak_magnitude_error_pct']:+.1f}%\n"
                         f"Timing error = {best_m['peak_timing_error_hr']:+.1f} hr")
            ax.text(0.98, 0.97, stats_txt, transform=ax.transAxes, fontsize=9.5,
                    va='top', ha='right', family='monospace',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='white',
                              edgecolor='#D5D8DC', alpha=0.95))
            plot_path = os.path.join(calib_dir, 'observed_vs_simulated.png')
            plt.tight_layout()
            plt.savefig(plot_path, dpi=160, bbox_inches='tight', facecolor='white')
            plt.close(fig)
            feedback.pushInfo(f"  Calibration plot saved: {os.path.basename(plot_path)}")
        except Exception as e:
            feedback.pushWarning(f"  Calibration plot failed: {e}")

    return rows


def _plot_idf_curves(design_storms, return_periods, durations, output_dir, feedback):
    """Plot IDF curves."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    ax1, ax2 = axes
    colors = plt.cm.viridis(np.linspace(0.1, 0.9, len(return_periods)))

    for rp, col in zip(return_periods, colors):
        idx  = return_periods.index(rp)
        ints = [design_storms[d][idx] / d for d in durations if d in design_storms]
        durs = [d for d in durations if d in design_storms]
        if ints:
            ax1.plot(durs, ints, 'o-', color=col, lw=2, label=f'{rp}-yr')
            ax2.plot(durs, [design_storms[d][idx] for d in durs],
                     's--', color=col, lw=1.5, label=f'{rp}-yr')

    ax1.set_title('Intensity-Duration-Frequency (IDF)', fontweight='bold')
    ax1.set_xlabel('Duration (hr)')
    ax1.set_ylabel('Intensity (mm/hr)')
    ax1.legend(fontsize=8); ax1.grid(True, ls='--', alpha=0.5)
    ax1.set_xscale('log')

    ax2.set_title('Depth-Duration-Frequency (DDF)', fontweight='bold')
    ax2.set_xlabel('Duration (hr)')
    ax2.set_ylabel('Rainfall Depth (mm)')
    ax2.legend(fontsize=8); ax2.grid(True, ls='--', alpha=0.5)

    fig.tight_layout()
    out = os.path.join(output_dir, 'IDF_DDF_Curves.png')
    fig.savefig(out, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    if feedback:
        feedback.pushInfo(f"IDF/DDF plot saved: {out}")


def _export_hec_hms(output_dir, df_out, hyd_data, design_storms, return_periods, durations,
                     storm_dur_hr, area, cn, mann_n, slope_pct, L_m, method_idx, method_names, feedback):
    hec_dir = os.path.join(output_dir, 'hec_hms')
    os.makedirs(hec_dir, exist_ok=True)

    for rp, data in hyd_data.items():
        path = os.path.join(hec_dir, f'hydrograph_{rp}yr.dss.csv')
        pd.DataFrame({'Time_hr': data['time'], 'Discharge_m3s': data['discharge']}).to_csv(path, index=False)

    for dur in durations:
        if dur in design_storms:
            path = os.path.join(hec_dir, f'design_storm_{dur}hr.csv')
            pd.DataFrame({'Return_Period_yr': return_periods,
                          'Rainfall_mm': design_storms[dur]}).to_csv(path, index=False)

    params = {
        'Area_km2': area, 'Curve_Number': cn, "Manning_n": mann_n,
        'Slope_pct': slope_pct, 'Flow_Path_m': L_m,
        'Storm_Duration_hr': storm_dur_hr,
        'Analysis_Method': method_names[method_idx],
    }
    with open(os.path.join(hec_dir, 'catchment_parameters.txt'), 'w') as f:
        f.write("=== HEC-HMS Catchment Parameters – Rain2Flood v3.0 ===\n\n")
        for k, v in params.items():
            f.write(f"{k:<30} {v}\n")
    feedback.pushInfo(f"HEC-HMS files saved to {hec_dir}")


def _save_excel(path, df_out, idf_df, sdm, return_periods, durations, design_storms,
                qc_report, cn, mann_n, amc, storm_dur_hr, method_name,
                design_storms_ci_lower=None, design_storms_ci_upper=None,
                design_storms_dist_name=None):
    design_storms_ci_lower = design_storms_ci_lower or {}
    design_storms_ci_upper = design_storms_ci_upper or {}
    design_storms_dist_name = design_storms_dist_name or {}
    with pd.ExcelWriter(path, engine='openpyxl') as writer:
        df_out.to_excel(writer, sheet_name='Results', index=False)
        idf_df.to_excel(writer, sheet_name='IDF Table', index=False)

        # Annual maxima sheet
        rows = []
        for dur in durations:
            if dur in sdm:
                for yr_idx, val in enumerate(sdm[dur]):
                    rows.append({'Duration (hr)': dur, 'Year': yr_idx + 1, 'Max Rainfall (mm)': val})
        if rows:
            pd.DataFrame(rows).to_excel(writer, sheet_name='Annual Maxima', index=False)

        # Design storms sheet
        ds_rows = []
        for dur in durations:
            if dur in design_storms:
                for rp, val in zip(return_periods, design_storms[dur]):
                    ds_rows.append({'Duration (hr)': dur, 'Return Period (yr)': rp,
                                    'Rainfall (mm)': val, 'Intensity (mm/hr)': val / dur})
        if ds_rows:
            pd.DataFrame(ds_rows).to_excel(writer, sheet_name='Design Storms', index=False)

        # Frequency analysis uncertainty sheet — 90% bootstrap confidence
        # intervals and the distribution actually selected/used per
        # duration, so a short record's design values come with an
        # honest sense of how much to trust them instead of a bare
        # point estimate.
        ci_rows = []
        for dur in durations:
            if dur in design_storms and dur in design_storms_ci_lower:
                dist_name = design_storms_dist_name.get(dur, 'N/A')
                for rp, val, lo, hi in zip(return_periods, design_storms[dur],
                                            design_storms_ci_lower[dur],
                                            design_storms_ci_upper[dur]):
                    ci_rows.append({
                        'Duration (hr)': dur, 'Return Period (yr)': rp,
                        'Distribution Used': dist_name,
                        'Design Rainfall (mm)': round(float(val), 2),
                        '90% CI Lower (mm)': round(float(lo), 2),
                        '90% CI Upper (mm)': round(float(hi), 2),
                    })
        if ci_rows:
            pd.DataFrame(ci_rows).to_excel(writer, sheet_name='Frequency Uncertainty', index=False)

        # Parameters sheet
        params_df = pd.DataFrame([
            ('Method', method_name), ('CN (AMC II→adjusted)', cn),
            ("Manning's n", mann_n), ('AMC', amc), ('Storm Duration (hr)', storm_dur_hr),
            ('QC Negatives Removed', qc_report.get('negatives_removed', 0)),
            ('QC NaN Filled', qc_report.get('nan_filled', 0)),
            ('Record Length (yr)', qc_report.get('record_length_years', 'N/A')),
        ], columns=['Parameter', 'Value'])
        params_df.to_excel(writer, sheet_name='Parameters', index=False)
