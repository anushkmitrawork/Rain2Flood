# Rain2Flood

**Rainfall-to-flood analysis for QGIS.**

Give it a DEM and a pour point. It delineates the upstream catchment, traces
the longest flow path, measures the main-stem slope, fetches rainfall, fits
design storms, routes a hydrograph, and maps flood depth, velocity and hazard
class.

Cooked by **[Rahul Pandey](https://in.linkedin.com/in/rahul-pandey-nitb)** ·
[github.com/rahulpandey696/Rain2Flood](https://github.com/rahulpandey696/Rain2Flood)

---

## Workflow

| Tab | Does |
|---|---|
| **1. DEM & Slope** | Reproject to a projected CRS, derive slope (Horn's method, nodata-aware, computed *before* any clip) |
| **2. Streams & Sub-basins** | GRASS `r.watershed` delineation, Strahler order, sub-basins |
| **3. CN / LULC** | ESA WorldCover download, NLCD/CORINE/MODIS tables, CN and Manning's rasters, AMC adjustment |
| **4. Flash Flood** | Sub-daily. SCS Triangular UH, NRCS DUH, Snyder, Clark IUH, Rational, Wadi. IDF, ABM, HEC-HMS export |
| **5. Standard Flood** | Daily. UK FEH, ARR2019, Canada MTO, NZ NIWA, Wadi. SCS Type-II / ABM / Chicago |
| *Rainfall Data* | Standalone utility — **not** a pipeline step. The flood tabs fetch their own rainfall |

**No catchment polygon is required anywhere.** Tabs 1 and 2 take one
optionally; Tabs 4 and 5 delineate it from your pour point.

## Pour-point workflow

Set a pour point in Tab 4 or 5 and choose **Pour Point + DEM
(auto-delineate)**. You then need only the DEM. You get:

| Layer | Symbology | Attributes |
|---|---|---|
| `upstream_catchment.gpkg` | hollow boundary | `Area_km2`, `FlowPath_m`, `S1085` |
| `longest_flow_path.gpkg` | solid, cased | `Length_m`, `Vertices`, `Complete` |
| `pour_point_snapped.gpkg` | hollow star | `Moved_cells`, `Moved_m` |

The pour point is **snapped to the modelled stream network** first. A point a
cell or two off the channel delineates a hillslope facet, not a basin — on a
test DEM the same point gave 0.08 km² unsnapped and 36.0 km² snapped. Check
the reported snap distance: a large jump means it landed on a different river.

## Keywords

Flood modelling · flood mapping · flood risk · inundation mapping · rainfall-runoff ·
catchment delineation · watershed delineation · pour point · stream network ·
sub-basin routing · HAND (Height Above Nearest Drainage) · unit hydrograph ·
SCS Curve Number · TR-55 · NRCS · FEH · ARR2019 · wadi hydrology · IDF/DDF curves ·
flood frequency analysis · Gumbel · GEV · Log-Pearson III · design storm ·
time of concentration · Manning's n · land cover · ESA WorldCover · Esri 10m Land Cover ·
NLCD · CORINE · MODIS · ERA5 · Open-Meteo · IMD · CHIRPS · NASA POWER ·
HEC-HMS · HEC-RAS · DEM processing · flow accumulation · QGIS plugin · Python · hydrology

`#QGIS` `#Hydrology` `#FloodModelling` `#FloodMapping` `#FloodRisk` `#GIS`
`#RainfallRunoff` `#Catchment` `#Watershed` `#HEC_HMS` `#HEC_RAS` `#HAND`
`#CurveNumber` `#UnitHydrograph` `#IDF` `#FloodFrequency` `#ESAWorldCover`
`#ERA5` `#OpenMeteo` `#WaterResources` `#Stormwater` `#FlashFlood`
`#OpenSource` `#Python` `#GeoSpatial` `#RemoteSensing` `#DEM` `#Terrain`

## Land cover schemes

Class colours come from each product's own published specification, applied
as **exact** colours per class — never interpolated. Pick the right dataset
in Tab 3: the two 10 m schemes **overlap but disagree**.

| Value | Esri 10m Annual LULC | ESA WorldCover |
|---|---|---|
| 1 | Water | — |
| 2 | Trees | — |
| 10 | **Clouds** | **Tree cover** |
| 20–100 | — | Shrubland … Moss and lichen |

Choosing ESA for an Esri raster paints forest dark grey and assigns it
cloud handling — a map that looks entirely plausible and is wrong
throughout. The dataset you select drives both the colours and the
CN / Manning's lookup.

Esri class 10 (Clouds) has **no** CN value on purpose. It is not land
cover, it is the sensor failing to see the ground, so it falls through to
nodata rather than being given runoff behaviour.

## Requirements

QGIS 3.28+ (QGIS 4.x supported). Python packages: `geopandas`, `rasterio`,
`shapely`, `scipy`, `pandas`, `numpy`, `matplotlib`, `openpyxl`. The plugin
offers to install missing ones on first run.

GRASS Processing provider is needed for Tab 2 only.

---

## Changelog

### 3.0 — major correctness and workflow release

**Pour-point workflow.** Set one pour point and the upstream catchment,
longest flow path and channel slope are all delineated from the DEM.
Delineation uses pointer jumping over the D8 flow graph — 1.44M cells in
4.8 s. No catchment polygon is required anywhere in the plugin.

**Flood extent corrected.** Depression filling was seeded from the array edge
after nodata had been replaced with the catchment mean elevation. On a
clipped catchment that constant ring acts as a dam: the entire lower basin
was raised to a flat surface, HAND against it was ~0, and roughly 66% of the
catchment flooded *regardless of discharge* — a 1.9× increase in Q moved the
extent from 65.8% to 65.9%. Extents are now channel-scale and respond to
discharge.

**Volume budget.** Mapped flood water can no longer exceed the runoff the
storm produced. Depth comes from Manning's normal depth at regime width
`W = 3√Q`; at small Q that width collapses while the valley it is spread
across does not, so a trickle was being rendered as a metres-deep flood. The
consistency check existed and warned every time, and nothing acted on it.

**Channel slope.** Measured longitudinally as S1085 along the traced main
stem, not from the DEM gradient magnitude — which has no sign, is dominated
by the cross-section, and was returning ~30× the true slope. Velocity goes as
√S, so that alone was inflating velocity about five-fold and driving the
hazard classification.

**HAND.** Computed by walking each cell's own D8 flow path down to the
channel it drains into, rather than taking the geometrically nearest stream
cell, which reached across divides and put 16% of cells at zero.

**Sub-basin routing.** Sub-basins are clipped to the analysis catchment, so
basins draining elsewhere are no longer summed into the hydrograph.

**Method-range warnings.** The SCS lag equation reports when it is being
extrapolated past its ~8 km² validity range, and when time to peak exceeds
the design storm duration (the storm ends before the UH peaks, heavily
attenuating the result).

**Rainfall location check.** Warns when the rainfall point falls outside the
delineated catchment.

**CN / LULC extent.** The CN tab takes an area of interest — layer extent,
canvas extent, or a rectangle drawn on the map — instead of demanding a
catchment polygon.

**Tabs 1 and 2.** Catchment boundary now optional. Slope is computed before
any clip, so boundary cells keep real neighbours in Horn's method instead of
taking their slope from missing data.

**Interface.** Rebuilt with a contrast-checked light theme (every
text/background pair verified against WCAG AA), new raster colour ramps for
DEM, slope, CN, LULC and Manning's n, and QGIS 4 / PyQt6 compatibility.

### 2.2

Support for QGIS 4.0 and beyond.

### 2.0–2.1

Flash Flood analysis with hourly rainfall. Open-Meteo integration for global
hourly/daily data. Excel rainfall input. DEM and slope processing with
automated catchment extraction. Manning's-equation flood depth. HEC-HMS
export. CHIRPS extraction fix for global users. Dependency management.
Map-based point selection. SCS Unit Hydrograph, Rational and Time-Area
methods.

---

## Licence

GNU GPL v3 or later.
