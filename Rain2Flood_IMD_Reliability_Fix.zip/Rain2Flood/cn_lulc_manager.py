"""
CN / LULC / Manning's-n Raster Manager
=======================================
Lookup tables and raster-extraction utilities following:
  - NRCS TR-55 (USA) for Curve Numbers
  - HEC-RAS raster conventions (pixel value = CN or Manning's n)
  - ESA WorldCover (2021) v200 land-cover classes
  - NLCD 2019 (USA)
  - CORINE Land Cover (Europe)
  - MODIS MCD12Q1 (global)
  - Manning's n from Chow (1959) and FHWA HEC-15
"""

import numpy as np

# ---------------------------------------------------------------------------
# 1.  TR-55 / NRCS Standard CN Table  (AMC II, cover + HSG A/B/C/D)
# ---------------------------------------------------------------------------
# Each entry: 'key': (description, CN_A, CN_B, CN_C, CN_D)
CN_TABLE_TR55 = {
    # Agricultural
    'Fallow_Bare':            ('Fallow – Bare Soil',                    77, 86, 91, 94),
    'Fallow_Residue':         ('Fallow – Crop Residue',                 76, 85, 90, 93),
    'RowCrop_Straight':       ('Row Crops – Straight Rows',              72, 81, 88, 91),
    'RowCrop_Contoured':      ('Row Crops – Contoured',                  67, 78, 85, 89),
    'RowCrop_Terraced':       ('Row Crops – Contoured + Terraced',       66, 74, 80, 82),
    'SmallGrain_Straight':    ('Small Grain – Straight Rows',            65, 76, 84, 88),
    'SmallGrain_Contoured':   ('Small Grain – Contoured',                63, 75, 83, 87),
    'CloseSeeded_Straight':   ('Close-Seeded Legumes – Straight',        66, 77, 85, 89),
    # Pasture / Range
    'Pasture_Poor':           ('Pasture / Range – Poor',                 68, 79, 86, 89),
    'Pasture_Fair':           ('Pasture / Range – Fair',                 49, 69, 79, 84),
    'Pasture_Good':           ('Pasture / Range – Good',                 39, 61, 74, 80),
    'Meadow_Good':            ('Meadow – Good',                          30, 58, 71, 78),
    # Brush / Woods
    'Brush_Poor':             ('Brush – Poor',                           48, 67, 77, 83),
    'Brush_Fair':             ('Brush – Fair',                           35, 56, 70, 77),
    'Brush_Good':             ('Brush – Good',                           30, 48, 65, 73),
    'Woods_Poor':             ('Woods – Poor',                           45, 66, 77, 83),
    'Woods_Fair':             ('Woods – Fair',                           36, 60, 73, 79),
    'Woods_Good':             ('Woods – Good',                           25, 55, 70, 77),
    'Farmsteads':             ('Farmsteads – Buildings, Lanes',          59, 74, 82, 86),
    # Roads
    'Road_Dirt':              ('Dirt Roads',                             72, 82, 87, 89),
    'Road_Gravel':            ('Gravel Roads',                           76, 85, 89, 91),
    'Road_Paved':             ('Paved Roads / Curbs & Storm Sewers',     98, 98, 98, 98),
    # Urban / Impervious
    'Impervious':             ('Impervious Surfaces',                    98, 98, 98, 98),
    'OpenSpace_Poor':         ('Open Space – Poor (>75% bare)',          68, 79, 86, 89),
    'OpenSpace_Fair':         ('Open Space – Fair (50–75% grass)',       49, 69, 79, 84),
    'OpenSpace_Good':         ('Open Space – Good (>75% grass)',         39, 61, 74, 80),
    'Commercial_85imp':       ('Commercial – 85% Impervious',           89, 92, 94, 95),
    'Industrial_72imp':       ('Industrial – 72% Impervious',           81, 88, 91, 93),
    'Residential_1_8ac':      ('Residential – 1/8 ac (65% imp)',        77, 85, 90, 92),
    'Residential_1_4ac':      ('Residential – 1/4 ac (38% imp)',        61, 75, 83, 87),
    'Residential_1_2ac':      ('Residential – 1/2 ac (25% imp)',        54, 70, 80, 85),
    'Residential_1ac':        ('Residential – 1 ac (20% imp)',          51, 68, 79, 84),
    'Residential_2ac':        ('Residential – 2 ac (12% imp)',          46, 65, 77, 82),
    # Water / Wetlands
    'Water':                  ('Open Water / Reservoirs',               100,100,100,100),
    'Wetlands_Wooded':        ('Woody Wetlands',                         78, 78, 78, 78),
    'Wetlands_Herbaceous':    ('Herbaceous Wetlands',                    86, 86, 86, 86),
    'SnowIce':                ('Snow and Ice',                          100,100,100,100),
}

# Flat list for GUI drop-down  → "CN_B value  (description)"
def cn_dropdown_items(hsg='B'):
    idx = {'A': 1, 'B': 2, 'C': 3, 'D': 4}[hsg.upper()]
    items = []
    for key, val in CN_TABLE_TR55.items():
        items.append(f"{val[idx]:3d}  ({val[0]})")
    return items

# ---------------------------------------------------------------------------
# 2.  ESA WorldCover 2021 v200  →  CN (AMC II) + Manning's n
# ---------------------------------------------------------------------------
# pixel_value: (description, CN_A, CN_B, CN_C, CN_D, manning_n_channel, manning_n_overland)
ESA_WORLDCOVER_TO_PARAMS = {
    10:  ('Tree cover',               36, 60, 73, 79, 0.100, 0.400),
    20:  ('Shrubland',                35, 56, 70, 77, 0.050, 0.200),
    30:  ('Grassland',                49, 69, 79, 84, 0.035, 0.150),
    40:  ('Cropland',                 67, 78, 85, 89, 0.040, 0.150),
    50:  ('Built-up',                 77, 85, 90, 92, 0.015, 0.030),
    60:  ('Bare / sparse vegetation', 77, 86, 91, 94, 0.022, 0.050),
    70:  ('Snow and ice',            100,100,100,100, 0.010, 0.010),
    80:  ('Permanent water bodies',  100,100,100,100, 0.030, 0.030),
    90:  ('Herbaceous wetland',       78, 78, 78, 78, 0.045, 0.200),
    95:  ('Mangroves',                36, 60, 73, 79, 0.100, 0.400),
    100: ('Moss and lichen',          30, 58, 71, 78, 0.040, 0.180),
}

# ---------------------------------------------------------------------------
# 2b.  Esri 10m Annual Land Cover (Sentinel-2)  ->  CN (AMC II) + Manning's n
#
# CN and Manning's values are carried over from the ESA WorldCover class
# each Esri class corresponds to, rather than invented: Trees from Tree
# cover, Crops from Cropland, Built Area from Built-up, Rangeland from
# Grassland, Water from Permanent water bodies. The two products classify
# the same physical ground, so the hydrological parameters transfer; only
# the class codes and names differ.
#
# Class 10 (Clouds) is deliberately ABSENT. It is not land cover — it is
# the sensor failing to see the ground. Giving it a CN would silently
# assign runoff behaviour to unknown terrain, so it falls through to the
# caller's nodata handling instead, which is the honest treatment.
ESRI_LULC_TO_PARAMS = {
    1:  ('Water',              100, 100, 100, 100, 0.030, 0.030),
    2:  ('Trees',               36,  60,  73,  79, 0.100, 0.400),
    4:  ('Flooded Vegetation',  78,  78,  78,  78, 0.045, 0.200),
    5:  ('Crops',               67,  78,  85,  89, 0.040, 0.150),
    7:  ('Built Area',          77,  85,  90,  92, 0.015, 0.030),
    8:  ('Bare Ground',         77,  86,  91,  94, 0.022, 0.050),
    9:  ('Snow/Ice',           100, 100, 100, 100, 0.010, 0.010),
    11: ('Rangeland',           49,  69,  79,  84, 0.035, 0.150),
}


# ---------------------------------------------------------------------------
# 3.  NLCD 2019 (USA)  →  CN (AMC II) + Manning's n
# ---------------------------------------------------------------------------
NLCD_TO_PARAMS = {
    11:  ('Open Water',                  100,100,100,100, 0.030, 0.030),
    12:  ('Perennial Ice/Snow',          100,100,100,100, 0.010, 0.010),
    21:  ('Developed, Open Space',        68, 79, 86, 89, 0.025, 0.100),
    22:  ('Developed, Low Intensity',     77, 85, 90, 92, 0.018, 0.050),
    23:  ('Developed, Medium Intensity',  85, 89, 92, 94, 0.015, 0.030),
    24:  ('Developed, High Intensity',    89, 92, 94, 95, 0.012, 0.020),
    31:  ('Barren Land',                  77, 86, 91, 94, 0.022, 0.050),
    41:  ('Deciduous Forest',             36, 60, 73, 79, 0.120, 0.400),
    42:  ('Evergreen Forest',             36, 60, 73, 79, 0.120, 0.400),
    43:  ('Mixed Forest',                 36, 60, 73, 79, 0.120, 0.400),
    51:  ('Dwarf Scrub',                  35, 56, 70, 77, 0.050, 0.200),
    52:  ('Shrub/Scrub',                  35, 56, 70, 77, 0.050, 0.200),
    71:  ('Grassland/Herbaceous',         49, 69, 79, 84, 0.035, 0.150),
    72:  ('Sedge/Herbaceous',             49, 69, 79, 84, 0.035, 0.150),
    81:  ('Pasture/Hay',                  49, 69, 79, 84, 0.035, 0.150),
    82:  ('Cultivated Crops',             72, 81, 88, 91, 0.040, 0.150),
    90:  ('Woody Wetlands',               78, 78, 78, 78, 0.080, 0.300),
    95:  ('Emergent Herbaceous Wetlands', 86, 86, 86, 86, 0.045, 0.200),
}

# ---------------------------------------------------------------------------
# 4.  CORINE Land Cover (Europe, CLC2018)  →  CN + Manning's n
# ---------------------------------------------------------------------------
CORINE_TO_PARAMS = {
    111: ('Continuous urban fabric',         89, 92, 94, 95, 0.012, 0.020),
    112: ('Discontinuous urban fabric',      81, 88, 91, 93, 0.015, 0.030),
    121: ('Industrial/commercial units',     81, 88, 91, 93, 0.012, 0.020),
    122: ('Road and rail networks',          98, 98, 98, 98, 0.014, 0.020),
    124: ('Airports',                        89, 92, 94, 95, 0.015, 0.025),
    131: ('Mineral extraction sites',        77, 86, 91, 94, 0.022, 0.050),
    133: ('Construction sites',              77, 86, 91, 94, 0.022, 0.050),
    141: ('Green urban areas',               49, 69, 79, 84, 0.025, 0.100),
    142: ('Sport and leisure facilities',    49, 69, 79, 84, 0.025, 0.100),
    211: ('Non-irrigated arable land',       72, 81, 88, 91, 0.040, 0.150),
    212: ('Permanently irrigated land',      72, 81, 88, 91, 0.040, 0.150),
    213: ('Rice fields',                     78, 78, 78, 78, 0.040, 0.150),
    221: ('Vineyards',                       64, 75, 82, 87, 0.040, 0.150),
    222: ('Fruit trees and berry plants',    64, 75, 82, 87, 0.040, 0.150),
    223: ('Olive groves',                    64, 75, 82, 87, 0.040, 0.150),
    231: ('Pastures',                        49, 69, 79, 84, 0.035, 0.150),
    241: ('Annual crops + permanent crops',  67, 78, 85, 89, 0.040, 0.150),
    242: ('Complex cultivation patterns',    67, 78, 85, 89, 0.040, 0.150),
    243: ('Land + agriculture',              67, 78, 85, 89, 0.040, 0.150),
    244: ('Agro-forestry areas',             55, 70, 77, 83, 0.060, 0.250),
    311: ('Broad-leaved forest',             25, 55, 70, 77, 0.120, 0.400),
    312: ('Coniferous forest',               25, 55, 70, 77, 0.120, 0.400),
    313: ('Mixed forest',                    30, 58, 71, 78, 0.120, 0.400),
    321: ('Natural grasslands',              39, 61, 74, 80, 0.035, 0.150),
    322: ('Moors and heathland',             35, 56, 70, 77, 0.050, 0.200),
    323: ('Sclerophyllous vegetation',       45, 65, 75, 81, 0.050, 0.200),
    324: ('Transitional woodland-shrub',     35, 56, 70, 77, 0.070, 0.250),
    331: ('Beaches, dunes, sands',           77, 86, 91, 94, 0.020, 0.050),
    332: ('Bare rocks',                      98, 98, 98, 98, 0.015, 0.020),
    333: ('Sparsely vegetated areas',        63, 77, 85, 88, 0.030, 0.080),
    334: ('Burnt areas',                     77, 86, 91, 94, 0.025, 0.060),
    335: ('Glaciers and perpetual snow',    100,100,100,100, 0.010, 0.010),
    411: ('Inland marshes',                  78, 78, 78, 78, 0.050, 0.200),
    412: ('Peat bogs',                       78, 78, 78, 78, 0.050, 0.200),
    421: ('Salt marshes',                    78, 78, 78, 78, 0.050, 0.200),
    422: ('Salines',                         78, 78, 78, 78, 0.040, 0.180),
    423: ('Intertidal flats',               100,100,100,100, 0.035, 0.100),
    511: ('Water courses',                  100,100,100,100, 0.030, 0.030),
    512: ('Water bodies',                   100,100,100,100, 0.030, 0.030),
    521: ('Coastal lagoons',               100,100,100,100, 0.030, 0.030),
    522: ('Estuaries',                     100,100,100,100, 0.030, 0.030),
    523: ('Sea and ocean',                 100,100,100,100, 0.030, 0.030),
}

# ---------------------------------------------------------------------------
# 5.  MODIS MCD12Q1 (Land Cover Type 1 – IGBP)  →  CN + Manning's n
# ---------------------------------------------------------------------------
MODIS_IGBP_TO_PARAMS = {
    1:  ('Evergreen Needleleaf Forest',   25, 55, 70, 77, 0.120, 0.400),
    2:  ('Evergreen Broadleaf Forest',    25, 55, 70, 77, 0.120, 0.400),
    3:  ('Deciduous Needleleaf Forest',   36, 60, 73, 79, 0.120, 0.400),
    4:  ('Deciduous Broadleaf Forest',    36, 60, 73, 79, 0.120, 0.400),
    5:  ('Mixed Forests',                 30, 58, 71, 78, 0.120, 0.400),
    6:  ('Closed Shrublands',             35, 56, 70, 77, 0.050, 0.200),
    7:  ('Open Shrublands',               35, 56, 70, 77, 0.050, 0.180),
    8:  ('Woody Savannas',                39, 61, 74, 80, 0.070, 0.250),
    9:  ('Savannas',                      49, 69, 79, 84, 0.040, 0.180),
    10: ('Grasslands',                    39, 61, 74, 80, 0.035, 0.150),
    11: ('Permanent Wetlands',            78, 78, 78, 78, 0.060, 0.250),
    12: ('Croplands',                     67, 78, 85, 89, 0.040, 0.150),
    13: ('Urban and Built-up',            89, 92, 94, 95, 0.015, 0.030),
    14: ('Cropland/Natural Mosaic',       67, 78, 85, 89, 0.040, 0.150),
    15: ('Snow and Ice',                 100,100,100,100, 0.010, 0.010),
    16: ('Barren',                        77, 86, 91, 94, 0.022, 0.050),
    17: ('Water Bodies',                 100,100,100,100, 0.030, 0.030),
}

# ---------------------------------------------------------------------------
# 6.  Manning's n Comprehensive Table  (Chow 1959, HEC-15, FHWA)
# ---------------------------------------------------------------------------
MANNING_N_CHANNELS = {
    # Artificial channels
    'Smooth concrete (troweled)':         0.011,
    'Concrete (formed, no finish)':       0.013,
    'Concrete (rough, wood forms)':       0.017,
    'Grouted riprap':                     0.028,
    'Dry rubble riprap':                  0.035,
    'Earth (clean, straight)':            0.022,
    'Earth (some weeds, minor stones)':   0.027,
    'Earth (dense weeds, deep pools)':    0.035,
    'Gravel (straight, uniform)':         0.025,
    'Rock cut (smooth/uniform)':          0.033,
    'Rock cut (jagged/irregular)':        0.045,
    'Brick (unlined)':                    0.017,
    'Masonry':                            0.025,
    # Natural channels
    'Natural stream (clean, straight)':   0.025,
    'Natural stream (minor bends/weeds)': 0.033,
    'Natural stream (winding, pools)':    0.040,
    'Natural stream (sluggish, weedy)':   0.050,
    'Natural stream (dense weeds)':       0.070,
    'Natural stream (heavy brush/trees)': 0.100,
    'Mountain stream (gravel/cobbles)':   0.040,
    'Mountain stream (cobbles/boulders)': 0.070,
    # Floodplains
    'Floodplain – pasture (short grass)': 0.025,
    'Floodplain – pasture (high grass)':  0.030,
    'Floodplain – cultivated (no crop)':  0.030,
    'Floodplain – cultivated (mature)':   0.040,
    'Floodplain – brush (scattered)':     0.050,
    'Floodplain – brush (heavy)':         0.070,
    'Floodplain – trees (cleared)':       0.080,
    'Floodplain – trees (dense)':         0.120,
    'Floodplain – forested (flooded)':    0.160,
}

MANNING_N_OVERLAND = {
    'Smooth asphalt':                     0.011,
    'Smooth concrete':                    0.012,
    'Bare packed soil':                   0.020,
    'Bare sand':                          0.025,
    'Disturbed soil (gravel)':            0.030,
    'Sparse grass':                       0.030,
    'Short grass (lawn)':                 0.050,
    'Dense grass':                        0.100,
    'Bermuda grass':                      0.150,
    'Range (natural)':                    0.130,
    'Dense range / weeds':                0.200,
    'Light underbrush':                   0.200,
    'Dense underbrush':                   0.300,
    'Forest litter':                      0.400,
    'Dense forest':                       0.800,
}

# ---------------------------------------------------------------------------
# 7.  AMC Adjustment (Antecedent Moisture Condition)
# ---------------------------------------------------------------------------
def adjust_cn_for_amc(cn2, amc=2):
    """
    Convert AMC-II CN to AMC-I (dry) or AMC-III (wet).
    Equations from SCS NEH-4 (1985).
    """
    if amc == 1:  # Dry
        return (4.2 * cn2) / (10 - 0.058 * cn2)
    elif amc == 3:  # Wet
        return (23 * cn2) / (10 + 0.13 * cn2)
    return cn2  # AMC II

# ---------------------------------------------------------------------------
# 8.  Weighted CN extraction from a raster (with HSG raster optional)
# ---------------------------------------------------------------------------
def extract_weighted_cn_from_rasters(
        lulc_array, lulc_type, hsg_array=None, default_hsg='B', amc=2, nodata=None, feedback=None
):
    """
    Compute spatially weighted mean CN from a LULC raster.

    Parameters
    ----------
    lulc_array  : 2D numpy array  – land-cover pixel values
    lulc_type   : str             – 'ESA', 'NLCD', 'CORINE', 'MODIS'
    hsg_array   : 2D numpy array  – Hydrologic Soil Group codes (1=A,2=B,3=C,4=D) or None
    default_hsg : str             – default HSG if hsg_array is None
    amc         : int             – 1, 2, or 3  (Antecedent Moisture Condition)
    nodata      : numeric         – nodata value to exclude
    feedback    : QgsProcessingFeedback or None

    Returns
    -------
    weighted_cn       : float
    weighted_manning  : float  (overland)
    cn_array          : 2D float array
    manning_array     : 2D float array
    """
    lut = {
        'ESA':    ESA_WORLDCOVER_TO_PARAMS,
        'ESRI':   ESRI_LULC_TO_PARAMS,
        'NLCD':   NLCD_TO_PARAMS,
        'CORINE': CORINE_TO_PARAMS,
        'MODIS':  MODIS_IGBP_TO_PARAMS,
    }.get(lulc_type.upper(), ESA_WORLDCOVER_TO_PARAMS)

    hsg_col = {'A': 1, 'B': 2, 'C': 3, 'D': 4}[default_hsg.upper()]

    cn_array      = np.full(lulc_array.shape, np.nan, dtype=np.float32)
    manning_array = np.full(lulc_array.shape, np.nan, dtype=np.float32)

    unique_vals = np.unique(lulc_array)
    for pv in unique_vals:
        if nodata is not None and pv == nodata:
            continue
        if pv not in lut:
            continue

        entry = lut[pv]       # (desc, CN_A, CN_B, CN_C, CN_D, mann_ch, mann_ov)
        mask = (lulc_array == pv)

        if hsg_array is not None:
            # Vectorised per-pixel HSG lookup
            hsg_pix = hsg_array[mask].astype(int)
            cn_vals = np.where(hsg_pix == 1, entry[1],
                      np.where(hsg_pix == 2, entry[2],
                      np.where(hsg_pix == 3, entry[3],
                               entry[4])))
        else:
            cn_vals = np.full(np.sum(mask), float(entry[hsg_col]), dtype=np.float32)

        cn_array[mask]      = cn_vals
        manning_array[mask] = entry[6]  # overland Manning's n

    # Apply AMC adjustment
    valid = ~np.isnan(cn_array)
    cn_array[valid] = np.vectorize(adjust_cn_for_amc)(cn_array[valid], amc)

    # Weighted means
    valid_cn = cn_array[valid]
    valid_mn = manning_array[valid]
    weighted_cn      = float(np.mean(valid_cn))      if len(valid_cn) > 0 else 75.0
    weighted_manning = float(np.mean(valid_mn))      if len(valid_mn) > 0 else 0.05

    if feedback:
        feedback.pushInfo(
            f"LULC→CN: {len(valid_cn)} valid pixels, weighted CN={weighted_cn:.1f} "
            f"(AMC {amc}), weighted Manning n={weighted_manning:.4f}"
        )
    return weighted_cn, weighted_manning, cn_array, manning_array


def extract_weighted_cn_single_raster(cn_array, nodata=None, amc=2, feedback=None):
    """
    Compute weighted mean CN from a CN raster (pixel values ARE CN values, HEC-RAS style).

    Parameters
    ----------
    cn_array : 2D numpy array  – pixel values in [1, 100] representing CN directly
    nodata   : numeric or None
    amc      : 1 | 2 | 3
    """
    arr = cn_array.astype(np.float32)
    if nodata is not None:
        arr[arr == nodata] = np.nan
    arr[(arr < 1) | (arr > 100)] = np.nan

    valid = arr[~np.isnan(arr)]
    if len(valid) == 0:
        if feedback:
            feedback.pushWarning("No valid CN values found in raster. Using default CN=75.")
        return 75.0, cn_array

    # Apply AMC conversion (input assumed AMC-II)
    adjusted = np.vectorize(adjust_cn_for_amc)(valid, amc)
    weighted_cn = float(np.mean(adjusted))

    adjusted_full = arr.copy()
    mask = ~np.isnan(adjusted_full)
    adjusted_full[mask] = np.vectorize(adjust_cn_for_amc)(adjusted_full[mask], amc)

    if feedback:
        feedback.pushInfo(
            f"CN raster: {len(valid)} valid pixels, mean CN={weighted_cn:.1f} "
            f"(AMC {amc}). Original AMC-II mean={np.mean(valid):.1f}"
        )
    return weighted_cn, adjusted_full


def build_cn_raster_from_lulc(lulc_array, lulc_type, hsg='B', amc=2, nodata=None, feedback=None):
    """
    Generate a CN raster array from a LULC raster.
    Returns a float32 array where pixel values are CN values (HEC-RAS compatible).
    """
    _, _, cn_array, _ = extract_weighted_cn_from_rasters(
        lulc_array, lulc_type, hsg_array=None, default_hsg=hsg, amc=amc, nodata=nodata, feedback=feedback
    )
    return cn_array


def build_manning_raster_from_lulc(lulc_array, lulc_type, overland=True, nodata=None, feedback=None):
    """
    Generate a Manning's n raster array from a LULC raster.
    Returns a float32 array (HEC-RAS compatible).
    """
    lut = {
        'ESA':    ESA_WORLDCOVER_TO_PARAMS,
        'ESRI':   ESRI_LULC_TO_PARAMS,
        'NLCD':   NLCD_TO_PARAMS,
        'CORINE': CORINE_TO_PARAMS,
        'MODIS':  MODIS_IGBP_TO_PARAMS,
    }.get(lulc_type.upper(), ESA_WORLDCOVER_TO_PARAMS)

    col = 6 if overland else 5  # overland or channel Manning's n

    manning_array = np.full(lulc_array.shape, np.nan, dtype=np.float32)
    for pv in np.unique(lulc_array):
        if nodata is not None and pv == nodata:
            continue
        if pv not in lut:
            continue
        manning_array[lulc_array == pv] = lut[pv][col]

    if feedback:
        valid = manning_array[~np.isnan(manning_array)]
        if len(valid) > 0:
            feedback.pushInfo(
                f"Manning's n raster: mean={np.mean(valid):.4f}, "
                f"min={np.min(valid):.4f}, max={np.max(valid):.4f}"
            )
    return manning_array


# ---------------------------------------------------------------------------
# 9.  Hydrologic Soil Group pixel-value conventions
# ---------------------------------------------------------------------------
# If a HSG raster is available, the convention depends on the source.
# Common conventions:
#   SSURGO (USA): A=1, B=2, C=3, D=4, A/D=14, B/D=24, C/D=34
#   FAO global soils:  same 1-4 encoding

HSG_PIXEL_MAP = {
    1: 'A', 2: 'B', 3: 'C', 4: 'D',
    14: 'A',  # dual A/D → use A (drained)
    24: 'B',  # dual B/D → use B (drained)
    34: 'C',  # dual C/D → use C (drained)
}

# ---------------------------------------------------------------------------
# 10.  HEC-RAS CN raster class descriptions  (for GUI/legend)
# ---------------------------------------------------------------------------
HECRAS_CN_CLASSES = [
    (0,  24,  'Water / Very High Infiltration',       '#0000FF'),
    (25, 39,  'Woods Good / Very Low Runoff',         '#006400'),
    (40, 54,  'Meadow / Pasture Good',                '#32CD32'),
    (55, 64,  'Pasture Fair / Brush',                 '#ADFF2F'),
    (65, 74,  'Agricultural / Cultivated',            '#FFD700'),
    (75, 84,  'Residential / Open Urban',             '#FF8C00'),
    (85, 94,  'Commercial / Industrial / Dense Urban','#FF4500'),
    (95, 100, 'Impervious / Water bodies',            '#FF0000'),
]

def get_cn_class_legend():
    """Return a list of (min_cn, max_cn, label, hex_color) for map legends."""
    return HECRAS_CN_CLASSES
