"""
Raster Downloader - Rain2Flood v3.0
Generates CN, LULC, Manning's n rasters with:
  - QML style files (.qml) - colour ramp + class labels, auto-loaded by QGIS
  - GDAL auxiliary RAT (.aux.xml) - class names for ArcGIS / QGIS
  - Parallel ESA tile downloads for speed
  - Correct v200 filename: ESA_WorldCover_10m_2021_v200_{TILE}_Map.tif
"""

import os, math, json, warnings
import urllib.request
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import rasterio
    from rasterio.merge import merge as rasterio_merge
    from rasterio.mask import mask as rasterio_mask
    from rasterio.warp import reproject, Resampling, calculate_default_transform
    from rasterio.crs import CRS
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False

try:
    from .cn_lulc_manager import (
        build_cn_raster_from_lulc, build_manning_raster_from_lulc,
        HECRAS_CN_CLASSES,
        ESA_WORLDCOVER_TO_PARAMS, NLCD_TO_PARAMS,
        CORINE_TO_PARAMS, MODIS_IGBP_TO_PARAMS,
    )
except ImportError:
    from cn_lulc_manager import (
        build_cn_raster_from_lulc, build_manning_raster_from_lulc,
        HECRAS_CN_CLASSES,
        ESA_WORLDCOVER_TO_PARAMS, NLCD_TO_PARAMS,
        CORINE_TO_PARAMS, MODIS_IGBP_TO_PARAMS,
    )

ESA_BASES = [
    "https://esa-worldcover.s3.amazonaws.com/v200/2021/map",
    "https://esa-worldcover.s3.eu-central-1.amazonaws.com/v200/2021/map",
]
LULC_LOOKUP = {
    'ESA':    ESA_WORLDCOVER_TO_PARAMS,
    'NLCD':   NLCD_TO_PARAMS,
    'CORINE': CORINE_TO_PARAMS,
    'MODIS':  MODIS_IGBP_TO_PARAMS,
}


def _qml_pseudo(qml_path, items_xml, vmin, vmax, ramp_type="DISCRETE"):
    """
    DISCRETE classification gives bold, distinct colour bands matching
    each class exactly (a pixel gets the colour of the smallest item
    whose value >= the pixel value). An earlier version of this used
    "EXACT" instead, which sounds similar but is a completely different
    QGIS mode: it only draws a pixel whose value EXACTLY equals one of
    the defined breakpoints. For continuous data like CN or Manning's n,
    virtually no floating-point pixel value exactly equals a breakpoint
    like 24.0 or 0.035, so with EXACT mode almost nothing renders at
    all — confirmed as the actual cause of CN/Manning's n rasters
    appearing to have no visible symbology at all after loading.
    INTERPOLATED (the original default before that) smoothly blends
    colour between class midpoints, which muddies genuinely classified
    data into a washed-out gradient — that was the "dull" look.
    """
    qml = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" band="1"
        classificationMin="{vmin}" classificationMax="{vmax}" opacity="1">
      <rastershader>
        <colorrampshader colorRampType="{ramp_type}"
            minimumValue="{vmin}" maximumValue="{vmax}" labelPrecision="2"
            clip="0">
{chr(10).join(items_xml)}
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="10" contrast="15" gamma="1"/>
    <huesaturation saturation="20" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
</qgis>"""
    with open(qml_path, 'w') as f:
        f.write(qml)


def write_qml_cn(qml_path):
    """QML for CN raster: bold, distinct colour bands matching HECRAS_CN_CLASSES."""
    palette = ['#0D47A1','#1B7837','#66BD63','#A6D96A','#FEE08B',
               '#FDAE61','#F46D43','#D73027']
    items = []
    for i, (mn, mx, desc, _) in enumerate(HECRAS_CN_CLASSES):
        col = palette[min(i, len(palette)-1)]
        items.append(
            f'      <item alpha="255" color="{col}" '
            f'label="CN {mn}-{mx}  {desc}" value="{mx}"/>'
        )
    _qml_pseudo(qml_path, items, 0.0, 100.0)


def write_qml_manning(qml_path, max_n=0.15):
    """QML for Manning's n raster with bold, distinct roughness-class bands."""
    classes = [
        (0.010, 0.016, '#D6EAF8', 'Smooth concrete / asphalt'),
        (0.016, 0.025, '#85C1E9', 'Improved channel / brick'),
        (0.025, 0.035, '#3498DB', 'Earth channel (clean)'),
        (0.035, 0.050, '#1F618D', 'Natural stream (clean)'),
        (0.050, 0.080, '#117864', 'Weedy / sluggish stream'),
        (0.080, 0.120, '#1E8449', 'Heavy brush / light forest'),
        (0.120, 0.200, '#B9770E', 'Dense forest / floodplain'),
        (0.200, 0.500, '#6C3483', 'Very dense forest / marsh'),
    ]
    items = []
    for lo, hi, col, label in classes:
        if lo >= max_n * 1.5:
            break
        items.append(
            f'      <item alpha="255" color="{col}" '
            f'label="{lo:.3f}-{hi:.3f}  {label}" value="{hi}"/>'
        )
    _qml_pseudo(qml_path, items, 0.0, max(max_n, 0.02))


def write_qml_lulc(qml_path, lut, dataset_name='ESA'):
    """QML for integer LULC raster: distinct colour per class with class name label."""
    import colorsys
    n = len(lut)
    items = []
    for idx, (pv, val) in enumerate(sorted(lut.items())):
        h = idx / max(n-1, 1)
        sat = 0.45 if val[1] >= 100 else 0.85
        r, g, b = [int(x*255) for x in colorsys.hsv_to_rgb(h, sat, 0.90)]
        label = f'{pv}: {val[0]}'
        items.append(
            f'    <paletteEntry alpha="255" color="#{r:02x}{g:02x}{b:02x}" '
            f'label="{label}" value="{pv}"/>'
        )
    qml = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="paletted" band="1" opacity="1">
      <colorPalette>
{chr(10).join(items)}
      </colorPalette>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
</qgis>"""
    with open(qml_path, 'w') as f:
        f.write(qml)


def embed_rat_lulc(raster_path, lut, feedback=None):
    """Write GDAL .aux.xml with class names (readable by QGIS and ArcGIS)."""
    rows = []
    for i, (pv, val) in enumerate(sorted(lut.items())):
        rows.append(
            f'      <Row index="{i}">'
            f'<F>{pv}</F><F>{val[0]}</F>'
            f'<F>{val[2]}</F><F>{val[6]:.4f}</F>'
            f'</Row>'
        )
    xml = (
        '<PAMDataset>\n  <PAMRasterBand band="1">\n'
        '    <GDALRasterAttributeTable>\n'
        '      <FieldDefn index="0"><Name>Value</Name><Type>1</Type><Usage>0</Usage></FieldDefn>\n'
        '      <FieldDefn index="1"><Name>ClassName</Name><Type>2</Type><Usage>2</Usage></FieldDefn>\n'
        '      <FieldDefn index="2"><Name>CN_HSG_B</Name><Type>1</Type><Usage>0</Usage></FieldDefn>\n'
        '      <FieldDefn index="3"><Name>Manning_n_overland</Name><Type>3</Type><Usage>0</Usage></FieldDefn>\n'
        + '\n'.join(rows)
        + '\n    </GDALRasterAttributeTable>\n  </PAMRasterBand>\n</PAMDataset>'
    )
    aux = raster_path + '.aux.xml'
    with open(aux, 'w') as f:
        f.write(xml)
    if feedback:
        feedback.pushInfo(f"    Class names embedded: {os.path.basename(aux)}")


def embed_rat_cn(raster_path, feedback=None):
    """Write GDAL .aux.xml with CN class names for CN raster."""
    rows = []
    for i, (mn, mx, desc, _) in enumerate(HECRAS_CN_CLASSES):
        rows.append(
            f'      <Row index="{i}">'
            f'<F>{(mn+mx)/2:.1f}</F><F>CN {mn}-{mx}: {desc}</F>'
            f'</Row>'
        )
    xml = (
        '<PAMDataset>\n  <PAMRasterBand band="1">\n'
        '    <GDALRasterAttributeTable>\n'
        '      <FieldDefn index="0"><Name>CN_midpoint</Name><Type>3</Type><Usage>0</Usage></FieldDefn>\n'
        '      <FieldDefn index="1"><Name>Class</Name><Type>2</Type><Usage>2</Usage></FieldDefn>\n'
        + '\n'.join(rows)
        + '\n    </GDALRasterAttributeTable>\n  </PAMRasterBand>\n</PAMDataset>'
    )
    aux = raster_path + '.aux.xml'
    with open(aux, 'w') as f:
        f.write(xml)
    if feedback:
        feedback.pushInfo(f"    CN class names embedded: {os.path.basename(aux)}")


def _tile_name(lat, lon):
    lb = int(math.floor(lat/3))*3; lo_b = int(math.floor(lon/3))*3
    ns = 'N' if lb >= 0 else 'S'; ew = 'E' if lo_b >= 0 else 'W'
    return f"{ns}{abs(lb):02d}{ew}{abs(lo_b):03d}"


def get_esa_worldcover_tiles_for_bbox(s, n, w, e):
    tiles = []
    la = int(math.floor(s/3))*3
    while la < n:
        lo = int(math.floor(w/3))*3
        while lo < e:
            tiles.append(_tile_name(la+0.001, lo+0.001)); lo += 3
        la += 3
    return list(dict.fromkeys(tiles))


def _download_tile(tile_name, out_dir, timeout=180):
    """Download one tile; returns (path, cached_bool, error_str)."""
    fname   = f"ESA_WorldCover_10m_2021_v200_{tile_name}_Map.tif"
    outpath = os.path.join(out_dir, fname)
    if os.path.exists(outpath) and os.path.getsize(outpath) > 100000:
        return outpath, True, None
    os.makedirs(out_dir, exist_ok=True)
    last_err = None
    for base in ESA_BASES:
        url = f"{base}/{fname}"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Rain2Flood/3.0'})
            with urllib.request.urlopen(req, timeout=timeout) as resp, \
                 open(outpath, 'wb') as fout:
                while True:
                    chunk = resp.read(65536)
                    if not chunk: break
                    fout.write(chunk)
            if os.path.getsize(outpath) > 100000:
                return outpath, False, None
            os.remove(outpath)
        except Exception as e:
            if os.path.exists(outpath):
                os.remove(outpath)
            last_err = str(e)
    return None, False, last_err


def merge_raster_tiles(tile_paths, out_dir, output_name="merged_lulc_tiles.tif", feedback=None):
    """
    Merge multiple user-supplied raster tiles (e.g. manually downloaded
    LULC tiles that aren't pre-merged) into one mosaic, reprojecting any
    tile whose CRS doesn't match the first tile's before merging.
    Returns the merged file path, or None on failure.
    """
    if not RASTERIO_OK:
        if feedback: feedback.reportError("rasterio required.")
        return None
    if not tile_paths:
        if feedback: feedback.reportError("No tiles given to merge.")
        return None
    if len(tile_paths) == 1:
        if feedback:
            feedback.pushInfo("Only one tile given — nothing to merge, using it directly.")
        return tile_paths[0]

    os.makedirs(out_dir, exist_ok=True)
    merged = os.path.join(out_dir, output_name)

    try:
        with rasterio.open(tile_paths[0]) as ref:
            ref_crs = ref.crs

        datasets = []
        tmp_reprojected = []
        for p in tile_paths:
            with rasterio.open(p) as src:
                if src.crs == ref_crs:
                    datasets.append(rasterio.open(p))
                    continue
            # Reproject any mismatched tile to the first tile's CRS before
            # merging — rasterio.merge assumes all inputs share one CRS.
            if feedback:
                feedback.pushInfo(f"  Reprojecting {os.path.basename(p)} to match the first tile's CRS ...")
            tmp_path = os.path.join(out_dir, f"_reproj_{os.path.basename(p)}")
            with rasterio.open(p) as src:
                transform, width, height = calculate_default_transform(
                    src.crs, ref_crs, src.width, src.height, *src.bounds)
                meta = src.meta.copy()
                meta.update(crs=ref_crs, transform=transform, width=width, height=height)
                with rasterio.open(tmp_path, 'w', **meta) as dst:
                    for band_i in range(1, src.count + 1):
                        reproject(
                            source=rasterio.band(src, band_i),
                            destination=rasterio.band(dst, band_i),
                            src_transform=src.transform, src_crs=src.crs,
                            dst_transform=transform, dst_crs=ref_crs,
                            resampling=Resampling.nearest
                        )
            tmp_reprojected.append(tmp_path)
            datasets.append(rasterio.open(tmp_path))

        if feedback:
            feedback.pushInfo(f"Merging {len(tile_paths)} tile(s) ...")
        mosaic, transform = rasterio_merge(datasets)
        meta = datasets[0].meta.copy()
        meta.update({'driver': 'GTiff', 'height': mosaic.shape[1], 'width': mosaic.shape[2],
                     'transform': transform, 'compress': 'lzw', 'tiled': True,
                     'blockxsize': 512, 'blockysize': 512})
        with rasterio.open(merged, 'w', **meta) as dst:
            dst.write(mosaic)
        for ds in datasets:
            ds.close()
        for tmp in tmp_reprojected:
            try: os.remove(tmp)
            except Exception: pass

        if feedback:
            feedback.pushInfo(f"Merged: {merged}  ({os.path.getsize(merged)/1e6:.1f} MB)")
        return merged
    except Exception as e:
        if feedback:
            feedback.reportError(f"Tile merge failed: {e}")
        return None


def download_esa_worldcover_for_bbox(bbox, out_dir, feedback=None):
    """Download all tiles covering bbox in parallel and merge. Returns merged path or None."""
    if not RASTERIO_OK:
        if feedback: feedback.reportError("rasterio required.")
        return None

    s, n, w, e = bbox
    tiles = get_esa_worldcover_tiles_for_bbox(s, n, w, e)
    if feedback:
        feedback.pushInfo(
            f"ESA WorldCover v200: {len(tiles)} tile(s): {', '.join(tiles)}\n"
            f"File format: ESA_WorldCover_10m_2021_v200_<TILE>_Map.tif"
        )

    tile_paths = []
    with ThreadPoolExecutor(max_workers=min(4, max(1,len(tiles)))) as ex:
        futs = {ex.submit(_download_tile, t, out_dir): t for t in tiles}
        for fut in as_completed(futs):
            t = futs[fut]
            try:
                path, cached, err = fut.result()
                if path:
                    tile_paths.append(path)
                    mb = os.path.getsize(path)/1e6
                    if feedback:
                        status = "cached" if cached else "downloaded"
                        feedback.pushInfo(f"  {t}: {status} ({mb:.1f} MB)")
                else:
                    if feedback:
                        feedback.reportError(
                            f"  {t}: FAILED ({err})\n"
                            "  Download manually from viewer.esa-worldcover.org\n"
                            "  then use Option 2: Derive from Existing LULC Raster."
                        )
            except Exception as e:
                if feedback: feedback.reportError(f"  {t}: {e}")

    if not tile_paths:
        return None

    merged = os.path.join(out_dir, "ESA_WorldCover_10m_2021_v200_merged.tif")
    if len(tile_paths) == 1:
        import shutil; shutil.copy(tile_paths[0], merged)
    else:
        datasets = [rasterio.open(p) for p in tile_paths]
        mosaic, transform = rasterio_merge(datasets)
        meta = datasets[0].meta.copy()
        meta.update({'driver':'GTiff','height':mosaic.shape[1],'width':mosaic.shape[2],
                     'transform':transform,'compress':'lzw','tiled':True,
                     'blockxsize':512,'blockysize':512})
        with rasterio.open(merged, 'w', **meta) as dst:
            dst.write(mosaic)
        for ds in datasets: ds.close()
    if feedback:
        feedback.pushInfo(f"Merged: {merged}  ({os.path.getsize(merged)/1e6:.1f} MB)")
    return merged


def generate_cn_raster_from_lulc_file(lulc_path, out_dir, lulc_type='ESA',
                                        hsg='B', amc=2,
                                        catchment_geoms=None, feedback=None):
    """
    LULC GeoTIFF -> CN and Manning's n GeoTIFFs with QML styles + RAT class names.
    """
    if not RASTERIO_OK:
        if feedback: feedback.reportError("rasterio required.")
        return {}

    lut = LULC_LOOKUP.get(lulc_type.upper(), ESA_WORLDCOVER_TO_PARAMS)
    os.makedirs(out_dir, exist_ok=True)

    cn_path    = os.path.join(out_dir, f"cn_{lulc_type}_HSG{hsg}_AMC{amc}.tif")
    mn_path    = os.path.join(out_dir, f"manning_n_{lulc_type}.tif")
    lulc_path2 = os.path.join(out_dir, f"lulc_classes_{lulc_type}.tif")

    with rasterio.open(lulc_path) as src:
        meta = src.meta.copy()
        nd   = src.nodata if src.nodata is not None else 0

        if catchment_geoms:
            from shapely.geometry import mapping
            geoms = [mapping(g) for g in catchment_geoms]
            arr_d, tr = rasterio_mask(src, geoms, crop=True, nodata=nd, filled=True)
            lulc_arr = arr_d[0]
            meta.update({'height':lulc_arr.shape[0],'width':lulc_arr.shape[1],'transform':tr})
        else:
            lulc_arr = src.read(1)

    if feedback:
        unique = np.unique(lulc_arr[lulc_arr != nd])
        feedback.pushInfo(
            f"LULC: {lulc_arr.shape[0]}x{lulc_arr.shape[1]} px, "
            f"{len(unique)} unique classes: {unique[:10]}{'...' if len(unique)>10 else ''}"
        )

    cn_arr = build_cn_raster_from_lulc(lulc_arr, lulc_type, hsg=hsg, amc=amc,
                                        nodata=nd, feedback=feedback)
    mn_arr = build_manning_raster_from_lulc(lulc_arr, lulc_type, overland=True,
                                             nodata=nd, feedback=feedback)

    ometa = meta.copy()
    ometa.update({'dtype':'float32','count':1,'compress':'lzw','nodata':-9999.0})

    def _write(path, arr, desc, tags=None):
        clean = np.where(np.isnan(arr), -9999.0, arr).astype(np.float32)
        with rasterio.open(path, 'w', **ometa) as dst:
            dst.write(clean, 1)
            dst.update_tags(DESCRIPTION=desc, **(tags or {}))

    _write(cn_path, cn_arr, f'Curve Number - {lulc_type} HSG-{hsg} AMC-{amc}',
           {'STANDARD':'NRCS TR-55','HSG':hsg,'AMC':str(amc)})
    _write(mn_path, mn_arr, f"Manning n overland - {lulc_type}",
           {'STANDARD':'Chow 1959 / HEC-15'})

    lm2 = meta.copy(); lm2.update({'dtype':'int16','count':1,'compress':'lzw','nodata':-9999})
    lulc_int = np.where(lulc_arr==nd, -9999, lulc_arr).astype(np.int16)
    with rasterio.open(lulc_path2,'w',**lm2) as dst:
        dst.write(lulc_int,1)
        dst.update_tags(DESCRIPTION=f'LULC integer classes - {lulc_type}')

    write_qml_cn(cn_path.replace('.tif','.qml'))
    max_mn = float(np.nanmax(mn_arr[~np.isnan(mn_arr)])) if np.any(~np.isnan(mn_arr)) else 0.15
    write_qml_manning(mn_path.replace('.tif','.qml'), max_n=max(max_mn, 0.02))
    write_qml_lulc(lulc_path2.replace('.tif','.qml'), lut, lulc_type)

    embed_rat_lulc(lulc_path2, lut, feedback)
    embed_rat_cn(cn_path, feedback)

    valid_cn = cn_arr[~np.isnan(cn_arr)]; valid_mn = mn_arr[~np.isnan(mn_arr)]
    w_cn = float(np.mean(valid_cn)) if len(valid_cn) > 0 else 75.0
    w_mn = float(np.mean(valid_mn)) if len(valid_mn) > 0 else 0.05

    if feedback:
        feedback.pushInfo(
            f"\nOutputs:\n"
            f"  CN raster:    {cn_path}\n"
            f"  Manning's n:  {mn_path}\n"
            f"  LULC classes: {lulc_path2}\n"
            f"  Weighted CN={w_cn:.1f} (AMC{amc}, HSG-{hsg})  "
            f"Manning n={w_mn:.4f}\n"
            f"  All rasters have .qml style + .aux.xml class names"
        )

    return {'cn_raster': cn_path, 'manning_raster': mn_path,
            'lulc_int_raster': lulc_path2,
            'weighted_cn': w_cn, 'weighted_manning': w_mn}


def generate_cn_raster_manual(catchment_path, cn_value, manning_n,
                                out_dir, target_crs=None, resolution=30.0,
                                feedback=None):
    """Generate uniform CN and Manning's n rasters with QML styles."""
    if not RASTERIO_OK:
        if feedback: feedback.reportError("rasterio required.")
        return {}
    try:
        import geopandas as gpd
        from shapely.geometry import mapping
        from rasterio.transform import from_bounds
        from rasterio import features as rf

        gdf = gpd.read_file(catchment_path)
        if gdf.crs is None or gdf.crs.is_geographic:
            cx=gdf.geometry.unary_union.centroid.x; cy=gdf.geometry.unary_union.centroid.y
            z=int((cx+180)//6)+1; h='north' if cy>=0 else 'south'
            gdf=gdf.to_crs(f"EPSG:{'326' if h=='north' else '327'}{z:02d}")

        b=gdf.total_bounds
        W=max(1,int((b[2]-b[0])/resolution)); H=max(1,int((b[3]-b[1])/resolution))
        tr=from_bounds(b[0],b[1],b[2],b[3],W,H)
        mask=rf.geometry_mask([mapping(g) for g in gdf.geometry],
                               out_shape=(H,W), transform=tr, invert=True)
        os.makedirs(out_dir, exist_ok=True)
        cn_p=os.path.join(out_dir,f"cn_manual_CN{int(cn_value)}.tif")
        mn_p=os.path.join(out_dir,f"manning_n_manual_{manning_n:.4f}.tif")
        meta={'driver':'GTiff','dtype':'float32','count':1,'crs':gdf.crs,
              'transform':tr,'height':H,'width':W,'compress':'lzw','nodata':-9999.0}
        for path, val, desc in [(cn_p,cn_value,f'Manual CN={cn_value}'),
                                  (mn_p,manning_n,f"Manual Manning n={manning_n:.4f}")]:
            arr=np.where(mask,float(val),-9999.0).astype(np.float32)
            with rasterio.open(path,'w',**meta) as dst:
                dst.write(arr,1); dst.update_tags(DESCRIPTION=desc)
        write_qml_cn(cn_p.replace('.tif','.qml'))
        write_qml_manning(mn_p.replace('.tif','.qml'), max_n=max(manning_n*3,0.02))
        embed_rat_cn(cn_p, feedback)
        if feedback:
            feedback.pushInfo(f"Manual CN raster: {cn_p}  (CN={cn_value}, n={manning_n:.4f})")
        return {'cn_raster':cn_p,'manning_raster':mn_p,
                'weighted_cn':float(cn_value),'weighted_manning':float(manning_n)}
    except Exception as e:
        if feedback: feedback.reportError(f"Manual raster failed: {e}")
        return {}


def extract_catchment_cn_manning(cn_rp, mn_rp, cat_p, feedback=None):
    if not RASTERIO_OK: return 75.0, 0.05
    try:
        import geopandas as gpd
        from shapely.geometry import mapping
        gdf=gpd.read_file(cat_p); res={}
        for label, rpath in [('cn',cn_rp),('mn',mn_rp)]:
            if not rpath or not os.path.exists(rpath): res[label]=None; continue
            with rasterio.open(rpath) as src:
                g2=gdf.to_crs(src.crs)
                out,_=rasterio_mask(src,[mapping(g) for g in g2.geometry],
                                     crop=True,nodata=src.nodata or -9999.0)
                arr=out[0].astype(np.float32); arr[arr==(src.nodata or -9999.0)]=np.nan
                arr[arr<=0]=np.nan; valid=arr[~np.isnan(arr)]
                res[label]=float(np.mean(valid)) if len(valid)>0 else None
        wc=res.get('cn') or 75.0; wm=res.get('mn') or 0.05
        if feedback: feedback.pushInfo(f"Catchment weighted CN={wc:.1f}, n={wm:.4f}")
        return wc, wm
    except Exception as e:
        if feedback: feedback.pushWarning(f"Extraction failed ({e}).")
        return 75.0, 0.05
