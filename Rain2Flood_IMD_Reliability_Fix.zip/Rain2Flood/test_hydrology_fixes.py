"""
Regression tests for hydrology-correctness fixes.
==================================================
Standalone (no QGIS required) — run with:
    python3 test_hydrology_fixes.py

Covers the specific bugs found and fixed during the technical audit pass:
  1. FEH QMED formula (was using the wrong variable in the SAAR exponent
     slot, a fabricated SPRHOST term, a wrong FARL exponent, and a
     completely wrong BFIHOST term structure — ~5x underestimate)
  2. alternating_block_hyetograph crashing when idf_func returns None
     for an unfit return period (broken `depths is None` check)
  3. calculate_time_to_peak ignoring storm duration (always assumed 1hr)
  4. Modified Rational Method conflating Tc (time of concentration) with
     Tp (time to peak) — different quantities related by Tp = 0.6*Tc

This is NOT a comprehensive test suite for the whole plugin — it's
targeted at the specific issues found in this audit pass, to protect
against regression on exactly those.
"""
import sys
import numpy as np

sys.path.insert(0, '.')
import hydrological_calculations as hc


class _FB:
    """Minimal feedback stub."""
    def pushInfo(self, m): pass
    def pushWarning(self, m): print(f"  [warn] {m}")
    def reportError(self, m, fatalError=False): print(f"  [error] {m}")
    def setProgress(self, v): pass


def check(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f" — {detail}" if detail and not condition else ""))
    return condition


def test_sink_fill_and_network_connectivity():
    """
    Regression test for the cause of straight-line / blocky artifacts in
    real flood maps.

    The original sink fill raised each cell to the minimum of its
    neighbours. That only fills SINGLE-CELL pits: in a multi-cell
    depression every interior cell has a neighbour at its own elevation,
    so it never rises. Measured on a test DEM, a pit floor at 90 m inside
    a 115 m rim rose only to 90.15 m. Unfilled depressions trap flow, the
    derived stream network fragments (max accumulation reached just 40 of
    1600 cells), and HAND measured to those fragments is what produced
    the artifacts.

    Priority-flood fills correctly and an epsilon gradient guarantees D8
    always has a strictly-lower neighbour to route into.
    """
    import flood_mapping as fm
    n = 40
    yy, xx = np.mgrid[0:n, 0:n]
    dem = (100 + 0.5 * (n - xx) + 0.4 * np.abs(yy - n / 2))
    dem[18:23, 10:25] = 90.0          # multi-cell depression
    dem = dem.astype(np.float32)
    valid = np.ones((n, n), bool)

    filled = fm._fill_sinks(dem)
    ok1 = check("Multi-cell depression is filled to its true pour-point level",
                filled[20, 17] > 100.0,
                f"pit floor {dem[20,17]:.2f} -> {filled[20,17]:.2f} (needs >100)")
    ok2 = check("Sink filling never LOWERS terrain",
                bool(np.all(filled >= dem - 1e-6)))

    acc = fm._flow_accumulation_d8(filled, valid)
    ok3 = check("Flow network is connected to the outlet after filling",
                acc.max() > 0.8 * n * n,
                f"max accumulation {acc.max():.0f} of {n*n}")
    ok4 = check("Flow routes THROUGH the filled depression rather than dying in it",
                int(np.sum(acc[18:23, 10:25] == 1)) < 10,
                f"{int(np.sum(acc[18:23,10:25]==1))} of 75 pit cells never routed")
    return ok1 and ok2 and ok3 and ok4


def test_tab_widgets_defined_where_used():
    """
    Every self.<widget> a tab reads must be DEFINED in that same tab.

    This caught a real bug while wiring the pour point: an edit intended
    to add the UI to both flood tabs put both copies in FlashFloodTab,
    leaving StandardFloodTab reading self.pp_lat / self.sub_lyr /
    self.wave_cel that did not exist there. Everything still compiled and
    the parameter-consistency test still passed — it would have crashed
    only when a user clicked Run on that tab.
    """
    import re
    src = open('rain2flood_dialog.py').read()
    bounds = [('FlashFloodTab', src.index('class FlashFloodTab'),
               src.index('class StandardFloodTab')),
              ('StandardFloodTab', src.index('class StandardFloodTab'),
               src.index('class AboutTab'))]
    all_ok = True
    for name, s, e in bounds:
        blk = src[s:e]
        used = set(re.findall(
            r'self\.(\w+)\.(?:text|value|isChecked|currentIndex|currentLayer|dateTime)\(', blk))
        defined = set(re.findall(r'self\.(\w+)\s*=', blk))
        missing = sorted(used - defined)
        all_ok = check(f"{name}: all {len(used)} referenced widgets are defined in that tab",
                       not missing, f"undefined: {missing}") and all_ok
    return all_ok


def test_subbasin_lagged_routing():
    """
    Semi-distributed routing must (a) give a LOWER combined peak than
    perfectly synchronised sub-basins, because real sub-basins do not all
    peak at once, (b) conserve volume exactly regardless of lag, and
    (c) reduce to the synchronised sum when all lags are zero.
    """
    import subbasin_routing as sbr
    from shapely.geometry import box
    subs = [{'name': f'S{i+1}', 'area_km2': 500.0, 'centroid_x': 0, 'centroid_y': 0,
             'dist_to_outlet_m': 5000 + i * 25000, 'geometry': box(0, 0, 1000, 1000)}
            for i in range(5)]

    r = sbr.route_subbasins_to_outlet(subs, 204.6, 24, 68.5, 0.05, 6.52)
    ok1 = check("Lagged sub-basin peak is LOWER than perfectly synchronised sum",
                r['peak_m3s'] < r['sum_of_local_peaks_m3s'],
                f"{r['peak_m3s']:.1f} vs {r['sum_of_local_peaks_m3s']:.1f}")

    vol_c = np.trapezoid(r['discharge_m3s'], r['time_hr'])
    vol_p = sum(np.trapezoid(b['discharge'], b['time']) for b in r['per_basin'])
    ok2 = check("Lagging conserves volume exactly (creates/destroys no water)",
                abs(vol_c - vol_p) / vol_p < 0.02,
                f"error={100*abs(vol_c-vol_p)/vol_p:.3f}%")

    subs0 = [dict(s, dist_to_outlet_m=0.0) for s in subs]
    r0 = sbr.route_subbasins_to_outlet(subs0, 204.6, 24, 68.5, 0.05, 6.52)
    ok3 = check("At zero lag, combined peak equals the synchronised sum",
                abs(r0['peak_m3s'] - r0['sum_of_local_peaks_m3s'])
                / r0['sum_of_local_peaks_m3s'] < 0.02)
    return ok1 and ok2 and ok3


def test_flood_extent_scales_with_contributing_area():
    """
    Regression test for two linked errors found on a REAL 2577 km2
    catchment run, where flood extent came out at 43-46% of the whole
    catchment and barely moved between the 10-yr and 100-yr events:

      1. A fixed 0.5 km2 stream-initiation threshold is a headwater-gully
         criterion. On a large catchment it mapped 11.7% of the entire
         area as "channel", so almost every cell sat close to a "stream",
         HAND was small everywhere, and nearly everything flooded.
      2. The OUTLET discharge was applied to every stream cell, so a
         first-order gully draining 0.5 km2 was flooded as though it
         carried the full 1460 m3/s of a 2577 km2 catchment.

    Checks the network is now a plausible fraction of the catchment, that
    depth genuinely varies along it, and that extent responds to
    discharge instead of being pinned near a fixed value.
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmp = tempfile.mkdtemp()
    n, res = 200, 30.0
    y, x = np.mgrid[0:n, 0:n]
    dem = (600 + 200.0 * (n - x) / n
           + 12.0 * np.abs((y - n / 2) / (n / 2)) ** 1.2).astype(np.float32)
    ox, oy = 400000, 2000000
    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs='EPSG:32643', transform=from_origin(ox, oy, res, res), nodata=-9999.0)
    dem_path = os.path.join(tmp, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as d:
        d.write(dem, 1)
    poly = Polygon([(ox, oy), (ox + n * res, oy),
                     (ox + n * res, oy - n * res), (ox, oy - n * res)])
    cat = os.path.join(tmp, 'c.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs='EPSG:32643').to_file(cat, driver='GPKG')

    extents, depths = [], []
    for i, Q in enumerate([200, 1460, 4000]):
        _, tif, _, _ = fm.generate_flood_map(
            Q, dem_path, cat, tmp, 10 + i, manning_n=0.05, feedback=_FB())
        with rasterio.open(tif) as f:
            d_ = f.read(1)
        v = d_ > -9999
        extents.append(100.0 * np.sum(v & (d_ > 0)) / np.sum(v))
        depths.append(d_[v].max())

    ok1 = check("Flood extent is a plausible fraction of the catchment, not ~half of it",
                all(e < 25.0 for e in extents), f"extents={[round(e,2) for e in extents]}")
    ok2 = check("Flood extent responds to a 20x change in discharge "
                "(bug pinned it near-constant)",
                extents[-1] > extents[0] * 1.15,
                f"{extents[0]:.2f}% -> {extents[-1]:.2f}%")
    ok3 = check("Max depth increases with discharge",
                depths[0] < depths[-1], f"{depths[0]:.2f} -> {depths[-1]:.2f}")

    _, tif, _, _ = fm.generate_flood_map(1460, dem_path, cat, tmp, 99,
                                          manning_n=0.05, feedback=_FB())
    with rasterio.open(tif) as f:
        d_ = f.read(1)
    fl = d_[d_ > 0]
    ok4 = check("Depth VARIES along the network (headwaters shallower than outlet) "
                "rather than every stream cell getting the outlet depth",
                fl.size > 10 and fl.max() > 5 * np.median(fl[fl > 0]) or
                fl.max() / max(fl.min(), 1e-6) > 10,
                f"min={fl.min():.3f}, median={np.median(fl):.3f}, max={fl.max():.3f}")
    return ok1 and ok2 and ok3 and ok4


def test_no_shadowing_imports():
    """
    Detect the Python scoping trap that caused a real crash: importing a
    name INSIDE a function when it's already imported at module level
    makes that name function-local for the ENTIRE function body — so any
    use of it ABOVE the import line raises UnboundLocalError, even
    though the module-level import exists.

    This is exactly what broke Standard Flood: `import rasterio, numpy as np`
    partway through processAlgorithm made `np` local, so an np.clip() call
    ~10 lines earlier failed. The module compiled fine and every unit test
    passed — it only surfaced on a real run, which is why it's worth a
    static check.

    Only flags cases where the name is actually USED before the shadowing
    import (a shadow with no earlier use is harmless, and deferred QGIS
    imports inside functions are a deliberate, valid pattern here).
    """
    import ast, os
    offenders = []
    for fn in sorted(f for f in os.listdir('.') if f.endswith('.py')):
        try:
            tree = ast.parse(open(fn).read())
        except SyntaxError:
            continue
        mod_names = set()
        for node in tree.body:
            if isinstance(node, ast.Import):
                for a in node.names:
                    mod_names.add(a.asname or a.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                for a in node.names:
                    mod_names.add(a.asname or a.name)
        for func in ast.walk(tree):
            if not isinstance(func, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for node in ast.walk(func):
                if not isinstance(node, (ast.Import, ast.ImportFrom)):
                    continue
                for a in node.names:
                    nm = a.asname or a.name.split('.')[0]
                    if nm not in mod_names:
                        continue
                    used_before = any(
                        isinstance(n, ast.Name) and n.id == nm and
                        getattr(n, 'lineno', 0) < node.lineno
                        for n in ast.walk(func))
                    if used_before:
                        offenders.append(f"{fn}:{node.lineno} {func.name}() shadows '{nm}'")
    return check("No function shadows a module-level import it already uses "
                 "above the import line (causes UnboundLocalError at runtime)",
                 not offenders, f"found: {offenders}")


def test_level_pool_routing():
    """
    Level-pool (Modified Puls) reservoir routing. Verified against the
    properties that actually prove it's solving continuity rather than
    just producing a plausible attenuated curve:
      - mass balance: inflow volume = outflow volume + storage change
      - the peak MUST attenuate (storage absorbs it)
      - the peak MUST be delayed, never early
      - at the outflow peak, inflow and outflow are equal (the classic
        level-pool property that the two curves cross exactly there)
      - a larger basin must attenuate more
    """
    stages = np.linspace(0, 4, 9)
    areas = np.linspace(20000, 50000, 9)
    ssd = hc.build_ssd_from_geometry(areas, stages, outlet_type='weir',
                                      weir_length_m=8.0, crest_stage_m=0.5)
    t = np.linspace(0, 24, 145)
    I = 40 * np.exp(-((t - 6) ** 2) / 8)
    r = hc.level_pool_routing(t, I, ssd, feedback=_FB())

    ok1 = check("Level-pool routing conserves mass (in = out + storage change)",
                r['mass_balance_error_pct'] < 2.0,
                f"error={r['mass_balance_error_pct']:.2f}%")
    ok2 = check("Routing attenuates the peak",
                r['peak_outflow'] < r['peak_inflow'],
                f"{r['peak_inflow']:.1f} -> {r['peak_outflow']:.1f}")
    ok3 = check("Outflow peak is delayed, never early",
                r['peak_lag_hr'] >= 0, f"lag={r['peak_lag_hr']}")

    i_pk = int(np.argmax(r['outflow_q']))
    ok4 = check("Inflow and outflow are equal at the outflow peak "
                "(defining property of level-pool routing)",
                abs(I[i_pk] - r['outflow_q'][i_pk]) < 0.05 * r['peak_inflow'],
                f"I={I[i_pk]:.2f} vs O={r['outflow_q'][i_pk]:.2f}")

    ssd_big = hc.build_ssd_from_geometry(areas * 3, stages, weir_length_m=8.0,
                                          crest_stage_m=0.5)
    r_big = hc.level_pool_routing(t, I, ssd_big)
    ok5 = check("A larger basin attenuates the peak more",
                r_big['attenuation_pct'] > r['attenuation_pct'],
                f"{r_big['attenuation_pct']:.1f}% vs {r['attenuation_pct']:.1f}%")
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_channel_section_hydraulics():
    """
    Cross-section hydraulics verified against EXACT analytical solutions
    for shapes whose properties can be computed by hand — a rectangle
    and a trapezoid. This is a much stronger check than 'the numbers look
    reasonable': area, top width, wetted perimeter and hydraulic radius
    all have closed-form answers here, so any error in the panel
    integration or waterline interpolation shows up immediately.
    """
    import channel_geometry as cg

    x = np.array([-30, -10.0001, -10, 10, 10.0001, 30])
    z = np.array([110, 110, 100, 100, 110, 110])
    h = cg.section_hydraulics(x, z, 103.0)   # 3 m deep, 20 m wide rectangle
    ok1 = check("Rectangular section: area, top width, wetted perimeter exact",
                abs(h['area_m2'] - 60.0) < 0.5 and
                abs(h['top_width_m'] - 20.0) < 0.5 and
                abs(h['wetted_perimeter_m'] - 26.0) < 0.5, f"got {h}")

    xt = np.array([-40, -20, -5, 5, 20, 40])
    zt = np.array([120, 107.5, 100, 100, 107.5, 120])  # 10 m base, 2H:1V sides
    h2 = cg.section_hydraulics(xt, zt, 104.0)          # 4 m depth
    ok2 = check("Trapezoidal section matches closed-form A=b*d+z*d^2",
                abs(h2['area_m2'] - (10 * 4 + 2 * 16)) < 1.0 and
                abs(h2['top_width_m'] - 26.0) < 1.0, f"got {h2}")

    rc = cg.rating_curve(xt, zt, slope=0.001, manning_n=0.035)
    Qs = [r['discharge_m3s'] for r in rc]
    ok3 = check("Rating curve discharge increases monotonically with stage",
                all(Qs[i] <= Qs[i + 1] for i in range(len(Qs) - 1)) and all(q >= 0 for q in Qs))

    r4 = min(rc, key=lambda r: abs(r['depth_m'] - 4.0))
    q_recomputed = (1 / 0.035) * r4['area_m2'] * r4['hydraulic_radius_m'] ** (2 / 3) * np.sqrt(0.001)
    ok4 = check("Rating curve applies Manning's equation correctly",
                abs(r4['discharge_m3s'] - q_recomputed) < 0.01)
    return ok1 and ok2 and ok3 and ok4


def test_batch_processing_logic():
    """
    Batch processing helpers: folder names must be filesystem-safe and
    bounded (a catchment attribute like 'sub/basin:1' would otherwise
    create a nested path or fail on Windows), summary extraction must
    pull the right headline numbers, and a missing/incomplete result
    folder must return empty rather than raising — because one bad
    catchment shouldn't abort a 20-catchment batch.
    """
    import os, tempfile
    import pandas as pd
    import batch_processing as bp

    ok1 = check("Batch folder names are filesystem-safe",
                '/' not in bp._slugify('sub/basin:1') and
                ':' not in bp._slugify('sub/basin:1') and
                bp._slugify('Krishna Basin') == 'Krishna_Basin')
    ok2 = check("Blank/None catchment names fall back to a usable default",
                bp._slugify(None) == 'catchment' and bp._slugify('   ') == 'catchment')
    ok3 = check("Very long names are truncated (filesystem path limits)",
                len(bp._slugify('A' * 200)) == 60)

    d = tempfile.mkdtemp()
    pd.DataFrame({'Return Period (yr)': [10, 25, 100],
                  'Discharge (m³/s)': [84.2, 151.0, 274.2]}).to_excel(
        os.path.join(d, 'Flash_Flood_Analysis_Results.xlsx'),
        sheet_name='Results', index=False)
    s = bp._extract_summary(d)
    ok4 = check("Batch summary extracts max discharge and its return period",
                s.get('Max Discharge (m3/s)') == 274.2 and
                s.get('At Return Period (yr)') == 100, f"got {s}")
    ok5 = check("Missing results folder returns empty dict, doesn't raise",
                bp._extract_summary(tempfile.mkdtemp()) == {})

    msgs = []
    class _P:
        def pushInfo(s, m): msgs.append(m)
        def pushWarning(s, m): msgs.append(m)
        def isCanceled(s): return False
    fb = bp._BatchSubFeedback(_P(), 'Basin_A')
    fb.pushInfo('x'); fb.setProgress(50); fb.pushWarning('y')
    ok6 = check("Batch sub-feedback prefixes messages and swallows progress "
                "(so per-catchment progress can't reset the batch progress bar)",
                len(msgs) == 2 and all('Basin_A' in m for m in msgs), f"got {msgs}")
    return ok1 and ok2 and ok3 and ok4 and ok5 and ok6


def test_ui_params_match_algorithm_params():
    """
    Every parameter the UI sends must be registered by the corresponding
    QGIS processing algorithm — QGIS rejects unknown parameters, so a
    mismatch breaks the whole tab at runtime.

    This caught a REAL bug: UI fields for calibration, CWC coefficients
    and sensitivity analysis were added to BOTH flood tabs, but the
    parameters were only registered in Flash Flood. Standard Flood was
    sending three unregistered parameters and would have failed on every
    run. Static checks like this catch a class of wiring bug that unit
    tests on individual functions can't, because each piece works fine
    in isolation — it's the connection between them that breaks.
    """
    import re
    dlg = open('rain2flood_dialog.py').read()
    ff = open('flash_flood_analysis.py').read()
    sf = open('standard_flood_analysis.py').read()

    ff_start = dlg.index('class FlashFloodTab')
    sf_start = dlg.index('class StandardFloodTab')
    blocks = [('FlashFlood', dlg[ff_start:sf_start], ff),
              ('StandardFlood', dlg[sf_start:], sf)]

    all_ok = True
    for label, block, algo in blocks:
        sent = set(re.findall(r"'([A-Z][A-Z0-9_]+)'\s*:", block))
        missing = sorted(p for p in sent if f"'{p}'" not in algo)
        ok = check(f"{label}: all {len(sent)} UI parameters are registered "
                   f"by its algorithm", not missing, f"unregistered: {missing}")
        all_ok = all_ok and ok
    return all_ok


def test_report_generation():
    """
    Report generator: verify sections appear only when their underlying
    output actually exists (an empty 'Calibration' heading would imply
    work that wasn't done), that images are embedded so the file is
    genuinely self-contained, that the limitations section ALWAYS
    appears regardless of what else is present, and that section
    numbering stays sequential when sections are skipped.
    """
    import os, tempfile, re
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import report_generator as rg

    def _png(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        fig, ax = plt.subplots(figsize=(3, 2))
        ax.plot([0, 1], [0, 1])
        plt.savefig(p, dpi=50)
        plt.close(fig)

    full = tempfile.mkdtemp()
    _png(os.path.join(full, 'IDF_DDF_Curves.png'))
    _png(os.path.join(full, 'flood_maps', 'flood_map_100yr.png'))
    _png(os.path.join(full, 'sensitivity', 'sensitivity_tornado.png'))
    pd.DataFrame({'Parameter': ['CN'], 'Elasticity': [2.0]}).to_csv(
        os.path.join(full, 'sensitivity', 'sensitivity_analysis.csv'), index=False)
    p_full = rg.generate_html_report(
        full, 'Flash Flood', {'Method': 'SCS'},
        pd.DataFrame({'Return Period (yr)': [100], 'Discharge (m³/s)': [274.2]}), _FB())
    html_full = open(p_full, encoding='utf-8').read()

    ok1 = check("Report includes sections for outputs that exist",
                'Sensitivity Analysis' in html_full and
                'Flood Inundation Maps' in html_full)
    ok2 = check("Report embeds images as base64 (self-contained file)",
                'data:image/png;base64,' in html_full)

    minimal = tempfile.mkdtemp()
    p_min = rg.generate_html_report(minimal, 'Standard Flood', {'Method': 'FEH'}, None, _FB())
    html_min = open(p_min, encoding='utf-8').read()
    ok3 = check("Report OMITS sections whose outputs don't exist "
                "(rather than showing empty headings)",
                'Sensitivity Analysis' not in html_min and
                'Calibration Against Observed' not in html_min)
    ok4 = check("Limitations section always appears, even in a minimal report",
                'Limitations' in html_min)

    nums = [int(m) for m in re.findall(r'<h2>(\d+)\.', html_min)]
    ok5 = check("Section numbering stays sequential when sections are skipped",
                nums == list(range(1, len(nums) + 1)), f"got {nums}")
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_config_save_load_roundtrip():
    """
    Config save/load: verify a round-trip preserves every widget type,
    and — more importantly — that the two realistic failure modes REPORT
    rather than silently doing the wrong thing:
      - a saved layer that isn't loaded in the current project
      - a saved combo index that no longer exists because the option
        list changed between plugin versions (silently applying a
        wrong-but-valid index here would change the analysis method
        without the user noticing)
    Uses mock widgets since rain2flood_dialog imports QGIS at module level.
    """
    class _CB:
        def __init__(s, n=5): s._i, s._n = 0, n
        def currentIndex(s): return s._i
        def setCurrentIndex(s, i): s._i = i
        def count(s): return s._n
    class _Chk:
        def __init__(s): s._v = False
        def isChecked(s): return s._v
        def setChecked(s, v): s._v = v
    class _Spin:
        def __init__(s): s._v = 0.0
        def value(s): return s._v
        def setValue(s, v): s._v = v
    class _Line:
        def __init__(s): s._t = ''
        def text(s): return s._t
        def setText(s, t): s._t = t
    class _Lyr:
        def __init__(s, n): s._n = n
        def name(s): return s._n
    class _LCm:
        def __init__(s, l=None): s._l = l
        def currentLayer(s): return s._l
        class _C:
            def __init__(s, o): s.o = o
            def setLayer(s, l): s.o._l = l
        @property
        def c(s): return _LCm._C(s)
    layers = {}
    class _Proj:
        @staticmethod
        def instance(): return _Proj
        @staticmethod
        def mapLayers(): return layers

    with open('rain2flood_dialog.py') as f:
        src = f.read()
    seg = src[src.index('def _collect_config'):src.index('\n\ndef _save_config_dialog')]
    ns = {'QComboBox': _CB, 'QCheckBox': _Chk, 'QDoubleSpinBox': _Spin,
          'QSpinBox': _Spin, 'QLineEdit': _Line, 'QDateTimeEdit': type('DT', (), {}),
          '_LC': _LCm, 'QgsProject': _Proj, 'QDateTime': type('QDT', (), {})}
    exec(compile(seg, 'cfg', 'exec'), ns)
    collect, apply_ = ns['_collect_config'], ns['_apply_config']

    class T: pass
    src_tab = T()
    src_tab.combo = _CB(); src_tab.combo.setCurrentIndex(3)
    src_tab.check = _Chk(); src_tab.check.setChecked(True)
    src_tab.spin = _Spin(); src_tab.spin.setValue(0.045)
    src_tab.text = _Line(); src_tab.text.setText('10,25,50,100')
    src_tab.layer = _LCm(_Lyr('MyDEM'))
    src_tab._private = _Line()

    cfg = collect(src_tab)
    ok1 = check("Config collection skips private attributes",
                '_private' not in cfg, f"keys={list(cfg)}")

    dst = T()
    dst.combo = _CB(); dst.check = _Chk(); dst.spin = _Spin()
    dst.text = _Line(); dst.layer = _LCm(None)
    layers['id1'] = _Lyr('MyDEM')
    n, warns = apply_(dst, cfg)
    ok2 = check("Round-trip restores all widget values exactly",
                dst.combo.currentIndex() == 3 and dst.check.isChecked() and
                dst.spin.value() == 0.045 and dst.text.text() == '10,25,50,100' and
                dst.layer.currentLayer().name() == 'MyDEM' and not warns,
                f"applied={n}, warns={warns}")

    layers.clear()
    dst2 = T()
    dst2.combo = _CB(); dst2.check = _Chk(); dst2.spin = _Spin()
    dst2.text = _Line(); dst2.layer = _LCm(None)
    _, warns2 = apply_(dst2, cfg)
    ok3 = check("Missing layer is reported AND other settings still apply",
                any('MyDEM' in w for w in warns2) and dst2.text.text() == '10,25,50,100',
                f"warns={warns2}")

    dst3 = T(); dst3.combo = _CB(n=2)
    _, warns3 = apply_(dst3, {'combo': {'__type__': 'combo', 'value': 3}})
    ok4 = check("Stale combo index is reported, not silently mis-applied",
                any('no longer exists' in w for w in warns3) and
                dst3.combo.currentIndex() == 0, f"warns={warns3}")
    return ok1 and ok2 and ok3 and ok4


def test_sensitivity_elasticity_math():
    """
    Verify the sensitivity analysis's elasticity normalisation and the
    CN-clamping correction, both of which would silently give wrong
    rankings if subtly off.

    Elasticity = mean |%change in output| per |%change in input|, so a
    perfectly proportional response must give exactly 1.0.

    CN is physically capped near 100, so a naive +20% on a high CN would
    clip. If elasticity then divided by the NOMINAL 20% rather than the
    change actually applied, it would understate that parameter's true
    sensitivity — by a factor of ~1.7 at CN=95, enough to mis-rank it.
    """
    perturbation_pct = 20.0
    f = perturbation_pct / 100.0

    baseline = 100.0
    change_lo = 100.0 * (80.0 - baseline) / baseline
    change_hi = 100.0 * (120.0 - baseline) / baseline
    e_prop = (abs(change_lo) + abs(change_hi)) / 2.0 / perturbation_pct
    ok1 = check("Proportional response gives elasticity exactly 1.0",
                abs(e_prop - 1.0) < 1e-9, f"got {e_prop}")

    cn = 95.0
    cn_hi = min(cn * (1 + f), 98.0)
    cn_lo = max(cn * (1 - f), 30.0)
    applied_pct = 100.0 * (abs(cn_hi - cn) + abs(cn - cn_lo)) / (2 * cn)
    ok2 = check("CN perturbation is clamped to physical bounds (<=98)",
                cn_hi <= 98.0 and cn_lo >= 30.0, f"lo={cn_lo}, hi={cn_hi}")
    ok3 = check("Clamped CN reports a SMALLER applied change than the nominal "
                "20% (so elasticity isn't understated)",
                applied_pct < perturbation_pct,
                f"applied={applied_pct:.1f}% vs nominal {perturbation_pct}%")

    cn_mid = 50.0
    applied_mid = 100.0 * (abs(min(cn_mid*(1+f), 98.0) - cn_mid) +
                            abs(cn_mid - max(cn_mid*(1-f), 30.0))) / (2 * cn_mid)
    ok4 = check("Unclamped CN gives exactly the nominal perturbation",
                abs(applied_mid - perturbation_pct) < 1e-9, f"got {applied_mid}")
    return ok1 and ok2 and ok3 and ok4


def test_cwc_suh_physical_behaviour():
    """
    CWC SUH: verify physically correct responses to catchment geometry
    (the coefficients themselves are user-supplied per subzone, so what
    can be verified here is that the equation STRUCTURE responds the
    right way), and that the placeholder-coefficient warning flag is set
    correctly — that flag is what stops someone unknowingly using
    non-subzone-specific numbers for design.
    """
    r_short = hc.cwc_synthetic_unit_hydrograph(100, 20, 10, 0.004)
    r_long  = hc.cwc_synthetic_unit_hydrograph(2000, 90, 45, 0.004)
    ok1 = check("CWC SUH: longer stream gives longer basin lag",
                r_long['tp_hr'] > r_short['tp_hr'],
                f"short={r_short['tp_hr']:.2f}, long={r_long['tp_hr']:.2f}")

    r_flat  = hc.cwc_synthetic_unit_hydrograph(500, 45, 22, 0.001)
    r_steep = hc.cwc_synthetic_unit_hydrograph(500, 45, 22, 0.02)
    ok2 = check("CWC SUH: steeper slope gives shorter basin lag",
                r_steep['tp_hr'] < r_flat['tp_hr'],
                f"flat={r_flat['tp_hr']:.2f}, steep={r_steep['tp_hr']:.2f}")

    ok3 = check("CWC SUH: W50 is wider than W75 (correct width ordering)",
                r_flat['W50_hr'] > r_flat['W75_hr'])

    q = r_flat['discharge_m3s']
    ok4 = check("CWC SUH: hydrograph is non-negative with a single peak",
                np.all(q >= 0) and np.all(np.diff(q[:int(np.argmax(q))+1]) >= -1e-9))

    ok5 = check("CWC SUH: flags when placeholder (non-subzone) coefficients are used",
                r_flat['used_default_coeffs'] is True and
                hc.cwc_synthetic_unit_hydrograph(
                    500, 45, 22, 0.004, coeffs={'Ct': 0.55})['used_default_coeffs'] is False)
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_calibration_metrics_against_known_values():
    """
    Verify each calibration metric against hand-calculable cases,
    including two boundary conditions that would silently give wrong
    answers if the formula were subtly off:
      - NSE must be EXACTLY 0 when the model just predicts the observed
        mean (that's the metric's definitional baseline)
      - PBIAS sign convention: Moriasi et al. (2007) uses sum(O-S)/sum(O),
        so POSITIVE means the model UNDER-estimates. Other published
        sources use the opposite sign, so this is worth pinning down
        explicitly rather than assuming.
    """
    obs = np.array([1.0, 5.0, 10.0, 7.0, 3.0])
    ok1 = check("Perfect match gives NSE=1, PBIAS=0, RMSE=0",
                abs(hc.nash_sutcliffe_efficiency(obs, obs) - 1.0) < 1e-9 and
                abs(hc.percent_bias(obs, obs)) < 1e-9 and
                abs(hc.rmse(obs, obs)) < 1e-9)

    sim_mean = np.full_like(obs, obs.mean())
    ok2 = check("NSE is exactly 0 when the model predicts the observed mean",
                abs(hc.nash_sutcliffe_efficiency(obs, sim_mean)) < 1e-9,
                f"got {hc.nash_sutcliffe_efficiency(obs, sim_mean)}")

    obs3 = np.array([10.0, 10.0, 10.0])
    pb_under = hc.percent_bias(obs3, np.array([8.0, 8.0, 8.0]))
    pb_over = hc.percent_bias(obs3, np.array([12.0, 12.0, 12.0]))
    ok3 = check("PBIAS sign convention: positive = model under-estimates (Moriasi 2007)",
                abs(pb_under - 20.0) < 1e-9 and abs(pb_over + 20.0) < 1e-9,
                f"under={pb_under}, over={pb_over}")

    expected_rmse = np.sqrt(25.0 / 3.0)
    ok4 = check("RMSE matches hand calculation",
                abs(hc.rmse(np.array([0.0, 0.0, 0.0]), np.array([3.0, 4.0, 0.0]))
                     - expected_rmse) < 1e-9)

    ok5 = check("Moriasi performance ratings map to the right thresholds",
                hc.interpret_nse(0.80) == 'Very good' and
                hc.interpret_nse(0.30) == 'Unsatisfactory' and
                hc.interpret_pbias(5) == 'Very good' and
                hc.interpret_pbias(30) == 'Unsatisfactory')
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_hydrograph_comparison():
    """
    Test the full observed-vs-simulated hydrograph comparison, including
    interpolation onto a different time base, correct peak magnitude and
    timing error reporting, and graceful handling of non-overlapping
    records.
    """
    obs_t = np.linspace(0, 24, 25)
    obs_q = 50 * np.exp(-((obs_t - 8) ** 2) / 10)
    sim_t = np.linspace(0, 24, 97)  # deliberately different time base

    r_same = hc.hydrograph_comparison_metrics(
        obs_t, obs_q, sim_t, 50 * np.exp(-((sim_t - 8) ** 2) / 10), _FB())
    ok1 = check("Identical hydrographs on different time bases give NSE~1",
                r_same['NSE'] > 0.99, f"got NSE={r_same['NSE']}")

    r_off = hc.hydrograph_comparison_metrics(
        obs_t, obs_q, sim_t, 65 * np.exp(-((sim_t - 11) ** 2) / 10), _FB())
    ok2 = check("Peak magnitude error correctly reported (+30% case)",
                25 < r_off['peak_magnitude_error_pct'] < 35,
                f"got {r_off['peak_magnitude_error_pct']}")
    ok3 = check("Peak timing error correctly reported (+3hr case)",
                2.5 < r_off['peak_timing_error_hr'] < 3.5,
                f"got {r_off['peak_timing_error_hr']}")
    ok4 = check("Over-estimating model gives negative PBIAS",
                r_off['PBIAS_pct'] < 0, f"got {r_off['PBIAS_pct']}")

    r_none = hc.hydrograph_comparison_metrics([0, 1, 2], [1, 2, 3],
                                               [100, 101, 102], [1, 2, 3], _FB())
    ok5 = check("Non-overlapping records return None rather than nonsense metrics",
                r_none is None, f"got {r_none}")
    return ok1 and ok2 and ok3 and ok4 and ok5



def test_mann_kendall_calibration():
    """
    A well-calibrated statistical test's false-positive rate should
    match its stated alpha under the null hypothesis (no real trend) —
    this is a much stronger correctness check than 'looks plausible',
    since a subtly wrong test statistic or p-value formula would show
    up as a miscalibrated false-positive rate here.
    """
    rng = np.random.default_rng(42)
    false_positives = 0
    n_trials = 100
    for _ in range(n_trials):
        noise = rng.normal(50, 10, 20)
        r = hc.mann_kendall_test(noise, alpha=0.05)
        if r['significant']:
            false_positives += 1
    rate = false_positives / n_trials
    ok1 = check("Mann-Kendall false-positive rate matches alpha=0.05 under the null (no real trend)",
                0.0 <= rate <= 0.15, f"got {rate:.0%} (expect close to 5%)")

    trend_data = np.arange(30) * 2.0 + rng.normal(0, 3, 30) + 50
    r2 = hc.mann_kendall_test(trend_data)
    ok2 = check("Mann-Kendall detects a clear increasing trend",
                r2['trend'] == 'increasing' and r2['significant'], f"got {r2}")
    return ok1 and ok2


def test_grubbs_beck_detects_known_outlier():
    """Grubbs-Beck should flag an obvious low outlier and correctly
    decline to run with too few data points."""
    rng = np.random.default_rng(1)
    clean = rng.lognormal(mean=4.0, sigma=0.3, size=25)
    with_outlier = np.append(clean, 0.5)
    r = hc.grubbs_beck_test(with_outlier)
    ok1 = check("Grubbs-Beck flags an obvious low outlier",
                0.5 in r['low_outliers'], f"got flagged={r['low_outliers']}")
    r2 = hc.grubbs_beck_test(np.array([1, 2, 3, 4, 5]))
    ok2 = check("Grubbs-Beck declines to run with <10 points",
                r2['threshold'] is None, f"got threshold={r2['threshold']}")
    return ok1 and ok2


def test_distribution_selection_jacobian_fix():
    """
    Regression test for a severe bug found during development: AIC
    comparison between Log-Pearson III (fit to log-transformed data)
    and the other distributions (fit to the original data) requires a
    Jacobian correction from the change-of-variables formula — without
    it, LP3's likelihood was systematically and massively overstated
    (~200 AIC points too good), making it always "win" the comparison
    regardless of which distribution the data was actually drawn from.
    Data here is drawn from a TRUE Gumbel distribution; Gumbel should
    win outright or be closely competitive most of the time, not always
    lose to LP3 by an enormous margin.
    """
    from scipy.stats import gumbel_r
    gumbel_wins_or_close = 0
    n_trials = 20
    for i in range(n_trials):
        data = gumbel_r.rvs(loc=50, scale=15, size=25, random_state=i)
        data = data[data > 0]
        _, name, _, comparison = hc.select_best_distribution(data)
        aics = dict(comparison)
        best_aic = min(aics.values())
        gumbel_aic = aics.get('Gumbel (EV1)')
        if 'Gumbel' in name or (gumbel_aic is not None and (gumbel_aic - best_aic) < 6):
            gumbel_wins_or_close += 1
    rate = gumbel_wins_or_close / n_trials
    return check(
        "True-Gumbel data: Gumbel wins or is closely competitive most of the time "
        "(bug made LP3 always win regardless of true distribution)",
        rate >= 0.6, f"got {rate:.0%} (bug produced ~0%)"
    )


def test_bootstrap_ci_scales_with_sample_size():
    """Confidence intervals should be WIDER for smaller samples (more
    honest about the extra uncertainty) and should contain their own
    point estimate."""
    rng = np.random.default_rng(3)
    return_periods = [10, 25, 50, 100]
    data_large = rng.normal(50, 15, 60)
    data_large = np.abs(data_large) + 1
    data_small = data_large[:12]

    r_large = hc.frequency_analysis_with_uncertainty(
        data_large, return_periods, 1, _FB(), n_bootstrap=200, random_state=1)
    r_small = hc.frequency_analysis_with_uncertainty(
        data_small, return_periods, 1, _FB(), n_bootstrap=200, random_state=1)

    width_large = np.mean(r_large['ci_upper'] - r_large['ci_lower'])
    width_small = np.mean(r_small['ci_upper'] - r_small['ci_lower'])
    ok1 = check("Smaller sample gives wider confidence intervals",
                width_small > width_large,
                f"large(n=60)={width_large:.1f}, small(n=12)={width_small:.1f}")

    contained = all(lo <= d <= hi for d, lo, hi in
                     zip(r_large['design'], r_large['ci_lower'], r_large['ci_upper']))
    ok2 = check("Point estimates fall within their own confidence intervals", contained)
    return ok1 and ok2


def test_feh_qmed():
    """
    Verify against FEH's own published worked example: Afon Dwyryd at
    Maentwrog — AREA=78.15 km², SAAR=2212 mm, BFIHOST=0.378 -> QMED≈93.6 m³/s.
    (soil_class here is this plugin's own 1-5 HOST-class simplification,
    not a direct BFIHOST input — we check order of magnitude and that
    SAAR is actually influencing the result, not exact match to the
    published figure, since the plugin's simplified class->BFIHOST
    mapping won't hit 0.378 exactly.)
    """
    result = hc.feh_rainfall_runoff(
        area_km2=78.15, saar_mm=2212, soil_class=3, urbext=0.0,
        slope_percent=5.0, return_period=2, feedback=_FB())
    qmed = result['QMED']

    ok1 = check("FEH QMED is in a plausible range for this catchment (30-300 m3/s)",
                30 < qmed < 300, f"got {qmed:.1f}")

    # SAAR must actually influence QMED now (it didn't before the fix —
    # the parameter was accepted but silently unused).
    result_dry = hc.feh_rainfall_runoff(
        area_km2=78.15, saar_mm=600, soil_class=3, urbext=0.0,
        slope_percent=5.0, return_period=2, feedback=_FB())
    ok2 = check("SAAR actually changes QMED (wasn't used at all before the fix)",
                abs(result['QMED'] - result_dry['QMED']) > 1.0,
                f"wet={result['QMED']:.1f}, dry={result_dry['QMED']:.1f}")

    # Higher SAAR (wetter catchment) should give higher QMED.
    ok3 = check("Higher SAAR gives higher QMED (correct direction)",
                result['QMED'] > result_dry['QMED'])

    return ok1 and ok2 and ok3


def test_abm_none_handling():
    """
    idf_func returning None for a return period that wasn't fit
    previously crashed with TypeError inside the list comprehension,
    long before the (also broken) `depths is None` check was reached.
    """
    def idf_that_returns_none(duration_hr, return_period):
        return None  # simulates an unfit return period

    try:
        t, incr = hc.alternating_block_hyetograph(
            design_rainfall_mm=100.0, duration_hr=6, n_intervals=6,
            idf_func=idf_that_returns_none, return_period=100, feedback=_FB())
        ok = check("alternating_block_hyetograph doesn't crash when idf_func returns None",
                   True)
        ok2 = check("Falls back to sane values (no NaN/negative)",
                    np.all(np.isfinite(incr)) and np.all(incr >= 0))
        return ok and ok2
    except TypeError as e:
        return check("alternating_block_hyetograph doesn't crash when idf_func returns None",
                      False, str(e))


def test_time_to_peak_duration():
    """Tp = tL + D/2 — Tp must actually shift with D, not always add 0.5hr."""
    tp_1hr  = hc.calculate_time_to_peak(3000, 5.0, 75, _FB(), duration_hr=1.0)
    tp_6hr  = hc.calculate_time_to_peak(3000, 5.0, 75, _FB(), duration_hr=6.0)
    tp_24hr = hc.calculate_time_to_peak(3000, 5.0, 75, _FB(), duration_hr=24.0)

    ok1 = check("Tp increases with storm duration", tp_1hr < tp_6hr < tp_24hr,
                f"Tp(1hr)={tp_1hr:.2f}, Tp(6hr)={tp_6hr:.2f}, Tp(24hr)={tp_24hr:.2f}")
    # The difference between any two should be exactly (D2-D1)/2 (only tL
    # differs from the D/2 term, and tL doesn't depend on D).
    expected_diff = (24.0 - 1.0) / 2.0
    actual_diff = tp_24hr - tp_1hr
    ok2 = check("Tp difference matches D/2 exactly",
                abs(actual_diff - expected_diff) < 1e-6,
                f"expected {expected_diff}, got {actual_diff}")
    # Backward-compatible default (duration_hr=1.0) unchanged.
    tp_default = hc.calculate_time_to_peak(3000, 5.0, 75, _FB())
    ok3 = check("Default duration_hr=1.0 matches explicit duration_hr=1.0",
                abs(tp_default - tp_1hr) < 1e-9)
    return ok1 and ok2 and ok3


def test_rational_tc_vs_tp():
    """
    Sanity check on the Tc = Tp/0.6 relationship used at the Modified
    Rational Method call sites (flash_flood_analysis.py,
    standard_flood_analysis.py) — Tc must come out LARGER than Tp (since
    Tp = 0.6*Tc means Tc = Tp/0.6, and 1/0.6 > 1).
    """
    tp_hr = 2.5
    tc_hr_actual = tp_hr / 0.6
    ok = check("Tc (from Tp/0.6) is larger than Tp, not equal to it",
               tc_hr_actual > tp_hr, f"Tp={tp_hr}, Tc={tc_hr_actual:.3f}")
    ok2 = check("Tc/Tp ratio matches the SCS 1/0.6 convention",
                abs(tc_hr_actual / tp_hr - (1.0 / 0.6)) < 1e-9)
    return ok and ok2


def test_2d_routing_mass_conservation():
    """Flat domain, pulse hydrograph: total stored+drained volume should
    match total input volume."""
    import flood_routing_2d as fr
    np.random.seed(0)
    n = 40
    dem = np.zeros((n, n)) + np.random.rand(n, n) * 0.01
    manning = np.full((n, n), 0.05)
    t_h = np.array([0, 600, 1200, 1800, 2400, 3000])
    q_h = np.array([0, 5, 10, 5, 1, 0])
    result = fr.route_2d_diffusive_wave(
        dem, cell_size_m=10.0, manning_grid=manning,
        hydrograph_time_s=t_h, hydrograph_q_cms=q_h,
        source_rc=(n//2, n//2), sim_duration_s=1800,
        max_wall_time_s=30, feedback=_FB())
    ok = check("2D routing mass balance error is near-zero on a flat domain",
               result.mass_balance_error_pct < 1.0,
               f"got {result.mass_balance_error_pct:.2f}%")
    ok2 = check("2D routing produces no NaN/Inf",
                np.all(np.isfinite(result.max_depth[result.max_depth > -9999])))
    return ok and ok2


def test_2d_routing_manning_convergence():
    """Straight channel with known slope/width/n and an open outlet
    should converge close to the analytical Manning's normal depth."""
    import flood_routing_2d as fr
    n_rows, n_cols = 15, 60
    S, n_manning, W_cells, cell_size, Q = 0.001, 0.03, 3, 5.0, 3.0
    W = W_cells * cell_size
    x = np.arange(n_cols) * cell_size
    dem = np.tile(100.0 - S * x, (n_rows, 1))
    mid, half_w = n_rows // 2, W_cells // 2
    for r in range(n_rows):
        if abs(r - mid) > half_w:
            dem[r, :] += 5.0
    manning = np.full((n_rows, n_cols), n_manning)
    outlet_mask = np.zeros((n_rows, n_cols), dtype=bool)
    outlet_mask[mid, n_cols - 1] = True

    result = fr.route_2d_diffusive_wave(
        dem, cell_size_m=cell_size, manning_grid=manning,
        hydrograph_time_s=np.array([0, 100000]), hydrograph_q_cms=np.array([Q, Q]),
        source_rc=(mid, 2), outlet_mask=outlet_mask, sim_duration_s=20000,
        max_wall_time_s=45, max_steps=100000, feedback=_FB())

    h_analytical = (Q * n_manning / (np.sqrt(S) * W)) ** (3.0 / 5.0)
    channel_rows = [r for r in range(n_rows) if abs(r - mid) <= half_w]
    h_sim = np.mean(result.final_depth[channel_rows, n_cols // 2])
    rel_err = 100 * abs(h_sim - h_analytical) / h_analytical

    return check("2D routing converges to analytical Manning's normal depth (<10% error)",
                  rel_err < 10.0,
                  f"analytical={h_analytical:.4f}m, sim={h_sim:.4f}m, error={rel_err:.1f}%")


def test_flow_accumulation_direction_correct():
    """
    Regression test for a severe bug found during development: the
    src/dst index formulas in _flow_accumulation_d8's neighbor-array
    construction were swapped, so every cell compared against the WRONG
    neighbor (its east neighbor's value ending up where its west
    neighbor's should be, etc.) — this silently produced an entirely
    backwards flow-direction field. On a simple valley that slopes
    toward x=0, water should accumulate toward x=0; the buggy version
    gave a max accumulation of 2 (essentially no accumulation happening
    at all) instead of the correct answer approaching the full cell
    count at the true outlet.
    """
    import flood_mapping as fm
    n = 20
    y, x = np.mgrid[0:n, 0:n]
    dem = (100 + 2 * x + 0.5 * np.abs(y - n // 2)).astype(np.float64)
    valid_mask = np.ones((n, n), dtype=bool)

    acc = fm._flow_accumulation_d8(dem, valid_mask)
    outlet_idx = np.unravel_index(np.argmax(acc), acc.shape)

    ok1 = check("Flow accumulation reaches close to full cell count at the true outlet",
                acc.max() > 0.9 * n * n,
                f"max={acc.max()}, expected close to {n*n} (bug gave 2)")
    ok2 = check("Outlet with max accumulation is at the correct location (x=0)",
                outlet_idx[1] == 0, f"got outlet at column {outlet_idx[1]}, expected column 0")
    # Accumulation should DECREASE moving away (upstream) from the outlet
    # along the valley centerline.
    centerline = acc[n // 2, 0:5]
    ok3 = check("Accumulation decreases monotonically moving upstream from the outlet",
                all(centerline[i] >= centerline[i+1] for i in range(len(centerline)-1)),
                f"centerline values={centerline.tolist()}")
    return ok1 and ok2 and ok3


def test_hazard_classification_formula_and_variation():
    """
    Verify the UK Defra/EA Hazard Rating formula (HR = depth*(velocity+0.5)+DF)
    and thresholds (0.75/1.25/2.0) are applied correctly against hand-
    computed values, and that classification genuinely varies with
    terrain/discharge rather than always landing in one class.
    """
    # Hand-computed check against known inputs
    depth, velocity = 0.5, 1.0
    DF = 0.5 if depth <= 0.25 else 1.0
    expected_hr = depth * (velocity + 0.5) + DF
    ok1 = check("Hazard Rating formula matches hand calculation",
                abs(expected_hr - 1.75) < 1e-9, f"got {expected_hr}")

    # Threshold boundaries
    def classify(hr):
        if hr < 0.75: return 1
        if hr < 1.25: return 2
        if hr < 2.0: return 3
        return 4
    ok2 = check("Threshold classification matches expected bands",
                classify(0.5) == 1 and classify(1.0) == 2 and
                classify(1.5) == 3 and classify(2.5) == 4)

    # Genuine variation on gentle terrain across a range of discharges —
    # confirms hazard classification doesn't degenerate to one class
    # regardless of conditions (the specific concern after finding that
    # steep synthetic test terrain gave uniformly "Danger for all").
    import numpy as np_, os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmpdir = tempfile.mkdtemp()
    n = 100
    res = 30.0
    ox, oy = 400000, 2000000
    y, x = np_.mgrid[0:n, 0:n]
    main_slope = 20.0 * (n - x) / n
    cross_valley = 10.0 * np_.abs((y - n / 2) / (n / 2)) ** 1.5
    dem = (600 + main_slope + cross_valley).astype(np_.float32)
    transform = from_origin(ox, oy, res, res)
    crs = 'EPSG:32643'
    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs=crs, transform=transform, nodata=-9999.0)
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as dst:
        dst.write(dem, 1)
    poly = Polygon([(ox, oy), (ox + n * res, oy), (ox + n * res, oy - n * res), (ox, oy - n * res)])
    catch_path = os.path.join(tmpdir, 'catchment.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs=crs).to_file(catch_path, driver='GPKG')

    _, _, fvel, fhaz = fm.generate_flood_map(
        discharge=0.5, dem_path=dem_path, catchment_path=catch_path,
        output_dir=tmpdir, return_period=10, manning_n=0.05, feedback=_FB()
    )
    with rasterio.open(fhaz) as f:
        haz = f.read(1)
    classes_present = set(np_.unique(haz[haz != 255]).tolist()) - {0}
    ok3 = check("Hazard classification produces more than one class on realistic terrain",
                len(classes_present) > 1, f"classes found: {classes_present}")
    return ok1 and ok2 and ok3


def test_flood_mapping_extent_not_overinflated():
    """
    Regression test for the specific bug found in real-world use: local
    depth/extent adjustment based on Manning's n / CN was computed across
    the ENTIRE DEM (not just already-flooded cells), and a mask-extension
    condition was trivially true for roughly half the domain once
    depth_factor > 1.0 — pulling in disconnected low-elevation cells from
    anywhere in the DEM regardless of real connectivity to the outlet.
    In the field, this produced "75.8% of catchment flooded, max depth
    90.92 m" from an 11 m3/s discharge. This test builds a DEM with a
    large elevation range and a disconnected low-elevation patch far from
    the outlet (mimicking the real failure geometry) and checks depth/
    extent stay physically bounded.
    """
    import numpy as np, os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmpdir = tempfile.mkdtemp()
    n = 80
    res = 30.0
    ox, oy = 400000, 2000000

    # DEM: gentle slope toward one corner (the real outlet), PLUS an
    # isolated deep pit far from the outlet with a large elevation drop —
    # exactly the kind of disconnected low point that the old bug would
    # wrongly pull into the flood mask via the trivial extension test.
    y, x = np.mgrid[0:n, 0:n]
    dem = 600.0 + 0.5 * x + 0.3 * y
    dem[5:10, 60:65] -= 90.0  # isolated deep pit, far from the outlet corner
    dem = dem.astype(np.float32)

    transform = from_origin(ox, oy, res, res)
    crs = 'EPSG:32643'
    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs=crs, transform=transform, nodata=-9999.0)
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as dst:
        dst.write(dem, 1)

    poly = Polygon([(ox, oy), (ox + n * res, oy),
                     (ox + n * res, oy - n * res), (ox, oy - n * res)])
    catch_path = os.path.join(tmpdir, 'catchment.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs=crs).to_file(catch_path, driver='GPKG')

    # Varying Manning's n (some cells well above/below the mean) — the
    # ingredient that made depth_factor > 1 trivially true across large
    # areas in the old bug.
    mann = np.random.RandomState(1).uniform(0.03, 0.25, (n, n)).astype(np.float32)
    mann_path = os.path.join(tmpdir, 'mann.tif')
    with rasterio.open(mann_path, 'w', **{**meta, 'nodata': -9999.0}) as dst:
        dst.write(mann, 1)

    png, tif, _fv, _fh = fm.generate_flood_map(
        discharge=11.2, dem_path=dem_path, catchment_path=catch_path,
        output_dir=tmpdir, return_period=10, manning_n=0.05,
        feedback=_FB(), manning_raster_path=mann_path
    )

    with rasterio.open(tif) as f:
        depth = f.read(1)
    valid = depth > -9999
    flooded_pct = 100.0 * np.sum(valid & (depth > 0)) / np.sum(valid)
    max_depth = float(depth[valid].max()) if valid.any() else 0.0

    ok1 = check("Flood extent is not implausibly large for an 11 m3/s discharge (<30% of catchment)",
                flooded_pct < 30.0, f"got {flooded_pct:.1f}% (bug produced 75.8%)")
    ok2 = check("Max flood depth is physically bounded (<10 m, not 90+ m)",
                max_depth < 10.0, f"got {max_depth:.2f} m (bug produced 90.92 m)")
    ok3 = check("The isolated deep pit does NOT show an absurd depth "
                "(HAND treats it as its own local low point, so some bounded "
                "local ponding is expected/reasonable — the bug was UNBOUNDED "
                "depth, not any depth at all)",
                depth[7, 62] < 5.0, f"pit depth = {depth[7, 62]:.2f} m (should be small, not 90.92 m)")
    return ok1 and ok2 and ok3


def test_sink_fill_respects_catchment_mask():
    """
    Regression test for the cause of the ~66% flood extents.

    A catchment is an irregular blob clipped out of a rectangular DEM, so
    everything outside the polygon is nodata. The old code replaced that
    nodata with the catchment MEAN elevation and then ran priority-flood
    seeded from the ARRAY edge. That constant ring is a solid dam right
    round the catchment: every cell below it looks like one giant
    depression with no outlet, so the whole lower catchment gets raised to
    the ring level and comes out dead flat. HAND against a flat surface is
    ~0, so nearly everything floods, and extent stops responding to
    discharge — a 1.9x increase in Q moved real-run extent from 65.8% to
    65.9%.

    Every pre-existing flood-mapping test used a RECTANGULAR catchment
    covering the whole DEM, which has no nodata surround, which is exactly
    why they all passed while real runs were broken. This one uses an
    irregular catchment on purpose.
    """
    import flood_mapping as fm
    n = 120
    yy, xx = np.mgrid[0:n, 0:n].astype(float)

    # Valley draining toward +y, relief ~200 m.
    dem = (700.0 + 3.0 * np.abs(xx - n / 2) - 1.2 * yy).astype(np.float64)

    # Irregular catchment: an ellipse, so the array corners are nodata.
    valid = ((yy - n / 2) / (n * 0.45)) ** 2 + ((xx - n / 2) / (n * 0.42)) ** 2 < 1.0
    dem_masked = np.where(valid, dem, np.nan)
    mean_elev = float(np.nanmean(dem_masked))

    # --- the old behaviour, reproduced explicitly ---
    old = fm._fill_sinks(np.where(valid, dem, mean_elev))
    old_raised = float(np.mean((old[valid] - dem[valid]) > 0.5))

    # --- the fixed behaviour ---
    new = fm._fill_sinks(dem_masked, valid_mask=valid)
    new_raised = float(np.mean((new[valid] - dem[valid]) > 0.5))

    ok1 = check("Unmasked fill on a clipped catchment really does dam it "
                "(guards that this test still exercises the bug)",
                old_raised > 0.25,
                f"only {100*old_raised:.1f}% raised — test no longer reproduces the bug")
    ok2 = check("Masked fill does not dam the catchment behind its nodata surround",
                new_raised < 0.02,
                f"{100*new_raised:.1f}% of cells raised (bug raised {100*old_raised:.1f}%)")
    ok3 = check("Masked fill never lowers terrain",
                bool(np.all(new[valid] >= dem[valid] - 1e-6)))
    ok4 = check("Masked fill leaves the catchment's true low point untouched "
                "(it drains out through the perimeter)",
                abs(float(np.nanmin(new[valid])) - float(np.min(dem[valid]))) < 1e-3,
                f"min {np.min(dem[valid]):.2f} -> {np.nanmin(new[valid]):.2f}")

    # The derived stream network must not swallow the catchment either.
    filled = new
    acc = fm._flow_accumulation_d8(np.where(valid, filled, np.inf), valid)
    cell_km2 = (30.0 ** 2) / 1e6
    total_km2 = float(valid.sum()) * cell_km2
    thr = float(np.clip(0.005 * total_km2, 0.25, 25.0))
    stream = (acc >= max(1, int(thr / cell_km2))) & valid
    ok5 = check("Derived stream network occupies a channel-like fraction of the catchment (<5%)",
                0 < stream.sum() / valid.sum() < 0.05,
                f"{100*stream.sum()/valid.sum():.2f}% of catchment classed as channel")
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_flood_extent_on_irregular_catchment_is_plausible():
    """
    End-to-end version of the above, through generate_flood_map(), on an
    irregular catchment with a nodata surround.

    Checks the two properties the real run violated: extent must be a
    channel/floodplain-scale fraction of the catchment (not ~66%), and it
    must actually RESPOND to discharge (the real run moved 0.1 percentage
    points across a 1.9x range in Q, because extent was being set by the
    fill artefact rather than by the water).
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmpdir = tempfile.mkdtemp()
    n_rows, n_cols, res = 300, 400, 30.0
    ox, oy = 400000.0, 2000000.0
    crs = 'EPSG:32643'

    yy, xx = np.mgrid[0:n_rows, 0:n_cols].astype(float)
    stem_x = n_cols / 2 + 40 * np.sin(yy / 90.0)
    d_stem = np.abs(xx - stem_x)
    d_trib = np.full_like(d_stem, 1e6)
    for k in range(1, 7):
        d_trib = np.minimum(d_trib, np.abs(yy - k * n_rows / 7.0) * 1.4 + 0.25 * d_stem)
    d_ch = np.minimum(d_stem, d_trib)
    dem = (1030.0 - 0.62 * yy + 4.2 * np.sqrt(np.clip(d_ch, 0, None))
           + np.random.RandomState(7).randn(n_rows, n_cols) * 1.5).astype(np.float32)

    meta = dict(driver='GTiff', height=n_rows, width=n_cols, count=1,
                dtype='float32', crs=crs, nodata=-9999.0,
                transform=from_origin(ox, oy, res, res))
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as dst:
        dst.write(dem, 1)

    # Irregular, lobed catchment — leaves nodata in the array corners.
    th = np.linspace(0, 2 * np.pi, 90, endpoint=False)
    rr = 1.0 + 0.13 * np.sin(4 * th) + 0.07 * np.cos(7 * th)
    cx, cy = ox + n_cols * res / 2, oy - n_rows * res / 2
    ax, ay = n_cols * res * 0.44, n_rows * res * 0.46
    poly = Polygon([(cx + ax * rr[i] * np.cos(t), cy + ay * rr[i] * np.sin(t))
                    for i, t in enumerate(th)])
    cat_path = os.path.join(tmpdir, 'catchment.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs=crs).to_file(cat_path, driver='GPKG')

    pcts = []
    for i, Q in enumerate([600.0, 1785.0, 3364.0]):
        _, tif, fvel, _fh = fm.generate_flood_map(
            discharge=Q, dem_path=dem_path, catchment_path=cat_path,
            output_dir=tmpdir, return_period=10 + i, manning_n=0.1294,
            feedback=_FB())
        with rasterio.open(tif) as f:
            depth = f.read(1)
        with rasterio.open(fvel) as f:
            vel = f.read(1)
        valid = depth > -9999
        pcts.append(100.0 * np.sum(valid & (depth > 0)) / np.sum(valid))
        max_vel = float(vel[valid].max())

    ok1 = check("Flood extent on an irregular catchment stays channel/floodplain-scale (<25%)",
                all(p < 25.0 for p in pcts),
                f"extents={['%.1f%%' % p for p in pcts]} (bug produced ~66% at every Q)")
    ok2 = check("Flood extent actually responds to discharge (>1.3x across a 5.6x Q range)",
                pcts[0] > 0 and pcts[-1] / max(pcts[0], 1e-9) > 1.3,
                f"extents={['%.1f%%' % p for p in pcts]} (bug moved 65.8%% -> 65.9%%)")
    ok3 = check("Velocity is not pinned to the 10 m/s safety clamp",
                max_vel < 9.99, f"max velocity = {max_vel:.2f} m/s")
    return ok1 and ok2 and ok3


def test_channel_slope_from_long_profile():
    """
    Regression test for the channel-slope estimator, on terrain whose
    true main-stem slope is known by construction.

    Two failure modes this guards against, both of which produced wrong
    depths in real runs (depth ~ S^-0.3, so slope errors go straight into
    flood extent):

      1. Gradient MAGNITUDE at stream cells. Has no sign and is dominated
         by the cross-valley section, so it measures the valley walls
         rather than the fall along the channel. On a real 2577 km²
         catchment it returned 0.091 against a true main-stem slope near
         0.003 — a 30x overestimate, which via sqrt(S) inflated Manning's
         velocity ~5.5x and drove the hazard classification to "Danger
         for all" across most of the catchment.

      2. Median per-cell D8 drop. The baseline is one cell; over 30 m the
         1 mm epsilon left by depression filling swamps the real fall, so
         wherever filling has flattened the valley the median lands on the
         flats. Measured at native resolution with 11% of cells filled: it
         returned 0.00010 and depth blew up from 3.3 m to 16.4 m.

    S1085 over the traced long profile uses a baseline of ~75% of the
    whole flow path, which is immune to both.
    """
    import flood_mapping as fm
    n = 200
    cell = 30.0
    yy, xx = np.mgrid[0:n, 0:n].astype(float)

    # Channel runs straight down column n/2, falling at a KNOWN 1.5% along
    # its length. Valley walls are deliberately much steeper (20%) so that
    # any estimator measuring across the section instead of along it gives
    # a badly wrong answer.
    true_slope = 0.015
    dem = (900.0
           - true_slope * cell * yy                 # along-channel fall
           + 0.20 * cell * np.abs(xx - n / 2))      # cross-valley rise
    valid = np.ones((n, n), dtype=bool)

    # A flat-bottomed depression partway down the channel, so filling has
    # to leave an epsilon-flat stretch behind — the trap for the per-cell
    # median.
    dem[90:130, int(n / 2) - 1:int(n / 2) + 2] = dem[130, int(n / 2)]

    filled = fm._fill_sinks(dem, valid_mask=valid)
    acc, fdr, fdc, ht = fm._flow_accumulation_d8(filled, valid, return_dirs=True)

    # Stream network: cells draining more than ~1% of the grid. The trace
    # must stop at the top of this, not carry on up the hillslope.
    stream = (acc >= 0.01 * valid.sum()) & valid

    est = fm._main_stem_slope(filled, dem, valid, acc, fdr, fdc, ht, cell,
                               stream_mask=stream)

    ok1 = check("Main-stem slope is recovered from a known long profile (within 25%)",
                est is not None and abs(est - true_slope) / true_slope < 0.25,
                f"estimated {est}, true {true_slope}")

    # Without the stream-network stop the trace runs past the channel head
    # and up the valley wall, which is the bug this guards.
    unbounded = fm._main_stem_slope(filled, dem, valid, acc, fdr, fdc, ht, cell)
    ok2 = check("Tracing past the channel head really does corrupt the slope "
                "(guards that this test still exercises the bug)",
                unbounded is not None and unbounded > 2.0 * true_slope,
                f"unbounded trace gave {unbounded}, true {true_slope}")

    ok3 = check("Estimated slope lies inside the plausible clamp range, so the "
                "clamp is not what is setting the answer",
                est is not None and 1e-3 < est < 0.10, f"estimated {est}")

    # The epsilon-filled stretch must not be what sets the answer either.
    n_filled = int(np.sum((filled - dem) > 1e-6))
    ok4 = check("Depression fill did leave an epsilon-flat stretch in the channel "
                "(guards that this test still exercises the per-cell-median bug)",
                n_filled > 50, f"only {n_filled} cells filled")
    return ok1 and ok2 and ok3 and ok4


def test_pour_point_delineation():
    """
    Pour-point snapping, upstream catchment delineation, longest flow path
    and S1085, on terrain whose answers are known by construction.

    The failure this mainly guards is the snap. A pour point a few cells
    off the modelled channel sits on a hillslope, and the "catchment"
    delineated from it is the handful of cells draining that facet.
    Measured here: the same point delineates 0.08 km² unsnapped and
    36.0 km² snapped — a factor of 425. A user clicking a basemap, or
    pasting a lat/lon out of a report, will essentially never land exactly
    on the DEM's channel.

    Also guards the S1085 definition. Slope must be measured along the
    MAIN STREAM, not the longest flow path: the longest flow path
    correctly begins at the catchment divide and so includes the hillslope
    reach above the channel head, which is far steeper than any channel.
    On this DEM, whose channel slope is 1.5% by construction, taking
    S1085 along the longest flow path returns 0.060 — 4x too high.
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import pour_point_catchment as ppc

    tmpdir = tempfile.mkdtemp()
    n, res = 200, 30.0
    ox, oy = 400000.0, 2000000.0
    yy, xx = np.mgrid[0:n, 0:n].astype(float)

    true_slope = 0.015
    # V-valley: channel down column n/2, falling at a known 1.5%, valley
    # walls at a much steeper 20% so the two slope definitions diverge.
    dem = (900.0 - true_slope * res * yy + 0.20 * res * np.abs(xx - n / 2))
    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs='EPSG:32643', nodata=-9999.0,
                transform=from_origin(ox, oy, res, res))
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as d:
        d.write(dem.astype(np.float32), 1)

    def xy(row, col):
        return ox + res * (col + 0.5), oy - res * (row + 0.5)

    # Point ON the channel at the outlet.
    px, py = xy(n - 1, n // 2)
    r = ppc.delineate_from_pour_point(dem_path, px, py,
                                       os.path.join(tmpdir, 'on'), feedback=_FB())

    whole_grid_km2 = n * n * res * res / 1e6
    ok1 = check("Catchment from an outlet on the main channel captures the whole basin",
                abs(r['area_km2'] - whole_grid_km2) / whole_grid_km2 < 0.01,
                f"{r['area_km2']:.3f} km² vs {whole_grid_km2:.3f}")

    ok2 = check("S1085 is measured along the stream and recovers the known channel slope",
                r['s1085'] is not None and abs(r['s1085'] - true_slope) / true_slope < 0.05,
                f"S1085={r['s1085']}, true={true_slope}")

    # Longest flow path must reach the divide, so it is LONGER than the
    # straight channel — it includes the hillslope reach.
    ok3 = check("Longest flow path extends past the channel head to the divide",
                r['flow_path_m'] > n * res * 1.05,
                f"path={r['flow_path_m']:.0f} m, channel alone={n*res:.0f} m")

    # Point 6 cells off the channel, on the valley wall.
    ox_, oy_ = xy(n - 1, n // 2 + 6)
    unsnapped_area = None
    try:
        r_un = ppc.delineate_from_pour_point(
            dem_path, ox_, oy_, os.path.join(tmpdir, 'un'),
            snap_radius_cells=0, feedback=None)
        unsnapped_area = r_un['area_km2']
    except ValueError:
        unsnapped_area = 0.0
    r_sn = ppc.delineate_from_pour_point(
        dem_path, ox_, oy_, os.path.join(tmpdir, 'sn'),
        snap_radius_cells=10, feedback=_FB())

    ok4 = check("An unsnapped off-channel point really does delineate a hillslope "
                "(guards that this test still exercises the bug)",
                unsnapped_area < 0.1 * whole_grid_km2,
                f"unsnapped gave {unsnapped_area} km² of {whole_grid_km2}")
    ok5 = check("Snapping recovers the full catchment from an off-channel point",
                abs(r_sn['area_km2'] - whole_grid_km2) / whole_grid_km2 < 0.01,
                f"{r_sn['area_km2']:.3f} km², moved {r_sn['snap_moved_cells']:.1f} cells")

    # Two adjacent basins: membership must not leak across the divide.
    d2 = np.minimum(np.abs(xx - n / 4), np.abs(xx - 3 * n / 4))
    dem2 = (900.0 - true_slope * res * yy + 0.20 * res * d2)
    dem2_path = os.path.join(tmpdir, 'two.tif')
    with rasterio.open(dem2_path, 'w', **meta) as d:
        d.write(dem2.astype(np.float32), 1)
    lx, ly = xy(n - 1, n // 4)
    r_two = ppc.delineate_from_pour_point(dem2_path, lx, ly,
                                           os.path.join(tmpdir, 'two'), feedback=_FB())
    ok6 = check("Delineation does not leak across a divide into the neighbouring basin",
                abs(r_two['area_km2'] - whole_grid_km2 / 2) / (whole_grid_km2 / 2) < 0.05,
                f"{r_two['area_km2']:.3f} km² vs half-grid {whole_grid_km2/2:.3f}")

    # A catchment draining to one point cannot contain holes.
    import geopandas as gpd
    g = gpd.read_file(r['catchment_gpkg'])
    ok7 = check("Catchment polygon is a single hole-free part",
                len(g) == 1 and len(g.geometry.iloc[0].interiors) == 0,
                f"{len(g)} feature(s), "
                f"{len(g.geometry.iloc[0].interiors) if len(g) else '?'} hole(s)")

    return ok1 and ok2 and ok3 and ok4 and ok5 and ok6 and ok7


def test_pour_point_rejects_geographic_crs():
    """
    A DEM in degrees must be refused outright, not silently used.

    Cell size feeds directly into catchment area, flow path length and
    slope. On a geographic DEM a "cell" is ~0.00027 degrees, so area comes
    out around 1e-8 km² and the slope is elevation-over-degrees. Every
    number downstream would be wrong by orders of magnitude while looking
    perfectly well-formed, which is worse than an error.
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import pour_point_catchment as ppc

    tmpdir = tempfile.mkdtemp()
    meta = dict(driver='GTiff', height=60, width=60, count=1, dtype='float32',
                crs='EPSG:4326', nodata=-9999.0,
                transform=from_origin(74.0, 17.0, 0.001, 0.001))
    p = os.path.join(tmpdir, 'geo.tif')
    yy, xx = np.mgrid[0:60, 0:60].astype(float)
    with rasterio.open(p, 'w', **meta) as d:
        d.write((500 - yy + np.abs(xx - 30)).astype(np.float32), 1)

    raised = False
    msg = ""
    try:
        ppc.delineate_from_pour_point(p, 74.03, 16.97, os.path.join(tmpdir, 'o'))
    except ValueError as e:
        raised = True
        msg = str(e)

    ok1 = check("Geographic-CRS DEM is refused rather than silently mis-scaled", raised)
    ok2 = check("The refusal says what to do about it",
                'projected' in msg.lower() and ('utm' in msg.lower() or 'tab 1' in msg.lower()),
                f"message was: {msg[:120]}")
    return ok1 and ok2


def test_scs_lag_extrapolation_warning():
    """
    The NRCS lag equation must say so when it is being extrapolated.

    NEH-4 Ch.15 calibrated tL = L^0.8 (S+1)^0.7 / (1900 Y^0.5) on small
    agricultural watersheds — L up to about 24,000 ft (7.3 km), roughly
    8 km² of drainage area. Nothing in the formula stops it running far
    outside that, and lag grows as L^0.8 without bound, so on a large
    catchment it quietly returns a time to peak longer than the design
    storm. A real 2577 km² run gave L=180 km, tL=21.3 hr, Tp=33.3 hr
    against a 24-hr storm: the storm finishes before the unit hydrograph
    peaks, the computed peak is heavily attenuated, and nothing in the
    output said so. The arithmetic was right; the silence was the bug.
    """
    import hydrological_calculations as hc

    class Cap:
        def __init__(self): self.info, self.warn = [], []
        def pushInfo(self, m): self.info.append(str(m))
        def pushWarning(self, m): self.warn.append(str(m))
        def reportError(self, m, fatalError=False): self.warn.append(str(m))
        def setProgress(self, v): pass

    # Inside the valid range: 5 km flow path, no extrapolation warning.
    small = Cap()
    tp_small = hc.calculate_time_to_peak(5000.0, 5.0, 70, small, duration_hr=6.0)
    warned_small = any('extrapolat' in w.lower() for w in small.warn)
    ok1 = check("A catchment inside the lag equation's range is not warned about",
                not warned_small, f"warnings: {small.warn}")

    # The real case: 180 km flow path on a 24-hr storm.
    big = Cap()
    tp_big = hc.calculate_time_to_peak(180386.0, 11.68, 69, big, duration_hr=24.0)
    warn_text = ' '.join(big.warn).lower()

    ok2 = check("Extrapolating the lag equation ~25x past its range is warned about",
                'extrapolat' in warn_text, f"warnings: {big.warn}")
    ok3 = check("The warning quantifies how far past the range it has gone",
                '24000' in warn_text.replace(',', '') or '24,000' in warn_text,
                f"warnings: {big.warn}")
    ok4 = check("Tp exceeding the storm duration is called out separately",
                tp_big > 24.0 and ('storm' in warn_text and 'attenuat' in warn_text),
                f"Tp={tp_big:.1f} hr vs 24 hr storm; warnings: {big.warn}")
    ok5 = check("The warning names a usable alternative method",
                'clark' in warn_text or 'snyder' in warn_text,
                f"warnings: {big.warn}")

    # Slope outside 0.5-30% is also outside calibration.
    flat = Cap()
    hc.calculate_time_to_peak(5000.0, 0.05, 70, flat, duration_hr=6.0)
    ok6 = check("Slope outside the calibrated 0.5-30% range is warned about",
                any('slope' in w.lower() for w in flat.warn),
                f"warnings: {flat.warn}")

    ok7 = check("The lag equation still returns a usable number rather than failing",
                tp_small > 0 and tp_big > 0,
                f"Tp small={tp_small}, Tp big={tp_big}")
    return ok1 and ok2 and ok3 and ok4 and ok5 and ok6 and ok7


def test_pour_point_option_wired_into_both_flood_algorithms():
    """
    The pour-point catchment method has to be reachable from the UI, with
    every parameter the algorithms read actually being sent.

    This is the class of bug where a parameter dict drifts from the
    algorithm's registered parameters: the option appears in the combo
    box, the user picks it, and it silently behaves as the default because
    the key never arrives (or arrives under a name nothing reads).
    """
    # Source-text checks, not imports: these modules import qgis.core,
    # which isn't available in a bare test environment. The existing
    # UI/algorithm parameter test takes the same approach.
    src_dlg = open('rain2flood_dialog.py').read()
    oks = []

    for fname, name in (('flash_flood_analysis.py', 'FlashFloodAnalysis'),
                        ('standard_flood_analysis.py', 'StandardFloodAnalysis')):
        src = open(fname).read()

        oks.append(check(
            f"{name}: registers a SNAP_RADIUS parameter",
            "SNAP_RADIUS        = 'SNAP_RADIUS'" in src
            and 'self.SNAP_RADIUS' in src))
        oks.append(check(
            f"{name}: offers the pour-point option in Catchment Input Method",
            'auto-delineate' in src.lower()))
        oks.append(check(
            f"{name}: actually branches on the pour-point option",
            '== 2' in src and 'resolve_catchment_from_pour_point' in src))
        oks.append(check(
            f"{name}: maps the pour-point method onto the GIS-layer path "
            f"for parameter extraction rather than leaving it as method 2",
            'if catchment_input == 2 else' in src or 'if cat_input == 2 else' in src))
        oks.append(check(
            f"{name}: overrides the longest flow path with the traced D8 path",
            "pp_result['flow_path_m']" in src))

    oks.append(check(
        "Dialog sends SNAP_RADIUS for both flood tabs",
        src_dlg.count("'SNAP_RADIUS'") == 2,
        f"found {src_dlg.count(chr(39) + 'SNAP_RADIUS' + chr(39))}"))
    oks.append(check(
        "Dialog's catchment group offers the third method",
        'auto-delineate' in src_dlg.lower()))
    oks.append(check(
        "Dialog's catchment group builds the snap widget the dict reads",
        "r['snap']" in src_dlg and "c['snap'].value()" in src_dlg))

    # The pour point group must be built before the catchment group in
    # both tabs — it defines the analysis, so it belongs at the top.
    for cls_name in ('FlashFloodTab', 'StandardFloodTab'):
        i = src_dlg.index(f'class {cls_name}(')
        j = src_dlg.index('class ', i + 10)
        body = src_dlg[i:j]
        pp_at = body.find("gpp,fpp=_grp('Pour Point")
        cat_at = body.find('_cat_grp()')
        oks.append(check(
            f"{cls_name}: pour point section comes before the catchment section",
            pp_at != -1 and cat_at != -1 and pp_at < cat_at,
            f"pour point at {pp_at}, catchment at {cat_at}"))

    return all(oks)


def test_dem_slope_catchment_is_optional():
    """
    Tab 1 must not require a catchment boundary.

    Requiring it was circular: Tab 2 delineates the catchment FROM Tab 1's
    output, and Tabs 4/5 now delineate it from a pour point. It was also
    actively harmful for delineation, because flow accumulation on a
    clipped raster truncates upstream contributing area at the clip edge,
    so cells near the boundary get an accumulation that is too low and the
    derived stream network is wrong there.

    Also checks the ordering fix: slope must be computed before any clip,
    since Horn's method needs all eight neighbours and a cell on a clip
    boundary would otherwise take its slope from missing data.
    """
    src = open('dem_slope_processing.py').read()
    src_dlg = open('rain2flood_dialog.py').read()

    ok1 = check("DEM & Slope registers CATCHMENT as optional",
                'self.CATCHMENT,' in src and 'optional=True' in src)
    ok2 = check("DEM & Slope guards every catchment use behind a None check",
                'if catchment_layer is not None' in src
                and 'if catch_crs_gdf is not None' in src)

    # Slope must be computed before the clip.
    slope_at = src.find('_slope_horn(')
    clip_at = src.find('Step 4b')
    ok3 = check("Slope is computed BEFORE the catchment clip, so boundary "
                "cells keep real neighbours in Horn's method",
                slope_at != -1 and clip_at != -1 and slope_at < clip_at,
                f"slope at {slope_at}, clip at {clip_at}")

    ok4 = check("Dialog no longer blocks the run when no catchment is chosen",
                "'Select a DEM and an output folder.'" in src_dlg)
    ok5 = check("Dialog sends None rather than an empty source when unset",
                "if self.cat.currentLayer() else None" in src_dlg)
    ok6 = check("DEM-extent statistics are flagged as not being catchment "
                "statistics when no polygon is supplied",
                'DEM EXTENT, not a catchment' in src)
    return ok1 and ok2 and ok3 and ok4 and ok5 and ok6


def test_auto_entries_and_optional_catchments():
    """
    'Auto' dropdown entries and the two now-optional catchment inputs.

    The 'Auto' entries are a trap if they are only cosmetic. QGIS's
    QgsMapLayerComboBox returns None from currentLayer() for an additional
    (non-layer) item, which is indistinguishable from an empty combo, so
    an 'Auto' selection that isn't explicitly detected silently sends an
    empty catchment path and the run fails complaining about a missing
    boundary — while the UI plainly reads 'Auto'. Selecting either Auto
    entry must therefore force the pour-point method regardless of what
    the method combo says.

    Tab 2 requiring a catchment boundary was circular (delineating the
    catchment is what that tab is for) and harmful: cropping to a boundary
    truncates upstream contributing area at the clip edge, so the derived
    stream network is wrong near it.
    """
    src_dlg = open('rain2flood_dialog.py').read()
    src_sub = open('subcatchment_delineation.py').read()
    oks = []

    oks.append(check(
        "Layer combo wrapper can hold a non-layer 'Auto' entry",
        'def setAutoItem' in src_dlg and 'setAdditionalItems' in src_dlg))
    oks.append(check(
        "An 'Auto' selection is distinguishable from an empty combo",
        'def isAuto' in src_dlg and 'currentText() == t' in src_dlg))
    oks.append(check(
        "Both the catchment AND flow-path dropdowns offer an Auto entry",
        src_dlg.count('.setAutoItem(') == 2,
        f"found {src_dlg.count('.setAutoItem(')}"))
    oks.append(check(
        "Selecting either Auto entry forces the pour-point method",
        'def _cat_method_index' in src_dlg
        and "c['cat'].isAuto() or c['fp'].isAuto()" in src_dlg))
    oks.append(check(
        "Both flood tabs route their method through that resolver",
        src_dlg.count("'CATCHMENT_INPUT':_cat_method_index(c)") == 2,
        f"found {src_dlg.count(chr(39) + 'CATCHMENT_INPUT' + chr(39) + ':_cat_method_index(c)')}"))
    oks.append(check(
        "An Auto selection sends an empty layer path, not a stale source",
        'def _cat_source' in src_dlg
        and src_dlg.count("_cat_source(c['cat'])") == 2
        and src_dlg.count("_cat_source(c['fp'])") == 2))

    # Tab 2
    oks.append(check(
        "Sub-basin delineation registers CATCHMENT as optional",
        'optional=True' in src_sub
        and 'leave empty to delineate the whole DEM' in src_sub))
    oks.append(check(
        "Delineation guards every catchment use behind a None check",
        'if catchment_layer is not None' in src_sub
        and 'if catch_gdf is not None' in src_sub
        and 'if catch_union is not None' in src_sub))
    oks.append(check(
        "Delineation falls back to the DEM's own bounds for the crop window",
        'transform_bounds(' in src_sub and '_src_b.bounds' in src_sub))
    oks.append(check(
        "Tab 2 dialog no longer blocks the run when no catchment is chosen",
        'Please select a catchment boundary layer.' not in src_dlg))
    oks.append(check(
        "Tab 2 dialog sends None rather than an empty source when unset",
        "(cat_layer.source() if cat_layer else None)" in src_dlg))
    return all(oks)


def test_theme_is_self_consistent():
    """
    The theme must actually resolve, and must not leave light-theme
    remnants that turn into glare on a dark surface.

    Also guards two rendering traps found by actually rendering the
    dialog rather than reading the CSS:

    1. Qt reads '&' in tab and button text as a mnemonic marker, so
       '1. DEM & Slope' renders as '1. DEM _Slope'. Pre-existing, and
       visible in the tab bar the whole time.
    2. A CSS triangle (zero-sized box with coloured borders) does not
       render in Qt's stylesheet box model — it produces a small filled
       square. And styling a QSpinBox at all stops Qt drawing its native
       palette-coloured arrow, so the subcontrol cannot simply be left
       alone either. Real image assets are the only thing that works.
    """
    import os
    import re
    src = open('rain2flood_dialog.py').read()
    here = os.path.dirname(os.path.abspath('rain2flood_dialog.py'))

    blk = src[src.index('TRANSLUCENT = False'):src.index('# ── Themed callouts')]
    blk = blk.replace('os.path.dirname(os.path.abspath(__file__))', repr(here))
    ns = {'os': os}
    ok_exec = True
    try:
        exec(blk, ns)
    except Exception as e:
        ok_exec = False
        ns = {'GLOBAL_STYLE': ''}
    ok1 = check("Theme block evaluates and builds a stylesheet",
                ok_exec and len(ns.get('GLOBAL_STYLE', '')) > 2000)

    unresolved = re.findall(r'\{[A-Z_][A-Z_0-9]*\}', ns.get('GLOBAL_STYLE', ''))
    ok2 = check("Stylesheet has no unresolved placeholders",
                not unresolved, f"unresolved: {unresolved}")

    # ── Contrast, measured rather than eyeballed ──────────────────────
    # A hex blacklist was the wrong test: it only ever catches colours
    # someone thought to list, and it says nothing about whether the
    # result is readable. WCAG relative luminance answers the actual
    # question. AA wants 4.5:1 for body text and 3:1 for UI/large text.
    # The log matters most here — it is long diagnostic output that gets
    # read carefully, not decoration.
    def _lum(h):
        h = h.lstrip('#')
        c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        c = [v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
             for v in c]
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]

    def _ratio(a, b):
        la, lb = _lum(a), _lum(b)
        la, lb = max(la, lb), min(la, lb)
        return (la + 0.05) / (lb + 0.05)

    g = ns.get
    pairs = [
        ('body text on a card',        g('TEXT'),      g('SURFACE'),   4.5),
        ('body text on the window',    g('TEXT'),      g('BG'),        4.5),
        ('dim text on a card',         g('TEXT_DIM'),  g('SURFACE'),   4.5),
        ('faint text on a card',       g('TEXT_FAINT'), g('SURFACE'),  4.5),
        ('dim text on the window',     g('TEXT_DIM'),  g('BG'),        4.5),
        ('faint text on the window',   g('TEXT_FAINT'), g('BG'),       4.5),
        ('accent text on the window',  g('ACCENT_DEEP'), g('BG'),      4.5),
        ('text on an accent-soft chip', g('ACCENT_DEEP'), g('ACCENT_SOFT'), 4.5),
        ('dim text on a hover surface', g('TEXT_DIM'), g('SURFACE_3'),  4.5),
        ('label on the accent fill',   g('ON_ACCENT'), g('ACCENT'),    4.5),
        ('label on accent hover',      g('ON_ACCENT'), g('ACCENT_DEEP'), 4.5),
        ('group-box title on a card',  g('ACCENT_DEEP'), g('SURFACE'), 4.5),
        ('log body text',              g('LOG_TEXT'),  g('LOG_BG'),    4.5),
        ('log secondary text',         g('LOG_DIM'),   g('LOG_BG'),    4.5),
        ('log section header',         g('LOG_HEAD'),  g('LOG_BG'),    4.5),
        ('log warnings',               g('LOG_WARN'),  g('LOG_BG'),    4.5),
        ('log errors',                 g('LOG_ERROR'), g('LOG_BG'),    4.5),
        ('log success',                g('LOG_OK'),    g('LOG_BG'),    4.5),
        ('semantic button text',       g('ACCENT2'),   g('SURFACE'),   4.5),
        ('warning button text',        g('WARN'),      g('SURFACE'),   4.5),
        ('danger button text',         g('DANGER'),    g('SURFACE'),   4.5),
    ]
    failures = []
    for label, fg, bg, need in pairs:
        if not fg or not bg:
            failures.append(f'{label}: token missing')
            continue
        r = _ratio(fg, bg)
        if r < need:
            failures.append(f'{label}: {r:.2f}:1 (need {need})')
    ok3 = check("Every text/background pair meets WCAG AA contrast",
                not failures, '; '.join(failures))

    # Callout bodies sit on their own tint, so check those too.
    call = re.search(r'_CALLOUT = \{(.+?)\n\}', src, re.S)
    call_fail = []
    if call:
        for kind, edge, fill, fg in re.findall(
                r"'(\w+)':\s*\((\w+|None),\s*'([^']+)',\s*'?([#\w]+)'?\)",
                call.group(1)):
            if fill.startswith('#') and fg.startswith('#'):
                r = _ratio(fg, fill)
                if r < 4.5:
                    call_fail.append(f'{kind}: {r:.2f}:1')
    ok3b = check("Callout text meets AA against its own tint",
                 not call_fail, '; '.join(call_fail))
    ok3 = ok3 and ok3b

    ok4 = check("Ampersands in tab and button text are escaped for Qt mnemonics",
                "'1. DEM && Slope'" in src
                and "'2. Streams && Sub-basins'" in src
                and "Run Streams && Sub-basin Delineation" in src)

    ok5 = check("Arrow and tick glyphs use image assets, not CSS border triangles",
                'url({_CHEV_DOWN})' in src and 'url({_CHECK})' in src
                and 'border-top: 5px solid' not in src)

    missing = [n for n in ('r2f_chevron_down.png', 'r2f_chevron_up.png',
                           'r2f_chevron_down_hi.png', 'r2f_chevron_up_hi.png',
                           'r2f_check.png')
               if not os.path.exists(os.path.join('icons', n))]
    ok6 = check("Every glyph asset the stylesheet references exists",
                not missing, f"missing: {missing}")

    ok7 = check("Stylesheet icon paths use forward slashes on every platform",
                "replace('\\\\\\\\', '/')" in src or '.replace(' in src)

    ok8 = check("Real window translucency is opt-in, not the default",
                'TRANSLUCENT = False' in src and 'if TRANSLUCENT:' in src)

    # Every theme token referenced in an f-string brace must exist. A
    # stylesheet referencing a token that was renamed raises NameError at
    # import, which takes the whole plugin down before the dialog opens —
    # and a token referenced only inside a {} placeholder is invisible to
    # any check that only walks ast.Name nodes.
    import ast as _ast
    try:
        exec(src[src.index('_CALLOUT = {'):src.index('def _note(')], ns)
    except Exception:
        pass
    defined = {k for k in ns}
    tree = _ast.parse(src)
    assigned = {n.targets[0].id for n in _ast.walk(tree)
                if isinstance(n, _ast.Assign) and n.targets
                and isinstance(n.targets[0], _ast.Name)}
    imported = set()
    for n in _ast.walk(tree):
        if isinstance(n, (_ast.Import, _ast.ImportFrom)):
            for al in n.names:
                imported.add(al.asname or al.name.split('.')[0])
    # Walk the f-string nodes rather than regexing the source: a literal
    # '{TILE}' inside ordinary help text (a filename pattern shown to the
    # user) is not a placeholder, and a regex cannot tell the difference.
    braced = set()
    for n in _ast.walk(tree):
        if isinstance(n, _ast.JoinedStr):
            for part in n.values:
                if isinstance(part, _ast.FormattedValue):
                    for sub in _ast.walk(part.value):
                        if isinstance(sub, _ast.Name) and re.fullmatch(
                                r'[A-Z][A-Z_0-9]*', sub.id):
                            braced.add(sub.id)
    unknown = sorted(braced - defined - assigned - imported)
    ok9 = check("Every theme token used in an f-string placeholder is defined",
                not unknown, f"undefined: {unknown}")

    # Log severities must be visually distinct from one another, not just
    # from the background — an error the same colour as a warning is no
    # better than an unreadable one.
    sev = [ns.get('LOG_TEXT'), ns.get('LOG_WARN'),
           ns.get('LOG_ERROR'), ns.get('LOG_OK'), ns.get('LOG_HEAD')]
    ok10 = check("Log severity colours are all distinct",
                 len({c for c in sev if c}) == len([c for c in sev if c]),
                 f"duplicates among {sev}")

    # ACCENT_FILL is a decorative fill only — at 2.78:1 on white it is far
    # below AA and must never be used as a text colour. Easy mistake to
    # make, since it sits next to ACCENT2 in the palette and looks similar.
    fill = ns.get('ACCENT_FILL')
    misuse = []
    if fill:
        for ln_no, ln in enumerate(src.split('\n'), 1):
            if 'ACCENT_FILL' in ln and 'color:' in ln and 'background' not in ln:
                misuse.append(ln_no)
    ok11 = check("The decorative fill colour is never used as text",
                 not misuse, f"used as text at line(s) {misuse}")

    # The log palette was explicitly asked to stay put across theme
    # changes, so pin the values rather than trusting a future edit.
    ok12 = check("Log colours are unchanged by the theme swap",
                 ns.get('LOG_BG') == '#FFFFFF' and ns.get('LOG_TEXT') == '#1A1A1E'
                 and ns.get('LOG_WARN') == '#8A5200'
                 and ns.get('LOG_ERROR') == '#B3261E'
                 and ns.get('LOG_OK') == '#1B5E20',
                 f"log tokens are {[ns.get(k) for k in ('LOG_BG','LOG_TEXT','LOG_WARN','LOG_ERROR','LOG_OK')]}")

    ok13 = check("Window background is the requested #F2EFE7",
                 ns.get('BG') == '#F2EFE7', f"BG is {ns.get('BG')}")

    # The tooltip bug: stylesheet alone is not enough, the palette must be
    # set too (QToolTip is a top-level window).
    # The stylesheet and the palette must agree. QToolTip is a top-level
    # window and Qt resolves its foreground from QPalette.ToolTipText
    # before any stylesheet 'color' — so if the two disagree, whichever
    # one the platform honours wins and the other silently does nothing.
    ok14 = check("Tooltip colours are set through the palette as well as the stylesheet",
                 '_install_tooltip_palette' in src
                 and 'ToolTipText' in src
                 and 'background-color: {TOOLTIP_BG}' in src
                 and 'color: {TOOLTIP_FG}' in src
                 and 'pal.setColor(base_role, QColor(TOOLTIP_BG))' in src
                 and 'pal.setColor(text_role, QColor(TOOLTIP_FG))' in src)

    ok15 = check("Tooltip text is readable on its own background",
                 _ratio(ns.get('TOOLTIP_FG', '#000'),
                        ns.get('TOOLTIP_BG', '#fff')) >= 4.5,
                 f"{_ratio(ns.get('TOOLTIP_FG','#000'), ns.get('TOOLTIP_BG','#fff')):.2f}:1")

    # Everything typed into or picked from must be white with black text:
    # browse bars, spin boxes, dropdowns open and closed, and the log.
    ok16 = check("Inputs, dropdowns and the log are white with black text",
                 ns.get('INPUT_BG') == '#FFFFFF' and ns.get('INPUT_FG') == '#000000'
                 and 'background: {INPUT_BG}' in src
                 and 'QComboBox QAbstractItemView {{\n    background: {INPUT_BG}' in src)
    ok17 = check("Inputs are not tinted on hover (reads as half-disabled)",
                 'QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, '
                 'QDateTimeEdit:hover {{\n    background: {INPUT_BG};' in src)
    return (ok1 and ok2 and ok3 and ok4 and ok5 and ok6 and ok7
            and ok8 and ok9 and ok10 and ok11 and ok12 and ok13 and ok14
            and ok15 and ok16 and ok17)


def test_no_unscoped_qt_enums_outside_compat_shims():
    """
    Every Qt enum access must be scoped, or sit inside a try/except
    AttributeError compat shim.

    QGIS 4.x runs on PyQt6, where enums are scoped: Qt5's QFrame.NoFrame
    is QFrame.Shape.NoFrame, Qt.AlignCenter is
    Qt.AlignmentFlag.AlignCenter, and so on. PyQt6 removed the unscoped
    aliases outright, so an unscoped access does not warn — it raises
    AttributeError and takes the whole dialog down at construction time.

    This is exactly what happened on QGIS 4.2: a single QFrame.NoFrame
    added while restyling the scroll areas made the plugin fail to open
    with 'type object QFrame has no attribute NoFrame'. Nothing caught it
    because the theme tests are static text checks and the render harness
    runs on PyQt5, where the unscoped name still exists.

    The plugin already had a working shim pattern (try scoped / except
    AttributeError: unscoped). This test enforces that every new enum
    access uses it, since the failure mode is total and the offscreen
    harness will never reproduce it.
    """
    import ast
    import os

    QT_CLASSES = {
        'Qt', 'QFrame', 'QHeaderView', 'QAbstractItemView', 'QMessageBox',
        'QFileDialog', 'QPalette', 'QSizePolicy', 'QDialog', 'QLineEdit',
        'QTabWidget', 'QLayout', 'QFont', 'QPainter', 'QDialogButtonBox',
        'QSlider', 'QToolButton', 'QComboBox', 'QTableWidget',
        'QAbstractScrollArea', 'QFormLayout', 'QValidator',
    }
    # Scoped enum CONTAINERS — 'Qt.AlignmentFlag' is the scope, not a value.
    SCOPES = {
        'TextFormat', 'AlignmentFlag', 'WindowType', 'Shape', 'Shadow',
        'ResizeMode', 'EditTrigger', 'StandardButton', 'Icon', 'ButtonRole',
        'CursorShape', 'WidgetAttribute', 'ItemFlag', 'Orientation',
        'ItemDataRole', 'Policy', 'ScrollBarPolicy', 'FocusPolicy',
        'ContextMenuPolicy', 'KeyboardModifier', 'MouseButton', 'PenStyle',
        'BrushStyle', 'GlobalColor', 'ColorRole', 'ColorGroup', 'Weight',
        'FieldGrowthPolicy', 'State', 'TickPosition', 'ToolButtonStyle',
        'TabPosition', 'DialogCode', 'EchoMode', 'AspectRatioMode',
        'TransformationMode', 'DateFormat', 'TimeSpec', 'SortOrder',
        'CheckState', 'ConnectionType', 'LayoutDirection', 'FileMode',
        'AcceptMode', 'SelectionBehavior', 'SelectionMode', 'RenderHint',
    }

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.hits = []
            self._shielded = 0

        def visit_Try(self, node):
            # A handler naming AttributeError (or a bare except) is the
            # compat-shim pattern; anything inside is intentional.
            shields = any(
                h.type is None
                or (isinstance(h.type, ast.Name) and h.type.id == 'AttributeError')
                or (isinstance(h.type, ast.Tuple)
                    and any(isinstance(e, ast.Name) and e.id == 'AttributeError'
                            for e in h.type.elts))
                for h in node.handlers)
            if shields:
                self._shielded += 1
                for child in node.body:
                    self.visit(child)
                self._shielded -= 1
                for h in node.handlers:
                    self._shielded += 1
                    for child in h.body:
                        self.visit(child)
                    self._shielded -= 1
                for child in node.orelse + node.finalbody:
                    self.visit(child)
            else:
                self.generic_visit(node)

        def visit_Attribute(self, node):
            if (self._shielded == 0
                    and isinstance(node.value, ast.Name)
                    and node.value.id in QT_CLASSES
                    and node.attr
                    and node.attr[0].isupper()
                    and node.attr not in SCOPES):
                self.hits.append((node.lineno, f'{node.value.id}.{node.attr}'))
            self.generic_visit(node)

    offenders = []
    for fname in sorted(os.listdir('.')):
        if not fname.endswith('.py') or fname.startswith('test_'):
            continue
        try:
            tree = ast.parse(open(fname, encoding='utf-8').read())
        except SyntaxError as e:
            offenders.append((fname, 0, f'SYNTAX ERROR: {e}'))
            continue
        v = Visitor()
        v.visit(tree)
        for lineno, expr in v.hits:
            offenders.append((fname, lineno, expr))

    ok1 = check("No unscoped Qt enum access outside a compat shim "
                "(breaks the whole dialog on QGIS 4 / PyQt6)",
                not offenders,
                '; '.join(f'{f}:{l} {e}' for f, l, e in offenders[:8]))

    # The shim itself must cover both directions for everything it defines.
    dlg = open('rain2flood_dialog.py').read()
    shim = dlg[dlg.index('# Qt6 / Qt5 enum compatibility'):dlg.index('#  THEME')]
    try_part, except_part = shim.split('except AttributeError:')
    defined_try = {ln.split('=')[0].strip() for ln in try_part.split('\n')
                   if '=' in ln and ln.strip().startswith('_')}
    defined_exc = {ln.split('=')[0].strip() for ln in except_part.split('\n')
                   if '=' in ln and ln.strip().startswith('_')}
    ok2 = check("Compat shim defines the same names on both the Qt6 and Qt5 paths",
                defined_try == defined_exc,
                f"only Qt6: {sorted(defined_try - defined_exc)}, "
                f"only Qt5: {sorted(defined_exc - defined_try)}")

    # The AST lint above already proves no unscoped access escapes a shim;
    # this just confirms the shimmed names are the ones actually in use at
    # the two call sites, rather than being defined and then ignored.
    ok3 = check("Scroll areas and the translucency attribute use shimmed names",
                's.setFrameShape(_QFrame_NoFrame)' in dlg
                and 'self.setAttribute(_Qt_Translucent, True)' in dlg)
    return ok1 and ok2 and ok3


def test_flood_volume_budget_is_enforced():
    """
    Mapped flood water must not exceed the water the storm produced.

    Nothing upstream enforced this. Depth comes from Manning's normal
    depth in a channel of regime width W = 3*sqrt(Q), and that depth is
    then used as a HAND threshold across a valley that can be kilometres
    wide. When Q is small the regime width collapses — Q = 4.7 m3/s gives
    W = 6.5 m — while the valley it is spread across does not, so a
    trickle gets rendered as a metres-deep, tens-of-km2 flood.

    A real run produced 34.4 Mm3 of mapped flood water from an event that
    generated 0.42 Mm3 of runoff: a ratio of 82. Earlier runs on the same
    tool showed 6.9, 5.6, 5.0 and 4.5. The consistency check existed and
    warned every single time, and nothing acted on it, so maps went out
    with the warning buried in the log.

    Peak instantaneous floodplain storage is bounded above by total event
    runoff volume — in reality well below it, since water leaves the
    outlet throughout — so capping at the full runoff volume is generous
    and only bites when the result is physically impossible.
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmpdir = tempfile.mkdtemp()
    n_r, n_c, res = 400, 480, 30.0
    ox, oy = 400000.0, 2000000.0
    yy, xx = np.mgrid[0:n_r, 0:n_c].astype(float)

    # Broad, flat-bottomed valley — the geometry that makes a small
    # discharge spread absurdly far when depth is applied as a threshold.
    dem = (560.0 - 0.0004 * res * yy
           + 0.9 * np.sqrt(np.clip(np.abs(xx - n_c / 2) - 50, 0, None))
           + np.random.RandomState(4).randn(n_r, n_c) * 0.25)

    meta = dict(driver='GTiff', height=n_r, width=n_c, count=1, dtype='float32',
                crs='EPSG:32643', nodata=-9999.0,
                transform=from_origin(ox, oy, res, res))
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as d:
        d.write(dem.astype(np.float32), 1)

    th = np.linspace(0, 2 * np.pi, 80, endpoint=False)
    cx, cy = ox + n_c * res / 2, oy - n_r * res / 2
    poly = Polygon([(cx + n_c * res * 0.46 * np.cos(t),
                     cy + n_r * res * 0.46 * np.sin(t)) for t in th])
    cat_path = os.path.join(tmpdir, 'c.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs='EPSG:32643').to_file(
        cat_path, driver='GPKG')

    # The real failing case: tiny runoff depth, non-trivial discharge.
    _, tif, _, _ = fm.generate_flood_map(
        discharge=4.7, dem_path=dem_path, catchment_path=cat_path,
        output_dir=tmpdir, return_period=10, manning_n=0.1394,
        feedback=_FB(), runoff_depth_mm=0.18)
    with rasterio.open(tif) as f:
        depth = f.read(1)
    valid = depth > -9999
    cell_area = res * res
    mapped_m3 = float(np.sum(depth[valid & (depth > 0)])) * cell_area
    budget_m3 = (0.18 / 1000.0) * float(np.sum(valid)) * cell_area

    ok1 = check("Mapped flood volume does not exceed the event's runoff volume",
                mapped_m3 <= budget_m3 * 1.05,
                f"mapped {mapped_m3/1e6:.3f} Mm³ vs budget {budget_m3/1e6:.3f} Mm³ "
                f"(ratio {mapped_m3/max(budget_m3,1e-9):.1f})")

    # Without the cap the same terrain must blow the budget, otherwise
    # this test is not exercising anything.
    _, tif2, _, _ = fm.generate_flood_map(
        discharge=4.7, dem_path=dem_path, catchment_path=cat_path,
        output_dir=tmpdir, return_period=11, manning_n=0.1394,
        feedback=_FB(), runoff_depth_mm=None)
    with rasterio.open(tif2) as f:
        d2 = f.read(1)
    v2 = d2 > -9999
    uncapped_m3 = float(np.sum(d2[v2 & (d2 > 0)])) * cell_area
    ok2 = check("Uncapped depths really do blow the volume budget "
                "(guards that this test still exercises the bug)",
                uncapped_m3 > 5 * budget_m3,
                f"uncapped {uncapped_m3/1e6:.3f} Mm³ vs budget {budget_m3/1e6:.3f} Mm³")

    ok3 = check("A volume-capped map still produces a non-empty extent",
                np.any(valid & (depth > 0)))

    # The slope floor must allow genuinely flat alluvial rivers. A real
    # 2355 km² catchment measured S1085 = 2.3e-4 over a 138 km main stem
    # and the old 1e-3 floor overrode it on every return period.
    src = open('flood_mapping.py').read()
    ok4 = check("Channel-slope floor allows flat alluvial rivers (1e-4, not 1e-3)",
                'np.clip(channel_slope, 1e-4, 0.10)' in src)
    return ok1 and ok2 and ok3 and ok4


def test_subbasins_are_clipped_to_the_catchment():
    """
    Sub-basin routing must only use sub-basins inside the catchment.

    Tab 2 now delineates the whole DEM rather than a user-supplied
    boundary — correct for the stream network, since clipping truncates
    upstream contributing area at the clip edge. But it means
    sub_basins.gpkg covers the entire DEM, and load_subbasins took every
    polygon in the layer with no spatial filter.

    Observed on a real run: 258 sub-basins totalling 8155 km² routed to
    the outlet of a 2355 km² catchment — 3.5x the contributing area. The
    semi-distributed peak came out 432% above the lumped one and the log
    attributed that to sub-basin timing, which is exactly the kind of
    plausible-looking wrong answer that gets believed.
    """
    import os, tempfile
    import geopandas as gpd
    from shapely.geometry import Polygon, box
    from subbasin_routing import load_subbasins

    tmpdir = tempfile.mkdtemp()
    crs = 'EPSG:32643'
    ox, oy = 400000.0, 2000000.0

    # Catchment: a 30 x 30 km square = 900 km².
    cat = box(ox, oy, ox + 30000, oy + 30000)
    cat_path = os.path.join(tmpdir, 'cat.gpkg')
    gpd.GeoDataFrame({'geometry': [cat]}, crs=crs).to_file(cat_path, driver='GPKG')

    # Sub-basins tiling a 60 x 60 km area = 3600 km², i.e. 4x the
    # catchment, as a whole-DEM delineation would.
    subs = []
    for i in range(6):
        for j in range(6):
            subs.append(box(ox + i * 10000, oy + j * 10000,
                            ox + (i + 1) * 10000, oy + (j + 1) * 10000))
    sub_path = os.path.join(tmpdir, 'subs.gpkg')
    gpd.GeoDataFrame({'Name': [f'S{k+1}' for k in range(len(subs))],
                      'geometry': subs}, crs=crs).to_file(sub_path, driver='GPKG')

    unclipped = load_subbasins(sub_path, (ox, oy), feedback=None)
    clipped = load_subbasins(sub_path, (ox, oy),
                             catchment_path=cat_path, feedback=_FB())

    area_un = sum(r['area_km2'] for r in unclipped)
    area_cl = sum(r['area_km2'] for r in clipped)

    ok1 = check("Unclipped loading really does pull in the whole layer "
                "(guards that this test still exercises the bug)",
                abs(area_un - 3600.0) < 1.0, f"{area_un:.1f} km² of 3600")
    ok2 = check("Clipped sub-basin area matches the catchment area",
                abs(area_cl - 900.0) < 1.0, f"{area_cl:.1f} km² of 900")
    ok3 = check("Sub-basins draining outside the catchment are dropped",
                len(clipped) < len(unclipped),
                f"{len(clipped)} kept of {len(unclipped)}")

    # No catchment supplied must warn rather than silently over-route.
    class Cap:
        def __init__(self): self.warn = []
        def pushInfo(self, m): pass
        def pushWarning(self, m): self.warn.append(str(m))
        def reportError(self, m, fatalError=False): self.warn.append(str(m))
        def setProgress(self, v): pass
    cap = Cap()
    load_subbasins(sub_path, (ox, oy), feedback=cap)
    ok4 = check("Loading without a catchment warns that the peak may be inflated",
                any('catchment' in w.lower() and 'clip' in w.lower()
                    for w in cap.warn), f"warnings: {cap.warn}")

    src_ff = open('flash_flood_analysis.py').read()
    src_sf = open('standard_flood_analysis.py').read()
    ok5 = check("Both flood algorithms pass the catchment through to the clip",
                'catchment_path=catchment_path' in src_ff
                and 'catchment_path=catchment_path' in src_sf)
    return ok1 and ok2 and ok3 and ok4 and ok5


def test_flow_path_is_one_continuous_linestring():
    """
    The longest flow path must be a single-part LineString whose vertices
    are contiguous D8 steps, and a truncated trace must say so.

    Two separate things get confused here, so both are checked.

    GEOMETRY: every vertex is one D8 step from the last, so no gap can
    exceed one diagonal cell. A future routing change that started
    emitting jumps would still load as one feature and still look like a
    river on the map, which is why this is asserted rather than assumed.

    COMPLETENESS: the trace can stop early — at a cell with no downstream
    neighbour (an unresolved pit on a flat valley floor) or in a routing
    loop. The result is still one continuous line and still looks
    entirely plausible, but it is SHORT, and its length feeds SCS lag and
    every time-of-concentration estimate downstream. It must be flagged,
    not silently returned.

    Note on appearance: the layer used to be styled with a dashed line.
    On a 150 km path at map scale a dash pattern reads as a broken line,
    and a gap landing near a confluence looks exactly like a routing
    failure at that junction. The geometry was correct the whole time.
    It is now solid with a white casing, and QGIS render-time
    simplification is disabled, since that can visibly drop vertices at
    tight bends on a several-thousand-vertex line.
    """
    import os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import pour_point_catchment as ppc

    tmpdir = tempfile.mkdtemp()
    n, res = 500, 30.0
    ox, oy = 400000.0, 2000000.0
    yy, xx = np.mgrid[0:n, 0:n].astype(float)

    # Dendritic network with a meandering main stem and 13 tributaries —
    # plenty of junctions for the trace to pass through.
    stem = n / 2 + 60 * np.sin(yy / 100.0)
    d = np.abs(xx - stem)
    for k in range(1, 14):
        d = np.minimum(d, np.abs(yy - k * n / 14.0) * 1.3 + 0.22 * np.abs(xx - stem))
    dem = (1000.0 - 0.35 * yy + 3.4 * np.sqrt(np.clip(d, 0, None))
           + np.random.RandomState(5).randn(n, n) * 1.1)

    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs='EPSG:32643', nodata=-9999.0,
                transform=from_origin(ox, oy, res, res))
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as f:
        f.write(dem.astype(np.float32), 1)

    th = np.linspace(0, 2 * np.pi, 90, endpoint=False)
    cx, cy = ox + n * res / 2, oy - n * res / 2
    gpd.GeoDataFrame({'geometry': [Polygon(
        [(cx + n * res * 0.45 * np.cos(t), cy + n * res * 0.46 * np.sin(t))
         for t in th])]}, crs='EPSG:32643').to_file(
        os.path.join(tmpdir, 'c.gpkg'), driver='GPKG')

    px = ox + res * (n // 2 + 0.5)
    py = oy - res * (n - 1 + 0.5)
    r = ppc.delineate_from_pour_point(dem_path, px, py,
                                       os.path.join(tmpdir, 'o'), feedback=_FB())

    g = gpd.read_file(r['flow_path_gpkg'])
    geom = g.geometry.iloc[0]

    ok1 = check("Flow path is a single-part LineString, not a MultiLineString",
                len(g) == 1 and geom.geom_type == 'LineString',
                f"{len(g)} feature(s), type {geom.geom_type}")

    coords = np.asarray(geom.coords)
    steps = np.hypot(np.diff(coords[:, 0]), np.diff(coords[:, 1]))
    max_allowed = res * np.sqrt(2.0) * 1.01
    n_gaps = int(np.sum(steps > max_allowed))
    ok2 = check("Every vertex is one D8 step from the last — no gaps at junctions",
                n_gaps == 0,
                f"{n_gaps} gap(s), worst {steps.max():.1f} m "
                f"(one diagonal cell = {res*np.sqrt(2):.1f} m)")

    ok3 = check("Geometry length matches the traced flow-path length",
                abs(geom.length - r['flow_path_m']) < 1.0,
                f"geometry {geom.length:.1f} m vs reported {r['flow_path_m']:.1f} m")

    ok4 = check("Flow path carries vertex count and a completeness flag",
                'Vertices' in g.columns and 'Complete' in g.columns
                and g['Complete'].iloc[0] == 'yes',
                f"columns {list(g.columns)}")

    # A trace that cannot reach the outlet must be reported, not returned
    # quietly. Drive longest_flow_path with a flow graph whose links are
    # cut partway down.
    class Cap:
        def __init__(self): self.warn = []
        def pushInfo(self, m): pass
        def pushWarning(self, m): self.warn.append(str(m))
        def reportError(self, m, fatalError=False): self.warn.append(str(m))
        def setProgress(self, v): pass

    rows = cols = 12
    mask = np.ones((rows, cols), dtype=bool)
    # Every cell drains straight down column 0; sever the link at row 5.
    nxt = np.arange(rows * cols, dtype=np.int64)
    dist = np.zeros((rows, cols))
    for rr in range(rows - 1):
        for cc in range(cols):
            if cc == 0:
                nxt[rr * cols] = (rr + 1) * cols
            dist[rr, cc] = (rows - 1 - rr) * res
    nxt[5 * cols] = 5 * cols          # the break
    from rasterio.transform import from_origin as _fo
    cap = Cap()
    coords2, len2, _, reached = ppc.longest_flow_path(
        mask, dist, nxt, (rows - 1) * cols, _fo(ox, oy, res, res), feedback=cap)
    ok5 = check("A trace that cannot reach the outlet is reported as incomplete",
                reached is False
                and any('INCOMPLETE' in w or 'incomplete' in w.lower()
                        for w in cap.warn),
                f"reached={reached}, warnings={cap.warn}")

    src = open('pour_point_catchment.py').read()
    ok6 = check("Flow path is styled solid with a casing, not dashed",
                "'line_style': 'dash'" not in src
                and 'QgsSimpleLineSymbolLayer' in src
                and 'NoSimplification' in src)
    return ok1 and ok2 and ok3 and ok4 and ok5 and ok6


def test_palettes_version_and_credits():
    """
    Raster palettes match the supplied codes exactly, the version is 3.0
    everywhere, and the credit links are real links.

    The palettes are asserted character-for-character against the values
    as supplied. A colour ramp is the kind of thing that gets "tidied"
    by a later edit — one hex nudged for aesthetics — and nothing would
    catch it, because a slightly wrong ramp still renders.

    Version strings are checked across every module because they had
    genuinely drifted: at one point the plugin menu said v2, the window
    title said v3, the delineation log said v3.7 and the About tab said
    v3.13, all in the same install.
    """
    import os
    import re
    import ui_palettes as up

    oks = []

    # ── Supplied palettes, verbatim ───────────────────────────────────
    expected = {
        'CN_RAMP': ['#00FFFF', '#00BFFF', '#1E90FF', '#0000FF', '#7FFF00',
                    '#32CD32', '#008000', '#006400', '#FFFF00', '#FFD700',
                    '#FFA500', '#FF0000', '#FF00FF', '#8B008B'],
        'LULC_RAMP': ['#001f4d', '#0a3d8f', '#1565c0', '#1e88e5', '#29b6f6',
                      '#80deea', '#a5d6a7', '#ffee58', '#ff7043', '#d32f2f',
                      '#7b0000'],
        'MANNING_RAMP': ['#000099', '#0033CC', '#3380F2', '#99CCFF', '#E6F2FF',
                         '#FFFFFF', '#FFF2E6', '#FFB280', '#FF4C1A', '#CC0000',
                         '#8C0000'],
        'DEM_RAMP': ['#d9e5d6', '#6dc6dc', '#00a7e1', '#77c3c3', '#eddea4',
                     '#f2bf8b', '#f5b07f', '#f7a072', '#fb9e5a', '#ff9b42'],
    }
    for name, want in expected.items():
        got = getattr(up, name, None)
        oks.append(check(f"{name} matches the supplied colour codes exactly",
                         got == want,
                         f"got {got}"))

    # Direction matters and is easy to get backwards. The DEM palette's
    # hot end (#ff9b42) is its HIGH end, so slope must use it in the SAME
    # direction — reversed, it painted flat ground orange and the steepest
    # terrain pale green. Caught by rendering the legend, not by reading
    # the code.
    oks.append(check("Slope ramp runs the same direction as the DEM ramp, "
                     "so steep terrain gets the hot colour",
                     up.SLOPE_RAMP == list(up.DEM_RAMP)
                     and up.SLOPE_RAMP[-1] == '#ff9b42'
                     and up.SLOPE_RAMP[0] == '#d9e5d6',
                     f"ends are {up.SLOPE_RAMP[0]} -> {up.SLOPE_RAMP[-1]}"))

    # ── ramp_items behaviour ──────────────────────────────────────────
    items = up.ramp_items(30.0, 100.0, up.CN_RAMP)
    oks.append(check("A ramp spans the full requested range",
                     len(items) == len(up.CN_RAMP)
                     and abs(items[0][0] - 30.0) < 1e-9
                     and abs(items[-1][0] - 100.0) < 1e-9,
                     f"{len(items)} stops, {items[0][0]} to {items[-1][0]}"))
    oks.append(check("A constant raster collapses to one stop "
                     "instead of dividing by zero",
                     len(up.ramp_items(5.0, 5.0, up.DEM_RAMP)) == 1))
    oks.append(check("An empty palette yields no stops rather than raising",
                     up.ramp_items(0, 1, []) == []))

    # ── Discrete quantile classification ──────────────────────────────
    # The reported symptom was "I only see 3-4 colours". Cause: an
    # interpolated ramp stretched linearly between a raster's min and max
    # only shows its full range if values are spread evenly across it, and
    # real rasters are not. A DEM sitting mostly at 560-660 m but touching
    # 1030 m at one peak spends most of the palette on ground that barely
    # exists; slope is worse, being strongly right-skewed. Equal-count
    # breaks put the same number of cells in each class, so every colour
    # appears.
    class _Stats:
        def __init__(s, lo, hi): s.minimumValue, s.maximumValue = lo, hi

    class _Hist:
        def __init__(s, v): s.histogramVector = v

    class _Prov:
        def __init__(s, arr): s.a = arr
        def bandStatistics(s, b, *a):
            return _Stats(float(s.a.min()), float(s.a.max()))
        def histogram(s, b, bins, lo, hi):
            c, _ = np.histogram(s.a, bins=bins, range=(lo, hi))
            return _Hist(list(c))

    class _Layer:
        def __init__(s, arr): s._p = _Prov(arr)
        def dataProvider(s): return s._p
        def name(s): return 'test'

    rng = np.random.RandomState(0)
    # Shaped like the user's real catchment: DEM 528-1029, mean 639.
    dem = np.concatenate([rng.normal(620, 35, 120000),
                          rng.normal(800, 90, 8000),
                          rng.normal(990, 25, 600)])
    slope = np.abs(rng.gamma(1.4, 6.0, 120000))
    cn = rng.normal(68.1, 5.5, 120000).clip(30, 100)

    for label, arr, pal in (('DEM', dem, up.DEM_RAMP),
                            ('slope', slope, up.SLOPE_RAMP),
                            ('CN', cn, up.CN_RAMP)):
        items = up.discrete_items(_Layer(arr), pal)
        cols = {c for _, c, _ in items}
        oks.append(check(
            f"{label}: every palette colour is used on realistically "
            f"skewed data",
            len(cols) == len(pal),
            f"{len(cols)} of {len(pal)} colours across {len(items)} classes"))
        vals = [v for v, _, _ in items]
        oks.append(check(f"{label}: class bounds ascend",
                         all(b > a for a, b in zip(vals, vals[1:])),
                         f"{vals}"))

    # A raster with only a handful of distinct values (Manning's n derived
    # from land cover is one value per class) cannot have more classes than
    # it has values. It must degrade to that count rather than inventing
    # empty classes or collapsing to one.
    mann = rng.choice([0.035, 0.05, 0.10, 0.1394, 0.20, 0.30], 120000,
                      p=[.1, .35, .25, .15, .1, .05])
    m_items = up.discrete_items(_Layer(mann), up.MANNING_RAMP, fmt='{:.3f}')
    oks.append(check("A few-valued raster gets one class per value, "
                     "each a distinct colour",
                     2 <= len(m_items) <= 8
                     and len({c for _, c, _ in m_items}) == len(m_items),
                     f"{len(m_items)} classes, "
                     f"{len({c for _, c, _ in m_items})} colours"))

    # Near-constant raster: must not divide by zero or emit one giant class.
    flat = np.full(5000, 42.0)
    oks.append(check("A constant raster produces no classes rather than raising",
                     up.discrete_items(_Layer(flat), up.DEM_RAMP) == []))

    # ── Official land-cover class colours ─────────────────────────────
    # Two 10 m schemes are supported and their code ranges overlap while
    # meaning different things. Value 10 is Clouds in the Esri product and
    # Tree cover in ESA WorldCover, so applying one table to the other's
    # raster paints forest dark grey — while looking entirely plausible.
    esri_expected = {
        1: ('#419bdf', 'Water'), 2: ('#397d49', 'Trees'),
        4: ('#7a87c6', 'Flooded Vegetation'), 5: ('#e49635', 'Crops'),
        7: ('#c4281b', 'Built Area'), 8: ('#a59b8f', 'Bare Ground'),
        9: ('#a8ebff', 'Snow/Ice'), 10: ('#616161', 'Clouds'),
        11: ('#e3e2c3', 'Rangeland'),
    }
    oks.append(check("Esri 10m LULC colours match the published table exactly",
                     up.ESRI_LULC_CLASSES == esri_expected,
                     f"got {up.ESRI_LULC_CLASSES}"))
    # Verified against the official v200 Map Class Table (Google Earth
    # Engine catalogue for ESA/WorldCover/v200, Microsoft Planetary
    # Computer, ESA PUM v2.0 — all three agree). Pinned by value, not just
    # by key set: a table with the right codes and a wrong colour would
    # otherwise pass while mislabelling every map the plugin produces.
    esa_official = {
        10: '#006400', 20: '#ffbb22', 30: '#ffff4c', 40: '#f096ff',
        50: '#fa0000', 60: '#b4b4b4', 70: '#f0f0f0', 80: '#0064c8',
        90: '#0096a0', 95: '#00cf75', 100: '#fae6a0',
    }
    got = {k: v[0] for k, v in up.ESA_WORLDCOVER_CLASSES.items()}
    oks.append(check("ESA WorldCover colours match the official v200 "
                     "Map Class Table, all 11 classes",
                     got == esa_official,
                     f"differs at {[k for k in esa_official if got.get(k) != esa_official[k]]}"))
    oks.append(check("ESA labels name the classes as ESA names them",
                     up.ESA_WORLDCOVER_CLASSES[10][1] == 'Tree cover'
                     and up.ESA_WORLDCOVER_CLASSES[80][1] == 'Permanent water bodies'
                     and up.ESA_WORLDCOVER_CLASSES[95][1] == 'Mangroves'))
    oks.append(check("The two schemes genuinely collide on value 10 "
                     "(guards that this distinction still matters)",
                     up.ESRI_LULC_CLASSES[10][1] == 'Clouds'
                     and up.ESA_WORLDCOVER_CLASSES[10][1] == 'Tree cover'))

    # The declared dataset must win over code sniffing.
    sch, _ = up.detect_lulc_scheme([10, 20, 30], declared='ESA')
    oks.append(check("A declared ESA dataset is treated as ESA", sch == 'esa'))
    sch, _ = up.detect_lulc_scheme([1, 2, 5, 10], declared='ESRI')
    oks.append(check("A declared Esri dataset is treated as Esri", sch == 'esri'))
    sch, _ = up.detect_lulc_scheme([10, 20, 40, 80])
    oks.append(check("Codes above 11 are detected as ESA without a declaration",
                     sch == 'esa'))
    sch, _ = up.detect_lulc_scheme([1, 2, 5, 7, 11])
    oks.append(check("Esri codes are detected as Esri without a declaration",
                     sch == 'esri'))

    # Colours must come out attached to the right classes.
    items, sch = up.lulc_items([10, 20, 50, 80], declared='ESA')
    by_val = {v: (c, l) for v, c, l in items}
    oks.append(check("ESA tree cover renders dark green, not the Esri cloud grey",
                     by_val[10][0] == '#006400' and 'Tree' in by_val[10][1],
                     f"value 10 -> {by_val[10]}"))
    items, sch = up.lulc_items([1, 2, 7, 10], declared='ESRI')
    by_val = {v: (c, l) for v, c, l in items}
    oks.append(check("Esri value 10 renders as cloud grey with a Clouds label",
                     by_val[10][0] == '#616161' and by_val[10][1].endswith('Clouds'),
                     f"value 10 -> {by_val[10]}"))
    oks.append(check("Unknown class codes yield no scheme rather than a wrong one",
                     up.lulc_items([201, 202, 203])[0] is None))

    # Esri classes need CN/Manning parameters or the colours are decorative.
    import cn_lulc_manager as cl
    oks.append(check("Esri classes have CN and Manning's parameters",
                     hasattr(cl, 'ESRI_LULC_TO_PARAMS')
                     and set(cl.ESRI_LULC_TO_PARAMS) ==
                     set(up.ESRI_LULC_CLASSES) - {10}))
    oks.append(check("Esri 'Clouds' is deliberately absent from the CN table "
                     "(it is missing data, not land cover)",
                     10 not in getattr(cl, 'ESRI_LULC_TO_PARAMS', {})))
    dlg_src0 = open('rain2flood_dialog.py').read()
    # Both lookup tables must know about Esri. One builds the CN raster,
    # the other Manning's n — registering in only one would produce a CN
    # raster read from the Esri table and a Manning's raster read from the
    # ESA fallback, i.e. two rasters describing the same ground under
    # different class meanings. This is exactly what happened on the first
    # attempt: one site was patched, the other silently was not.
    cl_src = open('cn_lulc_manager.py').read()
    oks.append(check("Esri is registered in BOTH the CN and Manning's lookups",
                     cl_src.count("'ESRI':") == 2,
                     f"found {cl_src.count(chr(39)+'ESRI'+chr(39)+':')} of 2"))

    oks.append(check("The Esri dataset is selectable and maps to the right key",
                     "'ESA','ESRI','NLCD','CORINE','MODIS'" in dlg_src0
                     and 'Esri 10m Annual LULC' in dlg_src0))

    oks.append(check("Rasters render DISCRETE, not interpolated, by default",
                     'interpolated=False' in open('ui_palettes.py').read()))
    dlg_src = open('rain2flood_dialog.py').read()
    oks.append(check("CN and Manning's are no longer pinned to a fixed range "
                     "that the data never fills",
                     '_apply_fixed_ramp' not in dlg_src))

    # ── Version consistency ───────────────────────────────────────────
    stale = []
    version_pat = re.compile(r'Rain2Flood\s+v(\d+(?:\.\d+)*)')
    for fname in sorted(os.listdir('.')):
        if not fname.endswith('.py') or fname.startswith('test_'):
            continue
        for i, ln in enumerate(open(fname, encoding='utf-8'), 1):
            for m in version_pat.finditer(ln):
                if m.group(1) != '3.0':
                    stale.append(f'{fname}:{i} v{m.group(1)}')
    oks.append(check("Every 'Rain2Flood vX' string reads 3.0",
                     not stale, '; '.join(stale[:6])))

    meta = open('metadata.txt', encoding='utf-8').read()
    oks.append(check("metadata.txt declares version 3.0",
                     re.search(r'^version=3\.0\s*$', meta, re.M) is not None))
    oks.append(check("metadata.txt credits the real author, not a placeholder",
                     'author=Rahul Pandey' in meta
                     and 'rahulpandey696' in meta
                     and 'example.com' not in meta))

    # ── Changelog present in all four places ──────────────────────────
    dlg = open('rain2flood_dialog.py', encoding='utf-8').read()
    readme = open('README.md', encoding='utf-8').read() if os.path.exists('README.md') else ''
    oks.append(check("Changelog is in metadata, the About tab and the README",
                     'changelog=Version 3.0' in meta
                     and 'CHANGELOG_ENTRIES' in dlg
                     and 'CHANGELOG_HTML' in dlg
                     and '## Changelog' in readme
                     and '### 3.0' in readme))
    oks.append(check("The 2.2 history is preserved, not overwritten",
                     '2.2' in meta and '### 2.2' in readme))

    # ── Credits are real links ────────────────────────────────────────
    oks.append(check("Credit links are defined once and opened externally",
                     'LINKEDIN_URL' in dlg and 'GITHUB_URL' in dlg
                     and dlg.count('setOpenExternalLinks(True)') >= 2,
                     "setOpenExternalLinks is what makes a rich-text <a> in "
                     "a QLabel actually open a browser"))
    oks.append(check("Banner carries the credit",
                     'cooked by' in dlg and 'Rahul Pandey' in dlg))

    # ── Research references removed from the user-facing text ─────────
    about_start = dlg.find('<h3 style="color:{ACCENT_DEEP}">Tabs and Workflow</h3>')
    about = dlg[about_start:about_start + 4000] if about_start > 0 else ''
    oks.append(check("About tab no longer lists paper references",
                     'References:' not in about
                     and 'Hosking' not in about
                     and 'Snyder 1938' not in about))
    oks.append(check("Plugin description carries no paper references",
                     'et al' not in meta and 'Hosking' not in meta
                     and 'NEH-4' not in meta))
    return all(oks)


def test_no_undefined_names():
    """
    No module may reference a name that is never bound.

    Python resolves names at call time, so an undefined name inside a
    function body is not a syntax error and not an import error — it sits
    there silently until that exact line runs. Three of them were live in
    this plugin at once:

      * `iface` in CNLULCTab._gen_tab, where only `self.iface` exists.
        Crashed the dialog on open, so every tab was unreachable.
      * `gdf` left behind in the ESA download path after the catchment
        layer was replaced by the extent picker. Would have crashed only
        after a multi-hundred-megabyte land-cover download had completed.
      * `empirical_frequency_analysis` in hydrological_calculations. Its
        `def` line had gone missing, leaving the body indented inside the
        function above as unreachable code after that function's return.
        The name was never bound, so the last resort in the frequency
        fallback chain — fit fails, Gumbel fails, fall back to empirical
        — raised NameError instead of returning an estimate.

    The third is the reason this test exists rather than just the fixes.
    It would only fire on data pathological enough to defeat two fitters,
    and it had been sitting there through every run.

    Uses pyflakes when available (it handles scoping properly), and falls
    back to a conservative module-level check so the suite still says
    something useful without it.
    """
    import ast
    import os
    import re

    # The test file is scanned too. It was originally excluded, and the
    # first version of this very test shipped with an undefined `re` in
    # it — caught only by running it, which is precisely the failure mode
    # the test exists to remove. A lint that exempts itself is worth less
    # than no lint, because it implies a coverage it does not have.
    files = sorted(f for f in os.listdir('.') if f.endswith('.py'))
    offenders = []

    try:
        from pyflakes.api import check as pf_check
        from pyflakes.reporter import Reporter
        import io

        for fname in files:
            out, err = io.StringIO(), io.StringIO()
            pf_check(open(fname, encoding='utf-8').read(), fname,
                     Reporter(out, err))
            for line in out.getvalue().splitlines():
                if 'undefined name' in line:
                    offenders.append(line.strip())
        mode = 'pyflakes'
    except ImportError:
        # Conservative fallback: module-level Load names only. Catches a
        # missing import or a renamed constant; will not see function
        # scopes, so it is strictly weaker than pyflakes.
        mode = 'builtin (module scope only)'
        import builtins
        for fname in files:
            tree = ast.parse(open(fname, encoding='utf-8').read())
            bound = set(dir(builtins))
            for n in ast.walk(tree):
                if isinstance(n, (ast.Import, ast.ImportFrom)):
                    for al in n.names:
                        bound.add(al.asname or al.name.split('.')[0])
                elif isinstance(n, ast.Assign):
                    for t in n.targets:
                        if isinstance(t, ast.Name):
                            bound.add(t.id)
                elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef,
                                    ast.ClassDef)):
                    bound.add(n.name)
                elif isinstance(n, ast.arg):
                    bound.add(n.arg)
                elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                    bound.add(n.id)
                elif isinstance(n, ast.ExceptHandler) and n.name:
                    bound.add(n.name)
            for n in tree.body:
                for sub in ast.walk(n):
                    if (isinstance(sub, ast.Name)
                            and isinstance(sub.ctx, ast.Load)
                            and sub.id not in bound):
                        offenders.append(
                            f'{fname}:{sub.lineno}: undefined name {sub.id!r}')

    ok1 = check(f"No undefined names anywhere in the plugin [{mode}]",
                not offenders, '; '.join(offenders[:8]))

    # The specific fallback that was dead: it must exist AND work, not
    # merely be importable.
    import numpy as _np
    import hydrological_calculations as hc
    fn = getattr(hc, 'empirical_frequency_analysis', None)
    ok2 = check("The empirical frequency fallback is a real bound function",
                callable(fn))
    ok3 = False
    if callable(fn):
        try:
            d = _np.array([12., 18., 25., 31., 44., 52., 61., 70., 88., 120.])
            got = _np.asarray(fn(d, [10, 50, 100]))
            ok3 = check("The empirical fallback returns increasing design "
                        "values for increasing return periods",
                        got.shape == (3,) and _np.all(_np.isfinite(got))
                        and got[0] < got[1] < got[2],
                        f"got {got}")
        except Exception as e:
            ok3 = check("The empirical fallback runs without raising", False, str(e))

    # No bespoke `iface` regex here. One was tried and removed: a
    # line-based pattern cannot see scope, so it flagged every legitimate
    # use inside a function that takes iface as a parameter —
    # _coord_row(iface, ...) and Rain2FloodDialog.__init__(self, iface).
    # pyflakes already does proper scope analysis and caught the real
    # unbound `iface` on the first run. A second, cruder check that
    # produces five false positives for every true one trains you to
    # ignore the output, which is worse than not having it.
    #
    # What IS worth asserting is that the strong checker actually ran.
    # Without it the fallback only sees module scope and would have
    # missed all three of the bugs that motivated this test, while still
    # reporting a pass.
    ok4 = check("The scope-aware checker (pyflakes) was available, "
                "not the weaker module-scope fallback",
                mode == 'pyflakes',
                f"ran in {mode} mode — install pyflakes for full coverage")
    return ok1 and ok2 and ok3 and ok4


def test_flood_mapping_scales_monotonically_with_discharge():
    """
    A fundamental sanity property: increasing discharge must not decrease
    flood extent or max depth. Uses a synthetic V-shaped valley (similar
    relief profile to the real high-relief catchment where the extent-
    inflation/deflation bugs were found) and checks depth/extent both
    increase monotonically across a range of discharges.
    """
    import numpy as np, os, tempfile
    import rasterio
    from rasterio.transform import from_origin
    import geopandas as gpd
    from shapely.geometry import Polygon
    import flood_mapping as fm

    tmpdir = tempfile.mkdtemp()
    n = 100
    res = 30.0
    ox, oy = 400000, 2000000
    y, x = np.mgrid[0:n, 0:n]
    main_slope = 400.0 * (n - x) / n
    cross_valley = 150.0 * np.abs((y - n / 2) / (n / 2)) ** 1.5
    dem = (600 + main_slope + cross_valley).astype(np.float32)

    transform = from_origin(ox, oy, res, res)
    crs = 'EPSG:32643'
    meta = dict(driver='GTiff', height=n, width=n, count=1, dtype='float32',
                crs=crs, transform=transform, nodata=-9999.0)
    dem_path = os.path.join(tmpdir, 'dem.tif')
    with rasterio.open(dem_path, 'w', **meta) as dst:
        dst.write(dem, 1)
    poly = Polygon([(ox, oy), (ox + n * res, oy),
                     (ox + n * res, oy - n * res), (ox, oy - n * res)])
    catch_path = os.path.join(tmpdir, 'catchment.gpkg')
    gpd.GeoDataFrame({'geometry': [poly]}, crs=crs).to_file(catch_path, driver='GPKG')

    discharges = [20.0, 84.2, 150.0, 275.0, 1000.0]
    pcts, depths = [], []
    for i, Q in enumerate(discharges):
        _, tif, _fv, _fh = fm.generate_flood_map(
            discharge=Q, dem_path=dem_path, catchment_path=catch_path,
            output_dir=tmpdir, return_period=10 + i, manning_n=0.1294, feedback=_FB()
        )
        with rasterio.open(tif) as f:
            depth = f.read(1)
        valid = depth > -9999
        pcts.append(100.0 * np.sum(valid & (depth > 0)) / np.sum(valid))
        depths.append(float(depth[valid].max()))

    ok1 = check("Max depth increases monotonically with discharge",
                all(depths[i] <= depths[i+1] + 1e-6 for i in range(len(depths)-1)),
                f"depths={depths}")
    ok2 = check("Flood extent does not decrease with discharge",
                all(pcts[i] <= pcts[i+1] + 1e-6 for i in range(len(pcts)-1)),
                f"extents={pcts}")
    ok3 = check("Flood extent stays in a plausible range (not 0%, not >80%)",
                all(0 < p < 80 for p in pcts), f"extents={pcts}")
    return ok1 and ok2 and ok3


def _load_merge_functions():
    """
    subcatchment_delineation.py imports qgis.core at module level, so it
    can't be imported directly without a real QGIS install. Extract just
    the two pure geopandas/shapely functions under test and exec them in
    an isolated namespace, so this test always exercises the actual
    current source rather than a separately maintained copy that could
    drift out of sync with the real implementation.
    """
    import types
    with open('subcatchment_delineation.py') as f:
        src = f.read()
    start = src.index('def _merge_tiny_basins')
    end = src.index('\n\ndef _write_stats')
    func_src = src[start:end]
    ns = {'gpd': __import__('geopandas'), 'np': np}
    from shapely.ops import unary_union
    ns['unary_union'] = unary_union
    exec(compile(func_src, 'subcatchment_delineation.py', 'exec'), ns)
    mod = types.SimpleNamespace(**ns)
    return mod


def test_subbasin_merge_uses_longest_shared_boundary():
    """
    Regression test for the specific bug found in real-world use:
    merging a tiny basin into its LARGEST touching neighbour (rather
    than its most naturally adjacent one) produced elongated, awkward
    combined shapes when the tiny basin only marginally touched a much
    bigger one at a corner. This builds a tiny basin that barely touches
    a big basin A at a corner but shares a long edge with smaller basin
    B, and checks it merges into B (the natural neighbour), not A (the
    larger one).
    """
    import geopandas as gpd
    from shapely.geometry import Polygon
    sd = _load_merge_functions()

    tiny = Polygon([(1, 1), (2, 1), (2, 2), (1, 2)])
    basin_A = Polygon([(2, 0), (4, 0), (4, 4), (2, 4), (2, 2), (1.99, 2), (1.99, 1), (2, 1)])
    basin_B = Polygon([(0, 1), (1, 1), (1, 2), (0, 2)])  # shares the whole left edge of tiny

    gdf = gpd.GeoDataFrame({
        'Area_km2': [0.5, 20.0, 3.0],
        'geometry': [tiny, basin_A, basin_B]
    })
    result = sd._merge_tiny_basins(gdf.copy(), min_area_km2=1.0, feedback=_FB())

    ok1 = check("Tiny basin merges away (down to 2 basins)", len(result) == 2,
                f"got {len(result)} basins")
    ok2 = check("Basin A (only touches at a corner) stays unchanged, not merged into",
                any(abs(a - 20.0) < 1e-6 for a in result['Area_km2']),
                f"areas={result['Area_km2'].tolist()}")
    return ok1 and ok2


def test_subbasin_island_gets_dissolved():
    """
    Regression test for the specific bug found in real-world use: a
    basin ending up as a literal island fully enclosed inside another
    basin's shape (a side effect of surrounding fragments merging
    together) — topologically odd for dendritic drainage sub-basins,
    which should partition space without holes or disconnected enclaves.
    """
    import geopandas as gpd
    from shapely.geometry import Polygon
    sd = _load_merge_functions()

    outer = Polygon([(8, 8), (14, 8), (14, 14), (8, 14)])
    island = Polygon([(10, 10), (12, 10), (12, 12), (10, 12)])
    gdf = gpd.GeoDataFrame({'Area_km2': [5.0, 30.0], 'geometry': [island, outer]})

    result = sd._fix_enclosed_islands(gdf.copy(), _FB())
    return check("Enclosed island basin gets dissolved into its surrounding basin",
                 len(result) == 1, f"got {len(result)} basins (expected 1)")


def test_2d_routing_source_outlet_distinct():
    """Regression test for the specific bug found during development:
    if source and outlet are the same cell, water exits in the same step
    it enters and depth stays at 0 everywhere despite 'perfect' mass
    balance. Confirms a real (separated) source/outlet pair actually
    produces non-zero depth."""
    import flood_routing_2d as fr
    np.random.seed(3)
    n = 50
    dem = 50 + 0.3 * (n - np.arange(n))[None, :] + np.random.rand(n, n) * 0.3
    manning = np.full((n, n), 0.05)
    t_h = np.array([0, 900, 1800, 3600])
    q_h = np.array([0, 15, 15, 0])

    source_idx = np.unravel_index(np.argmax(dem), dem.shape)
    outlet_idx = np.unravel_index(np.argmin(dem), dem.shape)
    outlet_mask = np.zeros((n, n), dtype=bool)
    outlet_mask[outlet_idx] = True

    result = fr.route_2d_diffusive_wave(
        dem, cell_size_m=10.0, manning_grid=manning,
        hydrograph_time_s=t_h, hydrograph_q_cms=q_h,
        source_rc=source_idx, outlet_mask=outlet_mask, sim_duration_s=1800,
        max_wall_time_s=30, feedback=_FB())

    max_d = np.max(result.max_depth[result.max_depth > -9999])
    return check("Distinct source/outlet produces actual flood depth (not stuck at 0)",
                  max_d > 0.01, f"max depth = {max_d:.4f} m")


if __name__ == '__main__':
    print("=== Hydrology correctness regression tests ===\n")
    results = {
        'Sink fill and network connectivity': test_sink_fill_and_network_connectivity(),
        'Sink fill respects catchment mask': test_sink_fill_respects_catchment_mask(),
        'Channel slope from long profile': test_channel_slope_from_long_profile(),
        'Pour-point delineation and snapping': test_pour_point_delineation(),
        'Pour point rejects geographic CRS': test_pour_point_rejects_geographic_crs(),
        'SCS lag extrapolation warning': test_scs_lag_extrapolation_warning(),
        'Pour-point option wired into flood tabs': test_pour_point_option_wired_into_both_flood_algorithms(),
        'DEM & Slope catchment optional': test_dem_slope_catchment_is_optional(),
        'Auto entries and optional catchments': test_auto_entries_and_optional_catchments(),
        'Flood volume budget enforced': test_flood_volume_budget_is_enforced(),
        'Sub-basins clipped to catchment': test_subbasins_are_clipped_to_the_catchment(),
        'Flow path is one continuous line': test_flow_path_is_one_continuous_linestring(),
        'Theme is self-consistent': test_theme_is_self_consistent(),
        'Palettes, version and credits': test_palettes_version_and_credits(),
        'No undefined names': test_no_undefined_names(),
        'No unscoped Qt enums (PyQt6/QGIS4)': test_no_unscoped_qt_enums_outside_compat_shims(),
        'Flood extent on irregular catchment': test_flood_extent_on_irregular_catchment_is_plausible(),
        'Tab widgets defined where used': test_tab_widgets_defined_where_used(),
        'Sub-basin lagged routing': test_subbasin_lagged_routing(),
        'Flood extent scales with contributing area': test_flood_extent_scales_with_contributing_area(),
        'No shadowing imports': test_no_shadowing_imports(),
        'Level-pool routing': test_level_pool_routing(),
        'Channel section hydraulics': test_channel_section_hydraulics(),
        'Batch processing logic': test_batch_processing_logic(),
        'UI params match algorithm params': test_ui_params_match_algorithm_params(),
        'Report generation': test_report_generation(),
        'Config save/load round-trip': test_config_save_load_roundtrip(),
        'Sensitivity elasticity math': test_sensitivity_elasticity_math(),
        'CWC SUH physical behaviour': test_cwc_suh_physical_behaviour(),
        'Calibration metrics vs known values': test_calibration_metrics_against_known_values(),
        'Hydrograph comparison (obs vs sim)': test_hydrograph_comparison(),
        'Mann-Kendall trend test calibration': test_mann_kendall_calibration(),
        'Grubbs-Beck detects known outlier': test_grubbs_beck_detects_known_outlier(),
        'Distribution selection Jacobian fix': test_distribution_selection_jacobian_fix(),
        'Bootstrap CI scales with sample size': test_bootstrap_ci_scales_with_sample_size(),
        'FEH QMED formula':              test_feh_qmed(),
        'ABM None-handling crash fix':   test_abm_none_handling(),
        'Time-to-peak duration scaling': test_time_to_peak_duration(),
        'Rational method Tc vs Tp':      test_rational_tc_vs_tp(),
        '2D routing mass conservation':  test_2d_routing_mass_conservation(),
        '2D routing Manning convergence': test_2d_routing_manning_convergence(),
        '2D routing source/outlet fix':  test_2d_routing_source_outlet_distinct(),
        'Flow accumulation direction correct': test_flow_accumulation_direction_correct(),
        'Hazard classification formula and variation': test_hazard_classification_formula_and_variation(),
        'Flood mapping extent not overinflated': test_flood_mapping_extent_not_overinflated(),
        'Flood mapping scales monotonically': test_flood_mapping_scales_monotonically_with_discharge(),
        'Sub-basin merge uses shared boundary': test_subbasin_merge_uses_longest_shared_boundary(),
        'Sub-basin island gets dissolved': test_subbasin_island_gets_dissolved(),
    }
    print("\n=== Summary ===")
    n_pass = sum(results.values())
    for name, ok in results.items():
        print(f"  {'PASS' if ok else 'FAIL'}  {name}")
    print(f"\n{n_pass}/{len(results)} test groups passed.")
    sys.exit(0 if n_pass == len(results) else 1)
