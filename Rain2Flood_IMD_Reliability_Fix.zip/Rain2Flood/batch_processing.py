"""
Batch Processing
================
Run the existing flood analysis across every polygon in a multi-catchment
layer, writing per-catchment output folders plus one aggregate summary.

Design note — why this wraps the existing algorithm rather than
restructuring it:

The Flash/Standard Flood algorithms are long, have many interacting
parameters, and have been debugged extensively against real data. Making
them natively multi-catchment would mean threading a loop through all of
that, which is exactly the kind of change that historically broke things
in this project (the parameter-registration mismatch, the stale return
signature, the orphaned imports). Instead this splits the input layer
into single-polygon temporary layers and calls the SAME validated
algorithm once per catchment. Slower, but every catchment goes through
the identical, already-tested code path, and a failure in one catchment
cannot corrupt the others.
"""

import os
import traceback


def _slugify(text, fallback='catchment'):
    """Filesystem-safe folder name from a catchment attribute value."""
    if text is None:
        return fallback
    s = str(text).strip()
    if not s:
        return fallback
    keep = []
    for ch in s:
        if ch.isalnum() or ch in ('-', '_'):
            keep.append(ch)
        elif ch in (' ', '.', '/', '\\', ':'):
            keep.append('_')
    out = ''.join(keep).strip('_')
    return out[:60] or fallback


def split_catchment_layer(layer, name_field=None, feedback=None):
    """
    Split a multi-polygon layer into a list of
    (catchment_name, single_feature_layer) pairs.

    Each single-feature layer is an in-memory QGIS layer with the same
    CRS as the source, so downstream code sees exactly what it would
    have seen from a normal single-catchment input.
    """
    from qgis.core import QgsVectorLayer, QgsFeature, QgsProject

    feats = list(layer.getFeatures())
    if not feats:
        if feedback:
            feedback.reportError("Catchment layer contains no features.")
        return []

    fields = layer.fields()
    field_names = [f.name() for f in fields]
    # Pick a sensible naming field if the user didn't specify one — a
    # meaningful folder name per catchment matters a lot when reviewing
    # 20 output folders later.
    if name_field and name_field in field_names:
        chosen = name_field
    else:
        chosen = None
        for cand in ('Name', 'name', 'NAME', 'ID', 'id', 'Catchment', 'Sub_Basin'):
            if cand in field_names:
                chosen = cand
                break
        if feedback and chosen and not name_field:
            feedback.pushInfo(f"  Naming catchments from the '{chosen}' field.")
        elif feedback and not chosen:
            feedback.pushInfo("  No suitable name field found — using Catchment_1, _2, ...")

    out = []
    for i, feat in enumerate(feats, start=1):
        raw_name = feat[chosen] if chosen else None
        name = _slugify(raw_name, fallback=f'Catchment_{i}')
        # Guarantee uniqueness — duplicate names would silently overwrite
        # each other's output folders.
        existing = {n for n, _ in out}
        if name in existing:
            name = f"{name}_{i}"

        mem = QgsVectorLayer(
            f"Polygon?crs={layer.crs().authid()}", f"batch_{name}", "memory")
        dp = mem.dataProvider()
        dp.addAttributes(fields)
        mem.updateFields()
        nf = QgsFeature(mem.fields())
        nf.setGeometry(feat.geometry())
        nf.setAttributes(feat.attributes())
        dp.addFeature(nf)
        mem.updateExtents()
        out.append((name, mem))

    if feedback:
        feedback.pushInfo(f"  Split into {len(out)} catchment(s).")
    return out


def run_batch(algorithm_class, base_params, catchment_layer, output_dir,
              name_field=None, feedback=None, context=None):
    """
    Run `algorithm_class` once per catchment polygon.

    base_params : the parameter dict that would be used for a single run.
                  CATCHMENT and OUTPUT_DIR are overridden per catchment;
                  everything else is held constant, which is the point —
                  a batch run should apply consistent settings so results
                  are comparable across catchments.

    Returns (summary_rows, failures). Individual catchment failures are
    caught and recorded rather than aborting the batch: with a 20-
    catchment run, losing 19 good results because catchment 7 has a bad
    DEM would be a bad trade.
    """
    import pandas as pd
    from qgis.core import QgsProcessingContext, QgsProcessingFeedback

    pairs = split_catchment_layer(catchment_layer, name_field, feedback)
    if not pairs:
        return [], []

    summary_rows, failures = [], []
    total = len(pairs)

    for idx, (name, mem_layer) in enumerate(pairs, start=1):
        if feedback:
            feedback.pushInfo(f"\n=== Batch {idx}/{total}: {name} ===")
            feedback.setProgress(int(100 * (idx - 1) / total))

        catch_dir = os.path.join(output_dir, name)
        os.makedirs(catch_dir, exist_ok=True)

        params = dict(base_params)
        params['CATCHMENT'] = mem_layer
        params['OUTPUT_DIR'] = catch_dir

        try:
            alg = algorithm_class()
            alg.initAlgorithm({})
            ctx = context or QgsProcessingContext()
            sub_fb = _BatchSubFeedback(feedback, name)
            alg.processAlgorithm(params, ctx, sub_fb)

            row = {'Catchment': name, 'Status': 'OK', 'Output Folder': catch_dir}
            row.update(_extract_summary(catch_dir))
            summary_rows.append(row)
            if feedback:
                feedback.pushInfo(f"  {name}: completed.")
        except Exception as e:
            tb = traceback.format_exc()
            failures.append({'Catchment': name, 'Error': str(e), 'Traceback': tb})
            summary_rows.append({'Catchment': name, 'Status': f'FAILED: {e}',
                                  'Output Folder': catch_dir})
            if feedback:
                feedback.pushWarning(
                    f"  {name}: FAILED — {e}. Continuing with the remaining "
                    f"catchments; see batch_summary.csv for the full list."
                )

    # Aggregate summary — the actual deliverable of a batch run, since
    # nobody wants to open 20 separate spreadsheets to compare results.
    try:
        df = pd.DataFrame(summary_rows)
        summary_path = os.path.join(output_dir, 'batch_summary.csv')
        df.to_csv(summary_path, index=False)
        if feedback:
            n_ok = sum(1 for r in summary_rows if r.get('Status') == 'OK')
            feedback.pushInfo(
                f"\n=== Batch complete: {n_ok}/{total} succeeded ===")
            feedback.pushInfo(f"Summary saved: {summary_path}")
            if failures:
                feedback.pushWarning(
                    f"{len(failures)} catchment(s) failed: "
                    f"{', '.join(f['Catchment'] for f in failures)}")
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"Could not write batch summary: {e}")

    if feedback:
        feedback.setProgress(100)
    return summary_rows, failures


def _extract_summary(catch_dir):
    """
    Pull headline numbers out of a completed catchment's results so the
    aggregate summary is genuinely useful for comparison, not just a
    list of folder paths.
    """
    out = {}
    try:
        import pandas as pd
        for fn in ('Flash_Flood_Analysis_Results.xlsx',
                   'Standard_Flood_Analysis_Results.xlsx'):
            xp = os.path.join(catch_dir, fn)
            if not os.path.exists(xp):
                continue
            df = pd.read_excel(xp, sheet_name='Results')
            if df.empty:
                break
            q_col = next((c for c in df.columns if 'Discharge' in c), None)
            rp_col = next((c for c in df.columns if 'Return Period' in c), None)
            if q_col:
                out['Max Discharge (m3/s)'] = round(float(df[q_col].max()), 2)
                if rp_col:
                    i = df[q_col].idxmax()
                    out['At Return Period (yr)'] = int(df.loc[i, rp_col])
            area_col = next((c for c in df.columns if 'Area' in c), None)
            if area_col:
                out['Area (km2)'] = round(float(df[area_col].iloc[0]), 2)
            break
    except Exception:
        pass
    return out


class _BatchSubFeedback:
    """
    Prefixes each catchment's log lines so a long batch log stays
    readable, and swallows per-catchment progress (which would otherwise
    reset the overall batch progress bar on every catchment).
    """
    def __init__(self, parent, name):
        self._p = parent
        self._n = name

    def pushInfo(self, m):
        if self._p:
            self._p.pushInfo(f"    [{self._n}] {m}")

    def pushWarning(self, m):
        if self._p:
            self._p.pushWarning(f"    [{self._n}] {m}")

    def pushDebugInfo(self, m):
        pass

    def reportError(self, m, fatalError=False):
        if self._p:
            self._p.pushWarning(f"    [{self._n}] ERROR: {m}")

    def setProgress(self, v):
        pass

    def isCanceled(self):
        try:
            return self._p.isCanceled() if self._p else False
        except Exception:
            return False
