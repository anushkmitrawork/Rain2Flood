"""
Subcatchment Delineation & Stream Network  –  Rain2Flood v3.0
=============================================================
Engine: GRASS GIS r.watershed + r.to.vect, run through QGIS's own
        Processing framework (no third-party binaries) — the same
        engine QGIS's built-in "GRASS | Raster (r.*) | r.watershed" tool
        uses. Only CORE GRASS modules are used (r.watershed, r.to.vect);
        no GRASS addons (e.g. r.stream.order) are required, since those
        aren't guaranteed to be installed.
        + rasterio polygonize + shapely/geopandas/networkx-style graph
        logic (pure Python, no GRASS-specific raster codes decoded) for
        output assembly.

Outputs
-------
sub_basins.gpkg   – polygon  | Name (S1…SN), Area_km2
streams.gpkg      – line     | StreamID, Order (Strahler), Length_km,
                                UpstreamArea_km2, AvgSlope_pct
subcatchment_stats.txt

Why GRASS r.watershed (via QGIS Processing) instead of a bundled binary
------------------------------------------------------------------------
This file previously used WhiteboxTools, a standalone compiled binary the
`whitebox` Python package downloads on first use. That worked, but pulls
in a third-party binary dependency outside QGIS's own toolset. GRASS
ships with QGIS itself (no extra download), and r.watershed is the same
algorithm used by QGIS's own "GRASS | Raster (r.*) | r.watershed" menu
entry — a long-established, independently maintained hydrology engine,
not something this plugin has to keep patching.

Design notes (why this avoids re-introducing the earlier fragile code):
  - r.watershed's own `stream` output values are documented by GRASS to
    correspond directly to its `basin` output values — i.e. sub-basins
    and their stream reaches already share one ID scheme natively, the
    same relationship this plugin relied on with WhiteboxTools' link/
    subbasin IDs. No custom pour-point search or basin-labelling BFS is
    needed; `basin` is polygonised directly.
  - Strahler order is computed here in pure Python from the VECTORISED
    stream network's topology (which line endpoints connect to which),
    using flow accumulation only to tell upstream from downstream at
    each segment — never by decoding GRASS's own drainage-direction
    raster encoding. This keeps the one piece of new graph logic in this
    rewrite fully independent of any GRASS-version-specific raster
    convention, and it's covered by isolated unit-style tests (see the
    project notes) against known confluence topologies (simple Y-forks,
    3-way simultaneous confluences, and equal/unequal-order merges) — the
    class of thing that's easy to get subtly wrong and hard to notice.
  - GRASS Processing algorithm IDs differ across QGIS/GRASS versions
    (e.g. grass7:, grass8:, or unprefixed) — the exact ID is discovered
    at runtime from the Processing registry rather than hardcoded, so
    this doesn't silently break on a version this wasn't tested against.
"""

import os, gc, math, warnings
import numpy as np

# Physically plausible land-surface elevation range (meters) — used to catch
# unflagged DEM voids/sentinels that a file without a declared nodata value
# would otherwise let straight through into the flow-routing pipeline.
_PLAUSIBLE_ELEV_MIN = -500.0
_PLAUSIBLE_ELEV_MAX = 9000.0
warnings.filterwarnings('ignore')

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterCrs,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
    QgsProcessingException,
    QgsProcessing,
    QgsProject,
    QgsVectorLayer,
    QgsCoordinateReferenceSystem,
    QgsApplication,
    QgsProcessingFeedback,
)


class _GrassSubFeedback(QgsProcessingFeedback):
    """
    Forwards log messages from a GRASS sub-algorithm call (via
    processing.run) into this tool's own feedback/log, so GRASS's actual
    console output — the exact command it ran, its own warnings, the
    real error text — shows up directly in this tool's log instead of
    only in QGIS's separate global Log Messages panel (easy to miss, and
    the main obstacle when diagnosing GRASS parameter issues during this
    tool's development).

    setProgress is deliberately NOT forwarded: a sub-algorithm reports
    its own 0-100% for just that one step, which would fight with and
    reset this tool's own overall multi-step progress tracking if passed
    straight through.
    """
    def __init__(self, real_feedback):
        super().__init__()
        self._real = real_feedback

    def pushInfo(self, msg):
        if self._real:
            self._real.pushInfo(f"    [GRASS] {msg}")

    def pushWarning(self, msg):
        if self._real:
            self._real.pushWarning(f"[GRASS] {msg}")

    def reportError(self, msg, fatalError=False):
        if self._real:
            self._real.reportError(f"[GRASS] {msg}", fatalError)


class SubcatchmentDelineation(QgsProcessingAlgorithm):
    DEM            = 'DEM'
    CATCHMENT      = 'CATCHMENT'
    TARGET_CRS     = 'TARGET_CRS'
    STREAM_THRESH  = 'STREAM_THRESH'
    MIN_BASIN_AREA = 'MIN_BASIN_AREA'
    LOAD_IN_QGIS   = 'LOAD_IN_QGIS'
    OUTPUT_FOLDER  = 'OUTPUT_FOLDER'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DEM, 'Input DEM Raster (any CRS – will be reprojected)'))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CATCHMENT,
            'Catchment Boundary (OPTIONAL — leave empty to delineate the whole DEM)',
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterCrs(
            self.TARGET_CRS,
            'Target Projected CRS (UTM zone covering your area)',
            defaultValue='EPSG:32643'))
        self.addParameter(QgsProcessingParameterNumber(
            self.STREAM_THRESH,
            'Stream Accumulation Threshold (cells)\n'
            'Lower = denser network / more sub-basins',
            QgsProcessingParameterNumber.Integer,
            defaultValue=500, minValue=10))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_BASIN_AREA,
            'Minimum Sub-basin Area (km²)\n'
            'Tiny basins below this are merged into neighbours',
            QgsProcessingParameterNumber.Double,
            defaultValue=1.0, minValue=0.01))
        self.addParameter(QgsProcessingParameterBoolean(
            self.LOAD_IN_QGIS, 'Load outputs in QGIS automatically',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_FOLDER, 'Output Folder'))

    # ──────────────────────────────────────────────────────────────────────
    def processAlgorithm(self, parameters, context, feedback):

        # ── dependency check ──────────────────────────────────────────────
        missing = []
        for pkg in ('rasterio', 'geopandas', 'shapely'):
            try: __import__(pkg)
            except ImportError: missing.append(pkg)
        if missing:
            raise QgsProcessingException(
                f"Missing packages: {', '.join(missing)}\n"
                "Run: pip install rasterio geopandas shapely "
                "--break-system-packages")

        import processing
        watershed_alg_id = _find_grass_alg_id('r.watershed', feedback)
        tovect_alg_id     = _find_grass_alg_id('r.to.vect', feedback)
        if watershed_alg_id is None or tovect_alg_id is None:
            raise QgsProcessingException(
                "GRASS algorithms (r.watershed / r.to.vect) were not found "
                "in QGIS's Processing registry. This usually means the "
                "'Processing GRASS Provider' plugin isn't enabled: go to "
                "Plugins > Manage and Install Plugins, make sure "
                "'Processing GRASS Provider' (or similar) is checked, and "
                "also check Processing > Options > Providers > GRASS points "
                "to a valid GRASS installation. GRASS ships with the QGIS "
                "standalone installer, so it should already be present — "
                "it just may need enabling."
            )

        import rasterio
        from rasterio.warp import (calculate_default_transform, Resampling,
                                    transform_bounds)
        import geopandas as gpd
        from shapely.ops import unary_union

        dem_layer       = self.parameterAsRasterLayer(parameters, self.DEM, context)
        catchment_layer = self.parameterAsVectorLayer(parameters, self.CATCHMENT, context)
        target_crs_obj  = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        stream_thresh   = self.parameterAsInt(parameters, self.STREAM_THRESH, context)
        min_area_km2    = self.parameterAsDouble(parameters, self.MIN_BASIN_AREA, context)
        load_in_qgis    = self.parameterAsBoolean(parameters, self.LOAD_IN_QGIS, context)
        output_folder   = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        os.makedirs(output_folder, exist_ok=True)

        utm_epsg = target_crs_obj.authid()   # e.g. 'EPSG:32643'
        utm_crs_str = utm_epsg
        feedback.pushInfo("=== Subcatchment Delineation – Rain2Flood v3.0 (GRASS) ===")

        # ── Step 1-2: Single-pass reproject + crop via WarpedVRT ──────────
        # Replaces the old two-stage approach (reproject the WHOLE DEM to a
        # new grid, write it to disk, then separately mask/crop it) with a
        # windowed WarpedVRT bounded directly to the catchment's own extent
        # — the same robust, GDAL-backed pattern used in
        # dem_slope_processing.py. This only ever touches the pixels that
        # matter (fast/memory-safe on large source DEMs) and avoids an
        # entire class of subtle two-stage transform/rounding issues.
        #
        # IMPORTANT (this replaces the earlier "wall value" fix): the DEM
        # used for the actual flow-routing computation is now cropped to
        # the catchment's rectangular BOUNDING BOX only — NOT masked to
        # the irregular polygon shape. Masking to the polygon here turns
        # every bbox corner outside the (usually diagonal/irregular)
        # catchment into nodata, and forcing all of that into one uniform
        # "wall" elevation (the earlier fix) creates one giant, perfectly
        # flat, oddly-shaped region. Flat-resolution algorithms have to
        # assign a synthetic drainage pattern across that entire flat
        # area, and doing so over a large irregular flat region is
        # exactly what was producing the straight-line / rectangular
        # artifacts — that was a
        # side effect of the wall fix itself, not the original nodata-sink
        # bug it was meant to solve.
        #
        # The robust fix: give the flow-routing engine a real, fully-
        # populated rectangular DEM to work with (true contiguous terrain
        # everywhere), and only apply the user's irregular polygon
        # boundary as a final VECTOR clip on the output streams/basins
        # (see Step 9b below) — a pure geometric operation that can't
        # corrupt the flow computation.
        feedback.pushInfo("Step 1-2: Reprojecting + cropping DEM to catchment bounding box (single pass) …")
        from rasterio.vrt import WarpedVRT

        # The catchment boundary is OPTIONAL and, for delineation, leaving
        # it out is usually the BETTER choice. It was only ever used to
        # decide the crop window and to trim the output polygons — it never
        # improved the hydrology. Cropping to it actively hurts: flow
        # accumulation on a clipped raster truncates upstream contributing
        # area at the clip edge, so cells near the boundary report an
        # accumulation that is too low and the stream network is wrong
        # there. Requiring it was also circular, since delineating a
        # catchment is exactly what this tab is for.
        catch_gdf = None
        catch_union = None
        if catchment_layer is not None:
            catch_gdf = _read_vector_with_authoritative_crs(
                gpd, catchment_layer.source(), catchment_layer, feedback)
            catch_gdf = catch_gdf.to_crs(utm_crs_str)
            catch_union = unary_union(list(catch_gdf.geometry))
            cminx, cminy, cmaxx, cmaxy = catch_gdf.total_bounds
        else:
            feedback.pushInfo(
                "  No catchment boundary supplied — delineating the FULL DEM "
                "extent. This is the recommended mode: no upstream area is "
                "truncated at a clip edge, so the derived network is correct "
                "everywhere the DEM has data.")
            with rasterio.open(dem_layer.source()) as _src_b:
                _sb_crs = _src_b.crs
                if _sb_crs is None:
                    _sb_crs = dem_layer.crs().authid()
                cminx, cminy, cmaxx, cmaxy = transform_bounds(
                    _sb_crs, utm_crs_str, *_src_b.bounds)

        with rasterio.open(dem_layer.source()) as src:
            src_crs = src.crs
            if src_crs is None:
                qgis_dem_crs = dem_layer.crs().authid()
                if not qgis_dem_crs:
                    raise QgsProcessingException(
                        "The input DEM has no CRS defined and QGIS has no "
                        "assigned CRS either. Please assign a CRS to the "
                        "DEM layer before running.")
                feedback.pushWarning(
                    f"  DEM file has no embedded CRS — using the CRS "
                    f"assigned in QGIS ({qgis_dem_crs}) instead.")
                from rasterio.crs import CRS as RioCRS
                src_crs = RioCRS.from_user_input(qgis_dem_crs)
            src_nodata = src.nodata
            if src_nodata is None:
                feedback.pushWarning(
                    "  DEM has no nodata value defined — void/sentinel "
                    "values (if any) will be caught by the physical-"
                    "plausibility check below instead."
                )

            t_full, _, _ = calculate_default_transform(
                src_crs, utm_crs_str, src.width, src.height, *src.bounds)
            res_x, res_y = abs(t_full.a), abs(t_full.e)
            # Larger pad than before (20 cells, not 5): with the polygon
            # mask gone, the padding is what gives real upstream terrain
            # just outside the catchment a chance to route correctly
            # rather than starting right at the bbox edge.
            pad_x, pad_y = res_x * 20, res_y * 20
            win_minx, win_miny = cminx - pad_x, cminy - pad_y
            win_maxx, win_maxy = cmaxx + pad_x, cmaxy + pad_y
            out_width  = max(1, int(math.ceil((win_maxx - win_minx) / res_x)))
            out_height = max(1, int(math.ceil((win_maxy - win_miny) / res_y)))
            dst_transform = rasterio.transform.from_origin(
                win_minx, win_maxy, res_x, res_y)

            with WarpedVRT(src, src_crs=src_crs, crs=utm_crs_str,
                            transform=dst_transform, width=out_width,
                            height=out_height, resampling=Resampling.bilinear,
                            src_nodata=src_nodata, nodata=-9999.0,
                            dtype='float32') as vrt:
                crop_arr = vrt.read(1).astype(np.float32)
                crop_transform = vrt.transform
                crop_crs = vrt.crs

        clip_dem = os.path.join(output_folder, '_dem_clip.tif')
        meta = {'driver': 'GTiff', 'height': crop_arr.shape[0],
                'width': crop_arr.shape[1], 'count': 1, 'dtype': 'float32',
                'crs': crop_crs, 'transform': crop_transform,
                'nodata': -9999.0, 'compress': 'lzw'}
        with rasterio.open(clip_dem, 'w', **meta) as dst:
            dst.write(crop_arr, 1)
        feedback.setProgress(8)

        # ── Diagnostics: bounds comparison ────────────────────────────────
        with rasterio.open(clip_dem) as _dbg:
            dem_b = _dbg.bounds
        feedback.pushInfo(
            f"  [diag] Cropped DEM bounds ({utm_crs_str}):  "
            f"({dem_b.left:.0f}, {dem_b.bottom:.0f}) – ({dem_b.right:.0f}, {dem_b.top:.0f})")
        if catch_gdf is not None:
            cat_b = catch_gdf.total_bounds
            dem_cx, dem_cy = (dem_b.left + dem_b.right) / 2, (dem_b.bottom + dem_b.top) / 2
            cat_cx, cat_cy = (cat_b[0] + cat_b[2]) / 2, (cat_b[1] + cat_b[3]) / 2
            center_offset_km = ((dem_cx - cat_cx) ** 2 + (dem_cy - cat_cy) ** 2) ** 0.5 / 1000.0
            feedback.pushInfo(
                f"  [diag] Catchment bounds ({utm_crs_str}):    "
                f"({cat_b[0]:.0f}, {cat_b[1]:.0f}) – ({cat_b[2]:.0f}, {cat_b[3]:.0f})")
            feedback.pushInfo(f"  [diag] Center-to-center offset: {center_offset_km:.3f} km")

        with rasterio.open(clip_dem) as src:
            dem_arr  = src.read(1).astype(np.float64)
            rio_tfm  = src.transform
            res_x    = abs(rio_tfm[0])
            res_y    = abs(rio_tfm[4])
            cell_m2  = res_x * res_y
            rio_crs  = src.crs

        valid_mask = (dem_arr != -9999.0) & ~np.isnan(dem_arr)

        # Same unflagged-void issue as dem_slope_processing.py: a DEM with
        # no declared nodata can still contain sentinel/void values (e.g.
        # -32768) that pass the check above as "valid". Left in, these
        # would corrupt flow direction right where they sit (a false cliff/
        # pit inside the real catchment, not just at its edges) and can
        # produce the same kind of out-of-place artifact as the exterior
        # nodata-as-sink bug fixed above. Fold them into the same mask.
        implausible_interior = valid_mask & (
            (dem_arr < _PLAUSIBLE_ELEV_MIN) | (dem_arr > _PLAUSIBLE_ELEV_MAX)
        )
        n_implausible = int(implausible_interior.sum())
        if n_implausible > 0:
            feedback.pushWarning(
                f"  Found {n_implausible:,} DEM cell(s) inside the "
                f"catchment with physically implausible elevation (outside "
                f"{_PLAUSIBLE_ELEV_MIN:.0f}–{_PLAUSIBLE_ELEV_MAX:.0f} m) — "
                f"likely an unflagged void in the source DEM. Treating as "
                f"nodata so it can't corrupt flow direction/streams here."
            )
        valid_mask = valid_mask & ~implausible_interior

        # Any remaining nodata (true DEM edge/void cells — no longer a large
        # polygon-exterior region, since the DEM is a real rectangular crop
        # now; see note above) still needs to not act as a false sink for
        # fill/flow-direction. Replace with a value HIGHER than the true
        # max elevation so these (now rare, localized) cells behave like a
        # small impassable point rather than attracting flow. valid_mask
        # is still used afterwards to blank them out of every output.
        real_max_elev = float(dem_arr[valid_mask].max()) if valid_mask.any() else 0.0
        wall_value = real_max_elev + 9999.0
        dem_arr_proc = np.where(valid_mask, dem_arr, wall_value)
        feedback.pushInfo(
            f"  DEM: {dem_arr.shape[1]}×{dem_arr.shape[0]} cells  "
            f"res={res_x:.1f}×{res_y:.1f} m  "
            f"valid={int(valid_mask.sum())}")
        feedback.setProgress(16)

        # ── Step 3: GRASS r.watershed ──────────────────────────────────────
        feedback.pushInfo("Step 3: Running GRASS r.watershed (accumulation, streams, basins) …")
        grass_dir = os.path.join(output_folder, '_grass_work')
        os.makedirs(grass_dir, exist_ok=True)

        # Write the DEM (with wall-valued rare void/edge cells, so those
        # isolated cells act as small impassable points rather than false
        # sinks — see Step 2 above) out for GRASS to consume.
        dem_for_grass = os.path.join(grass_dir, 'dem.tif')
        with rasterio.open(clip_dem) as _src:
            grass_meta = _src.meta.copy()
        grass_meta.update(dtype='float32', nodata=-999999.0)
        with rasterio.open(dem_for_grass, 'w', **grass_meta) as _dst:
            _dst.write(dem_arr_proc.astype(np.float32), 1)

        acc_path    = os.path.join(grass_dir, 'accumulation.asc')
        basin_path  = os.path.join(grass_dir, 'basin.asc')
        stream_path = os.path.join(grass_dir, 'stream.asc')

        watershed_params = {
            'elevation': dem_for_grass,
            'depression': None, 'flow': None, 'disturbed_land': None,
            'blocking': None, 'max_slope_length': None,
            'threshold': int(stream_thresh),
            'convergence': 5, 'memory': 300,
            '-s': True,   # Single Flow Direction (D8) — matches the
                          # tree-like network topology this file's
                          # Strahler-order logic (below) expects, rather
                          # than GRASS's default multiple-flow-direction.
            '-b': True,   # Beautify flat areas — reduces flat-resolution
                          # artefacts (the same class of issue that caused
                          # the straight-line/rectangular problems before).
            '-a': False, '-m': False,
            'accumulation': acc_path,
            'drainage': None,     # not used — see module docstring: order
                                  # is computed from vector topology, not
                                  # by decoding this raster's direction codes.
            'basin': basin_path,
            'stream': stream_path,
            'half_basin': None, 'length_slope': None,
            'slope_steepness': None, 'tci': None, 'spi': None,
            'GRASS_REGION_PARAMETER': dem_for_grass,
            'GRASS_REGION_CELLSIZE_PARAMETER': 0,
        }
        try:
            # Pass a log-forwarding proxy (not our real feedback directly —
            # see _GrassSubFeedback) so GRASS's own detailed console output
            # (progress, warnings, the exact command it ran) appears in
            # this tool's log instead of only in QGIS's separate global Log
            # Messages panel, without GRASS's own 0-100% sub-progress
            # fighting with this tool's overall progress bar.
            processing.run(watershed_alg_id, watershed_params,
                            context=context, feedback=_GrassSubFeedback(feedback))
        except Exception as e:
            raise QgsProcessingException(
                f"GRASS r.watershed failed: {e}\n"
                "Check the [GRASS] log lines above for GRASS's own console "
                "output. If this mentions a missing GRASS installation or "
                "region error, check Processing > Options > Providers > "
                "GRASS in QGIS settings.")
        for p, label in [(acc_path, 'accumulation'), (basin_path, 'basin'),
                          (stream_path, 'stream')]:
            if not os.path.exists(p):
                raise QgsProcessingException(
                    f"GRASS r.watershed did not produce the expected "
                    f"'{label}' output — check the QGIS log panel (GRASS "
                    f"tab) for the underlying error message.")
        feedback.setProgress(45)

        with rasterio.open(acc_path) as _f:
            acc_arr = _f.read(1).astype(np.float64)
            acc_nodata = _f.nodata
        if acc_nodata is not None:
            acc_arr = np.where(acc_arr == acc_nodata, 0.0, acc_arr)
        acc_arr = np.nan_to_num(acc_arr, nan=0.0, posinf=0.0, neginf=0.0)
        # Belt-and-braces: zero out accumulation on the wall/void cells so
        # they can never qualify as stream cells or pour points.
        acc_arr = np.where(valid_mask, acc_arr, 0.0)
        max_acc = float(acc_arr[valid_mask].max()) if valid_mask.any() else float(acc_arr.max())
        feedback.pushInfo(
            f"  Max accumulation: {max_acc:.0f} cells "
            f"(≈ {max_acc * cell_m2 / 1e6:.3f} km²)")

        with rasterio.open(stream_path) as _f:
            stream_raw = _f.read(1).astype(np.float64)
            stream_nodata = _f.nodata
        stream_valid = np.isfinite(stream_raw)
        if stream_nodata is not None:
            stream_valid &= (stream_raw != stream_nodata)
        stream_valid &= (stream_raw != 0)
        streams_a = stream_valid & valid_mask
        n_sc = int(streams_a.sum())
        if n_sc < 3:
            raise QgsProcessingException(
                f"Only {n_sc} stream cells at threshold={stream_thresh}. "
                "Reduce the stream threshold.")
        feedback.pushInfo(f"  Stream cells: {n_sc}")

        with rasterio.open(basin_path) as _f:
            basin_2d = _f.read(1).astype(np.float64)
            basin_nodata = _f.nodata
        basin_valid = np.isfinite(basin_2d)
        if basin_nodata is not None:
            basin_valid &= (basin_2d != basin_nodata)
        basin_2d = np.where(basin_valid & valid_mask, basin_2d, 0).astype(np.int64)
        n_raw = len(np.unique(basin_2d[basin_2d > 0]))
        feedback.pushInfo(f"  Raw sub-basins: {n_raw}")
        feedback.setProgress(60)

        # GRASS documents that r.watershed's `stream` output values
        # correspond directly to its `basin` output values — i.e. each
        # stream reach and the sub-basin it drains already share one ID
        # scheme, the same relationship this file relied on with
        # WhiteboxTools' link/subbasin IDs. Used below for per-reach ID
        # sampling — no re-derived raster needed, this comes straight
        # from GRASS's own stream_arr already read above.
        stream_ids_arr = np.where(streams_a, stream_raw, 0).astype(np.int64)

        # ── Step 4: Vectorise the stream network (GRASS r.to.vect) ────────
        # Feeds r.watershed's own `stream` output straight into r.to.vect,
        # matching GRASS's own documented tutorial for exactly this
        # workflow (g.region ...; r.watershed elev=... stream=elev.streams
        # thresh=...; r.to.vect -s input=elev.streams output=elev_streams
        # type=line) rather than re-deriving an intermediate raster —
        # that tutorial's output already carries a `value` column equal
        # to the basin ID, which is the same thing this file samples
        # directly from the raster in Step 5 below.
        feedback.pushInfo("Step 4: Vectorising stream network (GRASS r.to.vect) …")
        streams_vec_path = os.path.join(grass_dir, 'streams_vec.gpkg')

        # The earlier attempt failed with "Incorrect parameter value for
        # type" — meaning this QGIS's wrapping of r.to.vect's `type`
        # parameter does NOT accept the plain string 'line' the GRASS
        # command line itself would (type=line), even though that's what
        # GRASS's own tutorial for this exact workflow shows. It's almost
        # certainly exposed as an enum (integer index into
        # [point, line, area]) instead. Rather than guess a single
        # encoding, inspect the actual live parameter definition for its
        # real options list and try every plausible candidate in order of
        # likelihood until one is accepted.
        type_candidates = []
        detected = _grass_param_value_for(tovect_alg_id, 'type', 'line', fallback=None)
        if detected is not None:
            type_candidates.append(detected)
        # Standard GRASS declaration order for this parameter is
        # point, line, area -> index 1 for "line" is the most likely
        # encoding if it's an enum; try it (if not already the detected
        # value), then the same for a 0-based miscount, then the plain
        # strings as a last resort.
        for cand in (1, 0, 2, 'line', 'Line', 'LINE'):
            if cand not in type_candidates:
                type_candidates.append(cand)

        tovect_errors = []
        succeeded = False
        n_line_features = 0
        for type_val in type_candidates:
            for use_s_flag in (True, False):
                params = {
                    'input': stream_path, 'type': type_val,
                    'output': streams_vec_path,
                    'GRASS_REGION_PARAMETER': dem_for_grass,
                    'GRASS_REGION_CELLSIZE_PARAMETER': 0,
                }
                if use_s_flag:
                    params['-s'] = True
                try:
                    processing.run(tovect_alg_id, params)
                except Exception as e:
                    tovect_errors.append(f"type={type_val!r}, -s={use_s_flag}: {e}")
                    continue
                if not os.path.exists(streams_vec_path):
                    tovect_errors.append(
                        f"type={type_val!r}, -s={use_s_flag}: ran without "
                        f"error but produced no output file")
                    continue
                # Critical check: a "successful" run with the WRONG type
                # value (e.g. actually producing points or polygons rather
                # than lines) creates a file just fine and raises nothing
                # — it just silently isn't what we asked for. Verify the
                # output actually contains line geometries before treating
                # this candidate as the right one; this is exactly what
                # was missing before (a wrong-but-non-erroring type value
                # produced an empty stream network with no warning).
                try:
                    _check_gdf = gpd.read_file(streams_vec_path)
                    n_line_features = int(
                        _check_gdf.geometry.type.isin(
                            ['LineString', 'MultiLineString']).sum()
                    ) if len(_check_gdf) else 0
                except Exception as e:
                    tovect_errors.append(
                        f"type={type_val!r}, -s={use_s_flag}: output file "
                        f"could not be read back ({e})")
                    continue
                if n_line_features > 0:
                    succeeded = True
                    break
                else:
                    geom_types = (sorted(_check_gdf.geometry.type.unique().tolist())
                                  if len(_check_gdf) else [])
                    tovect_errors.append(
                        f"type={type_val!r}, -s={use_s_flag}: produced "
                        f"{len(_check_gdf)} feature(s) but none were lines "
                        f"(geometry type(s) found: {geom_types or 'none'})")
            if succeeded:
                break

        streams_source = streams_vec_path
        if not succeeded:
            feedback.pushWarning(
                f"  GRASS r.to.vect didn't produce a usable line network "
                f"after trying {len(tovect_errors)} parameter combinations "
                f"(most recent: {tovect_errors[-1] if tovect_errors else 'n/a'}). "
                f"Falling back to a pure-Python vectoriser (no GRASS call) "
                f"for the stream network instead."
            )
            streams_source = _vectorize_streams_fallback(streams_a, rio_tfm, feedback)
            if not streams_source:
                detail = " | ".join(tovect_errors[-4:])
                raise QgsProcessingException(
                    "Neither GRASS r.to.vect nor the pure-Python fallback "
                    "could vectorise the stream network. "
                    f"r.to.vect attempts: {detail}\n"
                    "Check the QGIS log panel (GRASS tab) for the full "
                    "GRASS console output.")
        else:
            feedback.pushInfo(f"  r.to.vect produced {n_line_features} line feature(s)")
        feedback.setProgress(68)

        # ── Step 5: Build stream reach GeoDataFrame + Strahler order ───────
        feedback.pushInfo("Step 5: Computing per-reach stats + Strahler order …")
        streams_gdf = _build_streams_gdf_grass(
            streams_source, stream_ids_arr, acc_arr, dem_arr,
            rio_tfm, cell_m2, utm_crs_str, feedback)
        feedback.pushInfo(f"  Stream reaches: {len(streams_gdf) if streams_gdf is not None else 0}")
        feedback.setProgress(76)

        # ── Step 6: Sub-basin polygonisation ───────────────────────────────
        feedback.pushInfo("Step 6: Polygonising sub-basins …")
        min_cells = max(4, int(min_area_km2 * 1e6 / cell_m2))
        basins_gdf = _polygonize_basins(
            basin_2d, rio_tfm, min_area_km2, utm_crs_str, feedback)
        if basins_gdf is None or len(basins_gdf) == 0:
            raise QgsProcessingException(
                "No sub-basins delineated. "
                "Reduce minimum area or stream threshold.")
        feedback.pushInfo(f"  Sub-basins: {len(basins_gdf)}")
        feedback.setProgress(82)


        # ── Step 9b: Defensive clip to the supplied boundary (if any) ─────
        # Only meaningful when the user gave a boundary. Without one there
        # is nothing to clip to — the sub-basins ARE the delineation, and
        # every polygon is inside the DEM by construction.
        if catch_union is not None:
            try:
                basins_gdf['geometry'] = basins_gdf.geometry.intersection(catch_union)
                basins_gdf = basins_gdf[~basins_gdf.geometry.is_empty]
                basins_gdf['Area_km2'] = (basins_gdf.geometry.area / 1e6).round(4)
            except Exception as e:
                feedback.pushWarning(f"  Could not clip basins to boundary: {e}")
            if streams_gdf is not None and len(streams_gdf) > 0:
                try:
                    streams_gdf['geometry'] = streams_gdf.geometry.intersection(catch_union)
                    streams_gdf = streams_gdf[~streams_gdf.geometry.is_empty]
                except Exception as e:
                    feedback.pushWarning(f"  Could not clip streams to boundary: {e}")
        max_ord = int(streams_gdf['Order'].max()) if (streams_gdf is not None and len(streams_gdf) > 0) else 1

        # ── Step 10: Save outputs ─────────────────────────────────────────
        feedback.pushInfo("Step 10: Saving outputs …")
        basins_gpkg  = os.path.join(output_folder, 'sub_basins.gpkg')
        streams_gpkg = os.path.join(output_folder, 'streams.gpkg')
        basins_gdf.to_file(basins_gpkg, driver='GPKG')
        feedback.pushInfo(f"  sub_basins.gpkg  ({len(basins_gdf)} features)")
        if streams_gdf is not None and len(streams_gdf) > 0:
            streams_gdf.to_file(streams_gpkg, driver='GPKG')
            feedback.pushInfo(f"  streams.gpkg     ({len(streams_gdf)} features)")
        else:
            feedback.pushWarning("  No stream reaches to save.")

        stats_txt = os.path.join(output_folder, 'subcatchment_stats.txt')
        _write_stats(basins_gdf, streams_gdf, stream_thresh,
                     min_area_km2, max_ord, stats_txt)
        feedback.setProgress(92)

        # ── Step 11: Load in QGIS ─────────────────────────────────────────
        if load_in_qgis:
            _load_vector(basins_gpkg,  'Sub-basins',     'polygon', feedback)
            if streams_gdf is not None and len(streams_gdf) > 0:
                _load_vector(streams_gpkg, 'Stream Network', 'line', feedback)

        # Cleanup temp rasters
        for p in [clip_dem]:
            try: os.remove(p)
            except Exception: pass
        gc.collect()

        feedback.setProgress(100)
        feedback.pushInfo("=== Done ===")
        return {'SUB_BASINS': basins_gpkg,
                'STREAMS':    streams_gpkg,
                'STATS':      stats_txt}

    def name(self):           return 'subcatchment_delineation'
    def displayName(self):    return 'Subcatchment Delineation & Streams'
    def group(self):          return 'Hydrology'
    def groupId(self):        return 'hydrology'
    def createInstance(self): return SubcatchmentDelineation()


def _find_grass_alg_id(module_suffix, feedback=None):
    """
    Find the exact QGIS Processing algorithm ID for a GRASS module (e.g.
    'r.watershed'), without hardcoding a version-specific provider prefix
    (grass7:, grass8:, or unprefixed — this has changed across QGIS/GRASS
    releases). Searches the live Processing registry and returns the ID of
    the first match, or None if no GRASS provider algorithm for this
    module is registered at all.
    """
    try:
        reg = QgsApplication.processingRegistry()
        for alg in reg.algorithms():
            alg_id = alg.id()
            if 'grass' in alg_id.lower() and alg_id.lower().endswith(module_suffix.lower()):
                return alg_id
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"  Processing registry lookup failed: {e}")
    return None


def _grass_param_value_for(alg_id, param_name, desired_substring, fallback):
    """
    Some GRASS module parameters (e.g. r.to.vect's 'type') are exposed by
    QGIS Processing as an enum (integer index into a list of options) in
    some versions and as a plain string in others. Inspect the actual
    parameter definition at runtime and return whichever form it expects,
    rather than guessing one and hardcoding it.
    """
    try:
        reg = QgsApplication.processingRegistry()
        alg = reg.algorithmById(alg_id)
        if alg is None:
            return fallback
        param = alg.parameterDefinition(param_name)
        if param is None:
            return fallback
        options = getattr(param, 'options', None)
        if callable(options):
            opts = param.options()
            for i, opt in enumerate(opts):
                if desired_substring.lower() in str(opt).lower():
                    return i
        return fallback
    except Exception:
        return fallback


def _split_qgis_source(source_str):
    """
    QGIS's QgsVectorLayer.source() returns a plain file path for simple
    shapefiles, but for multi-layer containers (GeoPackage, FileGDB, etc.)
    it returns a decorated URI like
    '/path/to/file.gpkg|layername=catchment_boundary'.

    Passing that decorated string straight to geopandas.read_file() is not
    reliable — depending on the GDAL/Fiona version it can silently fall
    back to whichever layer GDAL treats as the default, which is not
    necessarily the layer the user actually selected in QGIS. That would
    read the wrong feature(s): geometry that's internally consistent but
    simply the wrong boundary — visually indistinguishable from a
    "shifted" one.

    Returns (path, layer_name_or_None).
    """
    if '|' not in source_str:
        return source_str, None
    path, _, rest = source_str.partition('|')
    layer_name = None
    for part in rest.split('|'):
        if part.startswith('layername='):
            layer_name = part.split('=', 1)[1]
    return path, layer_name


def _read_vector_with_authoritative_crs(gpd, path, qgis_layer, feedback):
    """
    Read a vector file with geopandas.

    Only fall back to the QGIS-assigned CRS when the file has NO CRS at
    all. If the file's CRS merely differs from what QGIS shows, trust the
    file (silently overriding on a guess is itself a way to introduce a
    shift) and log both values so the mismatch is visible for diagnosis.
    """
    gdf_path, gdf_layer = _split_qgis_source(path)
    if gdf_layer:
        feedback.pushInfo(f"  Reading catchment layer '{gdf_layer}' from {gdf_path}")
        gdf = gpd.read_file(gdf_path, layer=gdf_layer)
    else:
        gdf = gpd.read_file(gdf_path)
    qgis_crs_authid = qgis_layer.crs().authid() if qgis_layer.crs().isValid() else None

    if gdf.crs is None:
        if qgis_crs_authid:
            feedback.pushWarning(
                f"  Catchment file has no embedded CRS — using the CRS "
                f"assigned in QGIS ({qgis_crs_authid}) instead.")
            gdf = gdf.set_crs(qgis_crs_authid, allow_override=True)
        else:
            feedback.pushWarning(
                "  Catchment file has no embedded CRS and QGIS has none "
                "assigned either. Reprojection may be unreliable.")
    elif qgis_crs_authid:
        try:
            file_authid = gdf.crs.to_authority()
            file_authid_str = ':'.join(file_authid) if file_authid else str(gdf.crs)
        except Exception:
            file_authid_str = str(gdf.crs)
        if file_authid_str.upper() != qgis_crs_authid.upper():
            feedback.pushWarning(
                f"  Note: catchment file's embedded CRS ({file_authid_str}) "
                f"differs from the CRS QGIS shows for this layer "
                f"({qgis_crs_authid}). Using the file's own CRS "
                f"({file_authid_str})."
            )
    return gdf


# ═══════════════════════════════════════════════════════════════════════════
# Stream GeoDataFrame builder (GRASS r.to.vect output) + Strahler order
# ═══════════════════════════════════════════════════════════════════════════

def _compute_strahler_order(lines_geom, up_down_priority, tol=1e-6):
    """
    Compute Strahler stream order from pure vector topology — which line
    endpoints connect to which — using only `up_down_priority(point)` (a
    function returning a value that is HIGHER at a segment's downstream
    end than its upstream end, e.g. flow accumulation sampled there) to
    orient each edge. This deliberately never touches any GRASS-specific
    (or pysheds-specific) raster direction encoding, since that class of
    thing is exactly what's easy to get subtly wrong without a way to
    test against a real installation — this graph logic, by contrast, is
    covered by isolated tests against known confluence topologies
    (simple forks, 3-way simultaneous confluences, equal/unequal-order
    merges) independent of any particular hydrology engine.

    Returns a list of ints, one Strahler order per input geometry, in the
    same order as `lines_geom`.
    """
    from collections import deque

    def key(pt):
        return (round(pt[0] / tol) * tol, round(pt[1] / tol) * tol)

    n = len(lines_geom)
    if n == 0:
        return []

    up_node, down_node = [], []
    for geom in lines_geom:
        coords = list(geom.coords)
        p0, p1 = coords[0], coords[-1]
        v0, v1 = up_down_priority(p0), up_down_priority(p1)
        if v0 <= v1:
            up_node.append(key(p0)); down_node.append(key(p1))
        else:
            up_node.append(key(p1)); down_node.append(key(p0))

    incoming = {}
    for i in range(n):
        incoming.setdefault(down_node[i], []).append(i)

    order = [None] * n
    node_order = {}
    resolved_count_at_node = {}
    in_deg_at_upnode = [len(incoming.get(up_node[i], [])) for i in range(n)]

    q = deque()
    for i in range(n):
        if in_deg_at_upnode[i] == 0:
            order[i] = 1
            q.append(i)

    processed = [False] * n
    guard = 0
    guard_max = n * 4 + 10  # generous bound; prevents any pathological
                            # topology (e.g. a data glitch forming a loop)
                            # from hanging instead of just finishing with
                            # whatever could be resolved.
    while q and guard < guard_max:
        guard += 1
        i = q.popleft()
        if processed[i]:
            continue
        processed[i] = True
        dn = down_node[i]
        resolved_count_at_node[dn] = resolved_count_at_node.get(dn, 0) + 1
        total_incoming = len(incoming.get(dn, []))
        if resolved_count_at_node[dn] == total_incoming:
            in_orders = [order[j] for j in incoming[dn] if order[j] is not None]
            if in_orders:
                mx = max(in_orders)
                node_order[dn] = mx + 1 if in_orders.count(mx) >= 2 else mx
            for j in range(n):
                if up_node[j] == dn and order[j] is None:
                    order[j] = node_order.get(dn, 1)
                    q.append(j)

    # Anything left unresolved (shouldn't normally happen) defaults to 1
    # rather than leaving a None that would break downstream code.
    return [o if o is not None else 1 for o in order]


def _vectorize_streams_fallback(stream_mask, rio_tfm, feedback=None):
    """
    Vectorise a stream raster into LineStrings using only numpy + shapely
    — no GRASS r.to.vect call at all. Used as a fallback if r.to.vect
    can't be made to work in a given QGIS/GRASS installation (e.g. an
    unresolvable parameter-encoding mismatch), so a single stubborn
    Processing call can't leave this tool without any way to produce a
    stream network at all.

    Traces the stream pixel network (8-connectivity) between junction/
    endpoint cells (any cell whose count of stream neighbours isn't
    exactly 2) into individual line segments — the same segment
    granularity r.to.vect + r.watershed's stream/basin IDs would give.
    """
    from shapely.geometry import LineString

    rows, cols = np.where(stream_mask)
    if len(rows) == 0:
        return None
    cellset = set(zip(rows.tolist(), cols.tolist()))

    if feedback:
        feedback.pushInfo(
            f"  Fallback vectoriser: tracing {len(cellset):,} stream cells …")

    def neighbors(rc):
        r, c = rc
        out = []
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                nb = (r + dr, c + dc)
                if nb in cellset:
                    out.append(nb)
        return out

    neighbor_cache = {rc: neighbors(rc) for rc in cellset}
    degree = {rc: len(nb) for rc, nb in neighbor_cache.items()}
    junctions = [rc for rc, d in degree.items() if d != 2]

    def cell_xy(rc):
        r, c = rc
        x, y = rio_tfm * (c + 0.5, r + 0.5)
        return (x, y)

    visited_edges = set()
    line_geoms = []

    for j in junctions:
        for nb in neighbor_cache[j]:
            edge = (j, nb) if j < nb else (nb, j)
            if edge in visited_edges:
                continue
            path = [j, nb]
            visited_edges.add(edge)
            prev, cur = j, nb
            while degree.get(cur, 0) == 2:
                nxts = [z for z in neighbor_cache[cur] if z != prev]
                if not nxts:
                    break
                nxt = nxts[0]
                e2 = (cur, nxt) if cur < nxt else (nxt, cur)
                if e2 in visited_edges:
                    break
                visited_edges.add(e2)
                path.append(nxt)
                prev, cur = cur, nxt
            if len(path) >= 2:
                line_geoms.append(LineString([cell_xy(p) for p in path]))

    # Any purely isolated stream cells (degree 0 — shouldn't normally
    # happen above a real threshold, but handle defensively) become a
    # zero-length point-like line so they aren't silently dropped.
    isolated = [rc for rc, d in degree.items() if d == 0]
    for rc in isolated:
        x, y = cell_xy(rc)
        line_geoms.append(LineString([(x, y), (x + 1e-6, y + 1e-6)]))

    if feedback:
        feedback.pushInfo(f"  Fallback vectoriser: {len(line_geoms):,} segments")
    return line_geoms


def _build_streams_gdf_grass(streams_vec_source, stream_ids_arr, acc_arr, dem_arr,
                              rio_tfm, cell_m2, crs_str, feedback):
    """
    Build the final stream GeoDataFrame from a vectorised stream network.
    `streams_vec_source` is either a path to a vector file (GRASS
    r.to.vect output) or a plain list of shapely LineString geometries
    (from the pure-Python fallback vectoriser, used if r.to.vect can't be
    made to work). Per-reach length comes directly from each line's own
    geometry; slope from the DEM elevation difference between its two
    endpoints; upstream area from the accumulation raster sampled at the
    downstream endpoint; Strahler order from _compute_strahler_order
    above (using accumulation to tell upstream from downstream, not any
    GRASS-specific direction code). StreamID comes from GRASS's own
    basin/stream ID (sampled at the segment's midpoint), which — per
    GRASS's documented behaviour — already matches the sub-basin each
    reach belongs to.
    """
    import geopandas as gpd

    if isinstance(streams_vec_source, str):
        if not os.path.exists(streams_vec_source):
            return None
        gdf = gpd.read_file(streams_vec_source)
        if gdf.empty:
            return None
        gdf = gdf.set_crs(crs_str, allow_override=True)
        # Only keep true line geometries (r.to.vect / GRASS export can
        # include stray point features for start/confluence nodes in some
        # versions).
        gdf = gdf[gdf.geometry.type.isin(['LineString', 'MultiLineString'])].reset_index(drop=True)
        # Explode any MultiLineString into individual LineStrings so the
        # topology logic below has clean single-part geometries to work with.
        gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    else:
        # Pre-built list of LineStrings from the fallback vectoriser.
        if not streams_vec_source:
            return None
        gdf = gpd.GeoDataFrame({'geometry': list(streams_vec_source)}, crs=crs_str)
    if gdf.empty:
        return None

    rows, cols = stream_ids_arr.shape
    inv = ~rio_tfm  # world (x, y) -> (col, row)

    def _sample(arr, x, y, default=0.0):
        c, r = inv * (x, y)
        ci, ri = int(round(c)), int(round(r))
        if 0 <= ri < rows and 0 <= ci < cols:
            v = arr[ri, ci]
            if np.isfinite(v):
                return float(v)
        return default

    def _nearest_nonzero_id(x, y, max_radius=3):
        """Search an expanding window around (x, y) for the nearest
        non-zero stream ID — a defensive fallback for when a sampled
        point lands just off the 1-pixel-wide stream line (e.g. right at
        a confluence, or a vertex that rounds to an adjacent cell)."""
        c, r = inv * (x, y)
        ci, ri = int(round(c)), int(round(r))
        best_id, best_d2 = 0, None
        for radius in range(1, max_radius + 1):
            r0, r1 = max(0, ri - radius), min(rows, ri + radius + 1)
            c0, c1 = max(0, ci - radius), min(cols, ci + radius + 1)
            window = stream_ids_arr[r0:r1, c0:c1]
            nz = np.argwhere(window > 0)
            if nz.size:
                for dy, dx in nz:
                    d2 = (dy + r0 - ri) ** 2 + (dx + c0 - ci) ** 2
                    if best_d2 is None or d2 < best_d2:
                        best_d2 = d2
                        best_id = int(window[dy, dx])
                return best_id
        return best_id

    def _acc_priority(pt):
        return _sample(acc_arr, pt[0], pt[1], default=0.0)

    geoms = list(gdf.geometry)
    orders = _compute_strahler_order(geoms, _acc_priority)

    stream_ids, lengths, upareas, slopes = [], [], [], []
    for geom in geoms:
        coords = list(geom.coords)
        p0, p1 = coords[0], coords[-1]
        mx, my = geom.interpolate(0.5, normalized=True).coords[0]
        sid = int(round(_sample(stream_ids_arr, mx, my, default=0.0)))
        if sid == 0:
            # Midpoint landed off the 1-pixel-wide stream line (can happen
            # right at a confluence); try the endpoint with higher
            # accumulation (the segment's own downstream end) first ...
            end_acc0, end_acc1 = _acc_priority(p0), _acc_priority(p1)
            probe = p1 if end_acc1 >= end_acc0 else p0
            sid = int(round(_sample(stream_ids_arr, probe[0], probe[1], default=0.0)))
        if sid == 0:
            # ... and if that still misses, search a small neighbourhood
            # around the midpoint for the nearest actual stream-ID pixel.
            sid = _nearest_nonzero_id(mx, my)
        stream_ids.append(sid)

        length_m = geom.length
        lengths.append(round(length_m / 1000.0, 4))

        acc0, acc1 = _acc_priority(p0), _acc_priority(p1)
        upareas.append(round(max(acc0, acc1) * cell_m2 / 1e6, 4))

        elev0 = _sample(dem_arr, p0[0], p0[1], default=np.nan)
        elev1 = _sample(dem_arr, p1[0], p1[1], default=np.nan)
        if np.isfinite(elev0) and np.isfinite(elev1) and length_m > 0:
            slope_pct = abs(elev0 - elev1) / length_m * 100.0
        else:
            slope_pct = 0.0
        slopes.append(round(slope_pct, 4))

    gdf['StreamID']         = stream_ids
    gdf['Order']            = orders
    gdf['Length_km']        = lengths
    gdf['UpstreamArea_km2'] = upareas
    gdf['AvgSlope_pct']     = slopes

    return gdf[['StreamID', 'Order', 'Length_km',
                'UpstreamArea_km2', 'AvgSlope_pct', 'geometry']]


# ═══════════════════════════════════════════════════════════════════════════
# Sub-basin polygonisation (raster comes straight from GRASS r.watershed's
# own `basin` output — no custom pour-point search / BFS needed)
# ═══════════════════════════════════════════════════════════════════════════

def _polygonize_basins(basin_2d, rio_tfm, min_area_km2, crs_str, feedback):
    """Polygonise GRASS r.watershed's basin raster, merge slivers, and name
    the result S1…SN largest-first."""
    import geopandas as gpd
    from shapely.geometry import shape
    from shapely.ops import unary_union
    from rasterio.features import shapes as rio_shapes

    ids = np.unique(basin_2d[basin_2d > 0])
    basin_rows = []
    for bid in ids:
        mask = (basin_2d == bid).astype(np.uint8)
        n_px = int(mask.sum())
        if n_px < 4:
            continue
        polys = [shape(g) for g, v in rio_shapes(mask, transform=rio_tfm) if v == 1]
        if not polys:
            continue
        geom = unary_union(polys)
        if not geom.is_valid:
            geom = geom.buffer(0)
        basin_rows.append({
            'geometry': geom,
            'Area_km2': round(geom.area / 1e6, 4),
        })

    if not basin_rows:
        return None

    gdf = gpd.GeoDataFrame(basin_rows, crs=crs_str)
    gdf = _merge_tiny_basins(gdf, min_area_km2, feedback)
    gdf = gdf.sort_values('Area_km2', ascending=False).reset_index(drop=True)
    gdf['Name'] = [f'S{i + 1}' for i in range(len(gdf))]
    return gdf[['Name', 'Area_km2', 'geometry']]



def _merge_tiny_basins(gdf, min_area_km2, feedback):
    """
    Merge polygons below min_area_km2 into their most naturally adjacent
    neighbour (longest shared boundary — see below for why not simply
    the largest neighbour), then fix any basin left as a literal island
    fully enclosed inside another.
    """
    import geopandas as gpd
    from shapely.ops import unary_union

    n_raw = len(gdf)
    changed = True
    while changed:
        changed = False
        if len(gdf) <= 2:
            # Never merge past 2 remaining basins — a single basin
            # matching the whole catchment defeats the purpose of this
            # tool entirely, and is a strong sign the Minimum Sub-basin
            # Area setting is too large relative to this catchment's
            # natural sub-basin sizes (see the warning below), not
            # something to silently do anyway.
            break
        tiny_idx = gdf[gdf['Area_km2'] < min_area_km2].index.tolist()
        if not tiny_idx:
            break
        for ti in tiny_idx:
            if ti not in gdf.index:
                continue
            if len(gdf) <= 2:
                break
            tiny_geom = gdf.at[ti, 'geometry']
            # Find touching neighbours
            touches = gdf[gdf.index != ti].copy()
            touches['touches'] = touches.geometry.apply(
                lambda g: g.touches(tiny_geom) or g.intersects(tiny_geom))
            nbrs = touches[touches['touches']]
            if len(nbrs) == 0:
                continue
            # Merge into whichever neighbour shares the LONGEST common
            # boundary with the tiny basin, not simply the largest
            # neighbour by area. Picking by area alone can select a big
            # basin that only touches the tiny one at a single corner or
            # a short edge, which is not a natural adjacency — merging
            # into it produces elongated, oddly-shaped combined polygons.
            # Shared boundary length is a standard, more geometrically
            # sound heuristic for "which neighbour does this basin really
            # belong with."
            def _shared_len(g):
                try:
                    inter = g.boundary.intersection(tiny_geom.boundary)
                    return inter.length if not inter.is_empty else 0.0
                except Exception:
                    return 0.0
            nbrs = nbrs.copy()
            nbrs['shared_len'] = nbrs.geometry.apply(_shared_len)
            if nbrs['shared_len'].max() > 0:
                best_i = nbrs['shared_len'].idxmax()
            else:
                # Degenerate case (e.g. only point contact) — fall back
                # to the largest neighbour rather than merging nowhere.
                best_i = nbrs['Area_km2'].idxmax()
            merged = unary_union([gdf.at[best_i, 'geometry'], tiny_geom])
            if not merged.is_valid:
                merged = merged.buffer(0)
            gdf.at[best_i, 'geometry']  = merged
            gdf.at[best_i, 'Area_km2']  = merged.area / 1e6
            gdf = gdf.drop(index=ti).reset_index(drop=True)
            changed = True
            break

    gdf = _fix_enclosed_islands(gdf, feedback)

    n_final = len(gdf)
    if feedback and n_raw > 1 and (n_final == 1 or n_final < max(2, n_raw * 0.1)):
        feedback.pushWarning(
            f"  Minimum Sub-basin Area merged {n_raw} raw basin(s) down to "
            f"just {n_final} — this Min Area setting is likely too large "
            f"relative to this catchment's natural sub-basin sizes. If you "
            f"expected multiple sub-basins, reduce Minimum Sub-basin Area "
            f"and re-run."
        )

    return gdf


def _fix_enclosed_islands(gdf, feedback):
    """
    A basin can end up as a literal island fully enclosed inside another
    basin's shape as a side effect of the surrounding fragments merging
    together — even though neither basin individually did anything
    wrong, the geometric result is topologically odd for dendritic
    drainage sub-basins (which should partition space without holes or
    disconnected enclaves). Detect any basin whose geometry sits
    entirely within another's and dissolve it into that surrounding
    basin.
    """
    from shapely.ops import unary_union

    if len(gdf) <= 1:
        return gdf

    changed = True
    n_fixed = 0
    while changed and len(gdf) > 1:
        changed = False
        for i in gdf.index:
            geom_i = gdf.at[i, 'geometry']
            for j in gdf.index:
                if i == j:
                    continue
                geom_j = gdf.at[j, 'geometry']
                try:
                    if geom_i.within(geom_j) or geom_j.buffer(1e-6).contains(geom_i):
                        merged = unary_union([geom_i, geom_j])
                        if not merged.is_valid:
                            merged = merged.buffer(0)
                        gdf.at[j, 'geometry'] = merged
                        gdf.at[j, 'Area_km2'] = merged.area / 1e6
                        gdf = gdf.drop(index=i).reset_index(drop=True)
                        changed = True
                        n_fixed += 1
                        break
                except Exception:
                    continue
            if changed:
                break

    if feedback and n_fixed > 0:
        feedback.pushInfo(
            f"  Fixed {n_fixed} sub-basin(s) that ended up fully enclosed "
            f"inside another after merging — dissolved into the "
            f"surrounding basin (a real sub-basin shouldn't be an island "
            f"inside another one)."
        )
    return gdf


# ═══════════════════════════════════════════════════════════════════════════
# Output helpers
# ═══════════════════════════════════════════════════════════════════════════

def _write_stats(basins_gdf, streams_gdf, stream_thresh,
                  min_area_km2, max_order, out_path):
    lines = [
        "=== Subcatchment Delineation Statistics – Rain2Flood v3.0 ===\n",
        f"Engine:                  GRASS r.watershed + r.to.vect (via QGIS Processing)",
        f"Stream threshold (cells): {stream_thresh}",
        f"Minimum basin area (km²): {min_area_km2}",
        f"Max Strahler order:       {max_order}",
        "",
    ]
    if basins_gdf is not None and len(basins_gdf):
        lines += ["--- Sub-basins ---",
                  f"{'Name':<10}  {'Area_km2':>12}", "-" * 26]
        for _, row in basins_gdf.iterrows():
            lines.append(f"{row['Name']:<10}  {row['Area_km2']:>12.4f}")
        lines.append(
            f"\nTotal: {len(basins_gdf)} sub-basins  "
            f"{basins_gdf['Area_km2'].sum():.4f} km²")
    lines.append("")
    if streams_gdf is not None and len(streams_gdf):
        lines += ["--- Stream reaches ---",
                  f"{'ID':>4}  {'Ord':>3}  {'Length_km':>10}  "
                  f"{'UpsArea_km2':>12}  {'Slope_%':>8}",
                  "-" * 46]
        for _, row in streams_gdf.iterrows():
            lines.append(
                f"{row['StreamID']:>4}  {row['Order']:>3}  "
                f"{row['Length_km']:>10.3f}  "
                f"{row['UpstreamArea_km2']:>12.3f}  "
                f"{row['AvgSlope_pct']:>8.3f}")
        lines.append(f"\nTotal reaches: {len(streams_gdf)}")
    with open(out_path, 'w') as f:
        f.write('\n'.join(lines))


def _load_vector(path, name, geom_type, feedback):
    if not os.path.exists(path):
        return
    try:
        proj = QgsProject.instance()
        stale = [lyr.id() for lyr in proj.mapLayers().values() if lyr.name() == name]
        if stale:
            proj.removeMapLayers(stale)
            feedback.pushInfo(
                f"  Removed {len(stale)} previous layer(s) named '{name}' "
                f"before loading the new one.")
        layer = QgsVectorLayer(path, name, 'ogr')
        if not layer.isValid():
            feedback.pushWarning(f"  Failed to load {name}")
            return
        if geom_type == 'polygon':
            _style_basins(layer)
        else:
            _style_streams(layer)
        proj.addMapLayer(layer)
        feedback.pushInfo(f"  Loaded: {name}")
    except Exception as e:
        feedback.pushWarning(f"  Could not load {name}: {e}")


def _style_basins(layer):
    try:
        from qgis.core import QgsCategorizedSymbolRenderer, \
            QgsRendererCategory, QgsFillSymbol
        import colorsys
        feats = list(layer.getFeatures())
        n     = max(len(feats), 1)
        cats  = []
        for i, feat in enumerate(feats):
            h    = (i / n) % 1.0
            r, g, b = [int(v * 255) for v in colorsys.hsv_to_rgb(h, 0.45, 0.90)]
            sym  = QgsFillSymbol.createSimple({
                'color':         f'{r},{g},{b},150',
                'outline_color': '#1565C0',
                'outline_width': '0.6',
            })
            cats.append(QgsRendererCategory(feat['Name'], sym, feat['Name']))
        layer.setRenderer(QgsCategorizedSymbolRenderer('Name', cats))
        layer.triggerRepaint()
    except Exception:
        pass


def _style_streams(layer):
    try:
        from qgis.core import QgsGraduatedSymbolRenderer, \
            QgsRendererRange, QgsLineSymbol
        palette = ['#90CAF9', '#42A5F5', '#1565C0', '#0D3B8E', '#050A30']
        ranges  = []
        for order in range(1, 6):
            sym = QgsLineSymbol.createSimple({
                'color': palette[min(order-1, 4)],
                'width': str(0.4 + order * 0.4),
            })
            ranges.append(QgsRendererRange(
                order - 0.5, order + 0.5, sym, f'Order {order}'))
        layer.setRenderer(QgsGraduatedSymbolRenderer('Order', ranges))
        layer.triggerRepaint()
    except Exception:
        pass
