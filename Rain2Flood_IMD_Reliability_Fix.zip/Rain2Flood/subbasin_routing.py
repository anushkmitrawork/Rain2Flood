"""
Semi-Distributed Sub-Basin Routing
==================================
Run the rainfall-runoff calculation for EACH sub-basin separately, then
lag each sub-basin's hydrograph by its own travel time to the pour point
and sum them there.

Why this matters for a large catchment: the lumped approach treats the
whole catchment as one unit with one area-weighted CN and one time of
concentration derived from the single longest flow path. On a 2,500 km²
catchment that is a strong simplification — it implicitly assumes every
part of the catchment contributes with the same timing and the same
runoff characteristics. In reality a near-outlet sub-basin responds
within hours while a headwater sub-basin's contribution arrives much
later, and the two rarely peak together. Summing lagged sub-basin
hydrographs captures that offset, which usually gives a LOWER and
broader peak than the lumped calculation — the lumped result tends to
over-predict because it effectively assumes perfect synchronisation.

Honest scope: this is "lag and sum", not full network routing. Each
sub-basin's hydrograph is translated to the pour point by a travel time
and superposed. It does NOT solve channel storage attenuation between
sub-basins (Muskingum-Cunge is available separately for that on the
combined hydrograph), and it does not resolve which sub-basin flows into
which — it routes everything to the single pour point. That is a real
step up from lumped, and a real step down from a full HEC-HMS style
network model.
"""

import os
import numpy as np


def load_subbasins(subbasin_path, pour_point_xy=None, dem_crs=None,
                    catchment_path=None, feedback=None):
    """
    Load sub-basin polygons and compute, for each: area, centroid, and
    straight-line distance from its centroid to the pour point.

    pour_point_xy : (x, y) in the sub-basin layer's CRS. If None, the
                    centroid of the lowest sub-basin is not assumed —
                    the caller must supply a pour point, because guessing
                    one silently would anchor every result somewhere the
                    user never chose.

    catchment_path : the analysis catchment. Sub-basins are CLIPPED to it
                    and anything outside is dropped.

    Why the clip is not optional. Tab 2 now delineates the whole DEM
    rather than a user-supplied boundary, which is correct for the stream
    network (clipping truncates upstream contributing area at the clip
    edge) but means sub_basins.gpkg covers the entire DEM, not the
    catchment being analysed. Routing every polygon in that layer to the
    pour point sums water from basins that drain somewhere else entirely.
    Observed on a real run: 258 sub-basins totalling 8155 km² routed to
    the outlet of a 2355 km² catchment — 3.5x the contributing area — and
    the semi-distributed peak came out 432% above the lumped one, which
    was then reported as a timing effect rather than the area error it
    actually was.
    """
    try:
        import geopandas as gpd
    except ImportError:
        if feedback:
            feedback.reportError("geopandas is required for sub-basin routing.")
        return None

    try:
        gdf = gpd.read_file(subbasin_path)
    except Exception as e:
        if feedback:
            feedback.reportError(f"Could not read sub-basin layer: {e}")
        return None
    if gdf.empty:
        if feedback:
            feedback.pushWarning("Sub-basin layer has no features.")
        return None

    if gdf.crs is not None and gdf.crs.is_geographic:
        if feedback:
            feedback.pushWarning(
                "  Sub-basin layer is in a geographic CRS (degrees). Areas and "
                "distances need a projected CRS to be meaningful — reproject "
                "the sub-basins to a metric CRS (e.g. the UTM zone used for "
                "the DEM) and re-run."
            )
        return None

    # ── Clip to the analysis catchment ───────────────────────────────
    n_before = len(gdf)
    area_before = float(sum(g.area for g in gdf.geometry if g is not None)) / 1e6
    if catchment_path:
        try:
            from shapely.ops import unary_union
            cat = gpd.read_file(catchment_path)
            if gdf.crs is not None and cat.crs is not None and cat.crs != gdf.crs:
                cat = cat.to_crs(gdf.crs)
            cat_geom = unary_union(list(cat.geometry))
            gdf = gdf[gdf.geometry.intersects(cat_geom)].copy()
            gdf['geometry'] = gdf.geometry.intersection(cat_geom)
            gdf = gdf[~gdf.geometry.is_empty & gdf.geometry.notna()].copy()
            # Drop slivers left by boundary geometry that are too small to
            # carry meaningful runoff.
            gdf = gdf[gdf.geometry.area > 1e4].copy()      # > 0.01 km²
            area_after = float(gdf.geometry.area.sum()) / 1e6
            if feedback:
                feedback.pushInfo(
                    f"  Clipped sub-basins to the analysis catchment: "
                    f"{n_before} -> {len(gdf)} polygon(s), "
                    f"{area_before:.1f} -> {area_after:.1f} km².")
                if area_before > 1.2 * area_after:
                    feedback.pushInfo(
                        f"  ({area_before - area_after:.0f} km² of the "
                        f"sub-basin layer drains outside this catchment and "
                        f"has been excluded — routing it to this pour point "
                        f"would have inflated the peak.)")
        except Exception as e:
            if feedback:
                feedback.pushWarning(
                    f"  Could not clip sub-basins to the catchment ({e}). "
                    f"Routing every polygon in the layer instead — if the "
                    f"layer covers more than this catchment, the "
                    f"semi-distributed peak will be too high.")
    elif feedback:
        feedback.pushWarning(
            "  No catchment supplied to clip the sub-basin layer against. "
            "If that layer covers more than the catchment being analysed "
            "(Tab 2 delineates the whole DEM), the semi-distributed peak "
            "will include runoff that never reaches this pour point.")

    if gdf.empty:
        if feedback:
            feedback.pushWarning(
                "  No sub-basins remain inside the catchment after "
                "clipping. Skipping semi-distributed routing.")
        return None

    rows = []
    for idx, feat in gdf.iterrows():
        geom = feat.geometry
        if geom is None or geom.is_empty:
            continue
        c = geom.centroid
        name = None
        for key in ('Name', 'name', 'NAME', 'ID', 'id'):
            if key in gdf.columns:
                name = str(feat[key])
                break
        rows.append({
            'name': name or f'S{idx + 1}',
            'area_km2': geom.area / 1e6,
            'centroid_x': c.x, 'centroid_y': c.y,
            'geometry': geom,
        })

    if pour_point_xy is not None:
        px, py = pour_point_xy
        for r in rows:
            r['dist_to_outlet_m'] = float(
                np.hypot(r['centroid_x'] - px, r['centroid_y'] - py))
    else:
        for r in rows:
            r['dist_to_outlet_m'] = 0.0

    total = sum(r['area_km2'] for r in rows)
    if feedback:
        feedback.pushInfo(
            f"  Loaded {len(rows)} sub-basin(s), total area {total:.2f} km² "
            f"(range {min(r['area_km2'] for r in rows):.2f} – "
            f"{max(r['area_km2'] for r in rows):.2f} km²)"
        )
        if len(rows) == 1:
            feedback.pushWarning(
                "  This layer contains only ONE polygon, so there is nothing to "
                "distribute — semi-distributed routing needs the MULTI-POLYGON "
                "sub-basin output from Tab 2 (sub_basins.gpkg), not the catchment "
                "boundary. With a single polygon the 'semi-distributed' result is "
                "just the lumped calculation using an area-derived flow length "
                "instead of the traced longest flow path, so any difference from "
                "the lumped value is an artefact of that approximation, NOT a "
                "genuine timing effect. Select the sub-basins layer and re-run."
            )
        elif len(rows) < 4:
            feedback.pushWarning(
                f"  Only {len(rows)} sub-basins — semi-distributed routing gains "
                f"little over lumped at this level of subdivision. Reduce the "
                f"'Minimum Sub-basin Area' in Tab 2 for a finer breakdown."
            )
    return rows


def zonal_mean(raster_path, geom, fallback, feedback=None, valid_range=None):
    """
    Mean raster value within one polygon — used to get each sub-basin's
    OWN CN and Manning's n rather than reusing the catchment-wide
    average, which is the whole point of going semi-distributed.
    Returns `fallback` if the raster can't be sampled there.
    """
    if not raster_path or not os.path.exists(raster_path):
        return fallback
    try:
        import rasterio
        from rasterio.mask import mask as rasterio_mask
        from shapely.geometry import mapping
        with rasterio.open(raster_path) as src:
            out, _ = rasterio_mask(src, [mapping(geom)], crop=True,
                                    nodata=-9999.0, filled=True)
            arr = out[0].astype(np.float64)
            arr[arr <= -9998] = np.nan
            if valid_range:
                lo, hi = valid_range
                arr[(arr < lo) | (arr > hi)] = np.nan
            if np.all(np.isnan(arr)):
                return fallback
            return float(np.nanmean(arr))
    except Exception:
        return fallback


def route_subbasins_to_outlet(subbasins, design_rain_mm, storm_dur_hr,
                               cn_default, manning_default, slope_pct,
                               cn_raster_path=None, feedback=None,
                               wave_celerity_ms=1.0):
    """
    Build and combine sub-basin hydrographs at the pour point.

    For each sub-basin:
      1. its own CN (from the CN raster within that polygon, if supplied)
      2. its own runoff depth via SCS-CN
      3. its own time to peak from its own area and flow length
      4. its own SCS unit hydrograph, scaled to its runoff depth
      5. lagged by travel time = distance_to_outlet / wave_celerity

    Then all lagged hydrographs are summed onto a common time base.

    wave_celerity_ms : flood wave celerity used to convert distance to
        travel time. ~1-3 m/s is typical for natural channels; the
        default 1.0 m/s is deliberately conservative (slower celerity =
        more spread between sub-basin arrivals = lower combined peak, so
        this is not the assumption that inflates results).
    """
    try:
        from .hydrological_calculations import (
            calculate_scs_cn_runoff, calculate_time_to_peak,
            generate_scs_unit_hydrograph, generate_flood_hydrograph)
    except ImportError:
        from hydrological_calculations import (
            calculate_scs_cn_runoff, calculate_time_to_peak,
            generate_scs_unit_hydrograph, generate_flood_hydrograph)

    class _Quiet:
        def pushInfo(self, m): pass
        def pushWarning(self, m): pass

    per_basin = []
    for sb in subbasins:
        cn_sb = zonal_mean(cn_raster_path, sb['geometry'], cn_default,
                            valid_range=(1, 100))
        Q_mm = float(calculate_scs_cn_runoff([design_rain_mm], cn_sb)[0])

        # Flow length within the sub-basin, approximated from its area.
        # This is a standard shape-based estimate (L ~ 1.4*sqrt(A) for a
        # roughly compact basin) used when a traced flow path per
        # sub-basin isn't available.
        L_sb_m = 1400.0 * np.sqrt(max(sb['area_km2'], 1e-6))
        tp_sb = calculate_time_to_peak(L_sb_m, slope_pct, cn_sb, _Quiet(),
                                        duration_hr=storm_dur_hr)
        t_uh, q_uh = generate_scs_unit_hydrograph(sb['area_km2'], tp_sb, _Quiet())
        t_fh, q_fh = generate_flood_hydrograph(t_uh, q_uh, Q_mm, _Quiet())

        lag_hr = sb['dist_to_outlet_m'] / max(wave_celerity_ms, 0.01) / 3600.0
        per_basin.append({
            'name': sb['name'], 'area_km2': sb['area_km2'], 'cn': cn_sb,
            'runoff_mm': Q_mm, 'tp_hr': tp_sb,
            'lag_to_outlet_hr': lag_hr,
            'peak_local_m3s': float(np.max(q_fh)) if len(q_fh) else 0.0,
            'time': np.asarray(t_fh, dtype=np.float64) + lag_hr,
            'discharge': np.asarray(q_fh, dtype=np.float64),
        })

    if not per_basin:
        return None

    # Common time base spanning every lagged hydrograph
    t_max = max(float(np.max(b['time'])) for b in per_basin)
    dt = min(0.25, max(0.05, t_max / 600.0))
    t_common = np.arange(0.0, t_max + dt, dt)

    combined = np.zeros_like(t_common)
    for b in per_basin:
        combined += np.interp(t_common, b['time'], b['discharge'],
                               left=0.0, right=0.0)

    peak_combined = float(np.max(combined)) if len(combined) else 0.0
    sum_of_local_peaks = sum(b['peak_local_m3s'] for b in per_basin)

    if feedback:
        feedback.pushInfo(
            f"  Combined {len(per_basin)} sub-basin hydrographs at the pour point: "
            f"peak={peak_combined:.2f} m³/s"
        )
        feedback.pushInfo(
            f"    Sum of individual sub-basin peaks = {sum_of_local_peaks:.2f} m³/s. "
            f"The combined peak is lower because sub-basins do NOT all peak at "
            f"the same moment — that timing offset is exactly what a lumped "
            f"calculation misses."
        )
        lags = [b['lag_to_outlet_hr'] for b in per_basin]
        feedback.pushInfo(
            f"    Travel time to pour point ranges {min(lags):.2f} – {max(lags):.2f} hr "
            f"(at {wave_celerity_ms:.1f} m/s wave celerity)"
        )

    return {
        'time_hr': t_common, 'discharge_m3s': combined,
        'peak_m3s': peak_combined,
        'sum_of_local_peaks_m3s': sum_of_local_peaks,
        'per_basin': per_basin,
    }


def write_subbasin_summary(result, output_dir, return_period, feedback=None):
    """Save a per-sub-basin table so the contribution of each is visible
    rather than hidden inside a single combined number."""
    if not result:
        return None
    try:
        import pandas as pd
        rows = [{
            'Sub-basin': b['name'],
            'Area (km2)': round(b['area_km2'], 3),
            'CN': round(b['cn'], 1),
            'Runoff depth (mm)': round(b['runoff_mm'], 2),
            'Time to peak (hr)': round(b['tp_hr'], 2),
            'Lag to outlet (hr)': round(b['lag_to_outlet_hr'], 2),
            'Local peak (m3/s)': round(b['peak_local_m3s'], 2),
        } for b in result['per_basin']]
        df = pd.DataFrame(rows).sort_values('Area (km2)', ascending=False)
        out_dir = os.path.join(output_dir, 'subbasins')
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, f'subbasin_contributions_{return_period}yr.csv')
        df.to_csv(path, index=False)
        if feedback:
            feedback.pushInfo(f"  Sub-basin contributions saved: {os.path.basename(path)}")
        return path
    except Exception as e:
        if feedback:
            feedback.pushWarning(f"  Could not write sub-basin summary: {e}")
        return None
