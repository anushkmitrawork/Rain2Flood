"""
Rainfall Data Downloader – Processing Algorithm (v2)
Wraps all rainfall_data_sources functions for the QGIS Processing Toolbox.
"""
import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
try:
    from . import plot_style as _ps
except ImportError:
    import plot_style as _ps
_ps.apply_style()

from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterEnum,
    QgsProcessingParameterString, QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination, QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber, QgsProcessingException,
    QgsProcessing, QgsProcessingParameterPoint, QgsProcessingParameterDateTime,
    QgsProcessingOutputFile, QgsProcessingOutputFolder,
)
from qgis.PyQt.QtCore import QDateTime, QDate, QTime

try:
    from .rainfall_data_sources import (
        download_openmeteo_data, download_openmeteo_hourly_data,
        download_gpm_imerg_daily, download_noaa_ghcnd_nearest,
        download_imd_data, load_chirps_data, load_excel_rainfall_data,
        quality_control_rainfall, generate_synthetic_rainfall,
    )
except ImportError:
    from rainfall_data_sources import (
        download_openmeteo_data, download_openmeteo_hourly_data,
        download_gpm_imerg_daily, download_noaa_ghcnd_nearest,
        download_imd_data, load_chirps_data, load_excel_rainfall_data,
        quality_control_rainfall, generate_synthetic_rainfall,
    )


class RainfallDataDownloader(QgsProcessingAlgorithm):
    SOURCE         = 'SOURCE'
    LATITUDE       = 'LATITUDE'
    LONGITUDE      = 'LONGITUDE'
    COORDINATES_POINT  = 'COORDINATES_POINT'
    COORDINATES_MANUAL = 'COORDINATES_MANUAL'
    START_DATE     = 'START_DATE'
    END_DATE       = 'END_DATE'
    EXCEL_FILE     = 'EXCEL_FILE'
    DATE_COLUMN    = 'DATE_COLUMN'
    RAINFALL_COLUMN = 'RAINFALL_COLUMN'
    CHIRPS_FOLDER  = 'CHIRPS_FOLDER'
    OUTPUT_FOLDER  = 'OUTPUT_FOLDER'
    GENERATE_GRAPHS = 'GENERATE_GRAPHS'
    OUTPUT_EXCEL   = 'OUTPUT_EXCEL'
    OUTPUT_GRAPHS  = 'OUTPUT_GRAPHS'

    SOURCES = [
        'Open-Meteo ERA5 (Daily, Global, Free)',
        'Open-Meteo ERA5 (Hourly, Global, Free)',
        'Open-Meteo CERRA (Hourly, Europe, Free)',
        'NASA POWER (Daily, Global, Free)',
        'NOAA GHCND (Nearest Station, Free)',
        'IMD Gridded 0.25° (India)',
        'CHIRPS 0.05° (Local NetCDF files)',
        'Excel / CSV file',
        'Synthetic (planning only)',
    ]

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.SOURCE, 'Data Source', options=self.SOURCES, defaultValue=0))
        self.addParameter(QgsProcessingParameterPoint(
            self.COORDINATES_POINT, 'Select Location on Map', optional=True, defaultValue=''))
        self.addParameter(QgsProcessingParameterString(
            self.COORDINATES_MANUAL, 'Manual Coordinates (Lat, Lon)',
            defaultValue='20.0, 77.0', optional=True))
        self.addParameter(QgsProcessingParameterDateTime(
            self.START_DATE, 'Start Date',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate().addDays(-3650), QTime(0, 0, 0))))
        self.addParameter(QgsProcessingParameterDateTime(
            self.END_DATE, 'End Date',
            type=QgsProcessingParameterDateTime.DateTime,
            defaultValue=QDateTime(QDate.currentDate(), QTime(0, 0, 0))))
        self.addParameter(QgsProcessingParameterFile(
            self.EXCEL_FILE, 'Excel/CSV File', optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.DATE_COLUMN, 'Date Column Name', defaultValue='Date', optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.RAINFALL_COLUMN, 'Rainfall Column Name', defaultValue='Rainfall_mm', optional=True))
        self.addParameter(QgsProcessingParameterFile(
            self.CHIRPS_FOLDER, 'CHIRPS NetCDF Folder', optional=True,
            behavior=QgsProcessingParameterFile.Folder))
        self.addParameter(QgsProcessingParameterBoolean(
            self.GENERATE_GRAPHS, 'Generate Rainfall Graphs', defaultValue=True))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_FOLDER, 'Output Folder'))
        self.addOutput(QgsProcessingOutputFile(self.OUTPUT_EXCEL, 'Rainfall Excel File'))
        self.addOutput(QgsProcessingOutputFolder(self.OUTPUT_GRAPHS, 'Graphs Folder'))

    def processAlgorithm(self, parameters, context, feedback):
        src = self.parameterAsEnum(parameters, self.SOURCE, context)

        # Coordinates
        point  = self.parameterAsPoint(parameters, self.COORDINATES_POINT, context)
        manual = self.parameterAsString(parameters, self.COORDINATES_MANUAL, context)
        if point and not point.isEmpty():
            lat, lon = point.y(), point.x()
        elif manual and manual.strip():
            parts = manual.split(',')
            lat, lon = float(parts[0].strip()), float(parts[1].strip())
        else:
            lat, lon = 20.0, 77.0

        start_dt = self.parameterAsDateTime(parameters, self.START_DATE, context)
        end_dt   = self.parameterAsDateTime(parameters, self.END_DATE, context)
        start_str = start_dt.toString('yyyy-MM-dd')
        end_str   = end_dt.toString('yyyy-MM-dd')
        start_yr, end_yr = int(start_str[:4]), int(end_str[:4])

        out_dir = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        os.makedirs(out_dir, exist_ok=True)

        feedback.pushInfo(f"Source: {self.SOURCES[src]}  |  lat={lat:.4f}, lon={lon:.4f}")
        feedback.pushInfo(f"Period: {start_str} → {end_str}")

        # ── Download ─────────────────────────────────────────────────────
        df = None
        if src == 0:
            df = download_openmeteo_data(lat, lon, start_str, end_str, feedback)
        elif src == 1:
            df = download_openmeteo_hourly_data(lat, lon, start_str, end_str, feedback, 'era5')
        elif src == 2:
            df = download_openmeteo_hourly_data(lat, lon, start_str, end_str, feedback, 'cerra')
        elif src == 3:
            df = download_gpm_imerg_daily(lat, lon, start_str, end_str, feedback)
        elif src == 4:
            df = download_noaa_ghcnd_nearest(lat, lon, start_str, end_str, feedback=feedback)
        elif src == 5:
            xls_dir = self.parameterAsString(parameters, self.EXCEL_FILE, context)
            df = download_imd_data(lat, lon, start_yr, end_yr, xls_dir or out_dir, feedback)
        elif src == 6:
            chirps_dir = self.parameterAsString(parameters, self.CHIRPS_FOLDER, context)
            df = load_chirps_data(chirps_dir, lat, lon, start_yr, end_yr, feedback)
        elif src == 7:
            xls = self.parameterAsString(parameters, self.EXCEL_FILE, context)
            dc  = self.parameterAsString(parameters, self.DATE_COLUMN, context)
            rc  = self.parameterAsString(parameters, self.RAINFALL_COLUMN, context)
            df  = load_excel_rainfall_data(xls, dc, rc, feedback)
        else:
            df = generate_synthetic_rainfall(100.0, feedback=feedback)

        if df is None or df.empty:
            raise QgsProcessingException("No rainfall data retrieved.")

        df, qc = quality_control_rainfall(df, feedback=feedback)
        feedback.pushInfo(f"QC: {qc}")

        # ── Save Excel ────────────────────────────────────────────────────
        src_name   = self.SOURCES[src].split('(')[0].strip()
        excel_path = os.path.join(out_dir, 'rainfall_data.xlsx')
        col_name   = 'Rainfall (mm)'
        try:
            with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Rainfall Data')
                meta = pd.DataFrame({
                    'Parameter': ['Source', 'Latitude', 'Longitude', 'Start', 'End',
                                  'Records', 'Max (mm)', 'Mean (mm)', 'Zero days %'],
                    'Value': [src_name, lat, lon, start_str, end_str,
                              len(df), df[col_name].max(), df[col_name].mean(),
                              qc.get('zero_day_pct', '-')]
                })
                meta.to_excel(writer, sheet_name='Metadata', index=False)
                # Annual maxima
                try:
                    ann = df[col_name].resample('Y').max().reset_index()
                    ann.columns = ['Year', 'Annual Max (mm)']
                    ann.to_excel(writer, sheet_name='Annual Maxima', index=False)
                except Exception:
                    pass
            feedback.pushInfo(f"Saved: {excel_path}")
        except Exception as e:
            feedback.pushWarning(f"Excel save failed ({e}), saving CSV.")
            csv_path = excel_path.replace('.xlsx', '.csv')
            df.to_csv(csv_path)
            excel_path = csv_path

        # ── Graphs ────────────────────────────────────────────────────────
        if self.parameterAsBoolean(parameters, self.GENERATE_GRAPHS, context):
            self._make_graphs(df, out_dir, src_name, feedback)

        return {self.OUTPUT_EXCEL: excel_path, self.OUTPUT_GRAPHS: out_dir}

    def _make_graphs(self, df, out_dir, src_name, feedback):
        col = 'Rainfall (mm)'
        try:
            # Time series
            fig, ax = plt.subplots(figsize=(13, 5))
            ax.bar(df.index, df[col], color='steelblue', width=0.8, alpha=0.7)
            ax.set_title(f'{src_name} – Rainfall Time Series', fontweight='bold')
            ax.set_xlabel('Date'); ax.set_ylabel('Rainfall (mm)')
            ax.grid(True, ls='--', alpha=0.4)
            fig.savefig(os.path.join(out_dir, 'rainfall_timeseries.png'),
                        dpi=200, bbox_inches='tight', facecolor='white')
            plt.close(fig)

            # Monthly totals
            try:
                monthly = df[col].resample('ME').sum()
            except Exception:
                monthly = df[col].resample('M').sum()
            fig, ax = plt.subplots(figsize=(12, 5))
            ax.bar(monthly.index, monthly.values, color='dodgerblue', alpha=0.8)
            ax.set_title(f'{src_name} – Monthly Totals', fontweight='bold')
            ax.set_xlabel('Month'); ax.set_ylabel('Total Rainfall (mm)')
            ax.grid(True, ls='--', alpha=0.4)
            plt.xticks(rotation=45)
            fig.tight_layout()
            fig.savefig(os.path.join(out_dir, 'monthly_rainfall.png'),
                        dpi=200, bbox_inches='tight', facecolor='white')
            plt.close(fig)

            # Histogram
            rain_pos = df[col][df[col] > 0.1]
            if len(rain_pos) > 0:
                fig, ax = plt.subplots(figsize=(9, 5))
                ax.hist(rain_pos, bins=50, color='teal', alpha=0.75, edgecolor='white')
                ax.set_title(f'{src_name} – Rainfall Distribution (wet days only)', fontweight='bold')
                ax.set_xlabel('Rainfall (mm)'); ax.set_ylabel('Frequency')
                ax.grid(True, ls='--', alpha=0.4)
                fig.tight_layout()
                fig.savefig(os.path.join(out_dir, 'rainfall_distribution.png'),
                            dpi=200, bbox_inches='tight', facecolor='white')
                plt.close(fig)

            # Annual maxima
            try:
                ann = df[col].resample('Y').max().dropna()
                if len(ann) >= 2:
                    n    = len(ann)
                    rp   = (n + 1) / np.arange(1, n + 1)
                    vals = np.sort(ann.values)[::-1]
                    fig, ax = plt.subplots(figsize=(9, 5))
                    ax.semilogy(vals, rp, 'o-', color='crimson', ms=6)
                    ax.set_xlabel('Annual Max Rainfall (mm)')
                    ax.set_ylabel('Return Period (years)')
                    ax.set_title('Annual Maximum Rainfall – Empirical Return Periods', fontweight='bold')
                    ax.grid(True, ls='--', alpha=0.4)
                    fig.tight_layout()
                    fig.savefig(os.path.join(out_dir, 'annual_maxima_return_periods.png'),
                                dpi=200, bbox_inches='tight', facecolor='white')
                    plt.close(fig)
            except Exception:
                pass

            feedback.pushInfo(f"Graphs saved to: {out_dir}")
        except Exception as e:
            feedback.pushWarning(f"Graph generation error: {e}")

    def name(self):           return 'rainfall_data_downloader'
    def displayName(self):    return 'Rainfall Data Downloader'
    def group(self):          return 'Hydrology'
    def groupId(self):        return 'hydrology'
    def createInstance(self): return RainfallDataDownloader()
