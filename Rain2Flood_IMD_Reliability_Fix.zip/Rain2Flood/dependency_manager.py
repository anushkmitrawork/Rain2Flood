import os
import sys
import subprocess
import importlib
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QMessageBox, QPushButton, QApplication

# Qt6 / PyQt6 enum compatibility. PyQt6 requires the fully-qualified enum
# (Qt.TextFormat.RichText, QMessageBox.Icon.Warning, ...); PyQt5 accepts
# both forms. Try the PyQt6 form first, fall back to the PyQt5 shorthand
# — never fall back to referencing the not-yet-assigned name itself.
try:
    _QMsg_Warning    = QMessageBox.Icon.Warning
    _QMsg_ActionRole = QMessageBox.ButtonRole.ActionRole
    _QMsg_Ok         = QMessageBox.StandardButton.Ok
except AttributeError:
    _QMsg_Warning    = QMessageBox.Warning        # type: ignore
    _QMsg_ActionRole = QMessageBox.ActionRole      # type: ignore
    _QMsg_Ok         = QMessageBox.Ok              # type: ignore

try:
    _Qt_RichText = Qt.TextFormat.RichText
except AttributeError:
    _Qt_RichText = Qt.RichText                     # type: ignore



REQUIRED = [
    'numpy', 'pandas', 'scipy', 'matplotlib', 'openpyxl',
    'rasterio', 'geopandas', 'shapely', 'xarray',
]
OPTIONAL = ['imdlib']

INSTALL_CMD = (
    'pip install numpy pandas scipy matplotlib openpyxl '
    'rasterio geopandas shapely xarray --break-system-packages'
)
# Streams & Sub-basins uses GRASS (r.watershed, r.to.vect) through QGIS's
# own Processing framework rather than a separate Python package. GRASS
# ships with the QGIS standalone installer; if it's not showing up, enable
# the "Processing GRASS Provider" plugin (Plugins > Manage and Install
# Plugins) and check Processing > Options > Providers > GRASS.


class DependencyManager:
    @staticmethod
    def check_dependencies():
        missing = []
        for pkg in REQUIRED:
            try:
                importlib.import_module(pkg)
            except ImportError:
                missing.append(pkg)
        return missing

    @staticmethod
    def show_install_dialog(parent=None):
        missing = DependencyManager.check_dependencies()
        if not missing:
            return
        msg = QMessageBox(parent)
        msg.setIcon(_QMsg_Warning)
        msg.setWindowTitle('Rain2Flood v3.0 – Missing Dependencies')
        msg.setText(
            f'<b>Missing packages:</b> {", ".join(missing)}<br><br>'
            'Run this command in OSGeo4W Shell or terminal:<br>'
            f'<code>{INSTALL_CMD}</code><br><br>'
            'Restart QGIS after installation.'
        )
        msg.setTextFormat(_Qt_RichText)
        btn_copy  = QPushButton('Copy Command')
        btn_shell = QPushButton('Open OSGeo4W Shell')
        msg.addButton(btn_copy,  _QMsg_ActionRole)
        msg.addButton(btn_shell, _QMsg_ActionRole)
        msg.addButton(_QMsg_Ok)
        msg.exec()
        if msg.clickedButton() == btn_copy:
            QApplication.clipboard().setText(INSTALL_CMD)
        elif msg.clickedButton() == btn_shell:
            DependencyManager._open_osgeo_shell()

    @staticmethod
    def _open_osgeo_shell():
        for path in [
            r'C:\OSGeo4W\OSGeo4W.bat',
            r'C:\Program Files\QGIS 3.38\OSGeo4W.bat',
            r'C:\Program Files\QGIS 3.36\OSGeo4W.bat',
            r'C:\Program Files\QGIS 3.34\OSGeo4W.bat',
            r'C:\Program Files\QGIS 3.32\OSGeo4W.bat',
        ]:
            if os.path.exists(path):
                subprocess.Popen(['start', path], shell=True)
                return
        QMessageBox.information(
            None, 'OSGeo4W Shell',
            'Could not locate OSGeo4W Shell. Open it from Start → QGIS → OSGeo4W Shell.'
        )
