"""
Channel Geometry from DEM
=========================
Extract cross-sections perpendicular to a stream centreline, sample the
DEM along them, and derive hydraulic properties (area, wetted perimeter,
hydraulic radius, top width) and a stage-discharge rating curve via
Manning's equation.

Why this matters: elsewhere this plugin estimates channel width from a
regime equation (width as a power function of discharge), which is a
rough regional generalisation. Where a reasonable DEM exists, measuring
the actual valley cross-section is a real improvement over that guess —
particularly for the Muskingum-Cunge routing and the flood-mapping depth
calculation, both of which are sensitive to channel geometry.

Honest limitation, stated up front: a DEM captures the ground surface,
which in a wet channel is the WATER surface, not the bed. So extracted
sections are really valley/floodplain sections with the channel bed
truncated at whatever the water level was when the DEM was acquired.
For bankfull and above (the flood range this plugin cares about) that's
usually acceptable; for low-flow hydraulics it is not, and a surveyed
section should be used instead. Bathymetric correction is not attempted
here because guessing at unseen bed depth would be inventing data.
"""

import os
import numpy as np


def _perpendicular_offsets(x1, y1, x2, y2, width_m, n_points):
    """Sample points along a line perpendicular to the segment (x1,y1)-(x2,y2),
    centred on its midpoint."""
    dx, dy = x2 - x1, y2 - y1
    length = np.hypot(dx, dy)
    if length == 0:
        return None, None, None
    # Unit normal to the segment
    nx, ny = -dy / length, dx / length
    cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
    offs = np.linspace(-width_m / 2.0, width_m / 2.0, n_points)
    return cx + nx * offs, cy + ny * offs, offs


def extract_cross_sections(dem_path, stream_path, n_sections=10,
                            section_width_m=500.0, n_points=61, feedback=None):
    """
    Extract evenly-spaced cross-sections perpendicular to a stream layer.

    Returns a list of dicts, each with 'offsets_m' (distance across the
    section) and 'elevations_m', plus the section's centre coordinates.
    """
    try:
        import rasterio
        import geopandas as gpd
        from shapely.geometry import LineString, MultiLineString
    except ImportError:
        if feedback:
            feedback.reportError("rasterio and geopandas are required for cross-section extraction.")
        return []

    try:
        streams = gpd.read_file(stream_path)
    except Exception as e:
        if feedback:
            feedback.reportError(f"Could not read stream layer: {e}")
        return []
    if streams.empty:
        if feedback:
            feedback.pushWarning("Stream layer has no features.")
        return []

    with rasterio.open(dem_path) as src:
        dem_crs = src.crs
        if streams.crs is not None and str(streams.crs) != str(dem_crs):
            streams = streams.to_crs(dem_crs)

        # Use the longest stream as the main channel — cross-sections on
        # tiny headwater tributaries aren't representative of the reach
        # that actually conveys the flood.
        geoms = []
        for g in streams.geometry:
            if g is None or g.is_empty:
                continue
            if isinstance(g, MultiLineString):
                geoms.extend(list(g.geoms))
            elif isinstance(g, LineString):
                geoms.append(g)
        if not geoms:
            if feedback:
                feedback.pushWarning("No line geometries found in the stream layer.")
            return []
        main = max(geoms, key=lambda g: g.length)
        if feedback:
            feedback.pushInfo(
                f"  Main channel: {main.length/1000.0:.2f} km "
                f"(longest of {len(geoms)} stream segments)")

        # Space sections evenly along the main channel, skipping the very
        # ends where a perpendicular section is poorly defined.
        fracs = np.linspace(0.05, 0.95, max(2, n_sections))
        sections = []
        for i, f in enumerate(fracs):
            d = f * main.length
            p_mid = main.interpolate(d)
            step = max(main.length * 0.005, 1.0)
            p_a = main.interpolate(max(0.0, d - step))
            p_b = main.interpolate(min(main.length, d + step))

            xs, ys, offs = _perpendicular_offsets(
                p_a.x, p_a.y, p_b.x, p_b.y, section_width_m, n_points)
            if xs is None:
                continue
            try:
                vals = list(src.sample(list(zip(xs, ys))))
                elev = np.array([v[0] for v in vals], dtype=np.float64)
            except Exception:
                continue
            nod = src.nodata
            if nod is not None:
                elev = np.where(elev == nod, np.nan, elev)
            elev = np.where(elev < -1000, np.nan, elev)
            if np.sum(np.isfinite(elev)) < n_points * 0.5:
                continue  # section mostly off the DEM — skip rather than guess
            sections.append({
                'index': i + 1,
                'chainage_m': float(d),
                'centre_x': float(p_mid.x), 'centre_y': float(p_mid.y),
                'offsets_m': offs,
                'elevations_m': elev,
            })

    if feedback:
        feedback.pushInfo(
            f"  Extracted {len(sections)} usable cross-section(s) of "
            f"{len(fracs)} attempted.")
    return sections


def section_hydraulics(offsets_m, elevations_m, water_elev):
    """
    Hydraulic properties of one cross-section at a given water surface
    elevation: flow area, wetted perimeter, hydraulic radius, top width.

    Computed by trapezoidal integration between consecutive station
    pairs, handling the partially-submerged panels at the water's edge
    by interpolating the exact waterline crossing — without that, area
    is quantised to the sampling interval and systematically wrong for
    narrow channels.
    """
    x = np.asarray(offsets_m, dtype=np.float64)
    z = np.asarray(elevations_m, dtype=np.float64)
    ok = np.isfinite(z)
    x, z = x[ok], z[ok]
    if len(x) < 2:
        return {'area_m2': 0.0, 'wetted_perimeter_m': 0.0,
                'hydraulic_radius_m': 0.0, 'top_width_m': 0.0}

    area = 0.0
    perim = 0.0
    top_w = 0.0
    for i in range(len(x) - 1):
        x1, x2, z1, z2 = x[i], x[i + 1], z[i], z[i + 1]
        d1, d2 = water_elev - z1, water_elev - z2
        if d1 <= 0 and d2 <= 0:
            continue  # panel entirely above water
        if d1 > 0 and d2 > 0:
            xa, xb, da, db = x1, x2, d1, d2
        else:
            # Partially submerged: interpolate the waterline crossing
            frac = d1 / (d1 - d2)
            xc = x1 + frac * (x2 - x1)
            if d1 > 0:
                xa, xb, da, db = x1, xc, d1, 0.0
            else:
                xa, xb, da, db = xc, x2, 0.0, d2
        dx = xb - xa
        if dx <= 0:
            continue
        area += 0.5 * (da + db) * dx
        perim += np.hypot(dx, da - db)
        top_w += dx

    R = area / perim if perim > 0 else 0.0
    return {'area_m2': area, 'wetted_perimeter_m': perim,
            'hydraulic_radius_m': R, 'top_width_m': top_w}


def rating_curve(offsets_m, elevations_m, slope, manning_n,
                  n_stages=20, feedback=None):
    """
    Stage-discharge rating curve for one cross-section via Manning's:
        Q = (1/n) * A * R^(2/3) * S^(1/2)

    Returns a list of dicts (stage_m, depth_m, area_m2, top_width_m,
    hydraulic_radius_m, discharge_m3s), from the section's lowest point
    up to its lowest bank (beyond which flow would spill out of the
    section and the 1D assumption breaks down).
    """
    z = np.asarray(elevations_m, dtype=np.float64)
    z = z[np.isfinite(z)]
    if len(z) < 3:
        return []
    z_min = float(np.min(z))
    # Cap at the LOWER of the two bank elevations — above that the water
    # leaves the surveyed section, so any discharge computed from this
    # section alone would be meaningless.
    z_cap = float(min(z[0], z[-1]))
    if z_cap <= z_min:
        z_cap = z_min + max(1.0, 0.1 * (float(np.max(z)) - z_min))

    S = max(float(slope), 1e-5)
    n = max(float(manning_n), 1e-4)

    rows = []
    for we in np.linspace(z_min, z_cap, n_stages)[1:]:
        h = section_hydraulics(offsets_m, elevations_m, we)
        A, R = h['area_m2'], h['hydraulic_radius_m']
        Q = (1.0 / n) * A * (R ** (2.0 / 3.0)) * np.sqrt(S) if A > 0 and R > 0 else 0.0
        rows.append({
            'stage_m': float(we), 'depth_m': float(we - z_min),
            'area_m2': A, 'top_width_m': h['top_width_m'],
            'hydraulic_radius_m': R, 'discharge_m3s': float(Q),
        })
    return rows


def analyse_channel_geometry(dem_path, stream_path, slope, manning_n,
                              output_dir, n_sections=10, section_width_m=500.0,
                              feedback=None):
    """
    Full workflow: extract sections, compute rating curves, save a CSV
    and a plot, and report a representative bankfull width that can
    replace the regime-equation width guess used elsewhere.
    """
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        from . import plot_style as _ps
    except ImportError:
        import plot_style as _ps

    sections = extract_cross_sections(
        dem_path, stream_path, n_sections, section_width_m, feedback=feedback)
    if not sections:
        return None

    out_dir = os.path.join(output_dir, 'channel_geometry')
    os.makedirs(out_dir, exist_ok=True)

    rows, widths = [], []
    for sec in sections:
        rc = rating_curve(sec['offsets_m'], sec['elevations_m'],
                           slope, manning_n, feedback=feedback)
        if not rc:
            continue
        top = rc[-1]
        widths.append(top['top_width_m'])
        for r in rc:
            rows.append({'Section': sec['index'],
                         'Chainage (m)': round(sec['chainage_m'], 1), **{
                             k: round(v, 4) for k, v in r.items()}})

    if not rows:
        if feedback:
            feedback.pushWarning("  No usable rating curves could be derived.")
        return None

    df = pd.DataFrame(rows)
    csv_path = os.path.join(out_dir, 'channel_rating_curves.csv')
    df.to_csv(csv_path, index=False)

    rep_width = float(np.median(widths)) if widths else None

    # Plot: section profiles + rating curves side by side
    try:
        _ps.apply_style()
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))
        for sec in sections[:6]:
            z = sec['elevations_m']
            ax1.plot(sec['offsets_m'], z, lw=1.6,
                     label=f"Sec {sec['index']} @ {sec['chainage_m']/1000:.1f} km")
        _ps.style_axis(ax1, 'Extracted Cross-Sections', 'Offset from centreline (m)',
                        'Elevation (m)')
        for s_id, grp in df.groupby('Section'):
            if s_id > 6:
                break
            ax2.plot(grp['discharge_m3s'], grp['depth_m'], lw=1.6, label=f'Sec {s_id}')
        _ps.style_axis(ax2, 'Stage-Discharge Rating Curves',
                        'Discharge (m³/s)', 'Depth above thalweg (m)')
        plt.tight_layout()
        png_path = os.path.join(out_dir, 'channel_geometry.png')
        plt.savefig(png_path, dpi=160, bbox_inches='tight', facecolor='white')
        plt.close(fig)
    except Exception as e:
        png_path = None
        if feedback:
            feedback.pushWarning(f"  Channel geometry plot failed: {e}")

    if feedback:
        feedback.pushInfo(f"  Rating curves saved: {os.path.basename(csv_path)}")
        if rep_width:
            feedback.pushInfo(
                f"  Representative top width at the highest usable stage: "
                f"{rep_width:.1f} m (median of {len(widths)} sections) — this is "
                f"measured from the DEM rather than estimated from a regime "
                f"equation.")
        feedback.pushWarning(
            "  Note: DEM surfaces represent the WATER surface in wet channels, "
            "not the bed, so these sections truncate the channel below the "
            "water level present when the DEM was captured. Adequate for "
            "bankfull-and-above flood work; use surveyed sections for "
            "low-flow hydraulics."
        )

    return {'sections': sections, 'rating_df': df, 'csv_path': csv_path,
            'plot_path': png_path, 'representative_width_m': rep_width}
