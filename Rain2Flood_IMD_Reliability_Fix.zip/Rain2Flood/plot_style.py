"""
Shared plot styling
=====================
A small, centralised styling module so every chart in the plugin
(hydrographs, IDF curves, hyetographs, rainfall time series) shares one
consistent, polished look, instead of each plotting function using
matplotlib's basic defaults.

Usage: call apply_style() once near the top of any function that creates
a figure, before calling plt.subplots()/plt.figure().
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

PALETTE = ['#1565C0', '#2E7D32', '#EF6C00', '#8E24AA',
           '#C62828', '#00838F', '#6D4C41', '#AD1457']

GRID_COLOR   = '#D5D8DC'
SPINE_COLOR  = '#5D6D7E'
TEXT_COLOR   = '#2C3E50'
BG_COLOR     = '#FFFFFF'
PANEL_COLOR  = '#FAFBFC'


def apply_style():
    """Apply a shared, polished matplotlib style. Cheap and idempotent —
    safe to call at the top of every plotting function."""
    plt.rcParams.update({
        'figure.facecolor':  BG_COLOR,
        'axes.facecolor':    PANEL_COLOR,
        'axes.edgecolor':    SPINE_COLOR,
        'axes.linewidth':    0.9,
        'axes.labelcolor':   TEXT_COLOR,
        'axes.titlecolor':   TEXT_COLOR,
        'axes.titleweight':  'bold',
        'axes.titlesize':    13,
        'axes.labelsize':    10.5,
        'axes.labelweight':  'medium',
        'axes.grid':         True,
        'axes.axisbelow':    True,
        'grid.color':        GRID_COLOR,
        'grid.linewidth':    0.7,
        'grid.alpha':        0.9,
        'xtick.color':       TEXT_COLOR,
        'ytick.color':       TEXT_COLOR,
        'xtick.labelsize':   9.5,
        'ytick.labelsize':   9.5,
        'legend.frameon':    True,
        'legend.framealpha': 0.92,
        'legend.edgecolor':  GRID_COLOR,
        'legend.fontsize':   9.5,
        'legend.fancybox':   True,
        'font.family':       'sans-serif',
        'font.sans-serif':   ['DejaVu Sans', 'Arial', 'Helvetica'],
        'figure.dpi':        150,
        'savefig.dpi':       160,
        'savefig.facecolor': BG_COLOR,
        'lines.linewidth':   2.0,
        'lines.solid_capstyle': 'round',
    })


def style_axis(ax, title=None, xlabel=None, ylabel=None, legend_loc='best'):
    """Apply consistent titling/labelling/spine treatment to one axis."""
    if title:
        ax.set_title(title, pad=10)
    if xlabel:
        ax.set_xlabel(xlabel)
    if ylabel:
        ax.set_ylabel(ylabel)
    for spine in ('top', 'right'):
        ax.spines[spine].set_visible(False)
    for spine in ('left', 'bottom'):
        ax.spines[spine].set_color(SPINE_COLOR)
    ax.tick_params(length=3.5, width=0.8)
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        leg = ax.legend(loc=legend_loc, fontsize=9.5)
        leg.get_frame().set_linewidth(0.7)


def gradient_fill(ax, x, y, color, alpha_top=0.35, baseline=0.0):
    """Fill under a curve with a soft vertical gradient instead of one
    flat translucent block."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) < 2:
        return
    z = np.empty((100, 1, 4), dtype=float)
    rgb = matplotlib.colors.to_rgb(color)
    z[:, 0, :3] = rgb
    z[:, 0, 3] = np.linspace(0, alpha_top, 100)
    xmin, xmax = float(np.min(x)), float(np.max(x))
    ymin, ymax = baseline, float(np.max(y)) if np.max(y) > baseline else baseline + 1.0
    im = ax.imshow(z, aspect='auto', extent=[xmin, xmax, ymin, ymax],
                    origin='lower', zorder=1)
    poly = ax.fill_between(x, y, baseline, color='none', zorder=2)
    im.set_clip_path(poly.get_paths()[0], transform=ax.transData)


def annotate_peak(ax, x_peak, y_peak, label_fmt="Peak: {y:.1f}", color='#C62828',
                   xytext=(12, 14)):
    """Mark and label the peak point of a curve."""
    ax.plot([x_peak], [y_peak], marker='o', markersize=6.5,
            markerfacecolor=color, markeredgecolor='white',
            markeredgewidth=1.3, zorder=5)
    ax.annotate(
        label_fmt.format(y=y_peak, x=x_peak),
        xy=(x_peak, y_peak), xytext=xytext, textcoords='offset points',
        fontsize=9, fontweight='bold', color=color,
        arrowprops=dict(arrowstyle='-', color=color, lw=1.0, alpha=0.7),
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                  edgecolor=color, linewidth=0.8, alpha=0.95)
    )


def format_thousands(ax, axis='y'):
    """Comma-separated thousands on an axis."""
    fmt = mticker.FuncFormatter(lambda v, _: f'{v:,.0f}')
    (ax.yaxis if axis == 'y' else ax.xaxis).set_major_formatter(fmt)
